import discord
from discord.ext import commands
from discord.ui import View, Select, Modal, TextInput, Button
import asyncio
import json
import os
import logging

# Configuração de Logs para monitorar quedas
logging.basicConfig(level=logging.INFO)

# ================= CONFIGURAÇÕES =================
TOKEN = "MTQzODM1MzgyMzIzNTA1MTY0Mg.GjK93S.RPBT6-GX3XNy77U0XeEPMqfNfKcXdBPMpXLoAI" # Recomendo trocar o token imediatamente!
GUILD_ID = 1417672403382960130
STAFF_ROLE_IDS = [1419441539331002489, 1420702867148378203, 1417912504964878497]
TICKET_PARENT_CATEGORY_ID = 1477780293829132572
BANNER_URL = "https://i.postimg.cc/WzcCtxj9/6e8e2b50ce436a946142e99432b9f6b0.jpg"

EMOJI_SUCESSO = "<:2974:1438244299564126279>"
COR_EMBED = 0xFF0000

# ================= SISTEMA DE BANCO DE DADOS (JSON) =================
DATABASE_FILE = "tickets.json"

def load_tickets():
    if not os.path.exists(DATABASE_FILE):
        return {}
    with open(DATABASE_FILE, "r") as f:
        return json.load(f)

def save_ticket(channel_id, owner_id):
    data = load_tickets()
    data[str(channel_id)] = owner_id
    with open(DATABASE_FILE, "w") as f:
        json.dump(data, f, indent=4)

def remove_ticket(channel_id):
    data = load_tickets()
    if str(channel_id) in data:
        del data[str(channel_id)]
        with open(DATABASE_FILE, "w") as f:
            json.dump(data, f, indent=4)

# ================= INTENTS =================
intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)

# ================= AUXILIARES =================
def is_staff(interaction: discord.Interaction):
    return any(role.id in STAFF_ROLE_IDS for role in interaction.user.roles)

# ================= MODAIS =================

class NotifyModal(Modal, title="Notificar Usuário"):
    feedback = TextInput(label="Mensagem de Notificação", style=discord.TextStyle.paragraph, placeholder="Digite o que deseja enviar ao PV do usuário...")

    def __init__(self, owner: discord.Member):
        super().__init__()
        self.owner = owner

    async def on_submit(self, interaction: discord.Interaction):
        try:
            embed = discord.Embed(title="🔔 Notificação de Suporte", description=f"O suporte de **{interaction.guild.name}** enviou uma atualização:\n\n{self.feedback.value}", color=COR_EMBED)
            await self.owner.send(embed=embed)
            await interaction.response.send_message(f"{EMOJI_SUCESSO} Notificação enviada com sucesso!", ephemeral=True)
        except:
            await interaction.response.send_message("❌ O usuário está com a DM fechada.", ephemeral=True)

class UserManageModal(Modal):
    user_id = TextInput(label="ID do Usuário", placeholder="Insira o ID do membro aqui...")

    def __init__(self, action: str):
        super().__init__(title=f"{action} Membro")
        self.action = action

    async def on_submit(self, interaction: discord.Interaction):
        try:
            target = await interaction.guild.fetch_member(int(self.user_id.value))
            if self.action == "Adicionar":
                await interaction.channel.set_permissions(target, read_messages=True, send_messages=True)
            else:
                await interaction.channel.set_permissions(target, overwrite=None)
            await interaction.response.send_message(f"{EMOJI_SUCESSO} Usuário {self.action.lower()}do!", ephemeral=True)
        except:
            await interaction.response.send_message("❌ ID inválido ou usuário não encontrado.", ephemeral=True)

# ================= VIEWS =================

class AdminPanel(View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Add Usuário", style=discord.ButtonStyle.secondary, emoji="👤")
    async def add_user(self, interaction: discord.Interaction, button: Button):
        await interaction.response.send_modal(UserManageModal("Adicionar"))

    @discord.ui.button(label="Remover Usuário", style=discord.ButtonStyle.secondary, emoji="🚫")
    async def rem_user(self, interaction: discord.Interaction, button: Button):
        await interaction.response.send_modal(UserManageModal("Remover"))

    @discord.ui.button(label="Notificar Dono", style=discord.ButtonStyle.blurple, emoji="🔔")
    async def notify(self, interaction: discord.Interaction, button: Button):
        data = load_tickets()
        owner_id = data.get(str(interaction.channel_id))
        if owner_id:
            owner = interaction.guild.get_member(owner_id)
            if owner: await interaction.response.send_modal(NotifyModal(owner))
            else: await interaction.response.send_message("❌ Dono não encontrado.", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Erro ao localizar dono no banco de dados.", ephemeral=True)

class TicketInternalView(View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Atender", style=discord.ButtonStyle.success, custom_id="claim_btn")
    async def claim(self, interaction: discord.Interaction, button: Button):
        if not is_staff(interaction): return await interaction.response.send_message("Apenas Staff!", ephemeral=True)

        button.disabled = True
        button.style = discord.ButtonStyle.secondary
        button.label = f"Atendido por {interaction.user.name}"

        await interaction.channel.edit(name=f"✅️・atendido-{interaction.user.name}")
        await interaction.response.edit_message(view=self)
        await interaction.followup.send(f"O Staff {interaction.user.mention} assumiu o ticket!")

    @discord.ui.button(label="Painel Admin", style=discord.ButtonStyle.primary, custom_id="admin_btn")
    async def admin(self, interaction: discord.Interaction, button: Button):
        if not is_staff(interaction): return await interaction.response.send_message("Apenas Staff!", ephemeral=True)
        await interaction.response.send_message("⚙️ **Configurações Administrativas**", view=AdminPanel(), ephemeral=True)

    @discord.ui.button(label="Fechar", style=discord.ButtonStyle.danger, custom_id="close_btn")
    async def close(self, interaction: discord.Interaction, button: Button):
        if not is_staff(interaction): return await interaction.response.send_message("Apenas Staff!", ephemeral=True)

        remove_ticket(interaction.channel.id)
        await interaction.response.send_message("🔒 Este ticket será deletado em 5 segundos...")
        await asyncio.sleep(5)
        await interaction.channel.delete()

class TicketDropdown(Select):
    def __init__(self):
        # OPÇÃO DE LEILÃO REMOVIDA AQUI
        options = [
            discord.SelectOption(label="Ticket Vendas", description="Venda seu brainrot, envie foto e valor.", emoji="🧧"),
            discord.SelectOption(label="Ticket Suporte", description="Dúvidas gerais ou solicitar ajuda.", emoji="👤"),
            discord.SelectOption(label="Ticket Compras", description="Clique para comprar itens da loja.", emoji="🛒"),
            discord.SelectOption(label="Ticket Denuncias.", description="Informe o usuário e anexe as provas.", emoji="❕")
        ]
        super().__init__(placeholder="Escolha uma categoria", options=options, custom_id="dropdown_ticket")

    async def callback(self, interaction: discord.Interaction):
        category = interaction.guild.get_channel(TICKET_PARENT_CATEGORY_ID)

        overwrites = {
            interaction.guild.default_role: discord.PermissionOverwrite(read_messages=False),
            interaction.user: discord.PermissionOverwrite(read_messages=True, send_messages=True)
        }
        for role_id in STAFF_ROLE_IDS:
            role = interaction.guild.get_role(role_id)
            if role: overwrites[role] = discord.PermissionOverwrite(read_messages=True, send_messages=True)

        channel = await interaction.guild.create_text_channel(name=f"ticket-{interaction.user.name}", category=category, overwrites=overwrites)
        save_ticket(channel.id, interaction.user.id)

        embed = discord.Embed(color=COR_EMBED)
        embed.set_author(name=interaction.user.name, icon_url=interaction.user.display_avatar.url)
        embed.description = f"👋 {interaction.user.mention} seu ticket foi aberto com sucesso!"
        embed.add_field(name="Usuário", value=f"{interaction.user.name}\n({interaction.user.id})", inline=False)
        embed.add_field(name="Opção", value=self.values[0], inline=False)
        embed.set_thumbnail(url=interaction.user.display_avatar.url)
        embed.set_footer(text=f"Ticket #{channel.id}")

        await channel.send(content=f"{interaction.user.mention}", embed=embed, view=TicketInternalView())
        await interaction.response.send_message(f"{EMOJI_SUCESSO} Ticket criado com sucesso em {channel.mention}", ephemeral=True)

class SetupView(View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(TicketDropdown())

# ================= EVENTOS ANTI-QUEDA =================

@bot.event
async def on_ready():
    bot.add_view(SetupView())
    bot.add_view(TicketInternalView())
    print(f"✅ Sistema de Tickets Online como {bot.user}")

@bot.event
async def on_disconnect():
    print("⚠️ O bot desconectou. Tentando reconectar automaticamente...")

@bot.event
async def on_resumed():
    print("♻️ Conexão retomada com sucesso!")

# ================= COMANDOS =================

@bot.command()
@commands.has_permissions(administrator=True)
async def setup_ticket(ctx):
    embed = discord.Embed(
        title="ABRA SEU TICKET",
        description=(
            "> Oferecemos um suporte **rápido** e **organizado** em nosso servidor. "
            "Os suportes são resolvidos lá, poderá retirar suas dúvidas, fazer denúncias, "
            "revogar punições que não concorda, tudo isso com nossa equipe especializada de suporte."
        ),
        color=COR_EMBED
    )
    embed.set_image(url=BANNER_URL)
    await ctx.send(embed=embed, view=SetupView())

# Reconnect=True garante que a biblioteca tente reestabelecer o túnel em caso de falha de rede
bot.run(TOKEN, reconn