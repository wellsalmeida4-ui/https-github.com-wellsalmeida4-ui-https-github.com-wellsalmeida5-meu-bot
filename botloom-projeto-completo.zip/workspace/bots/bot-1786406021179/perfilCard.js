const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");
const fs = require("fs");
const path = require("path");

/* Register Poppins and NotoCJK fonts */
function registerPerfilFonts() {
    const searchDirs = [
        path.join(__dirname, "fonts"),
        path.join(process.cwd(), "fonts"),
        path.join(__dirname, "..", "fonts")
    ];
    const registeredFiles = new Set();
    for (const fontsDir of searchDirs) {
        if (!fs.existsSync(fontsDir)) continue;
        try {
            const files = fs.readdirSync(fontsDir);
            for (const file of files) {
                if (registeredFiles.has(file)) continue;
                const filePath = path.join(fontsDir, file);
                const lower = file.toLowerCase();
                if (lower.startsWith("poppins") && (lower.endsWith(".ttf") || lower.endsWith(".otf"))) {
                    try {
                        GlobalFonts.registerFromPath(filePath, "Poppins");
                        registeredFiles.add(file);
                    } catch (e) {}
                } else if ((lower.includes("noto") || lower.includes("cjk")) && (lower.endsWith(".ttf") || lower.endsWith(".otf"))) {
                    try {
                        GlobalFonts.registerFromPath(filePath, "NotoCJK");
                        registeredFiles.add(file);
                    } catch (e) {}
                }
            }
        } catch (e) {}
    }
}
registerPerfilFonts();

function getCardConfig() {
    try {
        const configPath = path.join(process.cwd(), "cardConfig.json");
        if (fs.existsSync(configPath)) {
            return JSON.parse(fs.readFileSync(configPath, "utf8"));
        }
    } catch (e) {}
    return {};
}

function cleanCanvasText(str) {
    if (!str) return "";
    let s = String(str).replace(/[\u0000-\u001F\u007F-\u009F]/g, "");
    s = s.replace(/\|/g, "").trim();
    s = s.replace(/[\uE000-\uF8FF]|\uD83C[\uDF00-\uDFFF]|\uD83D[\uDC00-\uDDFF]/g, "").trim();
    return s || str;
}

function drawRoundedRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
}

function truncateText(ctx, text, maxWidth) {
    if (!text) return "";
    if (ctx.measureText(text).width <= maxWidth) return text;
    let truncated = text;
    while (truncated.length > 0 && ctx.measureText(truncated + "...").width > maxWidth) {
        truncated = truncated.slice(0, -1);
    }
    return truncated + "...";
}

function drawVectorStar(ctx, cx, cy, spikes, outerRadius, innerRadius, fillStyle, strokeStyle) {
    let rot = (Math.PI / 2) * 3;
    let x = cx;
    let y = cy;
    let step = Math.PI / spikes;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(cx, cy - outerRadius);
    for (let i = 0; i < spikes; i++) {
        x = cx + Math.cos(rot) * outerRadius;
        y = cy + Math.sin(rot) * outerRadius;
        ctx.lineTo(x, y);
        rot += step;
        x = cx + Math.cos(rot) * innerRadius;
        y = cy + Math.sin(rot) * innerRadius;
        ctx.lineTo(x, y);
        rot += step;
    }
    ctx.lineTo(cx, cy - outerRadius);
    ctx.closePath();
    if (fillStyle) {
        ctx.fillStyle = fillStyle;
        ctx.shadowColor = fillStyle;
        ctx.shadowBlur = 6;
        ctx.fill();
    }
    if (strokeStyle) {
        ctx.strokeStyle = strokeStyle;
        ctx.lineWidth = 1.8;
        ctx.stroke();
    }
    ctx.restore();
}

function drawSparkle(ctx, cx, cy, size, color) {
    ctx.save();
    ctx.fillStyle = color || "#c084fc";
    ctx.shadowColor = color || "#c084fc";
    ctx.shadowBlur = 8;
    ctx.beginPath();
    ctx.moveTo(cx, cy - size);
    ctx.quadraticCurveTo(cx, cy, cx + size, cy);
    ctx.quadraticCurveTo(cx, cy, cx, cy + size);
    ctx.quadraticCurveTo(cx, cy, cx - size, cy);
    ctx.quadraticCurveTo(cx, cy, cx, cy - size);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
}

function drawVectorLock(ctx, cx, cy, size, color) {
    ctx.save();
    ctx.strokeStyle = color || "#64748b";
    ctx.fillStyle = color || "#64748b";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(cx, cy - size * 0.3, size * 0.35, Math.PI, 0);
    ctx.stroke();
    drawRoundedRect(ctx, cx - size * 0.4, cy - size * 0.1, size * 0.8, size * 0.7, 3);
    ctx.fill();
    ctx.restore();
}

function drawVectorBadgeIcon(ctx, type, cx, cy, size, color) {
    ctx.save();
    if (type === "money" || type === "💰" || String(type).includes("movim")) {
        ctx.fillStyle = color;
        ctx.shadowColor = color;
        ctx.shadowBlur = 6;
        ctx.beginPath();
        ctx.arc(cx, cy + size * 0.1, size * 0.65, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#120f21";
        ctx.font = `bold ${Math.round(size * 0.85)}px Arial, sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText("$", cx, cy + size * 0.12);
    } else if (type === "diamond" || type === "💎" || String(type).includes("Trade")) {
        ctx.fillStyle = color;
        ctx.shadowColor = color;
        ctx.shadowBlur = 6;
        ctx.beginPath();
        ctx.moveTo(cx, cy - size * 0.7);
        ctx.lineTo(cx + size * 0.7, cy - size * 0.2);
        ctx.lineTo(cx, cy + size * 0.7);
        ctx.lineTo(cx - size * 0.7, cy - size * 0.2);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = "#ffffff";
        ctx.globalAlpha = 0.6;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(cx - size * 0.7, cy - size * 0.2);
        ctx.lineTo(cx + size * 0.7, cy - size * 0.2);
        ctx.stroke();
    } else if (type === "flame" || type === "🔥" || String(type).includes("250") || String(type).includes("500")) {
        ctx.fillStyle = color;
        ctx.shadowColor = color;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.moveTo(cx, cy + size * 0.7);
        ctx.quadraticCurveTo(cx - size * 0.8, cy, cx - size * 0.3, cy - size * 0.4);
        ctx.quadraticCurveTo(cx - size * 0.1, cy - size * 0.9, cx + size * 0.6, cy - size * 0.6);
        ctx.quadraticCurveTo(cx + size * 0.6, cy - size * 0.2, cx + size * 0.4, cy + size * 0.4);
        ctx.quadraticCurveTo(cx + size * 0.2, cy + size * 0.8, cx, cy + size * 0.7);
        ctx.fill();
    } else {
        drawVectorStar(ctx, cx, cy, 5, size * 0.7, size * 0.32, color, null);
    }
    ctx.restore();
}

function formatValueForDisplay(val) {
    if (typeof val !== "number") val = parseFloat(String(val).replace(",", ".")) || 0;
    return "R$ " + val.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function createGoldMetallicGradient(ctx, yTop, yBottom) {
    const grad = ctx.createLinearGradient(0, yTop, 0, yBottom);
    grad.addColorStop(0.00, "#FFE885"); // Warm bright gold shine
    grad.addColorStop(0.25, "#F3C84B"); // Vibrant gold
    grad.addColorStop(0.55, "#E5B83B"); // Rich metallic gold
    grad.addColorStop(0.85, "#C49222"); // Deep amber gold
    grad.addColorStop(1.00, "#8F6510"); // Dark golden bronze base
    return grad;
}

async function gerarCartaoPerfil(opts) {
    opts = opts || {};
    const globalConfig = getCardConfig().perfilOptions || {};

    const perfilTitle = cleanCanvasText(opts.perfilTitle || globalConfig.title || "PERFIL DE ATENDIMENTO");
    const perfilTheme = opts.perfilTheme || globalConfig.theme || "bicolor_gold";
    const avatarR = Math.round((opts.perfilAvatarZoom || globalConfig.avatarZoom || 160) * 0.41);
    const rankBadgeStr = cleanCanvasText(opts.perfilRankBadge || globalConfig.rankBadge || "TOP #1 MIDDLEMAN");
    const brandFooterStr = cleanCanvasText(opts.perfilBrandFooter || globalConfig.brandFooter || "NEUX MIDDLE MEDIAÇÕES");
    const statsFontSize = opts.perfilStatsSize || globalConfig.statsSize || 38;

    const width = 1645;
    const height = 956;
    const scale = 1.3;
    const canvas = createCanvas(Math.round(width * scale), Math.round(height * scale));
    const ctx = canvas.getContext("2d");
    ctx.scale(scale, scale);

    const mainFont = "'Poppins', 'NotoCJK', 'DejaVu Sans', 'Noto Sans', Arial, sans-serif";
    const roleColor = opts.rankCorHex || "#e2b740";

    // 1. Dark Space Background with Glow
    ctx.fillStyle = "#07040d";
    ctx.fillRect(0, 0, width, height);

    const bgGlow = ctx.createRadialGradient(width * 0.4, height * 0.35, 80, width * 0.5, height * 0.5, width * 0.85);
    bgGlow.addColorStop(0, "rgba(35, 18, 65, 0.85)");
    bgGlow.addColorStop(0.5, "rgba(18, 10, 36, 0.95)");
    bgGlow.addColorStop(1, "rgba(7, 4, 13, 1)");
    ctx.fillStyle = bgGlow;
    ctx.fillRect(0, 0, width, height);

    const gradientTopRight = ctx.createRadialGradient(width, 0, 0, width, 0, 750);
    gradientTopRight.addColorStop(0, roleColor + "40");
    gradientTopRight.addColorStop(0.5, roleColor + "15");
    gradientTopRight.addColorStop(1, "transparent");
    ctx.fillStyle = gradientTopRight;
    ctx.fillRect(0, 0, width, height);

    const blGlow = ctx.createRadialGradient(0, height, 0, 0, height, 750);
    blGlow.addColorStop(0, roleColor + "30");
    blGlow.addColorStop(1, "transparent");
    ctx.fillStyle = blGlow;
    ctx.fillRect(0, 0, width, height);

    // Vector Sparkles
    const fixedSparkles = [
        { x: 120, y: 70, s: 10, c: "#c084fc" }, { x: 920, y: 45, s: 12, c: "#93c5fd" }, { x: 1270, y: 90, s: 8, c: "#e0e7ff" },
        { x: 1560, y: 75, s: 14, c: "#c084fc" }, { x: 770, y: 120, s: 7, c: "#ffffff" }, { x: 470, y: 320, s: 9, c: "#c084fc" },
        { x: 1390, y: 350, s: 10, c: "#93c5fd" }, { x: 270, y: 640, s: 9, c: "#e0e7ff" }, { x: 860, y: 920, s: 12, c: "#c084fc" },
        { x: 1550, y: 490, s: 10, c: "#ffffff" }, { x: 50, y: 420, s: 8, c: "#93c5fd" }, { x: 1180, y: 870, s: 8, c: "#e0e7ff" }
    ];
    fixedSparkles.forEach(st => {
        drawSparkle(ctx, st.x, st.y, st.s, st.c);
    });

    // Background Dots
    for (let i = 0; i < 40; i++) {
        const dotX = (i * 137 + 43) % width;
        const dotY = (i * 97 + 29) % height;
        ctx.globalAlpha = 0.35;
        ctx.fillStyle = "#ffffff";
        ctx.beginPath();
        ctx.arc(dotX, dotY, (i % 3) + 1, 0, Math.PI * 2);
        ctx.fill();
    }
    ctx.globalAlpha = 1;

    // 2. Avatar Section
    const avatarX = 75;
    const avatarY = 70;

    // Outer Glowing Border matching role color!
    ctx.save();
    ctx.beginPath();
    ctx.arc(avatarX + avatarR, avatarY + avatarR, avatarR + 6, 0, Math.PI * 2);
    ctx.strokeStyle = roleColor;
    ctx.lineWidth = 4.5;
    ctx.shadowColor = roleColor;
    ctx.shadowBlur = 16;
    ctx.stroke();
    ctx.restore();

    try {
        if (opts.avatarURL && opts.avatarURL.startsWith("http")) {
            const avatarImg = await loadImage(opts.avatarURL);
            ctx.save();
            ctx.beginPath();
            ctx.arc(avatarX + avatarR, avatarY + avatarR, avatarR, 0, Math.PI * 2);
            ctx.clip();
            ctx.drawImage(avatarImg, avatarX, avatarY, avatarR * 2, avatarR * 2);
            ctx.restore();
        } else {
            throw new Error("No avatar URL");
        }
    } catch (e) {
        ctx.save();
        ctx.fillStyle = "#1e1b2e";
        ctx.beginPath();
        ctx.arc(avatarX + avatarR, avatarY + avatarR, avatarR, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#c9c9c9";
        ctx.font = `bold ${avatarR}px ${mainFont}`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        const rawLetter = (opts.username || "U");
        const letter = (cleanCanvasText(rawLetter)[0] || "U").toUpperCase();
        ctx.fillText(letter, avatarX + avatarR, avatarY + avatarR + 4);
        ctx.restore();
    }

    // Rank Sun Badge on Avatar
    const badgeCx = avatarX + avatarR * 2 - 10;
    const badgeCy = avatarY + avatarR * 2 - 10;
    ctx.save();
    ctx.beginPath();
    ctx.arc(badgeCx, badgeCy, 16, 0, Math.PI * 2);
    ctx.fillStyle = "#1c1432";
    ctx.fill();
    ctx.strokeStyle = roleColor;
    ctx.lineWidth = 2;
    ctx.stroke();
    drawVectorStar(ctx, badgeCx, badgeCy, 8, 9, 5, "#f59e0b", null);
    ctx.restore();

    // 3. User Name & Rank Title Info
    const textX = 230;
    ctx.save();
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "#FFFFFF";
    ctx.font = `bold 42px ${mainFont}`;
    const rawUsername = cleanCanvasText(opts.username) || "Cliente VIP";
    const usernameStr = truncateText(ctx, rawUsername, 480);
    ctx.fillText(usernameStr, textX, avatarY + 48);

    const nameWidth = ctx.measureText(usernameStr).width;
    ctx.font = `bold 26px ${mainFont}`;
    const titleX = textX + nameWidth + 20;

    // Draw Vector Star in actual golden color
    drawVectorStar(ctx, titleX + 12, avatarY + 38, 8, 10, 5, "#f59e0b", null);
    ctx.fillStyle = roleColor;
    ctx.fillText(" · ", titleX + 26, avatarY + 46);

    ctx.fillStyle = createGoldMetallicGradient(ctx, avatarY + 20, avatarY + 60);
    const rankTitleStr = cleanCanvasText(opts.rankNome) || "Cliente Iniciante";
    ctx.fillText(rankTitleStr, titleX + 50, avatarY + 46);

    ctx.fillStyle = createGoldMetallicGradient(ctx, avatarY + 70, avatarY + 95);
    ctx.font = `bold 16px ${mainFont}`;
    const pos = opts.rankPosicao || opts.rank || 1;
    const tot = opts.rankTotal || (opts.rank ? 768 : 7);
    ctx.fillText(`RANKING GERAL • #${pos} de ${tot}`, textX, avatarY + 84);
    ctx.restore();

    // 4. Top Right Total Movimentado with Signature Gold Metallic Gradient
    const rightX = 1570;
    ctx.save();
    ctx.textAlign = "right";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "#94a3b8";
    ctx.font = `bold 18px ${mainFont}`;
    ctx.fillText("TOTAL MOVIMENTADO", rightX, avatarY + 42);

    ctx.font = `bold 68px ${mainFont}`;
    ctx.fillStyle = createGoldMetallicGradient(ctx, avatarY + 50, avatarY + 120);
    const totalMov = opts.totalMovimentado !== undefined ? opts.totalMovimentado : (opts.total !== undefined ? opts.total : (opts.totalValor !== undefined ? opts.totalValor : 0));
    ctx.fillText(formatValueForDisplay(totalMov), rightX, avatarY + 115);
    ctx.restore();

    // 5. Progress Bar Section
    const barX = 75;
    const barY = 320;
    const barW = 1495;
    const barH = 16;

    ctx.save();
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
    ctx.font = `bold 20px ${mainFont}`;
    ctx.fillStyle = createGoldMetallicGradient(ctx, barY - 30, barY);
    ctx.fillText(`• ${rankTitleStr}`, barX, barY - 14);

    ctx.textAlign = "right";
    let faltaStr = "";
    let proximoNome = "Cliente Nobre";
    if (opts.proximoRank) {
        faltaStr = formatValueForDisplay(opts.proximoRank.faltam);
        proximoNome = cleanCanvasText(opts.proximoRank.nome) || "Cliente Nobre";
    } else {
        faltaStr = "R$ 500,00";
    }
    ctx.fillStyle = "#94a3b8";
    ctx.font = `18px ${mainFont}`;
    const sufStr = `• ${proximoNome}`;
    const sufW = ctx.measureText(sufStr).width;
    ctx.fillText(`faltam ${faltaStr} para `, rightX - sufW - 6, barY - 14);

    ctx.fillStyle = createGoldMetallicGradient(ctx, barY - 30, barY);
    ctx.font = `bold 18px ${mainFont}`;
    ctx.fillText(sufStr, rightX, barY - 14);

    ctx.fillStyle = "#1e1833";
    drawRoundedRect(ctx, barX, barY, barW, barH, 8);
    ctx.fill();

    const progressVal = typeof opts.progresso === "number" ? opts.progresso : 0.45;
    const fillW = Math.max(Math.min(progressVal, 1) * barW, 20);
    const pGrad = ctx.createLinearGradient(barX, 0, barX + fillW, 0);
    pGrad.addColorStop(0, "#7c3aed");
    pGrad.addColorStop(0.5, roleColor);
    pGrad.addColorStop(1, "#c084fc");
    ctx.fillStyle = pGrad;
    ctx.shadowColor = roleColor;
    ctx.shadowBlur = 12;
    drawRoundedRect(ctx, barX, barY, fillW, barH, 8);
    ctx.fill();
    ctx.restore();

    // 6. 4 Stat Cards Row
    const stats = [
        { label: "INTERMEDIAÇÕES", value: opts.intermediacoes !== undefined ? opts.intermediacoes : (opts.trocas !== undefined ? opts.trocas : (opts.totalTrocas !== undefined ? opts.totalTrocas : 0)), isCurrency: false },
        { label: "MAIOR TRANSAÇÃO", value: opts.maiorTransacao !== undefined ? opts.maiorTransacao : (opts.maiorTrend !== undefined ? opts.maiorTrend : (opts.maiorTroca !== undefined ? opts.maiorTroca : 0)), isCurrency: true },
        { label: "NO MÊS", value: opts.noMes !== undefined ? opts.noMes : (opts.valorMensal !== undefined ? opts.valorMensal : (opts.totalMensal !== undefined ? opts.totalMensal : (opts.totalMes !== undefined ? opts.totalMes : 0))), isCurrency: true },
        { label: "CLIENTE DESDE", value: opts.clienteDesde || 2026, isCurrency: false }
    ];

    const cardW = 352;
    const cardH = 140;
    const cardGap = 29;
    const cardY = 410;

    stats.forEach((s, i) => {
        const x = barX + i * (cardW + cardGap);
        ctx.save();
        ctx.fillStyle = "rgba(18, 15, 33, 0.85)";
        ctx.strokeStyle = "rgba(120, 90, 200, 0.25)";
        ctx.lineWidth = 1.5;
        drawRoundedRect(ctx, x, cardY, cardW, cardH, 16);
        ctx.fill();
        ctx.stroke();

        ctx.textAlign = "left";
        ctx.textBaseline = "alphabetic";
        ctx.fillStyle = "#94a3b8";
        ctx.font = `bold 15px ${mainFont}`;
        ctx.fillText(s.label, x + 24, cardY + 40);

        const textVal = s.isCurrency ? formatValueForDisplay(s.value) : String(s.value);
        ctx.font = `bold ${statsFontSize}px ${mainFont}`;
        ctx.fillStyle = createGoldMetallicGradient(ctx, cardY + 50, cardY + 105);
        ctx.fillText(textVal, x + 24, cardY + 98);
        ctx.restore();
    });

    // 7. 6 Achievement Cards Row
    const conquistasDefault = [
        { label: "100 intermédios", icone: "handshake", desbloqueado: false },
        { label: "R$ 1k movim.", icone: "money", desbloqueado: false },
        { label: "R$ 10k movim.", icone: "money", desbloqueado: false },
        { label: "Trade R$ 500+", icone: "diamond", desbloqueado: false },
        { label: "250 intermédios", icone: "flame", desbloqueado: false },
        { label: "500 intermédios", icone: "flame", desbloqueado: false }
    ];

    const conqs = opts.conquistas && opts.conquistas.length >= 6 ? opts.conquistas : conquistasDefault;
    const conqGap = 22;
    const conqW = (barW - (conqs.length - 1) * conqGap) / conqs.length;
    const conqH = 210;
    const conqY = 590;

    for (let i = 0; i < conqs.length; i++) {
        const c = conqs[i];
        const x = barX + i * (conqW + conqGap);
        const active = c.desbloqueado;

        ctx.save();
        if (active) {
            ctx.fillStyle = "rgba(18, 15, 33, 0.9)";
            ctx.strokeStyle = roleColor;
            ctx.lineWidth = 2.5;
            ctx.shadowColor = roleColor;
            ctx.shadowBlur = 10;
        } else {
            ctx.fillStyle = "rgba(14, 11, 27, 0.7)";
            ctx.strokeStyle = "rgba(255, 255, 255, 0.08)";
            ctx.lineWidth = 1.5;
        }

        drawRoundedRect(ctx, x, conqY, conqW, conqH, 16);
        ctx.fill();
        ctx.stroke();
        ctx.restore();

        if (!active) {
            drawVectorLock(ctx, x + conqW - 22, conqY + 28, 14, "#475569");
        }

        const iconColor = active ? roleColor : "#475569";
        drawVectorBadgeIcon(ctx, c.icone || c.label, x + conqW / 2, conqY + conqH / 2 - 15, 24, iconColor);

        ctx.save();
        ctx.textAlign = "center";
        ctx.textBaseline = "alphabetic";
        ctx.font = `bold 16px ${mainFont}`;
        ctx.fillStyle = active ? "#FFFFFF" : "#64748b";
        const cleanConqLabel = cleanCanvasText(c.label || c.name || "");
        ctx.fillText(cleanConqLabel, x + conqW / 2, conqY + conqH / 2 + 45);
        ctx.restore();
    }

    // 8. Watermark
    ctx.save();
    ctx.textAlign = "right";
    ctx.textBaseline = "alphabetic";
    ctx.font = `bold 16px ${mainFont}`;
    ctx.fillStyle = createGoldMetallicGradient(ctx, height - 65, height - 35);
    ctx.fillText(brandFooterStr, rightX, height - 50);
    ctx.restore();

    return canvas.toBuffer("image/png");
}

export { gerarCartaoPerfil };
export default { gerarCartaoPerfil };
if (typeof module !== "undefined" && module.exports) {
    module.exports = { gerarCartaoPerfil };
}
