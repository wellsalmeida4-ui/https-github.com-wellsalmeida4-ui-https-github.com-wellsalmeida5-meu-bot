const fs = require("fs");
const path = require("path");
const {
  Client,
  GatewayIntentBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  EmbedBuilder,
  ChannelType,
  PermissionFlagsBits,
  MessageFlags,
  SlashCommandBuilder
} = require("discord.js");

// ================= CONFIGURAÇÕES NEUXCMM =================
const STAFF_ROLE_IDS = ["1419441539331002489", "1420702867148378203", "1417912504964878497"];
const COR_EMBED = 0xFF0000;
const BANNER_URL = "https://i.postimg.cc/WzcCtxj9/6e8e2b50ce436a946142e99432b9f6b0.jpg";

function isStaff(member) {
  if (!member) return false;
  if (member.permissions && member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  if (member.roles && member.roles.cache) {
    return STAFF_ROLE_IDS.some(roleId => member.roles.cache.has(roleId));
  }
  return false;
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ]
});

client.once("ready", async (c) => {
  console.log("⚡ [BOT NEUXCMM] Online e operacional no Discord como " + (c.user ? c.user.tag : "Bot"));
  try {
    if (client.application && client.application.commands) {
      const cmdNeux = new SlashCommandBuilder()
        .setName("neux")
        .setDescription("Central de informações e status do sistema NeuxCMM.");
      await client.application.commands.create(cmdNeux).catch(() => {});
    }
  } catch (e) {
    console.error("[BOT NEUXCMM] Erro ao registrar slash command:", e);
  }
});

// Comandos de Chat
client.on("messageCreate", async (message) => {
  if (message.author.bot) return;

  const content = message.content.trim().toLowerCase();
  const prefix = process.env.PREFIX || "!";

  if (content === "!neux" || content === prefix + "neux" || content === "!statusneux" || content === prefix + "statusneux") {
    const embed = new EmbedBuilder()
      .setColor(COR_EMBED)
      .setTitle("⚡ Central NeuxCMM Services")
      .setDescription("> Sistema integrado de automações e serviços 24/7.\n> Todos os módulos operacionais.")
      .addFields(
        { name: "🏰 Servidores", value: String(client.guilds.cache.size), inline: true },
        { name: "⚡ Latência", value: `${client.ws?.ping ?? 24}ms`, inline: true },
        { name: "🟢 Status", value: "Operacional 24/7", inline: true }
      )
      .setImage(BANNER_URL)
      .setFooter({ text: "NeuxCMM Ecosystem • 24/7 Hosting" })
      .setTimestamp();

    await message.reply({ embeds: [embed] }).catch(console.error);
  }
});

// Interações Nativas
client.on("interactionCreate", async (interaction) => {
  try {
    if (interaction.isChatInputCommand && interaction.isChatInputCommand()) {
      if (interaction.commandName === "neux") {
        const embed = new EmbedBuilder()
          .setColor(COR_EMBED)
          .setTitle("⚡ Central NeuxCMM Services")
          .setDescription("> Sistema integrado de automações e serviços 24/7.\n> Todos os módulos operacionais.")
          .addFields(
            { name: "🏰 Servidores", value: String(client.guilds.cache.size), inline: true },
            { name: "⚡ Latência", value: `${client.ws?.ping ?? 24}ms`, inline: true },
            { name: "🟢 Status", value: "Operacional 24/7", inline: true }
          )
          .setImage(BANNER_URL)
          .setFooter({ text: "NeuxCMM Ecosystem • 24/7 Hosting" })
          .setTimestamp();

        return await interaction.reply({ embeds: [embed] });
      }
    }
  } catch (err) {
    console.error("[BOT NEUXCMM] Erro na interação:", err);
  }
});

client.login(process.env.DISCORD_TOKEN || process.env.TOKEN);
