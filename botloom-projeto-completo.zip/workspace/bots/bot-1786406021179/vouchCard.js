const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");
const path = require("path");
const fs = require("fs");

/* ------------------------------------------------------------------ *
 *  CARREGAMENTO E REGISTRO DE FONTES CUSTOMIZADAS (Montserrat + NotoCJK)
 * ------------------------------------------------------------------ */
const FONT_FAMILY = "Montserrat";

function getActiveFontFamilies() {
    try {
        if (GlobalFonts && Array.isArray(GlobalFonts.families)) {
            return GlobalFonts.families.map(f => typeof f === "string" ? f : (f && f.family ? f.family : String(f)));
        }
        if (GlobalFonts && typeof GlobalFonts.getFamilies === "function") {
            const raw = GlobalFonts.getFamilies();
            const str = Buffer.isBuffer(raw) ? raw.toString("utf8") : String(raw);
            const parsed = JSON.parse(str);
            if (Array.isArray(parsed)) {
                return parsed.map(f => typeof f === "string" ? f : (f && f.family ? f.family : String(f)));
            }
        }
        if (GlobalFonts && typeof GlobalFonts.has === "function" && GlobalFonts.has("Montserrat")) {
            return ["Montserrat"];
        }
    } catch (e) {
        console.warn("[vouchCard] Aviso ao obter famílias de fontes:", e.message);
    }
    return [];
}

function registerAllFonts() {
    const searchDirs = [
        path.join(__dirname, "fonts"),
        path.join(process.cwd(), "fonts"),
        path.join(__dirname, "..", "fonts"),
        path.join(process.cwd(), "dist", "fonts")
    ];

    const registeredFiles = new Set();
    let montserratCount = 0;
    let notoCount = 0;

    console.log("=================================================");
    console.log("[vouchCard LOG] Iniciando verificação e registro de fontes...");

    for (const fontsDir of searchDirs) {
        console.log(`[vouchCard LOG] Verificando diretório de fontes: ${fontsDir} (existe: ${fs.existsSync(fontsDir)})`);
        if (!fs.existsSync(fontsDir)) continue;
        try {
            const files = fs.readdirSync(fontsDir);
            for (const file of files) {
                if (registeredFiles.has(file)) continue;
                const filePath = path.join(fontsDir, file);
                const exists = fs.existsSync(filePath);
                console.log(`[vouchCard LOG] Arquivo de fonte em disk: ${file} -> existe: ${exists}`);
                if (!exists) continue;

                const lower = file.toLowerCase();
                if (lower.startsWith("montserrat") && (lower.endsWith(".ttf") || lower.endsWith(".otf"))) {
                    // Registra TODOS os pesos (Regular, Medium, SemiBold, Bold,
                    // ExtraBold...) sob a mesma família "Montserrat". O
                    // @napi-rs/canvas escolhe o arquivo certo pelo font-weight
                    // pedido em ctx.font (ex: "800 40px Montserrat"), desde que
                    // cada .ttf tenha o weight correto no seu próprio metadado.
                    try {
                        const fontKey = GlobalFonts.registerFromPath(filePath, FONT_FAMILY);
                        registeredFiles.add(file);
                        montserratCount++;
                        console.log(`[vouchCard LOG] Sucesso ao registrar ${file} como '${FONT_FAMILY}' (Key: ${fontKey ? "OK" : "null"})`);
                    } catch (e) {
                        console.error(`[vouchCard ERRO] Falha ao registrar ${file}:`, e.message);
                    }
                } else if ((lower.includes("noto") || lower.includes("cjk")) && (lower.endsWith(".ttf") || lower.endsWith(".otf"))) {
                    try {
                        const fontKey = GlobalFonts.registerFromPath(filePath, "NotoCJK");
                        registeredFiles.add(file);
                        notoCount++;
                        console.log(`[vouchCard LOG] Sucesso ao registrar ${file} como 'NotoCJK' (Key: ${fontKey ? "OK" : "null"})`);
                    } catch (e) {
                        console.error(`[vouchCard ERRO] Falha ao registrar ${file}:`, e.message);
                    }
                }
            }
        } catch (e) {
            console.error("[vouchCard ERRO] Erro ao ler pasta de fontes:", e.message);
        }
    }

    const activeFamilies = getActiveFontFamilies();
    console.log(`[vouchCard LOG] Resumo do Registro: Montserrat=${montserratCount}, NotoCJK=${notoCount}`);
    console.log(`[vouchCard LOG] Famílias ativas no GlobalFonts: [${activeFamilies.join(", ")}]`);
    console.log("=================================================");

    return { montserratCount, notoCount, activeFamilies };
}

const fontRegStatus = registerAllFonts();

const FONT_STACK = `'${FONT_FAMILY}', 'NotoCJK', 'DejaVu Sans', 'Noto Sans', 'Liberation Sans', sans-serif`;
// Nome do staff/mediador usa a mesma família Montserrat (antes usava
// 'Inter' separado; não é mais necessário, Montserrat cobre tudo).
const NAME_FONT_STACK = FONT_STACK;

function getCardConfig() {
    try {
        const configPath = path.join(process.cwd(), "cardConfig.json");
        if (fs.existsSync(configPath)) {
            return JSON.parse(fs.readFileSync(configPath, "utf8"));
        }
    } catch (e) {}
    return {};
}

/* ------------------------------------------------------------------ *
 *  PALETAS METÁLICAS LUXUOSAS E HARMONIZADAS
 * ------------------------------------------------------------------ */
const THEMES = {
    bicolor_gold: {
        BG: "#120f06",
        GOLD_HIGH: "#FFF3B8",
        GOLD_1: "#F5CA48",
        GOLD_2: "#E8B923",
        GOLD_3: "#B88812",
        GOLD_4: "#6E4F08",
        GOLD_SHADOW: "rgba(232, 185, 35, 0.45)",
        GOLD_SOLID: "#E8B923",
        TEXT_MUTED: "#d4af37",
        DARK_STAR: "#3d2f0a"
    },
    platinum_silver: {
        BG: "#171B20",
        GOLD_HIGH: "#FFFFFF",
        GOLD_1: "#F0F4F8",
        GOLD_2: "#DDE3EA",
        GOLD_3: "#8A94A0",
        GOLD_4: "#4B5560",
        GOLD_SHADOW: "rgba(226, 232, 240, 0.45)",
        GOLD_SOLID: "#CBD5E1",
        TEXT_MUTED: "#94a3b8",
        DARK_STAR: "#1e293b"
    },
    emerald_gold: {
        BG: "#06150e",
        GOLD_HIGH: "#A7F3D0",
        GOLD_1: "#34D399",
        GOLD_2: "#10B981",
        GOLD_3: "#059669",
        GOLD_4: "#064E3B",
        GOLD_SHADOW: "rgba(16, 185, 129, 0.45)",
        GOLD_SOLID: "#10B981",
        TEXT_MUTED: "#6ee7b7",
        DARK_STAR: "#064e3b"
    },
    ruby_gold: {
        BG: "#18060a",
        GOLD_HIGH: "#FECDD3",
        GOLD_1: "#FB7185",
        GOLD_2: "#F43F5E",
        GOLD_3: "#E11D48",
        GOLD_4: "#881337",
        GOLD_SHADOW: "rgba(244, 63, 94, 0.45)",
        GOLD_SOLID: "#F43F5E",
        TEXT_MUTED: "#fda4af",
        DARK_STAR: "#4c0519"
    },
    diamond_blue: {
        BG: "#071524",
        GOLD_HIGH: "#BAE6FD",
        GOLD_1: "#38BDF8",
        GOLD_2: "#0EA5E9",
        GOLD_3: "#0284C7",
        GOLD_4: "#0369A1",
        GOLD_SHADOW: "rgba(14, 165, 233, 0.45)",
        GOLD_SOLID: "#0EA5E9",
        TEXT_MUTED: "#7dd3fc",
        DARK_STAR: "#082f49"
    }
};

function getPalette(themeName) {
    if (themeName && THEMES[themeName]) {
        return THEMES[themeName];
    }
    return THEMES.bicolor_gold || THEMES.platinum_silver;
}

/* ------------------------------------------------------------------ *
 *  SISTEMA DE PATENTES (RANK) POR NÚMERO DE INTERMEDIAÇÕES
 * ------------------------------------------------------------------ *
 *  A patente exibida ao lado do nome do staff sobe automaticamente
 *  conforme a quantidade de intermediações feitas (staffIntermediacoes).
 *  Ajuste os limites (min) e nomes abaixo como quiser — dá pra
 *  sobrescrever tudo isso passando `vOpts.rankNome` na hora de chamar
 *  gerarCartaoVouch, se precisar de um caso especial.
 * ------------------------------------------------------------------ */
const RANK_TIERS = [
    { min: 0, nome: "BRONZE" },
    { min: 20, nome: "PRATA" },
    { min: 30, nome: "OURO" },
    { min: 40, nome: "PLATINA" },
    { min: 50, nome: "DIAMANTE" },
    { min: 100, nome: "LENDÁRIO" }
];

function getRankPorIntermediacoes(qtd) {
    let atual = RANK_TIERS[0].nome;
    for (const tier of RANK_TIERS) {
        if (qtd >= tier.min) atual = tier.nome;
    }
    return atual;
}

/* ------------------------------------------------------------------ *
 *  CRIAÇÃO PRECISA DE GRADIENTE E UTILITÁRIOS DE DESENHO
 * ------------------------------------------------------------------ */

function criarGradienteOuro(ctx, y, altura, palette, direcao = "vertical") {
    const p = palette || THEMES.platinum_silver;
    const gHigh = p.GOLD_HIGH || "#FFE885";
    const g1 = p.GOLD_1 || "#F3C84B";
    const g2 = p.GOLD_2 || "#E5A93C";
    const g3 = p.GOLD_3 || "#C48A22";
    const g4 = p.GOLD_4 || "#80520D";

    if (direcao === "horizontal") {
        const grad = ctx.createLinearGradient(y, 0, y + altura, 0);
        grad.addColorStop(0.00, gHigh);
        grad.addColorStop(0.25, g1);
        grad.addColorStop(0.55, g2);
        grad.addColorStop(0.80, g3);
        grad.addColorStop(1.00, g4);
        return grad;
    }

    // Para textos: y é a linha de base (baseline).
    const yTop = y - Math.max(altura * 0.78, 1);
    const yBottom = y + Math.max(altura * 0.12, 1);
    const grad = ctx.createLinearGradient(0, yTop, 0, yBottom);
    grad.addColorStop(0.00, gHigh);
    grad.addColorStop(0.25, g1);
    grad.addColorStop(0.55, g2);
    grad.addColorStop(0.80, g3);
    grad.addColorStop(1.00, g4);
    return grad;
}

/**
 * Desenha texto com efeito de gradiente metálico (5 tons, de cima pra baixo).
 *
 * Técnica: em vez de usar fillStyle=gradiente (que causava texto invisível)
 * ou globalCompositeOperation (que não é suportado nesse ambiente e cobria
 * tudo com retângulo sólido), usamos ctx.clip() com faixas horizontais —
 * isso É suportado (é a mesma técnica usada nos avatares circulares, que
 * sempre recortaram certinho). O texto é desenhado 5 vezes, cada vez
 * recortado numa faixa horizontal diferente com uma cor sólida diferente,
 * criando o efeito de degradê sem depender de gradiente nativo em texto.
 */
function fillTextGradient(ctx, text, x, y, fontSizePx, palette, align = "left", customStops = null) {
    if (!text) return;
    const p = palette || THEMES.platinum_silver;

    // Mais pontos de cor = transição mais suave/realista (menos "faixado").
    // customStops permite um degradê mais simples (ex: 2 tons) para textos específicos.
    const stopColors = customStops || [
        p.GOLD_HIGH || "#FFE885",
        p.GOLD_1 || "#F3C84B",
        p.GOLD_1 || "#F3C84B",
        p.GOLD_2 || "#E5A93C",
        p.GOLD_2 || "#E5A93C",
        p.GOLD_3 || "#C48A22",
        p.GOLD_3 || "#C48A22",
        p.GOLD_4 || "#80520D"
    ];

    ctx.save();
    ctx.textAlign = align;

    let width;
    try {
        const metrics = ctx.measureText(text);
        width = metrics.width || (fontSizePx * text.length * 0.55);
    } catch (e) {
        width = fontSizePx * text.length * 0.55;
    }

    let rectX;
    if (align === "center") rectX = x - width / 2;
    else if (align === "right") rectX = x - width;
    else rectX = x;

    const ascent = fontSizePx * 0.85;
    const descent = fontSizePx * 0.28;
    const top = y - ascent - 2;
    const totalH = ascent + descent + 4;
    const bandH = totalH / stopColors.length;

    for (let i = 0; i < stopColors.length; i++) {
        ctx.save();
        ctx.beginPath();
        ctx.rect(rectX - 6, top + i * bandH - 0.5, width + 12, bandH + 1);
        ctx.clip();
        ctx.fillStyle = stopColors[i];
        ctx.fillText(text, x, y);
        ctx.restore();
    }

    ctx.restore();
}

/**
 * Trunca um texto com "..." no final se ele não couber em maxWidth,
 * usando a fonte já configurada em ctx.font. Usado no nome do staff/
 * mediador, comprador e vendedor pra não bugar o layout com nomes gigantes.
 */
function truncarComReticencias(ctx, text, maxWidth) {
    if (!text) return text;
    let t = String(text);
    if (ctx.measureText(t).width <= maxWidth) return t;
    while (t.length > 1 && ctx.measureText(t + "...").width > maxWidth) {
        t = t.slice(0, -1);
    }
    return t + "...";
}

function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
}

/**
 * Contorno metálico com brilho reforçado. Ajustado para ficar como UMA linha
 * única, nítida (usa o degradê metálico completo em vez de cor sólida
 * chapada, com um blur bem mais leve para não borrar o traço).
 */
function strokeGlowRoundRect(ctx, x, y, w, h, r, palette, lineWidth = 2) {
    // Camada 1: brilho suave e largo por trás da linha (halo)
    ctx.save();
    ctx.shadowColor = palette.GOLD_SHADOW;
    ctx.shadowBlur = 16;
    ctx.strokeStyle = palette.GOLD_SOLID;
    ctx.lineWidth = lineWidth + 2;
    roundRect(ctx, x, y, w, h, r);
    ctx.stroke();
    ctx.restore();

    // Camada 2: linha fina e nítida por cima, em degradê metálico completo
    ctx.save();
    const grad = ctx.createLinearGradient(x, y, x, y + h);
    grad.addColorStop(0.00, palette.GOLD_HIGH || "#FFE885");
    grad.addColorStop(0.30, palette.GOLD_1 || "#F3C84B");
    grad.addColorStop(0.60, palette.GOLD_2 || "#E5A93C");
    grad.addColorStop(0.85, palette.GOLD_3 || "#C48A22");
    grad.addColorStop(1.00, palette.GOLD_4 || "#80520D");
    ctx.strokeStyle = grad;
    ctx.lineWidth = lineWidth;
    roundRect(ctx, x, y, w, h, r);
    ctx.stroke();
    ctx.restore();
}

function strokeGlowCircle(ctx, cx, cy, r, palette, lineWidth = 3) {
    ctx.save();
    ctx.shadowColor = palette.GOLD_SHADOW;
    ctx.shadowBlur = 14;
    ctx.strokeStyle = palette.GOLD_2;
    ctx.lineWidth = lineWidth;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();

    ctx.save();
    const grad = ctx.createLinearGradient(cx, cy - r, cx, cy + r);
    grad.addColorStop(0, palette.GOLD_HIGH);
    grad.addColorStop(0.5, palette.GOLD_2);
    grad.addColorStop(1, palette.GOLD_4);
    ctx.strokeStyle = grad;
    ctx.lineWidth = lineWidth;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
}

function strokeGlowLine(ctx, x1, y1, x2, y2, palette, lineWidth = 1.5) {
    ctx.save();
    ctx.shadowColor = palette.GOLD_SHADOW;
    ctx.shadowBlur = 4;
    ctx.strokeStyle = palette.GOLD_SOLID;
    ctx.lineWidth = lineWidth;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
    ctx.restore();
}

/**
 * Linha "quebrada" (efeito rachadura/raio), usada como decoração
 * discreta nos cantos do cartão. `points` é uma lista de [x, y].
 */
function drawCrackLine(ctx, points, palette, width = 2) {
    ctx.save();
    ctx.shadowColor = palette.GOLD_SHADOW;
    ctx.shadowBlur = 3;
    ctx.strokeStyle = palette.GOLD_SOLID;
    ctx.lineWidth = width;
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(points[0][0], points[0][1]);
    for (let i = 1; i < points.length; i++) ctx.lineTo(points[i][0], points[i][1]);
    ctx.stroke();
    ctx.restore();
}

function desenharRachadurasCanto(ctx, W, H, palette) {
    // Canto superior direito
    drawCrackLine(ctx, [[W - 230, 10], [W - 170, 55], [W - 190, 60], [W - 120, 110], [W - 140, 115], [W - 70, 160]], palette, 2);
    drawCrackLine(ctx, [[W - 110, 15], [W - 80, 45], [W - 95, 50], [W - 40, 90]], palette, 2);
    // Canto inferior esquerdo
    drawCrackLine(ctx, [[20, H - 80], [80, H - 50], [60, H - 45], [120, H - 15]], palette, 2);
    drawCrackLine(ctx, [[15, H - 130], [55, H - 105], [40, H - 100], [90, H - 70]], palette, 2);
}

/**
 * Estrela. Ativa: preenchimento em gradiente metálico com brilho.
 * Inativa: fundo escuro, mas com contorno metálico (em vez de ficar apagada),
 * para que o conjunto de estrelas sempre "leia" como prata/platina.
 */
function drawStar(ctx, cx, cy, outerR, ativa, palette, innerRatio = 0.45) {
    const p = palette || THEMES.platinum_silver;
    const innerR = outerR * innerRatio;
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
        const r = i % 2 === 0 ? outerR : innerR;
        const angle = (Math.PI / 5) * i - Math.PI / 2;
        const x = cx + r * Math.cos(angle);
        const y = cy + r * Math.sin(angle);
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.closePath();
    if (ativa) {
        // Cor sólida e saturada, sem depender de gradiente + sombra: no ambiente
        // de canvas usado aqui, gradiente + shadowBlur em formas pequenas como a
        // estrela renderiza esbranquiçado. Cor sólida garante o prata visível.
        ctx.save();
        ctx.fillStyle = p.GOLD_SOLID || p.GOLD_2 || "#E5A93C";
        ctx.fill();
        ctx.lineWidth = Math.max(1, outerR * 0.08);
        ctx.strokeStyle = p.GOLD_4 || "#80520D";
        ctx.stroke();
        ctx.restore();
    } else {
        ctx.save();
        ctx.fillStyle = p.DARK_STAR || "#2a2412";
        ctx.fill();
        ctx.lineWidth = Math.max(1, outerR * 0.08);
        ctx.strokeStyle = p.GOLD_4 || "#80520D";
        ctx.stroke();
        ctx.restore();
    }
}

function drawCheckBadge(ctx, cx, cy, r, palette) {
    ctx.save();
    ctx.shadowColor = palette.GOLD_SHADOW;
    ctx.shadowBlur = 4;
    const grad = ctx.createLinearGradient(cx, cy - r, cx, cy + r);
    grad.addColorStop(0, palette.GOLD_1);
    grad.addColorStop(1, palette.GOLD_4);
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.fill();
    ctx.restore();

    ctx.beginPath();
    ctx.moveTo(cx - r * 0.5, cy);
    ctx.lineTo(cx - r * 0.1, cy + r * 0.4);
    ctx.lineTo(cx + r * 0.55, cy - r * 0.4);
    ctx.lineWidth = r * 0.3;
    ctx.strokeStyle = "#1a1206";
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke();
}

function drawCheckOutlineBadge(ctx, cx, cy, r, palette) {
    ctx.save();
    ctx.shadowColor = palette.GOLD_SHADOW;
    ctx.shadowBlur = 4;
    const grad = ctx.createLinearGradient(cx, cy - r, cx, cy + r);
    grad.addColorStop(0, palette.GOLD_1);
    grad.addColorStop(1, palette.GOLD_4);
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.lineWidth = r * 0.16;
    ctx.strokeStyle = grad;
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.5, cy);
    ctx.lineTo(cx - r * 0.1, cy + r * 0.4);
    ctx.lineTo(cx + r * 0.55, cy - r * 0.4);
    ctx.lineWidth = r * 0.24;
    ctx.strokeStyle = grad;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke();
    ctx.restore();
}

function drawCalendar(ctx, cx, cy, size, palette) {
    const w = size * 1.5, h = size * 1.3;
    ctx.strokeStyle = palette.GOLD_SOLID;
    ctx.lineWidth = size * 0.12;
    roundRect(ctx, cx - w / 2, cy - h / 2, w, h, size * 0.18);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx - w / 2, cy - h * 0.15);
    ctx.lineTo(cx + w / 2, cy - h * 0.15);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx - w * 0.25, cy - h / 2 - size * 0.12);
    ctx.lineTo(cx - w * 0.25, cy - h / 2 + size * 0.12);
    ctx.moveTo(cx + w * 0.25, cy - h / 2 - size * 0.12);
    ctx.lineTo(cx + w * 0.25, cy - h / 2 + size * 0.12);
    ctx.stroke();
}

function drawList(ctx, cx, cy, size, cor) {
    const w = size * 1.3, h = size * 1.5;
    ctx.strokeStyle = cor;
    ctx.lineWidth = size * 0.1;
    roundRect(ctx, cx - w / 2, cy - h / 2, w, h, size * 0.15);
    ctx.stroke();
    for (let i = 0; i < 3; i++) {
        const ly = cy - h / 2 + h * 0.28 + i * (h * 0.22);
        ctx.beginPath();
        ctx.moveTo(cx - w / 2 + w * 0.18, ly);
        ctx.lineTo(cx + w / 2 - w * 0.18, ly);
        ctx.stroke();
    }
}

function drawCopyIcon(ctx, cx, cy, size, palette) {
    ctx.strokeStyle = palette.GOLD_SOLID;
    ctx.lineWidth = size * 0.12;
    roundRect(ctx, cx - size * 0.1, cy - size * 0.5, size * 0.75, size * 0.9, size * 0.12);
    ctx.stroke();
    roundRect(ctx, cx - size * 0.5, cy - size * 0.25, size * 0.75, size * 0.9, size * 0.12);
    ctx.fillStyle = palette.BG;
    ctx.fill();
    ctx.stroke();
}

function desenharPontosFundo(ctx, W, H, palette) {
    // Malha pontilhada regular: pequenos quadrados organizados, sem aspecto
    // aleatório, para criar uma textura técnica e discreta no fundo.
    const p = palette || THEMES.platinum_silver;
    const corParticula = p.GOLD_2 || "#AEB8C3";
    const espacamento = 22;
    for (let y = 28; y < H - 20; y += espacamento) {
        for (let x = 28; x < W - 20; x += espacamento) {
            ctx.save();
            ctx.globalAlpha = 0.10;
            ctx.fillStyle = corParticula;
            ctx.fillRect(x, y, 2, 2);
            ctx.restore();
        }
    }
}

/**
 * Reduz gradualmente o tamanho da fonte até que o texto caiba dentro de
 * maxWidth, mantendo um tamanho mínimo legível. Mantida disponível para uso
 * futuro (ex: em outros campos), mas não é mais aplicada ao valor
 * intermediado — que agora usa fonte sempre fixa, igual à referência.
 */
function ajustarTamanhoFonteParaLargura(ctx, text, fontWeight, fontSizeInicial, maxWidth, fontSizeMinimo = 40) {
    let fontSize = fontSizeInicial;
    ctx.font = `${fontWeight} ${fontSize}px ${FONT_STACK}`;
    let largura = ctx.measureText(text).width;

    while (largura > maxWidth && fontSize > fontSizeMinimo) {
        fontSize -= 2;
        ctx.font = `${fontWeight} ${fontSize}px ${FONT_STACK}`;
        largura = ctx.measureText(text).width;
    }

    return fontSize;
}

async function desenharAvatarCirculo(ctx, cx, cy, r, urlOuLetra, palette) {
    const anonimato = urlOuLetra === '__ANONYMOUS__';
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();

    if (anonimato) {
        ctx.fillStyle = '#252B32';
        ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
        ctx.fillStyle = palette.GOLD_2 || '#B9C2CC';
        ctx.beginPath();
        ctx.arc(cx, cy - r * 0.28, r * 0.27, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(cx, cy + r * 0.48, r * 0.58, Math.PI, 0);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
        return;
    }

    let desenhouImagem = false;
    if (urlOuLetra && String(urlOuLetra).startsWith("http")) {
        try {
            const img = await loadImage(urlOuLetra);
            ctx.drawImage(img, cx - r, cy - r, r * 2, r * 2);
            desenhouImagem = true;
        } catch (e) { /* fallback */ }
    }
    if (!desenhouImagem) {
        ctx.fillStyle = "#161310";
        ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
        ctx.restore();
        ctx.save();
        ctx.fillStyle = criarGradienteOuro(ctx, cy, r * 1.6, palette);
        ctx.font = `bold ${Math.round(r)}px ${FONT_STACK}`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        const letra = (typeof urlOuLetra === "string" && urlOuLetra.length) ? urlOuLetra[0].toUpperCase() : "?";
        ctx.fillText(letra, cx, cy + 4);
        ctx.textAlign = "left";
        ctx.textBaseline = "alphabetic";
        ctx.restore();
        return;
    }
    ctx.restore();
}

/**
 * Gera o cartão de vouch (Buffer PNG) — visual platina/prata, com Montserrat e
 * NotoCJK para caracteres internacionais. Posições e tamanhos calibrados
 * para baterem com a referência pixel a pixel (1729x910): título, ID da
 * transação, caixa do código, valor intermediado (fixo, alinhado à
 * direita), avatar do staff com selo/estrelas/patente, e rodapé com
 * comprador/vendedor/data/marca.
 */
function desenharHalloween(ctx, W, H, palette, frame = 0, totalFrames = 12) {
    const t = ((frame % totalFrames) + totalFrames) % totalFrames / totalFrames;

    // Vinheta vermelha/preta sobre o fundo do postcard.
    ctx.save();
    const bg = ctx.createRadialGradient(W * 0.52, H * 0.42, 30, W * 0.52, H * 0.42, W * 0.78);
    bg.addColorStop(0, '#7f1d1d');
    bg.addColorStop(0.42, '#3b1016');
    bg.addColorStop(1, '#070709');
    ctx.globalAlpha = 0.92;
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);
    ctx.restore();

    // Abóbora grande e discreta ao fundo, apenas como textura temática.
    ctx.save();
    ctx.globalAlpha = 0.10;
    const bgx = W * 0.53, bgy = H * 0.55, br = 105;
    ctx.fillStyle = '#f97316';
    for (const dx of [-55, -28, 0, 28, 55]) {
        ctx.beginPath(); ctx.ellipse(bgx + dx, bgy, 38, 66, 0, 0, Math.PI * 2); ctx.fill();
    }
    ctx.fillStyle = '#22c55e'; ctx.fillRect(bgx - 8, bgy - 85, 16, 22);
    ctx.fillStyle = '#160b0b';
    ctx.beginPath(); ctx.moveTo(bgx-55,bgy-10); ctx.lineTo(bgx-22,bgy-25); ctx.lineTo(bgx-10,bgy-2); ctx.lineTo(bgx+15,bgy-25); ctx.lineTo(bgx+52,bgy-8); ctx.lineTo(bgx+25,bgy+18); ctx.lineTo(bgx-25,bgy+18); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(bgx-48,bgy+30); ctx.quadraticCurveTo(bgx,bgy+78,bgx+48,bgy+30); ctx.quadraticCurveTo(bgx,bgy+58,bgx-48,bgy+30); ctx.fill();
    ctx.restore();

    // Lua/brilho de Halloween discreto no fundo.
    ctx.save();
    ctx.globalAlpha = 0.20;
    ctx.fillStyle = '#ff5a36';
    ctx.beginPath();
    ctx.arc(W * 0.84, H * 0.19, 80, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 0.18;
    ctx.fillStyle = '#0a0a0c';
    ctx.beginPath();
    ctx.arc(W * 0.87, H * 0.16, 76, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Brilho correndo pela borda externa.
    const perimeter = 2 * (W - 28) + 2 * (H - 28);
    const head = t * perimeter;
    const points = [
        [14, 14], [W - 14, 14], [W - 14, H - 14], [14, H - 14], [14, 14]
    ];
    function pointAt(distance) {
        let d = ((distance % perimeter) + perimeter) % perimeter;
        for (let i = 0; i < points.length - 1; i++) {
            const [x1,y1] = points[i], [x2,y2] = points[i+1];
            const len = Math.hypot(x2-x1, y2-y1);
            if (d <= len) {
                const q = d / len;
                return [x1 + (x2-x1)*q, y1 + (y2-y1)*q];
            }
            d -= len;
        }
        return points[0];
    }
    ctx.save();
    ctx.lineCap = 'round';
    for (let i = 0; i < 22; i++) {
        const q = i / 22;
        const [x1,y1] = pointAt(head - q * 150);
        const [x2,y2] = pointAt(head - q * 150 - 18);
        ctx.globalAlpha = (1-q) * 0.85;
        ctx.strokeStyle = i < 5 ? '#fff1c2' : '#ff5a1f';
        ctx.shadowColor = '#ff3b12';
        ctx.shadowBlur = 22;
        ctx.lineWidth = i < 4 ? 8 : 4;
        ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); ctx.stroke();
    }
    ctx.restore();

    // Túmulos em silhueta no fundo, discretos para não atrapalhar a leitura.
    ctx.save();
    ctx.globalAlpha = 0.72;
    for (const [tx, ty, tw, th] of [[48, H-180, 120, 126], [188, H-150, 92, 96], [W-230, H-170, 112, 116], [W-95, H-145, 80, 90]]) {
        ctx.fillStyle = '#12090d';
        ctx.strokeStyle = '#6b1d28';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(tx, ty + th); ctx.lineTo(tx, ty + 24); ctx.quadraticCurveTo(tx + tw/2, ty - 14, tx + tw, ty + 24);
        ctx.lineTo(tx + tw, ty + th); ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.fillStyle = '#b91c1c';
        ctx.font = `700 ${Math.max(18, Math.round(tw * 0.22))}px sans-serif`;
        ctx.textAlign = 'center'; ctx.fillText('RIP', tx + tw/2, ty + th * 0.63);
    }
    ctx.restore();

    // Lateral com ícones/personagens genéricos de terror: caveira, vampiro e fantasma.
    ctx.save();
    const sx = W - 55, sy = 405;
    ctx.globalAlpha = 0.98;
    ctx.fillStyle = '#ded7d0';
    ctx.beginPath(); ctx.arc(sx, sy, 34, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = '#1a0b0e';
    ctx.beginPath(); ctx.arc(sx-12, sy-5, 8, 0, Math.PI*2); ctx.arc(sx+12, sy-5, 8, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.moveTo(sx-16, sy+17); ctx.lineTo(sx-5, sy+5); ctx.lineTo(sx, sy+20); ctx.lineTo(sx+7, sy+5); ctx.lineTo(sx+17, sy+17); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#8b1e2d';
    ctx.beginPath(); ctx.moveTo(sx-48, sy+58); ctx.lineTo(sx-28, sy+13); ctx.lineTo(sx, sy+35); ctx.lineTo(sx+28, sy+13); ctx.lineTo(sx+48, sy+58); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#cbd5e1';
    ctx.beginPath(); ctx.arc(sx-70, sy+80, 22, Math.PI, 0); ctx.lineTo(sx-48, sy+120); ctx.lineTo(sx-92, sy+120); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#12090d';
    ctx.beginPath(); ctx.arc(sx-77, sy+78, 4, 0, Math.PI*2); ctx.arc(sx-63, sy+78, 4, 0, Math.PI*2); ctx.fill();
    // Fantasma separado, visível ao lado do vampiro.
    const gx = W - 125, gy = 145;
    ctx.fillStyle = '#e5e7eb';
    ctx.beginPath(); ctx.arc(gx, gy, 30, Math.PI, 0); ctx.lineTo(gx+30, gy+48);
    ctx.lineTo(gx+14, gy+36); ctx.lineTo(gx, gy+51); ctx.lineTo(gx-15, gy+36); ctx.lineTo(gx-30, gy+48); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#251017';
    ctx.beginPath(); ctx.arc(gx-10, gy+4, 5, 0, Math.PI*2); ctx.arc(gx+10, gy+4, 5, 0, Math.PI*2); ctx.fill();
    ctx.restore();

    // Abóbora estilizada atravessando a parte inferior do card.
    const pumpkinX = -100 + t * (W + 200);
    const pumpkinY = H - 105;
    const r = 34;
    ctx.save();
    ctx.translate(pumpkinX, pumpkinY);
    ctx.globalAlpha = 0.98;
    ctx.fillStyle = '#f97316';
    for (const dx of [-22, 0, 22]) {
        ctx.beginPath(); ctx.ellipse(dx, 0, 25, 34, 0, 0, Math.PI*2); ctx.fill();
    }
    ctx.fillStyle = '#713f12';
    ctx.fillRect(-5, -43, 10, 12);
    ctx.fillStyle = '#22c55e';
    ctx.beginPath(); ctx.ellipse(12, -39, 16, 7, -0.45, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = '#170b0b';
    ctx.beginPath(); ctx.moveTo(-20,-8); ctx.lineTo(-7,-14); ctx.lineTo(-2,-3); ctx.lineTo(7,-14); ctx.lineTo(20,-8); ctx.lineTo(11,10); ctx.lineTo(-11,10); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(-17,18); ctx.quadraticCurveTo(0,34,17,18); ctx.quadraticCurveTo(0,28,-17,18); ctx.fill();
    ctx.restore();

    // Bruxa genérica voando numa vassoura pela parte superior do card.
    const wx = 170 + t * (W - 340);
    const wy = 210 + Math.sin(t * Math.PI * 2) * 35;
    ctx.save();
    ctx.translate(wx, wy);
    ctx.scale(1.25, 1.25);
    ctx.rotate(Math.sin(t * Math.PI * 2) * 0.18 - 0.12);
    ctx.globalAlpha = 0.98;
    ctx.shadowColor = '#ff3b24'; ctx.shadowBlur = 18;
    ctx.strokeStyle = '#713f12'; ctx.lineWidth = 8;
    ctx.beginPath(); ctx.moveTo(-58, 18); ctx.lineTo(58, -8); ctx.stroke();
    ctx.fillStyle = '#b45309';
    ctx.beginPath(); ctx.moveTo(-62, 12); ctx.lineTo(-94, -5); ctx.lineTo(-86, 10); ctx.lineTo(-103, 13); ctx.lineTo(-80, 22); ctx.lineTo(-96, 32); ctx.lineTo(-63, 25); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#160d20';
    ctx.beginPath(); ctx.moveTo(-6,-28); ctx.lineTo(19,-28); ctx.lineTo(8,-62); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#ef4444'; ctx.fillRect(-18,-29,42,6);
    ctx.fillStyle = '#d6a77a'; ctx.beginPath(); ctx.arc(3,-18,11,0,Math.PI*2); ctx.fill();
    ctx.fillStyle = '#24102d';
    ctx.beginPath(); ctx.moveTo(-9,-6); ctx.lineTo(28,4); ctx.lineTo(14,28); ctx.lineTo(-24,23); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#7c3aed'; ctx.lineWidth = 3; ctx.stroke();
    if (t > 0.28 && t < 0.62) {
        ctx.rotate(-Math.sin(t * Math.PI * 2) * 0.18 + 0.12);
        ctx.fillStyle = '#fff1c2'; ctx.strokeStyle = '#ef4444'; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.ellipse(74,-44,48,25,0,0,Math.PI*2); ctx.fill(); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(43,-26); ctx.lineTo(28,-12); ctx.lineTo(52,-22); ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.fillStyle = '#8b1e2d'; ctx.font = '800 22px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('BUH!', 74, -36);
    }
    ctx.restore();
}

function desenharContornoMMHalloween(ctx, cx, cy, r, frame, totalFrames) {
    const t = ((frame % totalFrames) + totalFrames) % totalFrames / totalFrames;
    const pulse = 0.55 + 0.45 * Math.sin(t * Math.PI * 2);
    ctx.save();
    ctx.globalAlpha = 0.5 + pulse * 0.35;
    ctx.shadowColor = '#ff2417';
    ctx.shadowBlur = 28 + pulse * 18;
    ctx.strokeStyle = '#ff3b24';
    ctx.lineWidth = 10;
    ctx.beginPath(); ctx.arc(cx, cy, r + 11, 0, Math.PI * 2); ctx.stroke();
    ctx.globalAlpha = 0.95;
    ctx.shadowBlur = 12;
    ctx.strokeStyle = '#ffb000';
    ctx.lineWidth = 4;
    ctx.beginPath(); ctx.arc(cx, cy, r + 17, -Math.PI/2 + t*Math.PI*2, -Math.PI/2 + t*Math.PI*2 + Math.PI*0.72); ctx.stroke();
    ctx.strokeStyle = '#ef4444';
    ctx.beginPath(); ctx.arc(cx, cy, r + 17, Math.PI/2 + t*Math.PI*2, Math.PI/2 + t*Math.PI*2 + Math.PI*0.55); ctx.stroke();
    // Raios/flash ao redor da foto.
    ctx.strokeStyle = '#ffd166'; ctx.lineWidth = 3; ctx.shadowBlur = 16;
    for (const a of [-2.45, -1.95, -1.45, -0.95, -0.45]) {
        const aa = a + t * 0.5;
        const x1 = cx + Math.cos(aa) * (r + 23), y1 = cy + Math.sin(aa) * (r + 23);
        const x2 = cx + Math.cos(aa) * (r + 39), y2 = cy + Math.sin(aa) * (r + 39);
        ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); ctx.stroke();
    }
    // Coroa limpa, pequena e separada do rosto, sem invadir o avatar.
    const crownY = cy - r - 18;
    ctx.save();
    ctx.fillStyle = '#171114';
    ctx.strokeStyle = '#ffb000';
    ctx.lineWidth = 4;
    ctx.shadowColor = '#ff3b24'; ctx.shadowBlur = 14;
    ctx.beginPath();
    ctx.moveTo(cx-r*0.42, crownY);
    ctx.lineTo(cx-r*0.34, crownY-32);
    ctx.lineTo(cx-r*0.12, crownY-12);
    ctx.lineTo(cx, crownY-42);
    ctx.lineTo(cx+r*0.13, crownY-12);
    ctx.lineTo(cx+r*0.35, crownY-32);
    ctx.lineTo(cx+r*0.43, crownY);
    ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#ef4444';
    roundRect(ctx, cx-r*0.46, crownY-2, r*0.92, 14, 5); ctx.fill(); ctx.stroke();
    ctx.restore();
    ctx.restore();
}

function desenharFlashValor(ctx, x, y, w, h, frame, totalFrames) {
    const t = ((frame % totalFrames) + totalFrames) % totalFrames / totalFrames;
    ctx.save();
    if (t < 0.43) {
        const q = t / 0.43;
        const sx = x - 70 + q * (w + 140);
        ctx.beginPath();
        ctx.rect(x, y - h * 0.92, w, h * 0.98);
        ctx.clip();
        const grad = ctx.createLinearGradient(sx - 28, 0, sx + 28, 0);
        grad.addColorStop(0, 'rgba(255,255,255,0)');
        grad.addColorStop(0.45, 'rgba(255,248,220,0.55)');
        grad.addColorStop(0.55, 'rgba(255,70,40,0.42)');
        grad.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = grad;
        ctx.shadowColor = '#ff3b24'; ctx.shadowBlur = 18;
        ctx.fillRect(sx - 28, y - h * 0.92, 56, h * 0.98);
    } else if (t < 0.64) {
        ctx.globalAlpha = 0;
    }
    ctx.restore();
}

function desenharShimmerLuxo(ctx, x, y, w, h, frame, totalFrames, palette) {
    if (!totalFrames || totalFrames <= 1) return;
    const t = ((frame % totalFrames) + totalFrames) % totalFrames / totalFrames;
    ctx.save();
    const sx = x - 80 + t * (w + 160);
    ctx.beginPath();
    ctx.rect(x - 20, y - h * 1.15, w + 40, h * 1.4);
    ctx.clip();
    const grad = ctx.createLinearGradient(sx - 40, 0, sx + 40, 0);
    grad.addColorStop(0, 'rgba(255,255,255,0)');
    grad.addColorStop(0.35, 'rgba(255,255,255,0.25)');
    grad.addColorStop(0.5, 'rgba(255,255,255,0.7)');
    grad.addColorStop(0.65, 'rgba(255,255,255,0.25)');
    grad.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = grad;
    ctx.shadowColor = palette.GOLD_SHADOW || 'rgba(255,255,255,0.35)';
    ctx.shadowBlur = 15;
    ctx.fillRect(sx - 40, y - h * 1.15, 80, h * 1.4);
    ctx.restore();
}

async function gerarCartaoVouchGif(opts = {}) {
    const { execFile } = require('child_process');
    const os = require('os');
    const fs = require('fs');
    const frames = Math.max(4, Number(opts.animationFrames || 8));
    const fps = Math.max(4, Number(opts.animationFps || 8));
    const isHalloween = opts.halloween === true || opts.theme === 'halloween';
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vouch-anim-'));
    try {
        for (let i = 0; i < frames; i++) {
            const png = await gerarCartaoVouch({
                ...opts,
                halloween: isHalloween,
                animationFrame: i,
                animationFrames: frames
            });
            fs.writeFileSync(path.join(dir, `frame-${String(i).padStart(3, '0')}.png`), png);
        }
        const out = path.join(dir, 'vouch-animated.gif');
        await new Promise((resolve, reject) => execFile('ffmpeg', ['-y', '-framerate', String(fps), '-i', path.join(dir, 'frame-%03d.png'), '-vf', 'split[s0][s1];[s0]palettegen=max_colors=128[p];[s1][p]paletteuse=dither=sierra2_4a', out], (err, _stdout, stderr) => err ? reject(new Error(stderr || err.message)) : resolve()));
        return fs.readFileSync(out);
    } finally {
        try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) {}
    }
}

async function gerarCartaoVouch(opts = {}) {
    // Verificação estrita de segurança de fonte
    const loadedFamilies = getActiveFontFamilies();
    const montserratLoaded = (fontRegStatus && fontRegStatus.montserratCount > 0) ||
        loadedFamilies.includes("Montserrat") ||
        (GlobalFonts && typeof GlobalFonts.has === "function" && GlobalFonts.has("Montserrat"));

    if (!montserratLoaded) {
        const errMsg = `[vouchCard ERRO CRÍTICO] A fonte 'Montserrat' não foi carregada no GlobalFonts! Famílias ativas: [${loadedFamilies.join(", ")}]. ` +
            `Certifique-se de que os arquivos Montserrat-*.ttf estejam presentes na pasta ./fonts/. ` +
            `Geração de card interrompida para evitar texto invisível.`;
        console.error(errMsg);
        throw new Error(errMsg);
    }

    const globalConfig = getCardConfig().vouchOptions || {};
    const vOpts = Object.assign({}, globalConfig, opts);

    const themeName = vOpts.theme || vOpts.vouchTheme || globalConfig.theme || "bicolor_gold";
    const palette = getPalette(themeName);
    const halloween = vOpts.halloween === true || themeName === 'halloween';
    const animationFrame = Number(vOpts.animationFrame || 0);
    const animationFrames = Math.max(1, Number(vOpts.animationFrames || 1));
    const halloweenRed = vOpts.halloweenTextColor || '#ef4444';
    const itemTexto = String(vOpts.item || '').trim();
    const halloweenTextPalette = { ...palette, GOLD_HIGH: '#ffb4b4', GOLD_1: halloweenRed, GOLD_2: '#dc2626', GOLD_3: '#991b1b', GOLD_4: '#450a0a', GOLD_SOLID: '#ef4444', DARK_STAR: '#4b1117' };

    const titleText = vOpts.title || vOpts.vouchTitle || "VOUCHER DE INTERMEDIAÇÃO";
    const seloTexto = vOpts.seloTexto || vOpts.vouchSeloTexto || "INTERMEDIADOR VERIFICADO";
    const brandFooter = vOpts.brandFooter || globalConfig.brandFooter || "NEUX MIDDLE";
    const showStars = vOpts.showStars !== undefined ? (vOpts.showStars === true || vOpts.showStars === 'true') : true;

    const useCustomBg = vOpts.useCustomBg === true || vOpts.useCustomBg === 'true';
    const customBgPath = vOpts.customBgImage || vOpts.customBgUrl || path.join(process.cwd(), 'assets', 'custom_vouch_bg.png');
    const customBgOpacity = vOpts.customBgOpacity !== undefined ? (Number(vOpts.customBgOpacity) > 1 ? Number(vOpts.customBgOpacity) / 100 : Number(vOpts.customBgOpacity)) : 1.0;
    const hideDefaultBorders = vOpts.hideDefaultBorders === true || vOpts.hideDefaultBorders === 'true';
    const hideDefaultDots = vOpts.hideDefaultDots === true || vOpts.hideDefaultDots === 'true';

    const showCodeBox = vOpts.showCodeBox !== undefined ? (vOpts.showCodeBox === true || vOpts.showCodeBox === 'true') : true;
    const codeLabel = vOpts.codeLabel || "CÓDIGO DO VOUCH";

    const nameFontSize = vOpts.nameFontSize || vOpts.vouchNameFontSize || 56;
    const titleFontSize = vOpts.titleFontSize || vOpts.vouchTitleFontSize || 62;
    const valorFontSize = vOpts.valorFontSize || vOpts.vouchValorFontSize || Math.round(titleFontSize * 1.8);
    const valorLabelFontSize = vOpts.valorLabelFontSize || vOpts.vouchValorLabelFontSize || 34;
    const interFontSize = vOpts.interFontSize || vOpts.vouchInterFontSize || 24;
    const codeFontSize = vOpts.codeFontSize || vOpts.vouchCodeFontSize || 58;
    const avatarZoomR = Math.round(vOpts.avatarZoom || vOpts.vouchAvatarZoom || 133);

    const transacaoId = vOpts.transacaoId || "MM-1785439368477803";
    const vouchCodigo = vOpts.vouchCodigo || "#01645";
    const valorNum = typeof vOpts.valor === "number" ? vOpts.valor : (parseFloat(String(vOpts.valor || "1499.90").replace(",", ".")) || 1499.90);

    // Nome completo ou apelido do intermediador preservado sem truncar indevidamente
    let staffNome = vOpts.staffNome || vOpts.staffNomeCompleto || globalConfig.staffNome || "Intermediador";

    const staffAvatarURL = vOpts.staffAvatarURL || "";
    const staffNota = typeof vOpts.staffNota === "number" ? vOpts.staffNota : 5.0;
    const staffIntermediacoes = vOpts.staffIntermediacoes !== undefined ? vOpts.staffIntermediacoes : 128;

    const rankNome = vOpts.rankNome || vOpts.staffRank || getRankPorIntermediacoes(staffIntermediacoes);

    const compradorNome = vOpts.compradorNome || "Neeux MM Services (2)";
    const compradorAvatarURL = vOpts.compradorAvatarURL || "";
    const vendedorAnonimo = vOpts.vendedorAnonimo === true || vOpts.anonymous === true;
    const vendedorNome = vendedorAnonimo ? "ANÔNIMO" : (vOpts.vendedorNome || "Neeux MM Services (2)");
    const vendedorAvatarURL = vendedorAnonimo ? "__ANONYMOUS__" : (vOpts.vendedorAvatarURL || "");
    const dataStr = vOpts.data || "30/07/2026";

    const W = 1729, H = 910;
    const canvas = createCanvas(W, H);
    const ctx = canvas.getContext("2d");

    // Base de fundo do cartão de acordo com o tema selecionado
    const bgBaseColor = halloween ? "#260d12" : (palette.BG || "#120f06");
    ctx.fillStyle = bgBaseColor;
    ctx.fillRect(0, 0, W, H);

    // Imagem de fundo personalizada (custom background) se habilitada
    if (useCustomBg) {
        try {
            let bgImg = null;
            if (typeof customBgPath === 'string' && fs.existsSync(customBgPath)) {
                bgImg = await loadImage(customBgPath);
            } else if (typeof customBgPath === 'string' && (customBgPath.startsWith('http://') || customBgPath.startsWith('https://') || customBgPath.startsWith('data:'))) {
                bgImg = await loadImage(customBgPath);
            } else {
                const assetFallback = path.join(process.cwd(), 'assets', 'custom_vouch_bg.png');
                if (fs.existsSync(assetFallback)) {
                    bgImg = await loadImage(assetFallback);
                }
            }
            if (bgImg) {
                ctx.save();
                ctx.globalAlpha = Math.max(0.01, Math.min(1.0, customBgOpacity));
                ctx.drawImage(bgImg, 0, 0, W, H);
                ctx.restore();
            }
        } catch (e) {
            console.error('[vouchCard] Aviso ao carregar custom background:', e.message);
        }
    }

    if (!useCustomBg || customBgOpacity < 0.85) {
        const vignette = ctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, Math.max(W, H) * 0.82);
        vignette.addColorStop(0, "rgba(255, 255, 255, 0.04)");
        vignette.addColorStop(0.52, "rgba(0, 0, 0, 0.22)");
        vignette.addColorStop(1, "rgba(0, 0, 0, 0.65)");
        ctx.fillStyle = vignette;
        ctx.fillRect(0, 0, W, H);

        ctx.save();
        ctx.globalAlpha = 0.12;
        const luzConteudo = ctx.createRadialGradient(760, 390, 20, 760, 390, 620);
        luzConteudo.addColorStop(0, palette.GOLD_HIGH || "#FFFFFF");
        luzConteudo.addColorStop(0.55, palette.GOLD_2 || "#E8B923");
        luzConteudo.addColorStop(1, "rgba(0, 0, 0, 0)");
        ctx.fillStyle = luzConteudo;
        ctx.fillRect(80, 90, W - 160, 560);
        ctx.restore();

        ctx.save();
        ctx.globalAlpha = 0.05;
        ctx.fillStyle = palette.GOLD_2 || "#E8B923";
        ctx.fillRect(0, 0, W, H);
        ctx.restore();

        ctx.save();
        ctx.globalAlpha = 0.18;
        const brilhoEsquerdo = ctx.createLinearGradient(0, 0, W * 0.34, 0);
        brilhoEsquerdo.addColorStop(0.00, palette.GOLD_HIGH || "#FFFFFF");
        brilhoEsquerdo.addColorStop(0.45, palette.GOLD_2 || "#E8B923");
        brilhoEsquerdo.addColorStop(1.00, "rgba(0, 0, 0, 0)");
        ctx.fillStyle = brilhoEsquerdo;
        ctx.fillRect(0, 0, W * 0.34, H);

        const brilhoDireito = ctx.createLinearGradient(W, 0, W * 0.66, 0);
        brilhoDireito.addColorStop(0.00, palette.GOLD_HIGH || "#FFFFFF");
        brilhoDireito.addColorStop(0.45, palette.GOLD_2 || "#E8B923");
        brilhoDireito.addColorStop(1.00, "rgba(0, 0, 0, 0)");
        ctx.fillStyle = brilhoDireito;
        ctx.fillRect(W * 0.66, 0, W * 0.34, H);
        ctx.restore();
    }

    if (!hideDefaultDots) {
        desenharPontosFundo(ctx, W, H, palette);
    }

    if (halloween) {
        desenharHalloween(ctx, W, H, palette, animationFrame, animationFrames);
    }

    // Moldura externa se não estiver ocultada
    if (!hideDefaultBorders) {
        strokeGlowRoundRect(ctx, 14, 14, W - 28, H - 28, 12, palette, 6);

        ctx.save();
        ctx.shadowColor = palette.GOLD_SHADOW || "rgba(255, 255, 255, 0.6)";
        ctx.shadowBlur = 7;
        ctx.strokeStyle = palette.GOLD_HIGH || "rgba(255, 255, 255, 0.9)";
        ctx.lineWidth = 1.7;
        roundRect(ctx, 14, 14, W - 28, H - 28, 12);
        ctx.stroke();
        ctx.restore();

        ctx.save();
        ctx.globalAlpha = 0.42;
        ctx.strokeStyle = palette.GOLD_3 || "#8A94A0";
        ctx.lineWidth = 1;
        roundRect(ctx, 25, 25, W - 50, H - 50, 9);
        ctx.stroke();
        ctx.restore();

        if (halloween) {
            ctx.save();
            ctx.shadowColor = '#ff2417'; ctx.shadowBlur = 25; ctx.globalAlpha = 0.65;
            ctx.strokeStyle = '#b91c1c'; ctx.lineWidth = 7;
            roundRect(ctx, 10, 10, W - 20, H - 20, 16); ctx.stroke();
            ctx.restore();
        }
    }

    // 1. TÍTULO PRINCIPAL ("VOUCHER DE INTERMEDIAÇÃO")
    ctx.font = `800 ${titleFontSize}px ${FONT_STACK}`;
    ctx.textAlign = "left";
    fillTextGradient(ctx, titleText, 65, 118, titleFontSize, palette, "left");

    // Linha sob o título
    const titleUnderlineW = Math.max(157, ctx.measureText(titleText).width * 0.42);
    strokeGlowLine(ctx, 89, 168, 89 + titleUnderlineW, 168, palette, 2.5);

    // 2. ID DA TRANSAÇÃO (Canto Superior Direito)
    const rightColX = 1179;
    ctx.textAlign = "left";
    ctx.font = `500 22px ${FONT_STACK}`;
    fillTextGradient(ctx, "ID DA TRANSAÇÃO", rightColX, 82, 22, palette, "left");

    ctx.fillStyle = "#FFFFFF";
    ctx.font = `500 26px ${FONT_STACK}`;
    ctx.fillText(transacaoId, rightColX, 122);
    const idValW = ctx.measureText(transacaoId).width;
    drawCopyIcon(ctx, rightColX + idValW + 30, 108, 24, palette);

    // 3. CÓDIGO DO VOUCH (Caixa Central Direita)
    const boxW = 530, boxH = 94;
    const boxX = 1112, boxY = 215;
    const labelCx = boxX + boxW / 2;

    if (showCodeBox) {
        ctx.font = `500 20px ${FONT_STACK}`;
        fillTextGradient(ctx, codeLabel, labelCx, 210, 20, palette, "center");
        const labelW = ctx.measureText(codeLabel).width;
        strokeGlowLine(ctx, boxX, 203, labelCx - labelW / 2 - 20, 203, palette, 1.5);
        strokeGlowLine(ctx, labelCx + labelW / 2 + 20, 203, boxX + boxW, 203, palette, 1.5);

        strokeGlowRoundRect(ctx, boxX, boxY, boxW, boxH, 12, palette, 2);
        ctx.font = `800 ${codeFontSize}px ${FONT_STACK}`;
        fillTextGradient(ctx, vouchCodigo, labelCx, boxY + 64, codeFontSize, palette, "center");
    }

    // 4. VALOR INTERMEDIADO
    const valorMaxWidth = 640;
    const valorPrefixStr = "R$ ";
    const valorNumeroStr = valorNum.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
    const valorFmt = `${valorPrefixStr}${valorNumeroStr}`;

    const valorFontSizeBase = Math.round(titleFontSize * 1.82);
    const valorFontSizeAjustado = ajustarTamanhoFonteParaLargura(ctx, valorFmt, 800, valorFontSizeBase, valorMaxWidth, 36);
    const valorPrefixFontSize = valorFontSizeAjustado;

    ctx.font = `800 ${valorFontSizeAjustado}px ${FONT_STACK}`;
    const valorNumeroW = ctx.measureText(valorNumeroStr).width;
    const valorPrefixW = ctx.measureText(valorPrefixStr).width;
    const valorTotalW = valorNumeroW + valorPrefixW;

    const labelValorY = 388;
    const valorY = labelValorY + valorFontSizeAjustado + 34;

    ctx.font = `500 ${valorLabelFontSize}px ${FONT_STACK}`;
    fillTextGradient(ctx, "VALOR INTERMEDIADO", labelCx, labelValorY, valorLabelFontSize, palette, "center");

    const valorStops = [
        palette.GOLD_HIGH, palette.GOLD_HIGH,
        palette.GOLD_1, palette.GOLD_1, palette.GOLD_2,
        palette.GOLD_3, palette.GOLD_3, palette.GOLD_4
    ];

    const valorStartX = labelCx - valorTotalW / 2;

    ctx.font = `800 ${valorPrefixFontSize}px ${FONT_STACK}`;
    fillTextGradient(ctx, valorPrefixStr, valorStartX, valorY, valorPrefixFontSize, halloween ? halloweenTextPalette : palette, "left", halloween ? null : valorStops);

    ctx.font = `800 ${valorFontSizeAjustado}px ${FONT_STACK}`;
    fillTextGradient(ctx, valorNumeroStr, valorStartX + valorPrefixW, valorY, valorFontSizeAjustado, halloween ? halloweenTextPalette : palette, "left", halloween ? null : valorStops);

    if (halloween) {
        desenharFlashValor(ctx, valorStartX - 12, valorY, valorTotalW + 24, valorFontSizeAjustado, animationFrame, animationFrames);
    } else if (animationFrames > 1) {
        desenharShimmerLuxo(ctx, valorStartX - 12, valorY, valorTotalW + 24, valorFontSizeAjustado, animationFrame, animationFrames, palette);
    }

    if (itemTexto) {
        ctx.font = `500 18px ${FONT_STACK}`;
        fillTextGradient(ctx, 'ITEM', labelCx, 548, 18, halloween ? halloweenTextPalette : palette, 'center');
        ctx.fillStyle = halloween ? halloweenRed : '#FFFFFF';
        ctx.font = `600 22px ${FONT_STACK}`;
        const itemExibido = truncarComReticencias(ctx, itemTexto, 540);
        ctx.textAlign = 'center';
        ctx.fillText(itemExibido, labelCx, 583);
        ctx.textAlign = 'left';
    }

    // 5. AVATAR + INFORMAÇÕES DO STAFF / USER (Esquerda)
    const avX = 222, avY = 350, avR = avatarZoomR;
    await desenharAvatarCirculo(ctx, avX, avY, avR, staffAvatarURL || staffNome, palette);
    strokeGlowCircle(ctx, avX, avY, avR + 3, palette, 5);
    if (halloween) desenharContornoMMHalloween(ctx, avX, avY, avR, animationFrame, animationFrames);
    const infoX = avX + avR + 58;
    ctx.fillStyle = halloween ? halloweenRed : "#F5F5F5";
    ctx.font = `800 ${nameFontSize}px ${NAME_FONT_STACK}`;
    const staffNomeExibido = truncarComReticencias(ctx, staffNome, 480);
    ctx.fillText(staffNomeExibido, infoX, 299);

    // Pill da PATENTE (rank)
    const nomeW = ctx.measureText(staffNomeExibido).width;
    const rankFontSize = 22;
    ctx.font = `500 ${rankFontSize}px ${FONT_STACK}`;
    const rankTextW = ctx.measureText(rankNome).width;
    const rankPillH = 44;
    const rankPillW = rankTextW + 46;
    const rankPillX = infoX + nomeW + 26;
    const rankPillY = 299 - nameFontSize * 0.72;
    strokeGlowRoundRect(ctx, rankPillX, rankPillY, rankPillW, rankPillH, rankPillH / 2, palette, 2);
    fillTextGradient(ctx, rankNome, rankPillX + rankPillW / 2, rankPillY + rankPillH / 2 + rankFontSize * 0.35, rankFontSize, palette, "center");

    // Selo "INTERMEDIADOR VERIFICADO"
    ctx.font = `500 22px ${FONT_STACK}`;
    const seloTextW = ctx.measureText(seloTexto).width;
    const seloPillW = Math.max(392, seloTextW + 80), seloPillH = 47, seloPillY = 341;
    strokeGlowRoundRect(ctx, infoX, seloPillY, seloPillW, seloPillH, 12, palette, 2);
    drawCheckOutlineBadge(ctx, infoX + 28, seloPillY + seloPillH / 2, 13, palette);
    fillTextGradient(ctx, seloTexto, infoX + 50, seloPillY + 31, 22, palette, "left");

    // Estrelas + Nota
    let nextY = 436;
    if (showStars) {
        const notaArred = Math.max(0, Math.min(5, Math.round(staffNota)));
        let starX = infoX;
        const starY = 436, starR = 15;
        for (let i = 0; i < 5; i++) {
            drawStar(ctx, starX + starR, starY, starR, i < notaArred, halloween ? halloweenTextPalette : palette);
            starX += starR * 2 + 16;
        }
        fillTextGradient(ctx, staffNota.toFixed(1), starX + 13, 448, 28, palette, "left");
        nextY = 503;
    }

    // Intermediações
    drawList(ctx, infoX + 14, nextY, 18, palette.TEXT_MUTED);
    ctx.fillStyle = palette.TEXT_MUTED;
    ctx.font = `500 ${interFontSize}px ${FONT_STACK}`;
    ctx.fillText(`${staffIntermediacoes} INTERMEDIAÇÕES`, infoX + 36, nextY + 9);

    // 6. BLOCO RODAPÉ (Comprador / Vendedor / Data / Brand)
    const footX = 83, footY = 633, footW = 1563, footH = 194;
    const cyCirc = footY + footH / 2 + 36;

    const footLineY = footY + 18;
    ctx.save();
    const footLineGrad = ctx.createLinearGradient(footX, 0, footX + footW, 0);
    footLineGrad.addColorStop(0.00, palette.GOLD_4 || "#4B5560");
    footLineGrad.addColorStop(0.15, palette.GOLD_2 || "#B9C2CC");
    footLineGrad.addColorStop(0.50, palette.GOLD_HIGH || "#F5F7FA");
    footLineGrad.addColorStop(0.85, palette.GOLD_2 || "#B9C2CC");
    footLineGrad.addColorStop(1.00, palette.GOLD_4 || "#4B5560");
    ctx.strokeStyle = footLineGrad;
    ctx.globalAlpha = 0.48;
    ctx.lineWidth = 1.5;
    ctx.lineCap = "butt";
    ctx.beginPath();
    ctx.moveTo(footX, footLineY);
    ctx.lineTo(footX + footW, footLineY);
    ctx.stroke();
    ctx.restore();

    const circR = 38;

    async function desenharParte(cx, letra, avatarURL, label, nome, maxNomeWidth = 300) {
        await desenharAvatarCirculo(ctx, cx, cyCirc, circR, avatarURL || letra, palette);
        strokeGlowCircle(ctx, cx, cyCirc, circR + 2, palette, 1.5);

        const textX = cx + 70;

        ctx.save();
        ctx.globalAlpha = 0.65;
        ctx.fillStyle = palette.TEXT_MUTED;
        ctx.font = `500 16px ${FONT_STACK}`;
        ctx.fillText(label, textX, cyCirc - 4);
        ctx.restore();

        ctx.fillStyle = "#FFFFFF";
        ctx.font = `600 23px ${FONT_STACK}`;
        const nomeExibido = truncarComReticencias(ctx, nome, maxNomeWidth);
        ctx.fillText(nomeExibido, textX, cyCirc + 30);
        const nomeW2 = ctx.measureText(nomeExibido).width;
        drawCheckOutlineBadge(ctx, textX + nomeW2 + 22, cyCirc + 14, 14, palette);
    }

    await desenharParte(footX + 82, "C", compradorAvatarURL, "COMPRADOR", compradorNome);
    await desenharParte(footX + footW * 0.330 + 73, "V", vendedorAvatarURL, "VENDEDOR", vendedorNome);

    const dataCx = footX + footW * 0.651 + 63, dataCy = cyCirc;
    drawCalendar(ctx, dataCx, dataCy, 24, palette);

    ctx.save();
    ctx.globalAlpha = 0.65;
    ctx.fillStyle = palette.TEXT_MUTED;
    ctx.font = `500 16px ${FONT_STACK}`;
    ctx.fillText("DATA", dataCx + 42, dataCy - 4);
    ctx.restore();

    ctx.fillStyle = "#FFFFFF";
    ctx.font = `600 23px ${FONT_STACK}`;
    ctx.fillText(dataStr, dataCx + 42, dataCy + 30);

    ctx.font = `500 18px ${FONT_STACK}`;
    fillTextGradient(ctx, brandFooter, footX + footW * 0.832 + 6, cyCirc + 8, 18, palette, "left");

    return canvas.toBuffer("image/png");
}

export { gerarCartaoVouch, gerarCartaoVouchGif };
export default { gerarCartaoVouch, gerarCartaoVouchGif };
if (typeof module !== "undefined" && module.exports) {
    module.exports = { gerarCartaoVouch, gerarCartaoVouchGif };
}
