const fs = require("fs");
const path = require("path");
const {
    Client,
    GatewayIntentBits,
    EmbedBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    UserSelectMenuBuilder,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ChannelType,
    PermissionFlagsBits,
    ButtonBuilder,
    ButtonStyle,
    Events,
    MessageFlags,
    SlashCommandBuilder,
    REST,
    Routes,
    AttachmentBuilder,
    ContainerBuilder,
    TextDisplayBuilder,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder
} = require("discord.js");

const { gerarCartaoPerfil } = require("./perfilCard");
const { gerarCartaoVouch } = require("./vouchCard");
const QRCode = require("qrcode");

const TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = "1438353823235051642";
const GUILD_ID = "1417672403382960130";

const CATEGORIA_TICKETS = '1451246353735880857';
const CANAL_LOGS_ID = '1491989024276091004';
const CANAL_PROOFS = "1451245692042477752";
const CANAL_BIG_TRADE = "1455755067046236251";
const CANAL_TAXAS = "1470177275881455627";
const CANAL_AVALIACOES = "1417967103360630916";

const CARGO_STAFF_ID = "1422050552371740702";
const ID_AFILIADO = "1493722160269623367";
const CARGO_AFILIADO_ID = "1493722160269623367"; // Definido para evitar erros de referência

const RANK_COLORS = {
    "1472761782555771060": "#5865F2", // 200K  (limite 200000) - equivalente a "Master" - Azul Índigo
    "1470874824627716217": "#FFA500", // 100K  (limite 100000) - equivalente a "Nebula" - Laranja Dourado
    "1455064011413393515": "#00CED1", // Cliente Divino (limite 50000) - equivalente a "Imperador" - Ciano
    "1455064010033594549": "#9B30FF", // Cliente Lendário (limite 25000) - equivalente a "Galático" - Roxo
    "1455064008699805799": "#FF3B3B", // Cliente Sagrado (limite 10000) - equivalente a "Eterno" - Vermelho
    "1452028593268981964": "#10B981", // Cliente Celestial (limite 5000) - equivalente a "Esmeralda" - Verde
    "1455064005604540447": "#2196F3", // Cliente Imperial (limite 1000) - equivalente a "Platina" - AZUL
    "1455064003922366524": "#C0C0C0", // Cliente Nobre (limite 500) - equivalente a "Premium" - PRATA (era roxo, corrigido)
    "1417913178779549767": "#C0C0C0"  // Cliente Iniciante (limite 0) - equivalente a "Cliente" - PRATA (consistente com a paleta do vouch)
};

const RANK_CARGOS = [
  { nome: "200K", limite: 200000, id: "1472761782555771060", iconType: "crown" },
  { nome: "100K", limite: 100000, id: "1470874824627716217", iconType: "crown" },
  { nome: "Cliente Divino", limite: 50000, id: "1455064011413393515", iconType: "diamond" },
  { nome: "Cliente Lendário", limite: 25000, id: "1455064010033594549", iconType: "star" },
  { nome: "Cliente Sagrado", limite: 10000, id: "1455064008699805799", iconType: "star" },
  { nome: "Cliente Celestial", limite: 5000, id: "1452028593268981964", iconType: "diamond" },
  { nome: "Cliente Imperial", limite: 1000, id: "1455064005604540447", iconType: "shield" },
  { nome: "Cliente Nobre", limite: 500, id: "1455064003922366524", iconType: "shield" },
  { nome: "Cliente Iniciante", limite: 0, id: "1417913178779549767", iconType: "star" },
];

const CARGO_TOP_1 = "1475045304444256296";
const CARGO_TOP_2 = "1497401431739732019";
const CARGO_TOP_3 = "1442589543487373444";

const EMOJI_CHECK = '<:2974:1438244299564126279>';
const EMOJI_PIX_TITULO = "✅";
const THUMBNAIL_SPEED = "https://i.postimg.cc/ZKp8yjpK/nex1-2.gif"; // Link direto fornecido pelo usuário

const dbPixPath = path.join(__dirname, 'pix_database.json');
const dbUsersPath = path.join(__dirname, 'users_mm.json');
const dbGlobalPath = path.join(__dirname, 'proofs_global.json');
const dbTaxasPath = path.join(__dirname, 'taxas_diarias.json');

let globalCounter = 1447;
if (fs.existsSync(dbGlobalPath)) {
    try {
        const savedGlobal = JSON.parse(fs.readFileSync(dbGlobalPath));
        if (typeof savedGlobal === 'number') globalCounter = savedGlobal;
    } catch (e) { console.error("Erro ao carregar globalCounter:", e); }
}

let userData = {};
if (fs.existsSync(dbUsersPath)) {
    try {
        userData = JSON.parse(fs.readFileSync(dbUsersPath));
    } catch (e) { console.error("Erro ao carregar userData:", e); }
}

let taxasDiarias = {};
if (fs.existsSync(dbTaxasPath)) {
    try {
        taxasDiarias = JSON.parse(fs.readFileSync(dbTaxasPath));
    } catch (e) { console.error("Erro ao carregar taxasDiarias:", e); }
}

let pixConfig = new Map();
if (fs.existsSync(dbPixPath)) {
    try {
        pixConfig = new Map(Object.entries(JSON.parse(fs.readFileSync(dbPixPath))));
    } catch (e) { console.error("Erro ao carregar banco de dados PIX:", e); }
}

function saveGlobal() { fs.writeFileSync(dbGlobalPath, JSON.stringify(globalCounter)); }
function saveUsers() { fs.writeFileSync(dbUsersPath, JSON.stringify(userData, null, 2)); }
function saveTaxas() { fs.writeFileSync(dbTaxasPath, JSON.stringify(taxasDiarias, null, 2)); }
function salvarDadosPix() {
    const obj = Object.fromEntries(pixConfig);
    fs.writeFileSync(dbPixPath, JSON.stringify(obj, null, 2));
}

function sanitizarValor(valorStr) {
    if (typeof valorStr !== 'string') return 0;
    let limpo = valorStr.trim();

    if (limpo.includes('.') && limpo.includes(',')) {
        limpo = limpo.replace(/\./g, '').replace(',', '.');
    }
    else if (limpo.includes(',') && limpo.indexOf(',') < limpo.indexOf('.')) {
        limpo = limpo.replace(/,/g, '');
    }
    else if (limpo.includes('.') && !limpo.includes(',')) {
        const partes = limpo.split('.');
        const ultimaParte = partes[partes.length - 1];
        if (ultimaParte.length === 3) {
            limpo = limpo.replace(/\./g, '');
        }
    }
    else if (limpo.includes(',') && !limpo.includes('.')) {
        limpo = limpo.replace(',', '.');
    }

    const num = parseFloat(limpo);
    return isNaN(num) ? 0 : num;
}

const tradeData = new Map();
function loadTradeDataFromDisk() {
    try {
        if (fs.existsSync('trade_data.json')) {
            const content = fs.readFileSync('trade_data.json', 'utf8');
            if (content && content.trim().length > 2) {
                const parsed = JSON.parse(content);
                for (const [k, v] of Object.entries(parsed)) {
                    tradeData.set(k, v);
                }
            }
        }
    } catch (e) {
        console.error('Erro ao carregar trade_data.json:', e);
    }
}
function saveTradeDataToDisk() {
    try {
        const obj = {};
        for (const [k, v] of tradeData.entries()) {
            obj[k] = { ...v, colValor: null, colItem: null, msgValor: null, msgItem: null };
        }
        fs.writeFileSync('trade_data.json', JSON.stringify(obj, null, 2));
    } catch (e) {
        console.error('Erro ao salvar trade_data.json:', e);
    }
}
loadTradeDataFromDisk();
const pixStorage = new Map();
const chaveFinalStorage = new Map();
const dbAvaliacoesPath = path.join(__dirname, 'avaliacoes_pendentes.json');
const avaliacoesPendentes = new Map();
function loadAvaliacoesPendentes() {
    try {
        if (fs.existsSync(dbAvaliacoesPath)) {
            const data = JSON.parse(fs.readFileSync(dbAvaliacoesPath, 'utf8'));
            for (const [k, v] of Object.entries(data)) {
                avaliacoesPendentes.set(k, v);
            }
        }
    } catch (e) {
        console.error('Erro ao carregar avaliacoes_pendentes.json:', e);
    }
}
function saveAvaliacoesPendentes() {
    try {
        const obj = {};
        for (const [k, v] of avaliacoesPendentes.entries()) {
            obj[k] = v;
        }
        fs.writeFileSync(dbAvaliacoesPath, JSON.stringify(obj, null, 2));
    } catch (e) {
        console.error('Erro ao salvar avaliacoes_pendentes.json:', e);
    }
}
loadAvaliacoesPendentes();

function gerarIdAvaliacao() {
    return `AVL${Date.now()}${Math.floor(Math.random() * 900 + 100)}`;
}

function registerTrade(userId, valor, contraparteId = null) {
  if (!userData[userId]) userData[userId] = { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
  if (!userData[userId].clienteDesde) userData[userId].clienteDesde = new Date().getFullYear();
  userData[userId].totalTrocas++;
  userData[userId].totalValor += valor;
  userData[userId].totalMes += valor;
  if (valor > userData[userId].maiorTroca) userData[userId].maiorTroca = valor;

  if (contraparteId) {
    if (!userData[userId].listaPessoas) userData[userId].listaPessoas = [];
    if (!userData[userId].listaPessoas.includes(contraparteId)) {
      userData[userId].listaPessoas.push(contraparteId);
      userData[userId].pessoasIntermediadas = userData[userId].listaPessoas.length;
    }
  }

  saveUsers();
}

function registerStaffTrade(userId, valor, contraparteIds = []) {
  if (!userData[userId]) userData[userId] = { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
  if (!userData[userId].clienteDesde) userData[userId].clienteDesde = new Date().getFullYear();
  userData[userId].totalTrocas++;

  if (!userData[userId].listaPessoas) userData[userId].listaPessoas = [];
  for (const cid of contraparteIds) {
    if (cid && !userData[userId].listaPessoas.includes(cid)) {
      userData[userId].listaPessoas.push(cid);
    }
  }
  userData[userId].pessoasIntermediadas = userData[userId].listaPessoas.length;

  saveUsers();
}

async function atualizarCargos(guild, userId) {
  try {
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) return;
    const data = userData[userId];

    for (const rank of RANK_CARGOS) {
        if (data && data.totalValor >= rank.limite) {
            try {
                if (!member.roles.cache.has(rank.id)) {
                    await member.roles.add(rank.id);
                }
            } catch (e) {
                console.error(`Erro ao adicionar cargo ${rank.nome} para ${userId}:`, e.message);
            }
        }
    }

    const allUsersMonthly = Object.entries(userData).sort(([, a], [, b]) => b.totalMes - a.totalMes);
    const rolesTop = [CARGO_TOP_1, CARGO_TOP_2, CARGO_TOP_3];

    for (let i = 0; i < 3; i++) {
      if (allUsersMonthly[i]) {
        const topUserId = allUsersMonthly[i][0];
        const topMember = await guild.members.fetch(topUserId).catch(() => null);
        const roleId = rolesTop[i];

        if (topMember) {
          const role = guild.roles.cache.get(roleId);
          if (role) {
            await Promise.all(role.members.map(m => {
                if(m.id !== topUserId) return m.roles.remove(roleId).catch(() => {});
            }));
            if (!topMember.roles.cache.has(roleId)) await topMember.roles.add(roleId).catch(() => {});
          }
        }
      }
    }
  } catch (err) { console.error("Erro ao atualizar cargos:", err); }
}

// tipoTaxa: 'normal' (middleman padrão, !middleman) ou 'baixa' (middleman2, !middleman2)
// A diferença hoje é só na primeira faixa (R$0,50 vira R$0,25), mas dá pra ajustar
// as outras faixas do "baixa" aqui se quiser deixar tudo mais barato também.
function calcularTaxaBase(v, tipoTaxa = 'normal') {
  v = parseFloat(v) || 0;
  const taxaMinima = tipoTaxa === 'baixa' ? 0.25 : 0.50;
  if (v >= 700) return v * 0.01;
  if (v >= 400) return 6.50;
  if (v >= 200) return 4.00;
  if (v >= 100) return 2.00;
  if (v >= 8) return taxaMinima;
  return 0;
}

function calcularTaxa(tipo, valor, enviadorId, recebedorId) {
  let taxaBase = 0;
  if (tipo === "crosstrade") taxaBase = 1.0;
  else if (valor >= 700) taxaBase = valor * 0.01;
  else if (valor >= 400) taxaBase = 6.50;
  else if (valor >= 200) taxaBase = 4.00;
  else if (valor >= 100) taxaBase = 2.00;
  else if (valor >= 8) taxaBase = 0.50;
  if (enviadorId === ID_AFILIADO || recebedorId === ID_AFILIADO) taxaBase /= 2;
  return taxaBase;
}

function crc16(payload) {
    let polinomio = 0x1021;
    let resultado = 0xFFFF;
    for (let i = 0; i < payload.length; i++) {
        resultado ^= payload.charCodeAt(i) << 8;
        for (let j = 0; j < 8; j++) {
            if (resultado & 0x8000) resultado = (resultado << 1) ^ polinomio;
            else resultado <<= 1;
            resultado &= 0xFFFF;
        }
    }
    return resultado.toString(16).toUpperCase().padStart(4, "0");
}

function gerarPix(chave, nome, valor) {
    if (typeof chave !== "string" || !chave.trim()) {
        throw new Error("Chave PIX vazia ou inválida");
    }

    const valorNumerico = Number(valor);
    if (!Number.isFinite(valorNumerico) || valorNumerico <= 0) {
        throw new Error(`Valor PIX inválido: ${valor}`);
    }

    const chaveF = chave.trim();
    const nomeF = String(nome || "PAGAMENTO")
        .trim()
        .substring(0, 25)
        .toUpperCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "");
    const valorF = valorNumerico.toFixed(2);

    const merchantAccount =
        "0014br.gov.bcb.pix01" +
        chaveF.length.toString().padStart(2, "0") +
        chaveF;

    const payload =
        "00020101021126" +
        merchantAccount.length.toString().padStart(2, "0") +
        merchantAccount +
        "52040000530398654" +
        valorF.length.toString().padStart(2, "0") +
        valorF +
        "5802BR59" +
        nomeF.length.toString().padStart(2, "0") +
        nomeF +
        "6009SAO PAULO62070503***6304";

    return payload + crc16(payload);
}

async function getRankingEmbed(guild, tipo, pagina) {
  const isGeral = tipo === "geral";
  const sortedUsers = Object.entries(userData).sort(([, a], [, b]) => (isGeral ? b.totalValor - a.totalValor : b.totalMes - a.totalMes));

  const itensPorPagina = 10;
  const totalPaginas = Math.ceil(sortedUsers.length / itensPorPagina) || 1;
  if (pagina < 1) pagina = 1;
  if (pagina > totalPaginas) pagina = totalPaginas;

  const indexInicio = (pagina - 1) * itensPorPagina;
  const slice = sortedUsers.slice(indexInicio, indexInicio + itensPorPagina);

  const embedTitulo = new EmbedBuilder()
    .setColor("#DE4548")
    .setTitle(`🏆 Ranking de Movimentação - ${isGeral ? "Geral" : "Mensal"}`)
    .setThumbnail(THUMBNAIL_SPEED);

  const rowMenu = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId("rank_select")
      .setPlaceholder("Alterar tipo de ranking...")
      .addOptions(
        { label: "Ranking Geral", value: "geral", default: isGeral },
        { label: "Ranking Mensal", value: "mensal", default: !isGeral }
      )
  );

  let listaCorpo = "";
  for (let i = 0; i < slice.length; i++) {
    const [id, data] = slice[i];
    const posicao = indexInicio + i + 1;
    const valor = isGeral ? data.totalValor : data.totalMes;
    const valorFormatado = valor.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
    listaCorpo += `${posicao}. <@${id}> total de R$ \`${valorFormatado}\` gastos e \`${data.totalTrocas}\` troca(s)\n`;
  }

  const embedLista = new EmbedBuilder()
    .setColor("#DE4548")
    .setDescription(listaCorpo || "Nenhum resultado encontrado.")
    .setFooter({ text: `Página ${pagina} de ${totalPaginas} • ${sortedUsers.length} trader(s)` });

  const rowBotoes = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`rankprev_${tipo}_${pagina}`).setLabel("Anterior").setEmoji("◀️").setStyle(ButtonStyle.Secondary).setDisabled(pagina <= 1),
    new ButtonBuilder().setCustomId(`ranknext_${tipo}_${pagina}`).setLabel("Próximo").setEmoji("▶️").setStyle(ButtonStyle.Secondary).setDisabled(pagina >= totalPaginas)
  );

  return { embeds: [embedTitulo, embedLista], components: [rowMenu, rowBotoes] };
}

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.DirectMessages
    ]
});

client.once(Events.ClientReady, () => {
    console.log(`✅ Santa MM\'s V2 Integrado Online!`);
    checkScheduledTasks();
    setInterval(checkScheduledTasks, 60 * 1000); // Executa a cada minuto
});

process.on('unhandledRejection', (reason) => console.log(' [ANTI-CRASH] Rejeição:', reason));
process.on('uncaughtException', (err) => console.log(' [ANTI-CRASH] Exceção:', err));

function construirContainerFuncoes(data) {
    const mencoes = data.participantes.map(id => `<@${id}>`).join(' ') || '';

    return new ContainerBuilder()
        .setAccentColor(0xDE4548)
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `${mencoes}\n` +
                `# <:parceria:1485054250429054986> ━ Seleção de Funções\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `Confirmem as funções de vocês: quem vai enviar o PIX pro MM e quem vai receber o PIX do MM depois da troca.\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `<:emoji_166:1541616981348851763> **Vou enviar o pix** — Você vai enviar o PIX para o middleman.\n` +
                `<:emoji_164:1541612138756579439> **Vou receber** — Você vai receber o PIX do middleman.\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `**Enviador:** ${data.enviador ? `<@${data.enviador}>` : 'Aguardando...'}\n` +
                `**Recebedor:** ${data.recebedor ? `<@${data.recebedor}>` : 'Aguardando...'}`
            )
        )
        .addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('set_enviador').setLabel('Vou enviar o Pix').setEmoji('<:emoji_166:1541616981348851763>').setStyle(ButtonStyle.Secondary).setDisabled(!!data.enviador),
                new ButtonBuilder().setCustomId('set_recebedor').setLabel('Vou Receber').setEmoji('<:emoji_164:1541612138756579439>').setStyle(ButtonStyle.Secondary).setDisabled(!!data.recebedor),
                new ButtonBuilder().setCustomId('resetar_fluxo').setLabel('Resetar').setEmoji('<:emoji_167:1541618912238768148>').setStyle(ButtonStyle.Secondary)
            )
        )
        .addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('btn_fechar').setLabel('Excluir intermediação').setEmoji('<:emoji_167:1541618912238768148>').setStyle(ButtonStyle.Secondary)
            )
        );
}

async function iniciarFluxoImagens(channel) {
    let data = tradeData.get(channel.id);
    if (!data) {
        data = { enviador: null, recebedor: null, valor: null, item: null, staffReivindicou: null, msgDmId: null, confirmacoes: [], confirmacoesEntrega: [], participantes: [], colValor: null, colItem: null, msgValor: null, msgItem: null };
        tradeData.set(channel.id, data);
    } else {
        data.colValor?.stop();
        data.colItem?.stop();
        data.colValor = null;
        data.colItem = null;
        data.msgValor = null;
        data.msgItem = null;
        data.enviador = null; data.recebedor = null; data.valor = null; data.item = null; data.staffReivindicou = null; data.confirmacoes = []; data.confirmacoesEntrega = []; data.lockValor = false; data.lockItem = false;
    }

    const container = construirContainerFuncoes(data);

    await channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(console.error);
}

async function getCanal(guild, channelId) {
    if (!guild || !channelId) return null;
    try {
        return guild.channels.cache.get(channelId) || await guild.channels.fetch(channelId).catch(() => null);
    } catch (e) {
        return null;
    }
}

async function responderSeguro(interaction, options) {
    const isDM = !interaction.guildId;
    const opts = typeof options === 'string' ? { content: options } : { ...options };
    if (isDM) {
        delete opts.flags;
        if (opts.ephemeral) delete opts.ephemeral;
    } else {
        if (opts.ephemeral && !opts.flags) opts.flags = [MessageFlags.Ephemeral];
    }
    try {
        if (interaction.deferred || interaction.replied) {
            return await interaction.followUp(opts).catch(console.error);
        }
        return await interaction.reply(opts).catch(console.error);
    } catch (e) {
        console.error("Erro ao responder interação:", e);
    }
}

async function enviarLog(guild, embed, files = []) {
    const canalLog = await getCanal(guild, CANAL_LOGS_ID);
    if (!canalLog) {
        console.error("Canal de logs não encontrado:", CANAL_LOGS_ID);
        return false;
    }

    try {
        await canalLog.send({ embeds: [embed], files });
        return true;
    } catch (erro) {
        console.error("Erro ao enviar embed para o canal de logs:", erro);
        return false;
    }
}

// ── Sistema Anti-Duplicação (Cooldown) ──
// Evita que a mesma pessoa dispare a mesma ação duas vezes clicando/respondendo
// rápido demais (double-click, lag do Discord reenviando a interação, etc).
const interactionCooldowns = new Map();
const COOLDOWN_MS = 2500; // tempo mínimo de espera entre ações repetidas

function estaEmCooldown(key) {
    const ultimo = interactionCooldowns.get(key);
    if (!ultimo) return false;
    return (Date.now() - ultimo) < COOLDOWN_MS;
}

function registrarCooldown(key) {
    interactionCooldowns.set(key, Date.now());
}

// Limpa entradas antigas periodicamente para não crescer a memória infinitamente
setInterval(() => {
    const agora = Date.now();
    for (const [key, timestamp] of interactionCooldowns) {
        if (agora - timestamp > COOLDOWN_MS * 4) interactionCooldowns.delete(key);
    }
}, 60 * 1000);

// Evita registrar o handler mais de uma vez caso o painel de hospedagem
// recarregue este arquivo sem reiniciar o processo Node por completo
// (o que causaria a mesma interação sendo processada 2x e gerando erros
// "Unknown Message" ao tentar editar uma resposta já usada).
// client.removeAllListeners(Events.InteractionCreate) bypassed

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (interaction.inGuild() && !interaction.isModalSubmit() && (!interaction.member || !interaction.member.roles?.cache)) {
        try {
            interaction.member = await interaction.guild.members.fetch(interaction.user.id);
        } catch (e) {
            console.error("Falha ao buscar o member da interação:", e);
        }
    }

    // Bloqueia cliques/seleções repetidas do MESMO usuário no MESMO botão/menu
    // dentro do MESMO canal antes do tempo de cooldown passar.
    // Modais e comandos de barra não entram nesse bloqueio.
    if (interaction.isButton() || interaction.isStringSelectMenu() || interaction.isUserSelectMenu()) {
        const cooldownKey = `${interaction.channelId}_${interaction.customId}_${interaction.user.id}`;
        if (estaEmCooldown(cooldownKey)) {
            return await interaction.reply({ content: "⏳ Calma! Aguarde um instante antes de clicar novamente.", flags: [MessageFlags.Ephemeral] }).catch(() => {});
        }
        registrarCooldown(cooldownKey);
    }

    let data = tradeData.get(interaction.channelId); if (!data) { loadTradeDataFromDisk(); data = tradeData.get(interaction.channelId); }

    if (interaction.isChatInputCommand()) {
        if (interaction.commandName === "configpix") {
            if (!interaction.member?.permissions?.has(PermissionFlagsBits.Administrator)) {
                return await interaction.reply({ content: "❌ Apenas administradores podem configurar o PIX de um Middleman.", flags: [MessageFlags.Ephemeral] });
            }
            const modal = new ModalBuilder().setCustomId("modal_config_pix").setTitle("Configurar PIX do Middleman");
            modal.addComponents(
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("pix_id").setLabel("ID do usuário (Middleman)").setPlaceholder("Ex: 123456789012345678").setStyle(TextInputStyle.Short).setRequired(true)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("pix_key").setLabel("Chave PIX").setStyle(TextInputStyle.Short).setRequired(true)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("pix_name").setLabel("Nome Completo (Sem acentos)").setStyle(TextInputStyle.Short).setRequired(true)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("pix_limite").setLabel("Valor máximo que pode mediar (R$)").setPlaceholder("Ex: 500  |  deixe 0 para sem limite").setStyle(TextInputStyle.Short).setRequired(false))
            );
            return await interaction.showModal(modal);
        }
        if (interaction.commandName === "ranking") {
            const embedContent = await getRankingEmbed(interaction.guild, "geral", 1);
            return await interaction.reply(embedContent);
        }

        if (interaction.commandName === "perfil") {
            await interaction.deferReply();

            const user = interaction.options.getUser("usuario") || interaction.user;
            const profileUser = await interaction.client.users.fetch(user.id, { force: true }).catch(() => user);
            const dataU = userData[user.id] || { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
            const member = await interaction.guild.members.fetch(user.id).catch(() => null);

            const allUsersGeral = Object.entries(userData).sort(([, a], [, b]) => b.totalValor - a.totalValor);
            const rankGeral = allUsersGeral.findIndex(([id]) => id === user.id) + 1;
            const allUsersMensal = Object.entries(userData).sort(([, a], [, b]) => (b.totalMes || 0) - (a.totalMes || 0));
            const rankMensal = allUsersMensal.findIndex(([id]) => id === user.id) + 1;

            const cargoAtual = RANK_CARGOS.find(r => dataU.totalValor >= r.limite) || RANK_CARGOS[RANK_CARGOS.length - 1];
            const indexAtual = RANK_CARGOS.indexOf(cargoAtual);
            const proximoCargo = RANK_CARGOS[indexAtual - 1];

            try {
                const buffer = await gerarCartaoPerfil({
                    username: profileUser.username,
                    avatarURL: profileUser.displayAvatarURL({ extension: "png", size: 256 }),
                    userHandle: profileUser.username,
                    bannerURL: profileUser.bannerURL({ extension: "png", size: 1024 }),
                    hasNitro: Boolean(profileUser.banner),
                    cargos: member ? [...member.roles.cache.values()]
                        .filter(role => role.id !== interaction.guild.id)
                        .map(role => ({ id: role.id, name: role.name, color: role.hexColor, position: role.position })) : [],
                    rankNome: cargoAtual.nome,
                    rankCorHex: RANK_COLORS[cargoAtual.id] || "#9B30FF",
                    rankIconType: cargoAtual.iconType,
                    rank: rankGeral || allUsersGeral.length + 1,
                    rankMensal: rankMensal || allUsersMensal.length + 1,
                    total: dataU.totalValor || 0,
                    trocas: dataU.totalTrocas || 0,
                    maiorTrend: dataU.maiorTroca || 0,
                    valorMensal: dataU.totalMes || 0,
                    totalMensal: dataU.totalMes || 0,
                    clienteDesde: dataU.clienteDesde || new Date().getFullYear(),
                    proximoRank: proximoCargo ? { nome: proximoCargo.nome, faltam: Math.max(0, proximoCargo.limite - dataU.totalValor) } : null,
                    progresso: proximoCargo ? (dataU.totalValor - cargoAtual.limite) / (proximoCargo.limite - cargoAtual.limite) : 1,
                    conquistas: [
                        { tier: "bronze", iconType: "handshake", label: "100 intermédios", desbloqueado: dataU.totalTrocas >= 100 },
                        { tier: "prata", iconType: "money", label: "R$ 1k movim.", desbloqueado: dataU.totalValor >= 1000 },
                        { tier: "ouro", iconType: "money", label: "R$ 10k movim.", desbloqueado: dataU.totalValor >= 10000 },
                        { tier: "value", iconType: "diamond", label: "Trade R$ 500+", desbloqueado: dataU.maiorTroca >= 500 },
                        { tier: "black", iconType: "flame", label: "250 intermédios", desbloqueado: dataU.totalTrocas >= 250 },
                        { tier: "vermelho", iconType: "flame", label: "500 intermédios", desbloqueado: dataU.totalTrocas >= 500 },
                        { tier: "vermelho", iconType: "crown", label: "Top Trader", desbloqueado: rankGeral === 1 },
                        { tier: "vermelho", iconType: "crown", label: "Maior do mês", desbloqueado: rankMensal === 1 }
                    ]
                });

                const anexo = new AttachmentBuilder(buffer, { name: "perfil.png" });
                return await interaction.editReply({ files: [anexo] });
            } catch (e) {
                console.error("Erro ao gerar cartão de perfil:", e);
                return await interaction.editReply({ content: "❌ Erro ao gerar o cartão de perfil." });
            }
        }

        if (interaction.commandName === "vouch") {
            if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return await interaction.reply({ content: "❌ Sem permissão.", flags: [MessageFlags.Ephemeral] });
            const tipo = interaction.options.getString("tipo");
            const comprador = interaction.options.getUser("comprador");
            const vendedor = interaction.options.getUser("vendedor");
            const valor = sanitizarValor(interaction.options.getString("valor"));
            if (valor <= 0) return await interaction.reply({ content: "❌ Valor inválido.", flags: [MessageFlags.Ephemeral] });
            await interaction.deferReply();
            await executarAprovarPagamento(interaction.guild, interaction.user, tipo, comprador, vendedor, valor);
            return await interaction.editReply({ content: `✅ Pagamento de R$ ${valor.toFixed(2)} aprovado!` });
        }

        if (interaction.commandName === "aprovar_pagamento") {
            if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return await interaction.reply({ content: "❌ Sem permissão.", flags: [MessageFlags.Ephemeral] });
            const tipo = interaction.options.getString("tipo");
            const enviador = interaction.options.getUser("enviador");
            const recebedor = interaction.options.getUser("recebedor");
            const valor = sanitizarValor(interaction.options.getString("valor"));
            if (valor <= 0) return await interaction.reply({ content: "❌ Valor inválido.", flags: [MessageFlags.Ephemeral] });
            await interaction.deferReply();
            await executarAprovarPagamento(interaction.guild, interaction.user, tipo, enviador, recebedor, valor);
            return await interaction.editReply({ content: `✅ Pagamento de R$ ${valor.toFixed(2)} aprovado!` });
        }
        if (interaction.commandName === "remover_valor") {
            if (!interaction.member?.permissions?.has(PermissionFlagsBits.Administrator)) return await interaction.reply({ content: "❌ Sem permissão.", flags: [MessageFlags.Ephemeral] });
            const user = interaction.options.getUser("usuario");
            const valor = sanitizarValor(interaction.options.getString("valor"));
            if (valor <= 0) return await interaction.reply({ content: "❌ Valor inválido.", flags: [MessageFlags.Ephemeral] });
            if (userData[user.id]) {
                userData[user.id].totalValor -= valor;
                userData[user.id].totalMes -= valor;
                if (userData[user.id].totalValor < 0) userData[user.id].totalValor = 0;
                if (userData[user.id].totalMes < 0) userData[user.id].totalMes = 0;
                saveUsers();
                await atualizarCargos(interaction.guild, user.id);
                return await interaction.reply({ content: `✅ Removido R$ ${valor.toFixed(2)} de <@${user.id}>.` });
            }
            return await interaction.reply({ content: "❌ Usuário não encontrado no banco.", flags: [MessageFlags.Ephemeral] });
        }
    }

    if (interaction.isStringSelectMenu() && interaction.customId === "rank_select") {
        const tipo = interaction.values[0];
        const embedContent = await getRankingEmbed(interaction.guild, tipo, 1);
        return await interaction.update(embedContent);
    }

    if (interaction.isButton() && interaction.customId.startsWith("rank")) {
        const parts = interaction.customId.split("_");
        const action = parts[0];
        const tipo = parts[1];
        let pagina = parseInt(parts[2]);
        if (action === "rankprev") pagina--; else pagina++;
        const embedContent = await getRankingEmbed(interaction.guild, tipo, pagina);
        return await interaction.update(embedContent);
    }

    if (interaction.isButton() && ["mm_perfil", "mm_mes", "mm_dia", "mm_pessoas"].includes(interaction.customId)) {
        if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) {
            return await interaction.reply({ content: "❌ Esse painel é exclusivo para a staff.", flags: [MessageFlags.Ephemeral] });
        }

        const d = userData[interaction.user.id] || {};

        if (interaction.customId === "mm_perfil") {
            const avaliacoesStaff = d.avaliacoes || [];
            const notaMedia = avaliacoesStaff.length ? (avaliacoesStaff.reduce((a, b) => a + b, 0) / avaliacoesStaff.length).toFixed(1) : "Sem avaliações";
            const embed = new EmbedBuilder()
                .setColor("#DE4548")
                .setTitle(`👤 Perfil de Middleman — ${interaction.user.username}`)
                .setThumbnail(interaction.user.displayAvatarURL({ extension: "png", size: 128 }))
                .addFields(
                    { name: "🤝 Intermediações totais", value: `${d.totalTrocas || 0}`, inline: true },
                    { name: "👥 Pessoas atendidas", value: `${d.pessoasIntermediadas || 0}`, inline: true },
                    { name: "⭐ Nota média", value: `${notaMedia}`, inline: true },
                    { name: "💰 Taxa faturada (total)", value: `R$ ${(d.taxaTotal || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`, inline: true },
                    { name: "📅 Taxa faturada (mês)", value: `R$ ${(d.taxaMes || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`, inline: true },
                    { name: "🕐 Taxa faturada (hoje)", value: `R$ ${(taxasDiarias[interaction.user.id] || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`, inline: true }
                );
            return await interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
        }

        if (interaction.customId === "mm_mes") {
            const taxaMes = d.taxaMes || 0;
            return await interaction.reply({ content: `💰 Você faturou **R$ ${taxaMes.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}** em taxas este mês.`, flags: [MessageFlags.Ephemeral] });
        }

        if (interaction.customId === "mm_dia") {
            const taxaDia = taxasDiarias[interaction.user.id] || 0;
            return await interaction.reply({ content: `📅 Você faturou **R$ ${taxaDia.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}** em taxas hoje (ainda não repassado no fechamento diário).`, flags: [MessageFlags.Ephemeral] });
        }

        if (interaction.customId === "mm_pessoas") {
            const lista = d.listaPessoas || [];
            if (!lista.length) return await interaction.reply({ content: "👥 Você ainda não intermediou ninguém.", flags: [MessageFlags.Ephemeral] });
            const exibidos = lista.slice(0, 30).map(id => `<@${id}>`).join(", ");
            const resto = lista.length > 30 ? `\n-# ...e mais ${lista.length - 30} pessoa(s).` : "";
            return await interaction.reply({ content: `👥 **Pessoas que você já atendeu (${lista.length}):**\n${exibidos}${resto}`, flags: [MessageFlags.Ephemeral] });
        }
    }

    if (interaction.isButton() && interaction.customId.startsWith("abrir_transcript_")) {
        const pendingId = interaction.customId.replace("abrir_transcript_", "");
        const pend = avaliacoesPendentes.get(pendingId);
        if (!pend || !pend.transcript) return await responderSeguro(interaction, { content: "❌ Transcript não encontrado ou expirado.", ephemeral: true });
        const anexoTranscript = new AttachmentBuilder(Buffer.from(pend.transcript), { name: `transcript-${pendingId}.txt` });
        return await responderSeguro(interaction, { content: "📄 Aqui está o transcript da sua negociação:", files: [anexoTranscript], ephemeral: true });
    }

    if (interaction.isButton() && interaction.customId.startsWith("av_")) {
        const partesId = interaction.customId.split("_");
        const nota = partesId[1];
        const pendingId = partesId.slice(2).join("_");
        const pend = avaliacoesPendentes.get(pendingId);
        if (!pend) return await responderSeguro(interaction, { content: "❌ Essa avaliação já expirou ou não foi encontrada.", ephemeral: true });
        if (pend.avaliacoes && pend.avaliacoes[interaction.user.id]) return await responderSeguro(interaction, { content: "✅ Você já avaliou esta mediação, obrigado!", ephemeral: true });
        if (interaction.user.id !== pend.enviador && interaction.user.id !== pend.recebedor) return await responderSeguro(interaction, { content: "❌ Você não faz parte dessa negociação.", ephemeral: true });

        const modalAvaliacao = new ModalBuilder()
            .setCustomId(`modal_avaliacao_${nota}_${pendingId}`)
            .setTitle("Deixe seu comentário")
            .addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId("comentario_avaliacao")
                        .setLabel("Como foi sua experiência com o MM?")
                        .setStyle(TextInputStyle.Paragraph)
                        .setPlaceholder("Conte como foi a mediação, o atendimento, a agilidade...")
                        .setMaxLength(300)
                        .setRequired(true)
                )
            );
        return await interaction.showModal(modalAvaliacao);
    }

    if (data && interaction.isButton() && !interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) {
        if (!data.participantes.includes(interaction.user.id)) return await interaction.reply({ content: "❌ Você não faz parte desta negociação!", flags: [MessageFlags.Ephemeral] });
    }

    if (interaction.isModalSubmit() && interaction.customId === "modal_config_pix") {
        const idDigitado = interaction.fields.getTextInputValue("pix_id").trim();
        if (!/^\d{17,20}$/.test(idDigitado)) {
            return await interaction.reply({ content: "❌ ID inválido. Clique com o botão direito no usuário no Discord → **Copiar ID de Usuário** e cole exatamente esse valor.", flags: [MessageFlags.Ephemeral] });
        }
        const membroAlvo = await interaction.guild.members.fetch(idDigitado).catch(() => null);
        if (!membroAlvo) {
            return await interaction.reply({ content: "❌ Não encontrei ninguém com esse ID neste servidor. Confira se copiou o ID certo.", flags: [MessageFlags.Ephemeral] });
        }

        const limiteStr = interaction.fields.getTextInputValue("pix_limite");
        const limite = sanitizarValor(limiteStr); // 0 (ou vazio) = sem limite
        pixConfig.set(idDigitado, { chave: interaction.fields.getTextInputValue("pix_key"), nome: interaction.fields.getTextInputValue("pix_name"), limite });
        salvarDadosPix();
        if (fs.existsSync(dbPixPath)) {
            try { pixConfig = new Map(Object.entries(JSON.parse(fs.readFileSync(dbPixPath)))); } catch (e) {}
        }
        const limiteTexto = limite > 0 ? `R$ ${limite.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}` : "Sem limite";
        return await interaction.reply({ content: `${EMOJI_CHECK} PIX configurado com sucesso para <@${idDigitado}>!\n> Limite de mediação: **${limiteTexto}**`, flags: [MessageFlags.Ephemeral] });
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith("modal_avaliacao_")) {
        const semPrefixo = interaction.customId.replace("modal_avaliacao_", "");
        const partesModal = semPrefixo.split("_");
        const notaModal = partesModal[0];
        const pendingIdModal = partesModal.slice(1).join("_");
        const pendModal = avaliacoesPendentes.get(pendingIdModal);
        if (!pendModal) return await responderSeguro(interaction, { content: "❌ Essa avaliação expirou, sinto muito.", ephemeral: true });

        const comentarioModal = interaction.fields.getTextInputValue("comentario_avaliacao");
        if (interaction.guildId) {
            await interaction.deferReply({ flags: [MessageFlags.Ephemeral] }).catch(() => {});
        } else {
            await interaction.deferReply().catch(() => {});
        }

        if (!pendModal.avaliacoes) pendModal.avaliacoes = {};
        pendModal.avaliacoes[interaction.user.id] = { nota: notaModal, comentario: comentarioModal };
        saveAvaliacoesPendentes();

        if (pendModal.staffId) {
            if (!userData[pendModal.staffId]) userData[pendModal.staffId] = { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
            if (!userData[pendModal.staffId].avaliacoes) userData[pendModal.staffId].avaliacoes = [];
            userData[pendModal.staffId].avaliacoes.push(parseInt(notaModal) || 5);
            saveUsers();
        }

        try {
            const guildAvaliacao = client.guilds.cache.get(GUILD_ID) || await client.guilds.fetch(GUILD_ID).catch(() => null);
            const mediadorU = pendModal.staffId ? await client.users.fetch(pendModal.staffId).catch(() => null) : null;
            const estrelasTexto = "⭐".repeat(Math.max(1, Math.min(5, parseInt(notaModal) || 0)));

            const embedAvaliacao = new EmbedBuilder()
                .setColor(0xDE4548)
                .setTitle('⭐ Nova avaliação de intermediação')
                .setThumbnail("https://i.postimg.cc/hPqvpDtX/nex1-2.gif")
                .addFields(
                    { name: 'Nota', value: `${estrelasTexto} ${notaModal}/5` },
                    { name: 'Usuário', value: `<@${interaction.user.id}>` },
                    { name: 'Middleman', value: mediadorU ? `<@${mediadorU.id}>` : "Não informado" },
                    { name: 'Avaliação', value: comentarioModal || "Sem comentário" }
                )
                .setFooter({ text: `Intermediação ${pendModal.transacaoId || pendingIdModal}` })
                .setTimestamp();

            const canalAvaliacoes = await getCanal(guildAvaliacao, CANAL_AVALIACOES);
            if (canalAvaliacoes) await canalAvaliacoes.send({ embeds: [embedAvaliacao] }).catch(console.error);
        } catch (e) {
            console.error("Erro ao enviar embed de avaliação:", e);
        }

        await responderSeguro(interaction, { content: "✅ Obrigado pela sua avaliação!", ephemeral: true });

        if (pendModal.avaliacoes[pendModal.enviador] && pendModal.avaliacoes[pendModal.recebedor]) {
            avaliacoesPendentes.delete(pendingIdModal);
            saveAvaliacoesPendentes();
        }
        return;
    }

    if ((interaction.isStringSelectMenu() && interaction.customId === 'menu_mm') || (interaction.isButton() && (interaction.customId === 'abrir_mediacao' || interaction.customId === 'abrir_mediacao_baixa'))) {
        const tipoMM = interaction.isStringSelectMenu() ? interaction.values[0] : 'PIX';
        // abrir_mediacao = !middleman (taxa normal) | abrir_mediacao_baixa = !middleman2 (taxa reduzida)
        const tipoTaxa = (interaction.isButton() && interaction.customId === 'abrir_mediacao_baixa') ? 'baixa' : 'normal';
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

        const ticketExistente = interaction.guild.channels.cache.find(c => c.name.includes(interaction.user.username) && c.parentId === CATEGORIA_TICKETS);
        if (ticketExistente) {
            const containerAviso = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ❌ Você já possui um ticket de MM aberto!\nSeu ticket em <#${ticketExistente.id}> ainda está aberto.`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setLabel('Ir para o Ticket').setURL(`https://discord.com/channels/${interaction.guild.id}/${ticketExistente.id}`).setStyle(ButtonStyle.Secondary)));
            return await interaction.editReply({ components: [containerAviso], flags: MessageFlags.IsComponentsV2 });
        }

        const canalTicket = await interaction.guild.channels.create({
            name: `🛡・middleman${tipoTaxa === 'baixa' ? '2' : ''}-${tipoMM}-${interaction.user.username}`, type: ChannelType.GuildText, parent: CATEGORIA_TICKETS,
            permissionOverwrites: [{ id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] }, { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] }, { id: CARGO_STAFF_ID, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ManageMessages] }]
        });

        tradeData.set(canalTicket.id, { enviador: null, recebedor: null, valor: null, item: null, staffReivindicou: null, msgDmId: null, confirmacoes: [], confirmacoesEntrega: [], participantes: [interaction.user.id], criadorTicketId: interaction.user.id, colValor: null, colItem: null, msgValor: null, msgItem: null, tipoTaxa }); saveTradeDataToDisk();

        const container1 = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`||<@${interaction.user.id}> <@&${CARGO_STAFF_ID}>||\n\n# <:parceria:1485054250429054986> ╺╸ Middleman de PIX criado.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\nSeja bem vindo ao novo ticket **AUTOMÁTICO** de MiddleMan, com segurança e agilidade. É importante que você selecione as opções ao longo do ticket corretamente e responda as perguntas que o bot fizer. Reveja sempre antes de prosseguir qualquer passo para evitar scams e erros.\n\n**Passos:**\n1. Adicione o usuário com quem vai negociar usando o menu ou botão abaixo.\n2. O bot pedirá para ambos descreverem os itens no chat.\n3. Após confirmação, o pix automático é gerado.`));
        const container2 = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Notificação de Segurança\nNossa equipe e nosso bot jamais entram em contato por mensagem direta.\n\nToda comunicação da negociação deve acontecer exclusivamente por este ticket.\n\nIgnorar isso pode te colocar em risco de golpe ou fraude. Não aceitamos pagamentos via Inter ou PicPay.\n\nSolicitações indevidas de reembolso podem gerar medidas cabíveis, inclusive ação judicial.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Quem abriu o ticket** pode encerrar aqui se desistir antes de concluir a configuração.`));
        const container3 = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Com Quem Você Está Negociando?\nSelecione o usuário Discord da outra parte.\nSó quem abriu o ticket pode escolher.\n\nUse o menu abaixo **ou** envie o ID /\n@menção do usuário diretamente no chat.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`))
            .addActionRowComponents(new ActionRowBuilder().addComponents(new UserSelectMenuBuilder().setCustomId('add_user_menu').setPlaceholder('Selecione o outro usuário...')))
            .addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('btn_termos').setLabel('Termos MM').setEmoji('<:emoji_166:1541614807621443604>').setStyle(ButtonStyle.Secondary), new ButtonBuilder().setCustomId('btn_fechar').setLabel('Cancelar Ticket').setEmoji('<:emoji_167:1541618912238768148>').setStyle(ButtonStyle.Secondary)));

        await canalTicket.send({ components: [container1], flags: MessageFlags.IsComponentsV2 });
        await canalTicket.send({ components: [container2], flags: MessageFlags.IsComponentsV2 });
        await canalTicket.send({ components: [container3], flags: MessageFlags.IsComponentsV2 });

        enviarLog(interaction.guild, new EmbedBuilder().setColor('#DE4548').setTitle('Ticket Aberto').setDescription(`O usuário <@${interaction.user.id}> abriu um ticket de MM (${tipoMM}).\nCanal: ${canalTicket}`));
        await interaction.editReply({ content: `${EMOJI_CHECK} **|** Seu middleman foi criado com sucesso ${canalTicket}` });
    }

    if (interaction.isUserSelectMenu() && interaction.customId === 'add_user_menu') {
        const alvoId = interaction.values[0];
        if (alvoId === interaction.user.id) return await interaction.reply({ content: "> ❌ Você não pode adicionar a si mesmo.", flags: [MessageFlags.Ephemeral] });
        const container = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Confirmar Contraparte\nVocê selecionou <@${alvoId}>. Confirme que é a pessoa certa ou escolha outra.\n\nSó quem abriu o ticket pode confirmar.\nEvita convidar o usuário errado.`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`confirm_target_${alvoId}`).setLabel('Confirmar pessoa').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId('escolher_outro').setLabel('Escolher outra pessoa').setStyle(ButtonStyle.Secondary)));
        await interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
    }

    if (interaction.isButton() && interaction.customId.startsWith('confirm_target_')) {
        const alvoId = interaction.customId.split('_')[2];
        if (data) { if (!data.participantes.includes(alvoId)) data.participantes.push(alvoId); }
        await interaction.channel.permissionOverwrites.edit(alvoId, { ViewChannel: true, SendMessages: true });
        const fetched = await interaction.channel.messages.fetch({ limit: 10 }); if (fetched) await interaction.channel.bulkDelete(fetched);
        await interaction.reply({ content: `> ${EMOJI_CHECK} ╺╸ Usuário <@${alvoId}> adicionado!`, flags: [MessageFlags.Ephemeral] });
        await iniciarFluxoImagens(interaction.channel);
    }

    if (interaction.isButton() && interaction.customId === 'escolher_outro') {
        const container = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Com Quem Você Está Negociando?\nSelecione o usuário Discord da outra parte.\nSó quem abriu o ticket pode escolher.\n\nUse o menu abaixo **ou** envie o ID /\n@menção do usuário diretamente no chat.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(new UserSelectMenuBuilder().setCustomId('add_user_menu').setPlaceholder('Selecione o outro usuário...')));
        await interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
    }

    if (interaction.isButton() && (interaction.customId === 'set_enviador' || interaction.customId === 'set_recebedor')) {
        if (!data) { return await interaction.reply({ content: "❌ Os dados deste ticket não foram encontrados ou a sessão expirou. Por favor, reabra a mediação.", flags: [MessageFlags.Ephemeral] }).catch(() => {}); }
        if ((interaction.customId === 'set_enviador' && data.recebedor === interaction.user.id) || (interaction.customId === 'set_recebedor' && data.enviador === interaction.user.id)) return await interaction.reply({ content: "❌ Você não pode ocupar as duas vagas!", flags: [MessageFlags.Ephemeral] });
        if (interaction.customId === 'set_enviador' && data.enviador) return await interaction.reply({ content: "❌ Essa vaga já foi ocupada!", flags: [MessageFlags.Ephemeral] });
        if (interaction.customId === 'set_recebedor' && data.recebedor) return await interaction.reply({ content: "❌ Essa vaga já foi ocupada!", flags: [MessageFlags.Ephemeral] });
        if (interaction.customId === 'set_enviador') data.enviador = interaction.user.id; else data.recebedor = interaction.user.id;

        if (data.enviador && data.recebedor) {
            await interaction.deferUpdate().catch(() => {});
            await interaction.message.delete().catch(() => {});

            const containerV = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:emoji_166:1541613481646882987> ╺ Valor da negociação\n<@${data.enviador}> ou <@${data.recebedor}> — **qualquer um** pode digitar no chat o **valor total** da transação (ex.: \`80,50\` ou \`125.50\`).\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\nDepois, **ambos** devem confirmar na mensagem seguinte (**Confirmar valor**).`));
            data.msgValor = await interaction.channel.send({ components: [containerV], flags: MessageFlags.IsComponentsV2 });

            data.colValor?.stop();
            const colV = interaction.channel.createMessageCollector({ filter: m => data.participantes.includes(m.author.id) });
            data.colValor = colV;
            colV.on('collect', async m => {
                if (data.colValor !== colV || data.lockValor) return;
                const valorNumerico = sanitizarValor(m.content);
                if (valorNumerico <= 0) return interaction.channel.send({ content: `<@${m.author.id}> ❌ Valor inválido. Digite novamente o valor (ex: 1.000 ou 50,00).` });
                data.lockValor = true;
                data.valor = valorNumerico.toString(); colV.stop(); data.colValor = null;

                await data.msgValor?.delete().catch(() => {});
                data.msgValor = null;
                await m.delete().catch(() => {});

                const containerI = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:emoji_166:1541613481646882987>╺ Itens da negociação\n<@${data.enviador}> ou <@${data.recebedor}> — **qualquer um** pode digitar no chat o **item / produto** que você enviará.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\nDepois, **ambos** devem confirmar na mensagem seguinte (**Confirmar itens**).`));
                data.msgItem = await interaction.channel.send({ components: [containerI], flags: MessageFlags.IsComponentsV2 });

                data.colItem?.stop();
                const colI = interaction.channel.createMessageCollector({ filter: m => data.participantes.includes(m.author.id), max: 1 });
                data.colItem = colI;
                colI.on('collect', async m2 => {
                    if (data.colItem !== colI || data.lockItem) return;
                    data.lockItem = true;
                    data.item = m2.content; data.colItem = null;

                    await data.msgItem?.delete().catch(() => {});
                    data.msgItem = null;
                    await m2.delete().catch(() => {});

                    const taxaEstimada = calcularTaxaBase(data.valor, data.tipoTaxa);
                    const containerTaxa = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:parceria:1485054250429054986> ╺ Escolha o pagador da taxa\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n> Selecione corretamente o pagador da taxa. Caso o vendedor seja o pagador, ele receberá o valor total menos a taxa.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Taxa da MM:** R$ ${taxaEstimada.toFixed(2)}\n**Comprador:** <@${data.enviador}>\n**Vendedor:** <@${data.recebedor}>`))
                        .addActionRowComponents(new ActionRowBuilder().addComponents(
                            new ButtonBuilder().setCustomId('taxa_comprador').setLabel('Comprador').setEmoji('<:emoji_165:1499214852990832671>').setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId('taxa_dividir').setLabel('Dividir taxa').setEmoji('<:emoji_166:1541614807621443604>').setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId('taxa_vendedor').setLabel('Vendedor').setEmoji('<:emoji_164:1541612138756579439>').setStyle(ButtonStyle.Secondary)
                        ));
                    data.msgTaxa = await interaction.channel.send({ components: [containerTaxa], flags: MessageFlags.IsComponentsV2 });
                });
            });
        } else {
            await interaction.update({ components: [construirContainerFuncoes(data)], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        }
    }

    if (interaction.isButton() && ['taxa_comprador', 'taxa_dividir', 'taxa_vendedor'].includes(interaction.customId)) {
        if (!data) { return await interaction.reply({ content: "❌ Os dados deste ticket não foram encontrados ou a sessão expirou. Por favor, reabra a mediação.", flags: [MessageFlags.Ephemeral] }).catch(() => {}); }
        data.pagadorTaxa = interaction.customId.replace('taxa_', ''); // 'comprador' | 'dividir' | 'vendedor'
        await interaction.deferUpdate().catch(() => {});
        await interaction.message.delete().catch(() => {});
        data.msgTaxa = null;

        const labelPagador = { comprador: '<:emoji_165:1499214852990832671> Comprador', dividir: '<:emoji_166:1541614807621443604> Dividida entre ambos', vendedor: '<:emoji_164:1541612138756579439> Vendedor' }[data.pagadorTaxa];
        const containerF = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:parceria:1485054250429054986> — Confirmação Final\n<@${data.enviador}> <@${data.recebedor}>\nAmbas as partes devem confirmar se os dados abaixo estão corretos. Após a confirmação de ambos, o pagamento será gerado.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n<:emoji_165:1499214852990832671> **Enviador:** <@${data.enviador}>\n<:emoji_170:1505047772049702932> **Recebedor:** <@${data.recebedor}>\n<:emoji_165:1499214852990832671>  **Valor PIX:** R$ ${data.valor}\n<:emoji_171:1505047910667259924> **Itens/Serviço:** ${data.item}\n💰 **Pagador da Taxa:** ${labelPagador}\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Status:**\n⏳ <@${data.enviador}> Aguardando...\n⏳ <@${data.recebedor}> Aguardando...`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('confirm_trade').setLabel('Confirmar tudo').setStyle(ButtonStyle.Secondary), new ButtonBuilder().setCustomId('resetar_fluxo').setLabel('Tentar novamente').setStyle(ButtonStyle.Secondary)));
        await interaction.channel.send({ components: [containerF], flags: MessageFlags.IsComponentsV2 });
    }

    if (interaction.isButton() && interaction.customId === 'confirm_trade') {
        if (!data) { return await interaction.reply({ content: "❌ Os dados deste ticket não foram encontrados ou a sessão expirou. Por favor, reabra a mediação.", flags: [MessageFlags.Ephemeral] }).catch(() => {}); } if (data.confirmacoes.includes(interaction.user.id)) return await interaction.reply({ content: "Você já confirmou!", flags: [MessageFlags.Ephemeral] });
        data.confirmacoes.push(interaction.user.id);
        const statusE = data.confirmacoes.includes(data.enviador) ? `✅ <@${data.enviador}> Confirmou` : `⏳ <@${data.enviador}> Aguardando...`;
        const statusR = data.confirmacoes.includes(data.recebedor) ? `✅ <@${data.recebedor}> Confirmou` : `⏳ <@${data.recebedor}> Aguardando...`;
        const labelPagadorAtual = { comprador: '💳 Comprador', dividir: '<:emoji_166:1541614807621443604> Dividida entre ambos', vendedor: '🌿 Vendedor' }[data.pagadorTaxa] || '💳 Comprador';
        const container = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:parceria:1485054250429054986> — Confirmação Final\n<@${data.enviador}> <@${data.recebedor}>\nAmbas as partes devem confirmar se os dados abaixo estão corretos.\nApós a confirmação de ambos, o pagamento será gerado.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n<:emoji_165:1499214852990832671> **Enviador:** <@${data.enviador}>\n<:emoji_170:1505047772049702932> **Recebedor:** <@${data.recebedor}>\n<:emoji_165:1499214852990832671>  **Valor PIX:** R$ ${data.valor}\n<:emoji_171:1505047910667259924> **Itens/Serviço:** ${data.item}\n💰 **Pagador da Taxa:** ${labelPagadorAtual}\n\u200B\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Status:**\n${statusE}\n${statusR}`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('confirm_trade').setLabel('Confirmar tudo').setStyle(ButtonStyle.Secondary), new ButtonBuilder().setCustomId('resetar_fluxo').setLabel('Tentar novamente').setStyle(ButtonStyle.Secondary)));
        await interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        if (data.confirmacoes.length === 2) {
            const fetched = await interaction.channel.messages.fetch({ limit: 100 });
            if (fetched) await interaction.channel.bulkDelete(fetched.filter(m => !m.pinned));
            await interaction.channel.send({ content: `${EMOJI_CHECK} — **Ambas as partes confirmaram a negociação!**` });
            setTimeout(async () => {
                const containerRes = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`Midldleman imediato aqui!! <@&${CARGO_STAFF_ID}>\n\n# <:parce:1442163891462344798> | Resumo do Middleman\nConsulte este resumo do negócio para quaisquer reafirmações.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Enviador:** <@${data.enviador}>\n**Recebedor:** <@${data.recebedor}>\n**Valor:** R$ ${data.valor}\n**Itens:** ${data.item}\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('btn_reivindicar').setLabel('Reivindicar').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId('btn_fechar').setLabel('Cancelar').setStyle(ButtonStyle.Danger)));
                await interaction.channel.send({ components: [containerRes], flags: MessageFlags.IsComponentsV2 });
            }, 1500);
        }
    }

    if (interaction.isButton() && interaction.customId === 'btn_reivindicar') {
        if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return await interaction.reply({ content: "❌ Apenas a staff pode reivindicar!", flags: [MessageFlags.Ephemeral] });
        if (!data) return await interaction.reply({ content: "❌ Os dados desse ticket foram perdidos. Peça pro cliente clicar em 'Resetar' ou reabrir o fluxo.", flags: [MessageFlags.Ephemeral] });
        if (data.staffReivindicou) return await interaction.reply({ content: "❌️ | Esse mm já foi Assumido", flags: [MessageFlags.Ephemeral] });

        const config = pixConfig.get(interaction.user.id);
        if (!config) return await interaction.reply({ content: " ❌ Você não configurou seu PIX! Use `/configpix` primeiro.", flags: [MessageFlags.Ephemeral] });

        const vCheck = parseFloat(data.valor) || 0;
        if (config.limite && config.limite > 0 && vCheck > config.limite) {
            const limiteFormatado = config.limite.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
            return await interaction.reply({ content: `❌ Essa negociação é de **R$ ${vCheck.toFixed(2)}**, mas seu limite atual de mediação é **R$ ${limiteFormatado}**.\nPeça pra um staff com limite maior assumir, ou fale com um admin pra aumentar seu limite.`, flags: [MessageFlags.Ephemeral] });
        }

        data.staffReivindicou = interaction.user.id;
        saveTradeDataToDisk();

        const v = parseFloat(data.valor) || 0;
        let taxa = calcularTaxaBase(v, data.tipoTaxa);

        const mE = await interaction.guild.members.fetch(data.enviador).catch(() => null);
        const mR = await interaction.guild.members.fetch(data.recebedor).catch(() => null);
        if (mE?.roles.cache.has(CARGO_AFILIADO_ID) || mR?.roles.cache.has(CARGO_AFILIADO_ID)) taxa /= 2;

        data.taxaValor = taxa;
        const pagador = data.pagadorTaxa || 'comprador';
        // comprador: comprador paga v + taxa cheia | dividir: comprador paga v + metade da taxa | vendedor: comprador paga só v
        const totalCobradoComprador = pagador === 'vendedor' ? v : (pagador === 'dividir' ? v + taxa / 2 : v + taxa);
        const total = totalCobradoComprador.toFixed(2);
        const pixId = Date.now().toString();

        const pixPayload = gerarPix(config.chave, config.nome, total);
        pixStorage.set(pixId, { payload: pixPayload, total });

        const containerOriginal = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`Midldleman imediato aqui!! <@&${CARGO_STAFF_ID}>\n\n# <:parce:1442163891462344798> | Resumo do Middleman\nConsulte este resumo do negócio para quaisquer reafirmações.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Enviador:** <@${data.enviador}>\n**Recebedor:** <@${data.recebedor}>\n**Valor:** R$ ${data.valor}\n**Itens:** ${data.item}\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('btn_reivindicar_disabled').setLabel(`Assumido por ${interaction.user.username}`).setStyle(ButtonStyle.Secondary).setDisabled(true), new ButtonBuilder().setCustomId('btn_fechar').setLabel('Cancelar').setStyle(ButtonStyle.Danger)));
        await interaction.update({ components: [containerOriginal], flags: MessageFlags.IsComponentsV2 });
        await interaction.channel.send({ content: `> ${EMOJI_CHECK} ╺╸ Opa! O Middleman <@${interaction.user.id}> assumiu a mediação deste ticket.` });

        // Enviar log de reivindicação para o canal de logs da staff
        const embedLogClaim = new EmbedBuilder()
            .setColor(0xDE4548)
            .setTitle('🛡️ Ticket Reivindicado')
            .setDescription(`O staff <@${interaction.user.id}> assumiu a mediação deste ticket.`)
            .addFields(
                { name: 'Staff Responsável', value: `<@${interaction.user.id}> (\`${interaction.user.tag || interaction.user.username}\`)`, inline: true },
                { name: 'Ticket', value: `<#${interaction.channel.id}>`, inline: true },
                { name: 'Valor', value: `R$ ${v.toFixed(2)}`, inline: true },
                { name: 'Comprador', value: `<@${data.enviador}>`, inline: true },
                { name: 'Vendedor', value: `<@${data.recebedor}>`, inline: true },
                { name: 'Itens', value: `${data.item || 'Não informado'}` }
            )
            .setFooter({ text: `Ticket ID: ${interaction.channel.id}` })
            .setTimestamp();
        await enviarLog(interaction.guild, embedLogClaim).catch(console.error);

        setTimeout(async () => {
            const botoesPagamento = [
                new ButtonBuilder().setCustomId(`qr_${pixId}`).setLabel('QR Code').setEmoji('📷').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`copy_${pixId}`).setLabel('Copia e Cola').setEmoji('📋').setStyle(ButtonStyle.Secondary)
            ];
            if (data.pagadorTaxa === 'dividir') {
                botoesPagamento.push(new ButtonBuilder().setCustomId(`dividirtaxa_${pixId}`).setLabel('Dividir Taxa').setEmoji('<:emoji_166:1541614807621443604>').setStyle(ButtonStyle.Secondary));
            }
            botoesPagamento.push(new ButtonBuilder().setCustomId('btn_recebi_valor').setLabel('Confirmei Recebimento (Staff)').setStyle(ButtonStyle.Success));

            const containerPix = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`<@${data.enviador}>\n\n## <:parceria:1485054250429054986> ╺╸ MM Automático - Pagamento PIX\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n> ${config.nome} Deve pagar o valor de **R$ ${total}**.\n> A troca é automática sem intervenção humana, caso haja problemas há um botão de disputa.\n\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n* <:emoji_164:1498773852585463929> **Valor da Transação:** R$ ${v.toFixed(2)}\n* <:emoji_151:1487942140037304370> **Taxa da MM:** R$ ${taxa.toFixed(2)}\n* <:emoji_164:1498773734402556095> **Detalhes do Pedido:** ${data.item}\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n\n**Total a Pagar:** R$ ${total}`)).addActionRowComponents(new ActionRowBuilder().addComponents(...botoesPagamento));
            await interaction.channel.send({ components: [containerPix], flags: MessageFlags.IsComponentsV2 });
        }, 2000);
    }

    // ── Dividir Taxa ──
    // O comprador já embutiu a metade da taxa no PIX principal (botão "Copia e Cola").
    // Este botão gera um segundo PIX (payload + QR), só com a metade da taxa,
    // pra mesma chave do middleman que reivindicou o ticket, pro vendedor mandar essa parte.
    if (interaction.isButton() && interaction.customId.startsWith('dividirtaxa_')) {
        if (!data) return await interaction.reply({ content: "❌ Dados desse ticket foram perdidos.", flags: [MessageFlags.Ephemeral] });

        const pixIdOriginal = interaction.customId.replace('dividirtaxa_', '');

        let taxaTotal = data.taxaValor;

        // Fallback: se por algum motivo taxaValor não foi salvo (ex: bot reiniciou), recalcula na hora
        if (!taxaTotal) {
            const v = parseFloat(data.valor) || 0;
            taxaTotal = calcularTaxaBase(v, data.tipoTaxa);

            try {
                const mE = await interaction.guild.members.fetch(data.enviador).catch(() => null);
                const mR = await interaction.guild.members.fetch(data.recebedor).catch(() => null);
                if (mE?.roles.cache.has(CARGO_AFILIADO_ID) || mR?.roles.cache.has(CARGO_AFILIADO_ID)) taxaTotal /= 2;
            } catch (e) {}

            data.taxaValor = taxaTotal;
            console.log(`[dividirtaxa] taxaValor estava vazio no ticket ${interaction.channelId}, recalculado: ${taxaTotal}`);
        }

        const metade = (taxaTotal / 2).toFixed(2);

        const configStaff = pixConfig.get(data.staffReivindicou);
        if (!configStaff) {
            return await interaction.reply({ content: "❌ O Middleman responsável não tem PIX configurado, não dá pra gerar a cobrança da metade da taxa.", flags: [MessageFlags.Ephemeral] });
        }

        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] }).catch(() => {});

        try {
            const pixMetadeId = `${pixIdOriginal}_metade`;
            const pixPayloadMetade = gerarPix(configStaff.chave, configStaff.nome, metade);
            pixStorage.set(pixMetadeId, { payload: pixPayloadMetade, total: metade });

            const rowMetade = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`qr_${pixMetadeId}`).setLabel('QR Code (metade)').setEmoji('📷').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`copy_${pixMetadeId}`).setLabel('Copia e Cola (metade)').setEmoji('📋').setStyle(ButtonStyle.Secondary)
            );

            await interaction.editReply({
                content: `🌙 **Taxa dividida entre as partes**\n> Taxa total: R$ ${taxaTotal.toFixed(2)}\n\n<@${data.enviador}> já pagou **R$ ${metade}** de taxa a mais no PIX principal.\n<@${data.recebedor}> precisa mandar **R$ ${metade}** pro Middleman (pix abaixo) referente à sua parte da taxa.`,
                components: [rowMetade]
            });
        } catch (err) {
            console.error("Erro ao gerar PIX da metade da taxa:", err);
            await interaction.editReply({ content: "❌ Não consegui gerar o PIX da metade da taxa. Tenta de novo." }).catch(() => {});
        }
    }

    if (interaction.isButton() && interaction.customId === 'btn_recebi_valor') {
        if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return await interaction.reply({ content: "❌ Apenas a staff pode confirmar recebimento!", flags: [MessageFlags.Ephemeral] });
        if (!data) return await interaction.reply({ content: "❌ Dados desse ticket foram perdidos.", flags: [MessageFlags.Ephemeral] });
        if (data.staffReivindicou && data.staffReivindicou !== interaction.user.id && !interaction.member?.permissions?.has(PermissionFlagsBits.Administrator)) {
            return await interaction.reply({ content: "Apenas o staff que reivindicou pode confirmar!", flags: [MessageFlags.Ephemeral] });
        }
        if (data.pagamentoConfirmado) {
            return await interaction.reply({ content: "ℹ️ O recebimento já foi confirmado anteriormente.", flags: [MessageFlags.Ephemeral] });
        }

        data.pagamentoConfirmado = true;
        saveTradeDataToDisk();

        // Atualizar o botão na mensagem original para desabilitar
        try {
            if (interaction.message && interaction.message.components && interaction.message.components.length > 0) {
                const rowOriginal = ActionRowBuilder.from(interaction.message.components[0]);
                for (const comp of rowOriginal.components) {
                    if (comp.data.custom_id === 'btn_recebi_valor') {
                        comp.setDisabled(true).setLabel(`Recebido por ${interaction.user.username}`).setStyle(ButtonStyle.Secondary);
                    }
                }
                await interaction.update({ components: [rowOriginal], flags: MessageFlags.IsComponentsV2 }).catch(async () => {
                    await interaction.update({ components: [rowOriginal] }).catch(() => {});
                });
            } else {
                await interaction.reply({ content: "✅ Recebimento confirmado pelo staff.", flags: [MessageFlags.Ephemeral] });
            }
        } catch (e) {
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({ content: "✅ Recebimento confirmado pelo staff.", flags: [MessageFlags.Ephemeral] }).catch(() => {});
            }
        }

        // Log de confirmação de pagamento do comprador para staff logs
        const embedLogPagamento = new EmbedBuilder()
            .setColor(0xDE4548)
            .setTitle('💰 Pagamento do Comprador Confirmado (Staff)')
            .setDescription(`O staff <@${interaction.user.id}> confirmou o recebimento do PIX do comprador.`)
            .addFields(
                { name: 'Staff', value: `<@${interaction.user.id}>`, inline: true },
                { name: 'Ticket', value: `<#${interaction.channel.id}>`, inline: true },
                { name: 'Valor', value: `R$ ${parseFloat(data.valor || 0).toFixed(2)}`, inline: true },
                { name: 'Comprador', value: `<@${data.enviador}>`, inline: true },
                { name: 'Vendedor', value: `<@${data.recebedor}>`, inline: true }
            )
            .setFooter({ text: `Ticket ID: ${interaction.channel.id}` })
            .setTimestamp();
        await enviarLog(interaction.guild, embedLogPagamento).catch(console.error);

        const containerT = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ⚠️ PIX RECEBIDO - INICIAR TROCA\nO Middleman já está com o dinheiro em mãos.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Instruções:**\n• O vendedor deve entregar o item agora.\n• Após a entrega, ambos cliquem no botão abaixo.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('confirmar_entrega_user').setLabel('Confirmar Entrega').setEmoji('✅').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId('btn_fechar').setLabel('Fechar Ticket').setStyle(ButtonStyle.Danger)));
        await interaction.channel.send({ components: [containerT], flags: MessageFlags.IsComponentsV2 });
    }

    if (interaction.isButton() && interaction.customId === 'confirmar_entrega_user') {
        if (!data) { return await interaction.reply({ content: "❌ Os dados deste ticket não foram encontrados ou a sessão expirou. Por favor, reabra a mediação.", flags: [MessageFlags.Ephemeral] }).catch(() => {}); } if (interaction.user.id !== data.enviador && interaction.user.id !== data.recebedor) return await interaction.reply({ content: "Você não é participante da trade!", flags: [MessageFlags.Ephemeral] });
        if (data.confirmacoesEntrega.includes(interaction.user.id)) return await interaction.reply({ content: "Você já confirmou!", flags: [MessageFlags.Ephemeral] });
        data.confirmacoesEntrega.push(interaction.user.id);
        if (data.confirmacoesEntrega.length === 2) {
            const containerM = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`<@${data.recebedor}>\n\n# Selecione o tipo de chave PIX\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\nEscolha abaixo o tipo de chave que você deseja utilizar para receber o pagamento do staff.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('selecionar_tipo_pix').setPlaceholder('Clique aqui para selecionar o tipo...').addOptions([{ label: 'Celular', value: 'celular', emoji: '📱' }, { label: 'CPF/CNPJ', value: 'cpf_cnpj', emoji: '👤' }, { label: 'E-mail', value: 'email', emoji: '📧' }, { label: 'Chave Aleatória', value: 'aleatoria', emoji: '🆔' }, { label: 'USDT Wallet', value: 'usdt', emoji: '🪙' }])));
            await interaction.channel.send({ components: [containerM], flags: MessageFlags.IsComponentsV2 });
        } else { await interaction.reply({ content: `${EMOJI_CHECK} — <@${interaction.user.id}> confirmou a entrega. Aguardando a outra parte.` }); }
    }

    if (interaction.isStringSelectMenu() && interaction.customId === 'selecionar_tipo_pix') {
        if (!data || interaction.user.id !== data.recebedor) {
            return await interaction.reply({
                content: "❌ | Apenas o recebedor pode fornecer a chave PIX.",
                flags: [MessageFlags.Ephemeral]
            });
        }

        const tipo = String(interaction.values[0] || 'pix').toLowerCase();
        const nomesTipo = {
            celular: 'celular',
            cpf_cnpj: 'CPF/CNPJ',
            email: 'e-mail',
            aleatoria: 'aleatória',
            usdt: 'USDT Wallet'
        };
        const nomeTipo = nomesTipo[tipo] || 'PIX';

        try {
            const modal = new ModalBuilder()
                .setCustomId(`modal_chave_final_${tipo}`)
                .setTitle(`Chave PIX: ${nomeTipo.toUpperCase()}`)
                .addComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('chave_input')
                            .setLabel(`Digite sua chave ${nomeTipo}`)
                            .setPlaceholder(`Informe sua chave ${nomeTipo}`)
                            .setStyle(TextInputStyle.Short)
                            .setRequired(true)
                            .setMaxLength(200)
                    ),
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('nome_input')
                            .setLabel('Nome do recebedor')
                            .setPlaceholder('Nome que aparecerá no pagamento PIX')
                            .setStyle(TextInputStyle.Short)
                            .setRequired(true)
                            .setMaxLength(25)
                    )
                );

            return await interaction.showModal(modal);
        } catch (erroModal) {
            console.error('Erro ao abrir modal da chave PIX:', erroModal);
            if (!interaction.replied && !interaction.deferred) {
                return await interaction.reply({
                    content: '❌ Não foi possível abrir o formulário da chave PIX. Tente novamente.',
                    flags: [MessageFlags.Ephemeral]
                });
            }
        }
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith('modal_chave_final_')) {
        if (!data) {
            return await interaction.reply({ content: "❌ Os dados desse ticket foram perdidos. Reabra o fluxo da negociação.", flags: [MessageFlags.Ephemeral] });
        }

        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

        try {
            const chave = interaction.fields.getTextInputValue('chave_input')?.trim();
            const nomeRecebedor = interaction.fields.getTextInputValue('nome_input')?.trim();
            if (!chave) return await interaction.editReply("❌ A chave PIX não pode ficar vazia.");
            if (!nomeRecebedor) return await interaction.editReply("❌ O nome do recebedor não pode ficar vazio.");

            if (!data.staffReivindicou) {
                console.error("Staff não definido no ticket:", interaction.channelId);
                return await interaction.editReply("❌ O staff responsável não foi encontrado. Peça para a staff reivindicar o ticket novamente.");
            }

            const staff = await client.users.fetch(data.staffReivindicou).catch(err => {
                console.error("Erro ao buscar staff:", err);
                return null;
            });

            const vRecebedor = parseFloat(data.valor) || 0;
            const taxaRegistrada = data.taxaValor || 0;
            const pagadorAtual = data.pagadorTaxa || 'comprador';
            const valorPagarNumerico = pagadorAtual === 'vendedor' ? (vRecebedor - taxaRegistrada) : (pagadorAtual === 'dividir' ? (vRecebedor - taxaRegistrada / 2) : vRecebedor);
            const valorPagar = Math.max(0, valorPagarNumerico).toFixed(2);
            const chaveId = `${Date.now()}_${interaction.user.id}`;
            const pixIdFinal = `${chaveId}f`;
            const pixPayloadFinal = gerarPix(chave, nomeRecebedor, valorPagar);
            let qrBuffer = null;
            try {
                qrBuffer = await QRCode.toBuffer(pixPayloadFinal, {
                    type: 'png',
                    width: 700,
                    margin: 2,
                    errorCorrectionLevel: 'M'
                });
            } catch (erroQR) {
                console.error('Falha ao gerar QR Code; seguindo com copia e cola:', erroQR);
            }
            const qrFileName = `pix-${pixIdFinal}.png`;

            chaveFinalStorage.set(chaveId, chave);
            pixStorage.set(pixIdFinal, { payload: pixPayloadFinal, total: valorPagar });

            const paymentRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`copy_${pixIdFinal}`).setLabel('Copia e Cola').setEmoji('📋').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`copychave_${chaveId}`).setLabel('Copiar Chave PIX').setEmoji('📋').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('btn_paguei_vendedor').setLabel('Confirmei o pagamento ao Vendedor').setStyle(ButtonStyle.Success)
            );

            const notaTaxaVendedor = pagadorAtual === 'vendedor'
                ? `\n> 💰 Taxa de **R$ ${taxaRegistrada.toFixed(2)}** já descontada (vendedor ficou responsável pela taxa).`
                : pagadorAtual === 'dividir'
                    ? `\n> 💰 Metade da taxa (**R$ ${(taxaRegistrada / 2).toFixed(2)}**) já descontada (taxa dividida entre as partes).`
                    : '';
            const embedPagamento = new EmbedBuilder()
                .setColor(0xDE4548)
                .setTitle('<:ravisoshelt:1439092081024041063> PAGAMENTO PENDENTE')
                .setDescription(
                    `**O administrador deve pagar este valor ao recebedor.**\n\n` +
                    `**Recebedor:** ${nomeRecebedor} (<@${interaction.user.id}>)\n` +
                    `**Chave PIX:** \`${chave}\`\n` +
                    `**Valor exato a pagar:** **R$ ${valorPagar}**${notaTaxaVendedor}\n\n` +
                    `Escaneie o QR Code ou use o Pix copia e cola abaixo. Confirme o recebimento somente depois de conferir o valor.`
                )
                .addFields({ name: 'PIX copia e cola', value: `\`${pixPayloadFinal}\`` })
                .setFooter({ text: 'Confira o valor antes de realizar o pagamento.' });
            if (qrBuffer) embedPagamento.setImage(`attachment://${qrFileName}`);

            const embedLogChave = new EmbedBuilder()
                .setColor(0xDE4548)
                .setTitle('Chave Pix Fornecida')
                .setDescription(`Vendedor: <@${interaction.user.id}>\nChave: ${chave}\nPara: ${staff?.username || data.staffReivindicou}`)
                .addFields(
                    { name: 'Chave PIX informada', value: `\`${chave}\`` },
                    { name: 'Nome do recebedor', value: nomeRecebedor, inline: true },
                    { name: 'Recebedor', value: `<@${interaction.user.id}>`, inline: true },
                    { name: 'Staff responsável', value: `<@${data.staffReivindicou}>`, inline: true },
                    { name: 'Ticket', value: `<#${interaction.channel.id}>`, inline: true },
                    { name: 'Valor a pagar', value: `R$ ${valorPagar}`, inline: true }
                )
                .setFooter({ text: `Ticket ID: ${interaction.channel.id}` })
                .setTimestamp();

            const logEnviado = await enviarLog(interaction.guild, embedLogChave).catch(erroLog => {
                console.error('Falha ao enviar log da chave PIX; continuando o pagamento:', erroLog);
                return false;
            });
            if (!logEnviado) console.warn('Cobrança PIX publicada sem confirmação do log.');

            try {
                await interaction.channel.send({
                    content: `<@${data.enviador}> <@${data.recebedor}> <@${data.staffReivindicou}>`,
                    embeds: [embedPagamento],
                    components: [paymentRow],
                    ...(qrBuffer ? { files: [new AttachmentBuilder(qrBuffer, { name: qrFileName })] } : {})
                });

                await interaction.message?.delete().catch(() => {});
            } catch (erroCanal) {
                console.error('Não foi possível publicar a cobrança no ticket:', erroCanal);
                return await interaction.editReply('❌ Não foi possível publicar a cobrança no ticket. Tente novamente ou avise a staff.');
            }

            await interaction.editReply({
                content: `${EMOJI_CHECK} Chave enviada com sucesso ao Staff!`,
                flags: [MessageFlags.Ephemeral]
            });
        } catch (err) {
            console.error("Erro ao processar chave PIX:", err);
            await interaction.editReply("❌ Ocorreu um erro ao processar essa chave PIX. Tente novamente ou avise a staff.").catch(console.error);
        }
    }

    if (interaction.isButton() && interaction.customId === 'btn_paguei_vendedor') {
        if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return await interaction.reply({ content: "❌ Apenas a staff pode confirmar pagamento ao vendedor!", flags: [MessageFlags.Ephemeral] });
        if (!data) return await interaction.reply({ content: "❌ Dados deste ticket foram perdidos.", flags: [MessageFlags.Ephemeral] });
        if (data.staffReivindicou && data.staffReivindicou !== interaction.user.id && !interaction.member?.permissions?.has(PermissionFlagsBits.Administrator)) {
            return await interaction.reply({ content: "Apenas o staff que reivindicou pode finalizar a mediação!", flags: [MessageFlags.Ephemeral] });
        }
        if (data.pagamentoVendedorConfirmado) {
            return await interaction.reply({ content: "ℹ️ O pagamento ao vendedor já foi confirmado.", flags: [MessageFlags.Ephemeral] });
        }

        data.pagamentoVendedorConfirmado = true;
        saveTradeDataToDisk();

        // Desabilitar o botão na mensagem de pagamento ao vendedor
        try {
            if (interaction.message && interaction.message.components && interaction.message.components.length > 0) {
                const rowOriginal = ActionRowBuilder.from(interaction.message.components[0]);
                for (const comp of rowOriginal.components) {
                    if (comp.data.custom_id === 'btn_paguei_vendedor') {
                        comp.setDisabled(true).setLabel(`Pago ao Vendedor por ${interaction.user.username}`).setStyle(ButtonStyle.Secondary);
                    }
                }
                await interaction.update({ components: [rowOriginal] }).catch(() => {});
            } else {
                await interaction.reply({ content: "✅ Pagamento ao vendedor confirmado.", flags: [MessageFlags.Ephemeral] }).catch(() => {});
            }
        } catch (e) {
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({ content: "✅ Pagamento ao vendedor confirmado.", flags: [MessageFlags.Ephemeral] }).catch(() => {});
            }
        }

        let transacaoIdFinal = null;
        try {
            const enviadorU = await client.users.fetch(data.enviador).catch(() => null);
            const recebedorU = await client.users.fetch(data.recebedor).catch(() => null);
            const staffMediadorU = await client.users.fetch(data.staffReivindicou || interaction.user.id).catch(() => null);
            if (enviadorU && recebedorU && staffMediadorU) {
                transacaoIdFinal = await executarAprovarPagamento(interaction.guild, staffMediadorU, "pix", enviadorU, recebedorU, parseFloat(data.valor || 0));
                data.vouchGerado = true;
                saveTradeDataToDisk();
            }
        } catch (err) {
            console.error("Erro ao registrar proof automática em btn_paguei_vendedor:", err);
        }

        const messages = await interaction.channel.messages.fetch({ limit: 100 }).catch(() => new Map());
        const transcript = Array.from(messages.values()).reverse().map(m => `[${m.createdAt ? m.createdAt.toLocaleString() : ''}] ${m.author ? m.author.tag : 'User'}: ${m.content}`).join('\n');

        const v = parseFloat(data.valor || 0);
        let taxa = data.taxaValor || calcularTaxaBase(v, data.tipoTaxa);

        // Enviar log de encerramento para o canal de logs da staff
        const embedLogEncerrado = new EmbedBuilder()
            .setColor('#DE4548')
            .setTitle('Middle encerrado com Sucesso (Logs)')
            .addFields(
                { name: 'Administrador / MM', value: `<@${interaction.user.id}>` },
                { name: 'Canal', value: `#${interaction.channel.name}` },
                { name: 'Valor', value: `R$ ${v.toFixed(2)}`, inline: true },
                { name: 'Taxa', value: `R$ ${taxa.toFixed(2)}`, inline: true },
                { name: 'Transação ID', value: `${transacaoIdFinal || 'MM-' + Date.now()}`, inline: true }
            )
            .setTimestamp();
        await enviarLog(interaction.guild, embedLogEncerrado, [new AttachmentBuilder(Buffer.from(transcript), { name: `transcript-${interaction.channel.name}.txt` })]).catch(console.error);

        const pendingId = gerarIdAvaliacao();
        avaliacoesPendentes.set(pendingId, {
            enviador: data.enviador,
            recebedor: data.recebedor,
            valor: v,
            item: data.item,
            staffId: data.staffReivindicou || interaction.user.id,
            transacaoId: transacaoIdFinal || pendingId,
            transcript,
            avaliacoes: {}
        });
        saveAvaliacoesPendentes();

        const protocoloResumo = transacaoIdFinal || pendingId;
        const dataFechamentoTxt = new Date().toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" });

        const containerResumo = new ContainerBuilder().setAccentColor(0x5865F2).addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `## 📋 Resumo do Ticket Encerrado\n` +
                `**Protocolo:** ${protocoloResumo}\n` +
                `**Valor:** R$ ${v.toFixed(2)}\n` +
                `**Servidor:** ${interaction.guild.name}\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `**Comprador:** <@${data.enviador}>\n` +
                `**Vendedor:** <@${data.recebedor}>\n` +
                `**Intermediador:** <@${data.staffReivindicou || interaction.user.id}>\n\n` +
                `✅ **Ticket encerrado com sucesso.**\n` +
                `🗓️ ${dataFechamentoTxt}\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `📄 **Transcrição**\n` +
                `-# Histórico completo das mensagens deste ticket.`
            )
        ).addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`abrir_transcript_${pendingId}`).setLabel('Abrir transcrição').setEmoji('📄').setStyle(ButtonStyle.Secondary)
            )
        );

        const containerEstrelas = new ContainerBuilder().setAccentColor(0xf2a20e).addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`# ⭐ Avalie o Atendimento ⭐\nPor favor, avalie a mediação que você recebeu!`)
        ).addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`av_1_${pendingId}`).setEmoji('⭐').setLabel('1').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`av_2_${pendingId}`).setEmoji('⭐').setLabel('2').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`av_3_${pendingId}`).setEmoji('⭐').setLabel('3').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`av_4_${pendingId}`).setEmoji('⭐').setLabel('4').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`av_5_${pendingId}`).setEmoji('⭐').setLabel('5').setStyle(ButtonStyle.Success)
            )
        );

        // Enviar no PV (DM) dos participantes em Components V2
        for (const uid of [data.enviador, data.recebedor]) {
            try {
                const userDM = await client.users.fetch(uid).catch(() => null);
                if (userDM) {
                    await userDM.send({ components: [containerResumo], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
                    await userDM.send({ components: [containerEstrelas], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
                }
            } catch (e) {}
        }

        // Enviar no canal do ticket
        await interaction.channel.send({
            content: `🎉 **Mediação finalizada com sucesso!** <@${data.enviador}> <@${data.recebedor}>\nFechando ticket em 5 segundos...`,
            components: [containerResumo],
            flags: MessageFlags.IsComponentsV2
        }).catch(() => {});

        setTimeout(() => {
            interaction.channel.delete().catch(() => {});
            tradeData.delete(interaction.channelId);
            saveTradeDataToDisk();
        }, 5000);
    }

    if (interaction.isButton() && interaction.customId.startsWith('copychave_')) {
        const chaveId = interaction.customId.replace('copychave_', '');
        const chave = chaveFinalStorage.get(chaveId);
        if (!chave) return await interaction.reply({ content: "❌ Chave expirada ou não encontrada.", flags: [MessageFlags.Ephemeral] });
        await interaction.reply({ content: chave, flags: [MessageFlags.Ephemeral] });
    }

    if (interaction.isButton() && interaction.customId.startsWith('qr_')) {
        const id = interaction.customId.slice(3);
        const item = pixStorage.get(id);
        if (!item) return await interaction.reply({ content: "❌ QR Code expirado ou não encontrado.", flags: [MessageFlags.Ephemeral] });

        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        try {
            const qrBuffer = await QRCode.toBuffer(item.payload, {
                type: "png",
                width: 600,
                margin: 2,
                errorCorrectionLevel: "M"
            });

            const containerQR = new ContainerBuilder()
                .setAccentColor(0xDE4548)
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(
                    `# 📷 Escaneie o QR Code\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `> 💰 **Valor exato a pagar: R$ ${item.total}**`
                ));

            await interaction.editReply({
                content: "Escaneie o QR Code abaixo:",
                components: [containerQR],
                files: [new AttachmentBuilder(qrBuffer, { name: `pix-${id}.png` })],
                flags: MessageFlags.IsComponentsV2
            });
        } catch (err) {
            console.error("Erro ao gerar QR Code PIX:", err);
            await interaction.editReply("❌ Não foi possível gerar o QR Code. Use o botão Copia e Cola.").catch(console.error);
        }
    }

    if (interaction.isButton() && interaction.customId.startsWith('copy_')) {
        const id = interaction.customId.slice(5);
        const item = pixStorage.get(id);
        if (item) await interaction.reply({ content: item.payload, flags: [MessageFlags.Ephemeral] });
    }

    if (interaction.isButton() && interaction.customId === 'btn_termos') {
        const container = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:parceria:1485054250429054986> ╺╸ **Termos e Regras do MM Automático**\n\n**<:discotoolsxyzicon111:1470855659909284104> Segurança em Primeiro Lugar**\nPara garantir a segurança de ambas as partes, siga rigorosamente as instruções abaixo.\n\n**<:discotoolsxyzicon6:1470345157391155301> Para o Vendedor (Quem entrega o item):**\n> **GRAVE TUDO!** Recomendamos fortemente que você grave todo o processo de entrega do produto, desde o momento que inicia a troca até a confirmação de recebimento. Em caso de disputa, essa será sua principal prova.\n\n**<:discotoolsxyzicon28:1470856248122409171> Para o Comprador (Quem paga):**\n> **CONFIRA TUDO!** Verifique se o item recebido é exatamente o combinado antes de confirmar o recebimento no bot. Após confirmado, o dinheiro é liberado automaticamente e não há estorno.\n\n**<:discotoolsxyzicon13:1470342793716174880> Regras Gerais:**\n1. Não tente burlar o sistema de taxas.\n2. Mantenha toda a negociação dentro deste ticket.\n3. O bot não se responsabiliza por erros humanos (ex: enviar item para nick errado).\n4. Em caso de problemas, abra uma **Disputa** imediatamente.`));
        await interaction.reply({ components: [container], flags: [MessageFlags.Ephemeral, MessageFlags.IsComponentsV2] });
    }

    if (interaction.isButton() && interaction.customId === 'resetar_fluxo') {
        const fetched = await interaction.channel.messages.fetch({ limit: 100 }); if (fetched) await interaction.channel.bulkDelete(fetched.filter(m => !m.pinned));
        await iniciarFluxoImagens(interaction.channel);
    }

    if (interaction.isButton() && interaction.customId === 'btn_fechar') {
        await interaction.deferReply().catch(() => {});

        const v = parseFloat(data?.valor || 0);
        let taxa = data?.taxaValor || calcularTaxaBase(v, data?.tipoTaxa);
        try {
            const mE = data?.enviador ? await interaction.guild.members.fetch(data.enviador).catch(() => null) : null;
            const mR = data?.recebedor ? await interaction.guild.members.fetch(data.recebedor).catch(() => null) : null;
            if (mE?.roles.cache.has(CARGO_AFILIADO_ID) || mR?.roles.cache.has(CARGO_AFILIADO_ID)) taxa /= 2;
        } catch (err) {}

        let transacaoIdFinal = null;
        if (data && data.pagamentoConfirmado && !data.vouchGerado && data.enviador && data.recebedor && data.valor) {
            try {
                const enviadorU = await client.users.fetch(data.enviador).catch(() => null);
                const recebedorU = await client.users.fetch(data.recebedor).catch(() => null);
                const staffMediadorU = await client.users.fetch(data.staffReivindicou || interaction.user.id).catch(() => null);
                if (enviadorU && recebedorU && staffMediadorU) {
                    transacaoIdFinal = await executarAprovarPagamento(interaction.guild, staffMediadorU, "pix", enviadorU, recebedorU, parseFloat(data.valor));
                    data.vouchGerado = true;
                    saveTradeDataToDisk();
                }
            } catch (err) {
                console.error("Erro ao registrar proof automática no fechamento:", err);
            }
        }

        const messages = await interaction.channel.messages.fetch({ limit: 100 }).catch(() => new Map());
        const transcript = Array.from(messages.values()).reverse().map(m => `[${m.createdAt ? m.createdAt.toLocaleString() : ''}] ${m.author ? m.author.tag : 'User'}: ${m.content}`).join('\n');

        const embedLogEncerrado = new EmbedBuilder()
            .setColor('#DE4548')
            .setTitle('Middle encerrado (Logs)')
            .addFields(
                { name: 'Administrador / MM', value: `<@${interaction.user.id}>` },
                { name: 'Canal', value: `#${interaction.channel.name}` },
                { name: 'Valor', value: `R$ ${v.toFixed(2)}`, inline: true },
                { name: 'Taxa', value: `R$ ${taxa.toFixed(2)}`, inline: true }
            )
            .setTimestamp();
        await enviarLog(interaction.guild, embedLogEncerrado, [new AttachmentBuilder(Buffer.from(transcript), { name: `transcript-${interaction.channel.name}.txt` })]).catch(console.error);

        if (data && data.enviador && data.recebedor) {
            const pendingId = gerarIdAvaliacao();
            avaliacoesPendentes.set(pendingId, {
                enviador: data.enviador,
                recebedor: data.recebedor,
                valor: v,
                item: data.item,
                staffId: data.staffReivindicou || interaction.user.id,
                transacaoId: transacaoIdFinal || pendingId,
                transcript,
                avaliacoes: {}
            });
            saveAvaliacoesPendentes();

            const protocoloResumo = transacaoIdFinal || pendingId;
            const dataFechamentoTxt = new Date().toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" });

            const containerResumo = new ContainerBuilder().setAccentColor(0x5865F2).addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `## 📋 Resumo do Ticket Encerrado\n` +
                    `**Protocolo:** ${protocoloResumo}\n` +
                    `**Valor:** R$ ${v.toFixed(2)}\n` +
                    `**Servidor:** ${interaction.guild.name}\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `**Comprador:** <@${data.enviador}>\n` +
                    `**Vendedor:** <@${data.recebedor}>\n` +
                    `**Intermediador:** <@${data.staffReivindicou || interaction.user.id}>\n\n` +
                    `✅ **Ticket encerrado com sucesso.**\n` +
                    `🗓️ ${dataFechamentoTxt}\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `📄 **Transcrição**\n` +
                    `-# Histórico completo das mensagens deste ticket.`
                )
            ).addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`abrir_transcript_${pendingId}`).setLabel('Abrir transcrição').setEmoji('📄').setStyle(ButtonStyle.Secondary)
                )
            );

            const containerEstrelas = new ContainerBuilder().setAccentColor(0xf2a20e).addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`# ⭐ Avalie o Atendimento ⭐\nPor favor, avalie a mediação que você recebeu!`)
            ).addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`av_1_${pendingId}`).setEmoji('⭐').setLabel('1').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`av_2_${pendingId}`).setEmoji('⭐').setLabel('2').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`av_3_${pendingId}`).setEmoji('⭐').setLabel('3').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`av_4_${pendingId}`).setEmoji('⭐').setLabel('4').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`av_5_${pendingId}`).setEmoji('⭐').setLabel('5').setStyle(ButtonStyle.Success)
                )
            );

            for (const uid of [data.enviador, data.recebedor]) {
                try {
                    const userDM = await client.users.fetch(uid).catch(() => null);
                    if (userDM) {
                        await userDM.send({ components: [containerResumo], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
                        await userDM.send({ components: [containerEstrelas], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
                    }
                } catch (e) {}
            }
        }

        await interaction.editReply({ content: 'Fechando ticket em 5 segundos...' }).catch(() => {});
        setTimeout(() => {
            interaction.channel.delete().catch(() => {});
            tradeData.delete(interaction.channelId);
            saveTradeDataToDisk();
        }, 5000);
    }
  } catch (err) {
    console.error("❌ [ERRO NÃO TRATADO em interactionCreate]", err);
    const msgErro = { content: "❌ Ocorreu um erro inesperado ao processar essa ação. Tenta de novo — se persistir, avisa a staff.", flags: [MessageFlags.Ephemeral] };
    try {
        if (interaction.replied || interaction.deferred) {
            await interaction.followUp(msgErro).catch(() => {});
        } else {
            await interaction.reply(msgErro).catch(() => {});
        }
    } catch (e) {}
  }
});

async function executarAprovarPagamento(guild, staffUser, tipo, enviadorUser, recebedorUser, valor) {
    registerStaffTrade(staffUser.id, valor, [enviadorUser.id, recebedorUser.id]);

    registerTrade(enviadorUser.id, valor);
    registerTrade(recebedorUser.id, valor);
    globalCounter++;
    saveGlobal();
    if (userData[enviadorUser.id].contador === undefined) userData[enviadorUser.id].contador = 0;
    userData[enviadorUser.id].contador++;
    saveUsers();
    await atualizarCargos(guild, enviadorUser.id);
    await atualizarCargos(guild, recebedorUser.id);
    await atualizarCargos(guild, staffUser.id);
    const valorFormatado = valor.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
    const taxaTotal = calcularTaxa(tipo, valor, enviadorUser.id, recebedorUser.id);
    if (taxaTotal > 0) {
        taxasDiarias[staffUser.id] = (taxasDiarias[staffUser.id] || 0) + taxaTotal;
        saveTaxas();

        if (!userData[staffUser.id]) userData[staffUser.id] = { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
        userData[staffUser.id].taxaMes = (userData[staffUser.id].taxaMes || 0) + taxaTotal;
        userData[staffUser.id].taxaTotal = (userData[staffUser.id].taxaTotal || 0) + taxaTotal;
        saveUsers();
    }

    const transacaoId = `MM-${Date.now()}${Math.floor(Math.random() * 900 + 100)}`;
    const vouchCodigo = `#${String(globalCounter).padStart(5, '0')}`;

    const avaliacoesStaff = userData[staffUser.id]?.avaliacoes || [];
    const notaMedia = avaliacoesStaff.length
        ? avaliacoesStaff.reduce((a, b) => a + b, 0) / avaliacoesStaff.length
        : 5;

    const [staffMember, enviadorMember, recebedorMember] = await Promise.all([
        guild?.members?.fetch(staffUser.id).catch(() => null),
        guild?.members?.fetch(enviadorUser.id).catch(() => null),
        guild?.members?.fetch(recebedorUser.id).catch(() => null)
    ]);

    const staffDisplayName = staffMember?.displayName || staffUser?.username || "Staff";
    const enviadorDisplayName = enviadorMember?.displayName || enviadorUser?.username || "Comprador";
    const recebedorDisplayName = recebedorMember?.displayName || recebedorUser?.username || "Vendedor";

    const canalAlvoId = (tipo === "pix_grande" || valor >= 500) ? CANAL_BIG_TRADE : CANAL_PROOFS;
    const canal = await getCanal(guild, canalAlvoId) || await getCanal(guild, CANAL_PROOFS);
    if (canal) {
        try {
            const buffer = await gerarCartaoVouch({
                staffNome: staffDisplayName,
                staffAvatarURL: staffUser?.displayAvatarURL ? staffUser.displayAvatarURL({ extension: "png", size: 128 }) : null,
                staffNota: notaMedia,
                staffIntermediacoes: userData[staffUser.id]?.totalTrocas || 0,
                transacaoId,
                vouchCodigo,
                valor,
                compradorNome: enviadorDisplayName,
                compradorAvatarURL: enviadorUser?.displayAvatarURL ? enviadorUser.displayAvatarURL({ extension: "png", size: 128 }) : null,
                vendedorNome: recebedorDisplayName,
                vendedorAvatarURL: recebedorUser?.displayAvatarURL ? recebedorUser.displayAvatarURL({ extension: "png", size: 128 }) : null,
                data: new Date().toLocaleDateString("pt-BR")
            });
            const anexoVouch = new AttachmentBuilder(buffer, { name: `vouch-${vouchCodigo.replace('#', '')}.png` });
            await canal.send({
                files: [anexoVouch]
            }).catch(console.error);
            console.log(`[VOUCH] Cartão de vouch enviado com sucesso para #${canal.name} (${canal.id})`);
        } catch (e) {
            console.error("Erro ao gerar cartão de vouch:", e);
        }
    } else {
        console.error(`[VOUCH] Canal de proofs não encontrado (${canalAlvoId} / ${CANAL_PROOFS})`);
    }

    if (taxaTotal > 0) {
        const canalTaxas = await getCanal(guild, CANAL_TAXAS);
        if (canalTaxas) {
            const embedTaxas = new EmbedBuilder().setColor("#DE4548").setTitle("<:0961:1454624137992474644> — Relatório de Intermediação").setDescription(`**ID da Proof:** \`#${globalCounter}\` | Valor: \`R$ ${valorFormatado}\``).addFields({ name: "💰 Taxa Total", value: `\`R$ ${taxaTotal.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}\`` }, { name: "👑 Parte do Dono (50%)", value: `\`R$ ${(taxaTotal / 2).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}\``, inline: true }, { name: "🤝 Parte do Middleman (50%)", value: `\`R$ ${(taxaTotal / 2).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}\``, inline: true });
            await canalTaxas.send({ content: `🔔 <@${staffUser.id}>`, embeds: [embedTaxas] }).catch(() => {});
        }
    }

    return transacaoId;
}

let lastDailyRun = null;
const dbLastMonthlyPath = path.join(__dirname, 'lastMonthlyRun.json');
let lastMonthlyRun = fs.existsSync(dbLastMonthlyPath) ? JSON.parse(fs.readFileSync(dbLastMonthlyPath)) : null;

function saveLastMonthlyRun() { fs.writeFileSync(dbLastMonthlyPath, JSON.stringify(lastMonthlyRun)); }

function checkScheduledTasks() {
    const now = new Date();
    const options = { timeZone: "America/Sao_Paulo", hour: "numeric", minute: "numeric", day: "numeric" };
    const formatter = new Intl.DateTimeFormat("pt-BR", options);
    const parts = formatter.formatToParts(now);
    const hour = parseInt(parts.find(p => p.type === "hour").value);
    const minute = parseInt(parts.find(p => p.type === "minute").value);
    const day = parseInt(parts.find(p => p.type === "day").value);

    const currentMonthYear = new Date().getMonth() + "-" + new Date().getFullYear();
    if (day === 1 && lastMonthlyRun !== currentMonthYear) {
        console.log("Tentando executar reset mensal...");
        runMonthlyReset();
    }
    if (hour === 23 && minute >= 10) runDailyClosure();
}

async function runDailyClosure() {
    const today = new Date().toDateString();
    if (lastDailyRun === today) return;
    lastDailyRun = today;
    try {
        const guild = client.guilds.cache.get(GUILD_ID);
        if (!guild || Object.keys(taxasDiarias).length === 0) return;
        const canalTaxas = guild.channels.cache.get(CANAL_TAXAS);
        if (!canalTaxas) console.warn("[fechamento diário] Canal de taxas não encontrado:", CANAL_TAXAS);

        for (const [mmId, totalBruto] of Object.entries(taxasDiarias)) {
            // Blindagem: se por algum motivo o valor salvo não for um número válido, pula essa entrada
            // em vez de derrubar o fechamento inteiro (e loga pra facilitar achar a causa).
            const total = parseFloat(totalBruto);
            if (!Number.isFinite(total) || total <= 0) {
                console.warn(`[fechamento diário] Valor inválido para ${mmId}, ignorado:`, totalBruto);
                continue;
            }
            try {
                const metade = total / 2;
                const embed = new EmbedBuilder().setColor("#DE4548").setTitle("📊 Fechamento Diário de Taxas").setDescription(`Relatório de <@${mmId}>\nTotal: \`R$ ${total.toFixed(2)}\` | Repasse: \`R$ ${metade.toFixed(2)}\``);
                const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId("copiar_chave_pix_repasse").setLabel("Chave PIX para Repasse").setStyle(ButtonStyle.Primary));
                if (canalTaxas) await canalTaxas.send({ embeds: [embed], components: [row] }).catch((e) => console.error(`[fechamento diário] Falha ao enviar relatório de ${mmId}:`, e?.message || e));
            } catch (erroItem) {
                console.error(`[fechamento diário] Erro ao processar ${mmId}:`, erroItem?.message || erroItem);
            }
        }
        taxasDiarias = {}; saveTaxas();
    } catch (err) {
        console.error("Erro no fechamento diário:", err?.message || err);
        if (err?.stack) console.error(err.stack);
    }
}

async function runMonthlyReset() {
    const monthYear = new Date().getMonth() + "-" + new Date().getFullYear();
    if (lastMonthlyRun === monthYear) {
        console.log("Reset mensal já executado para este mês.");
        return;
    }
    lastMonthlyRun = monthYear;
    saveLastMonthlyRun();
    try {
        const guild = client.guilds.cache.get(GUILD_ID);
        if (!guild) return;
        const rolesTop = [CARGO_TOP_1, CARGO_TOP_2, CARGO_TOP_3];
        for (const roleId of rolesTop) {
            const role = guild.roles.cache.get(roleId);
            if (role) {
                for (const [mId, m] of role.members) await m.roles.remove(roleId).catch(() => { });
            }
        }
        for (const id in userData) {
            userData[id].totalMes = 0;
            userData[id].taxaMes = 0;
        }
        saveUsers();
        saveLastMonthlyRun(); // Salva a data do último reset mensal
    } catch (err) { console.error("Erro no reset mensal:", err); }
}

const commands = [
    new SlashCommandBuilder().setName("ranking").setDescription("Mostra o ranking de movimentação"),
    new SlashCommandBuilder().setName("perfil").setDescription("Ver perfil financeiro").addUserOption(o => o.setName("usuario").setDescription("Usuário")),
    new SlashCommandBuilder().setName("vouch").setDescription("Aprova um pagamento e gera o vouch de intermediação").addStringOption(o => o.setName("tipo").setDescription("Tipo").setRequired(true).addChoices({ name: "PIX", value: "pix" }, { name: "PIX GRANDE", value: "pix_grande" }, { name: "CROSSTRADE", value: "crosstrade" })).addUserOption(o => o.setName("comprador").setDescription("Comprador").setRequired(true)).addUserOption(o => o.setName("vendedor").setDescription("Vendedor").setRequired(true)).addStringOption(o => o.setName("valor").setDescription("Valor").setRequired(true)),
    new SlashCommandBuilder().setName("aprovar_pagamento").setDescription("Aprova um pagamento").addStringOption(o => o.setName("tipo").setDescription("Tipo").setRequired(true).addChoices({ name: "PIX", value: "pix" }, { name: "PIX GRANDE", value: "pix_grande" }, { name: "CROSSTRADE", value: "crosstrade" })).addUserOption(o => o.setName("enviador").setDescription("Enviador").setRequired(true)).addUserOption(o => o.setName("recebedor").setDescription("Recebedor").setRequired(true)).addStringOption(o => o.setName("valor").setDescription("Valor").setRequired(true)),
    new SlashCommandBuilder().setName("remover_valor").setDescription("Remove um valor do total de um usuário").addUserOption(o => o.setName("usuario").setDescription("Usuário").setRequired(true)).addStringOption(o => o.setName("valor").setDescription("Valor a remover").setRequired(true)),
    new SlashCommandBuilder().setName("configpix").setDescription("Configurar dados de PIX para os Middlemans").setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
];

const rest = new REST({ version: "10" }).setToken(TOKEN);
(async () => {
    try {
        await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body: commands });
        console.log("Comandos registrados.");
    } catch (err) { console.error(err); }
})();

// client.removeAllListeners(Events.MessageCreate) bypassed

client.on(Events.MessageCreate, async (message) => {
    if (message.content === '!middleman') {
        const container = new ContainerBuilder()
            .setAccentColor(0xDE4548)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    '# 🤝 — Solicitar MM\n' +
                    '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    'Selecione abaixo a categoria desejada. Oferecemos serviços de intermediação para qualquer tipo de produto ou negociação, com segurança e agilidade.\n\n' +
                       '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    
                    '## 💳 Taxa Sobre Transação via pix\n' +
                    '**Taxas Normais**\n' +
                    '**R$ 0,50** acima de R$ 8,00.\n' +
                    '**R$ 2,00** acima de R$ 100,00.\n' +
                    '**R$ 4,00** acima de R$ 200,00.\n' +
                    '**R$ 6,50** acima de R$ 400,00.\n' +
                    '**1%** acima de R$ 700,00.\n' +
                    'Em conta adicionamos **R$ 4,00**.\n\n' +
                    '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    '**Abrir MM**'
                )
            )
            .addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('abrir_mediacao')
                        .setLabel('Abrir Mediação')
                        .setStyle(ButtonStyle.Danger)
  
                )
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent('-# NEUX MEDIAÇÃO')
            );

        await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(console.error);
    }

    if (message.content === '!middleman2') {
        const container = new ContainerBuilder()
            .setAccentColor(0xDE4548)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    '# 🤝 — Solicitar MM (Taxa Reduzida)\n' +
                    '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    'Selecione abaixo a categoria desejada. Oferecemos serviços de intermediação para qualquer tipo de produto ou negociação, com segurança e agilidade.\n\n' +
                       '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    
                    '## 💳 Taxa Sobre Transação via pix\n' +
                    '**Taxa Reduzida**\n' +
                    '**R$ 0,25** acima de R$ 8,00.\n' +
                    '**R$ 2,00** acima de R$ 100,00.\n' +
                    '**R$ 4,00** acima de R$ 200,00.\n' +
                    '**R$ 6,50** acima de R$ 400,00.\n' +
                    '**1%** acima de R$ 700,00.\n' +
                    'Em conta adicionamos **R$ 4,00**.\n\n' +
                    '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    '**Abrir MM**'
                )
            )
            .addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('abrir_mediacao_baixa')
                        .setLabel('Abrir Mediação (Taxa Reduzida)')
                        .setStyle(ButtonStyle.Danger)
                )
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent('-# NEUX MEDIAÇÃO')
            );

        await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(console.error);
    }

    if (message.content === '!mm') {
        const container = new ContainerBuilder()
            .setAccentColor(0xDE4548)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# 📊 — Painel do Middleman\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `Estatísticas pessoais das suas intermediações: taxas, valores e clientes atendidos.\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `👤 **Perfil MM** — visão geral (intermediações, nota, taxas).\n` +
                    `💰 **Mês** — total faturado no mês atual.\n` +
                    `📅 **Dia** — faturado hoje, antes do fechamento (23h10).\n` +
                    `👥 **Pessoas** — quem você já atendeu.\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `-# Respostas privadas • Exclusivo staff\n` +
                    `-# NEUX MEDIAÇÃO`
                )
            )
            .addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('mm_perfil').setLabel('Perfil MM').setEmoji('👤').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('mm_mes').setLabel('Faturamento do Mês').setEmoji('💰').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('mm_dia').setLabel('Faturamento do Dia').setEmoji('📅').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('mm_pessoas').setLabel('Pessoas Atendidas').setEmoji('👥').setStyle(ButtonStyle.Secondary)
                )
            );

        await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(console.error);
    }
});

client.login(TOKEN);
