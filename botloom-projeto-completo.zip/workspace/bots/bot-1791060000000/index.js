// painel-vendedor-v3.js
// Requisitos: discord.js >= 14.22  |  npm i discord.js qrcode
// Rode com: node painel-vendedor-v3.js

const fs = require('fs');
const QRCode = require('qrcode');
const {
  Client, GatewayIntentBits, MessageFlags, PermissionFlagsBits, AttachmentBuilder, EmbedBuilder,
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SectionBuilder, ThumbnailBuilder,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  StringSelectMenuBuilder, StringSelectMenuOptionBuilder,
  ModalBuilder, LabelBuilder, FileUploadBuilder,
} = require('discord.js');

// ================== CONFIG ==================
const CONFIG = {
  TOKEN: 'COLE_O_TOKEN_AQUI',
  CHAVE_PIX: '9861328d-1190-41e0-9a10-b2f1adf77683',   // chave fixa
  NOME_RECEBEDOR: 'UELLINGTONALMEIDADEJESUS',          // até 25 caracteres
  CIDADE_RECEBEDOR: 'SAO PAULO',                       // até 15 caracteres
  CANAL_ADMIN_ID: '1510418519458582560',               // canal onde você avalia os comprovantes
  CANAL_AVISO_ID: '1460334865756061756',               // canal dos avisos (cadastro, vencimento)
  CARGOS: {                                            // um cargo por tier
    t1: '1417912504964878497',
    t2: '1417912504964878497',
    t3: '1417912504964878497',
  },
  COR: 0xde4548,
  COMANDO: '!painelvendas',
};

// Durações (iguais para todos os tiers)
const DURACOES = {
  diario:     { nome: 'Diário',     dias: 1,  texto: '1 dia',   sufixo: '/dia' },
  semanal:    { nome: 'Semanal',    dias: 7,  texto: '7 dias',  sufixo: '/semana' },
  quinzenal:  { nome: 'Quinzenal',  dias: 15, texto: '15 dias', sufixo: '/15d' },
  mensal:     { nome: 'Mensal',     dias: 30, texto: '30 dias', sufixo: '/mês' },
  trimestral: { nome: 'Trimestral', dias: 90, texto: '90 dias', sufixo: '/trimestre' },
};

// >>> AJUSTE AQUI: benefícios e preços de cada tier <<<
// Tier 1: diário R$ 2 · semanal R$ 8 · mensal R$ 17 (valores definidos por você).
// Demais valores calculados proporcionalmente, com desconto nos planos mais longos.
const TIERS = {
  t1: {
    nome: 'Tier 1 de Seller',
    beneficios: [
      '10 Leilões Grátis',
      '1 MM (De Taxa Reduzida) grátis por semana',
      'Divulgue a cada 2h no chat de anúncios da loja',
      'Acesso aos tickets de compra e venda',
      'Cargo exclusivo e acessos especiais',
      'Permissão para vender leilões para os membros',
    ],
    precos: { diario: 2, semanal: 8, quinzenal: 13, mensal: 17, trimestral: 42 },
  },
  t2: {
    nome: 'Tier 2 de Seller',
    beneficios: [
      'Todos os benefícios do anterior',
      '25 Leilões Grátis',
      '2 MM (de até R$ 500) grátis por semana',
    ],
    precos: { diario: 3, semanal: 11, quinzenal: 18, mensal: 24, trimestral: 60 },
  },
  t3: {
    nome: 'Tier 3 de Seller',
    beneficios: [
      'Todos os benefícios do anterior',
      '30 Leilões Grátis',                                  // PLACEHOLDER
      '3 MM (De Taxa Reduzida) grátis por semana',
      'Acesso facilitado pra entrar na equipe staff ou mediação',
      'Divulgue a cada 1h no chat de anúncios da loja',
    ],
    precos: { diario: 5, semanal: 16, quinzenal: 26, mensal: 35, trimestral: 90 },
  },
};

const DIA_MS = 24 * 60 * 60 * 1000;
const brl = (n) => `R$ ${n.toFixed(2).replace('.', ',')}`;
const V2 = MessageFlags.IsComponentsV2;
const EPH = MessageFlags.Ephemeral;
const sep = () => new SeparatorBuilder().setDivider(true);
const txt = (c) => new TextDisplayBuilder().setContent(c);
const SETA = '<:Eclipse_seta_red:1475039425200132200>';
const lista = (arr) => arr.map((b) => `${SETA} ${b}`).join('\n');
const linhaPrecos = (t) =>
  Object.entries(DURACOES).map(([k, d]) => `**${brl(t.precos[k])}**${d.sufixo}`).join(' · ');

// ================== PIX (BR Code estático + QR) ==================
const semAcento = (s) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase();
const campo = (id, v) => id + String(v.length).padStart(2, '0') + v;
function crc16(str) {
  let crc = 0xffff;
  for (let i = 0; i < str.length; i++) {
    crc ^= str.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}
function gerarPix(valor) {
  const payload =
    campo('00', '01') +
    campo('26', campo('00', 'br.gov.bcb.pix') + campo('01', CONFIG.CHAVE_PIX)) +
    campo('52', '0000') +
    campo('53', '986') +
    campo('54', valor.toFixed(2)) +
    campo('58', 'BR') +
    campo('59', semAcento(CONFIG.NOME_RECEBEDOR).slice(0, 25)) +
    campo('60', semAcento(CONFIG.CIDADE_RECEBEDOR).slice(0, 15)) +
    campo('62', campo('05', '***')) +
    '6304';
  return payload + crc16(payload);
}

// ================== "BANCO" SIMPLES ==================
const DB_FILE = './cadastros.json';
const lerDB = () => { try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch { return {}; } };
const salvarDB = (d) => fs.writeFileSync(DB_FILE, JSON.stringify(d, null, 4));

// ================== PAINÉIS ==================
function painelPrincipal() {
  const c = new ContainerBuilder()
    .setAccentColor(CONFIG.COR)
    .addTextDisplayComponents(
      txt('# VIRE VENDEDOR E FAÇA LEILÕES'),
      txt('Escolha um tier de seller, anuncie no servidor e ganhe leilões e MM grátis.')
    );

  for (const t of Object.values(TIERS)) {
    c.addSeparatorComponents(sep());
    c.addTextDisplayComponents(txt(`## ${t.nome.toUpperCase()}\n${lista(t.beneficios)}\n\n${linhaPrecos(t)}`));
  }

  const select = new StringSelectMenuBuilder()
    .setCustomId('escolher_tier')
    .setPlaceholder('Escolha o seu tier de vendedor')
    .addOptions(
      Object.entries(TIERS).map(([key, t]) =>
        new StringSelectMenuOptionBuilder().setLabel(t.nome).setValue(key).setDescription(`A partir de ${brl(t.precos.diario)}/dia`)
      )
    );

  return c
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(txt('-# <:ravisoshelt:1439092081024041063> O pagamento é por Pix e a liberação é feita pela administração depois de conferir o comprovante.'))
    .addActionRowComponents(new ActionRowBuilder().addComponents(select));
}

function painelTier(key) {
  const t = TIERS[key];
  const botoes = Object.entries(DURACOES).map(([dk, d]) =>
    new ButtonBuilder()
      .setCustomId(`pagar:${key}:${dk}`)
      .setLabel(`${brl(t.precos[dk])}${d.sufixo}`)
      .setEmoji('💰')
      .setStyle(ButtonStyle.Success)
  );
  return new ContainerBuilder()
    .setAccentColor(CONFIG.COR)
    .addTextDisplayComponents(txt(`# ${t.nome}`), txt(lista(t.beneficios)), txt('**Escolha por quanto tempo quer assinar.**'))
    .addSeparatorComponents(sep())
    .addActionRowComponents(new ActionRowBuilder().addComponents(...botoes));
}

function painelPagamento(key, dk, orderId, payload) {
  const t = TIERS[key];
  const d = DURACOES[dk];
  return new ContainerBuilder()
    .setAccentColor(CONFIG.COR)
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          txt('# Pagamento da assinatura'),
          txt(`**${t.nome}** · ${d.texto}\n**Valor:** ${brl(t.precos[dk])}\nPedido \`${orderId}\``),
          txt(`Recebedor: **${CONFIG.NOME_RECEBEDOR}**`)
        )
        .setThumbnailAccessory(new ThumbnailBuilder().setURL('attachment://pix.png'))
    )
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(txt(`**Pix copia e cola**\n\`\`\`\n${payload}\n\`\`\``))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`copiar:${key}:${dk}`).setLabel('Copiar código').setEmoji('📋').setStyle(ButtonStyle.Secondary)
      )
    )
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(
      txt('Pague o Pix e clique em **Enviar comprovante**.\n⚠️ O cargo só é entregue depois que a administração conferir o pagamento.')
    )
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`comp:${orderId}:${key}:${dk}`).setLabel('Enviar comprovante').setEmoji('🧾').setStyle(ButtonStyle.Success)
      )
    );
}

// ================== CADASTRO AUTOMÁTICO (ao aprovar) ==================
async function registrarAssinatura(guild, membro, key, dk) {
  const t = TIERS[key];
  const d = DURACOES[dk];

  // tira cargos de outros tiers (se forem IDs diferentes) e dá o do tier comprado
  const alvo = CONFIG.CARGOS[key];
  for (const id of Object.values(CONFIG.CARGOS)) if (id !== alvo) await membro.roles.remove(id).catch(() => {});
  await membro.roles.add(alvo);

  // renovação do mesmo tier soma o tempo que ainda resta
  const db = lerDB();
  const atual = db[membro.id];
  const ativo = atual && atual.tier === key && atual.expiraEm > Date.now();
  const base = ativo ? atual.expiraEm : Date.now();
  const expiraEm = base + d.dias * DIA_MS;

  db[membro.id] = {
    guildId: guild.id,
    username: membro.user.username,
    tier: key,
    expiraEm,
    avisoEm: d.dias > 1 ? expiraEm - DIA_MS : null, // plano diário não tem aviso prévio
    avisoEnviado: false,
  };
  salvarDB(db);

  const ts = Math.floor(expiraEm / 1000);
  const embed = new EmbedBuilder()
    .setColor(CONFIG.COR)
    .setTitle('✅ Cadastro Realizado')
    .setDescription(
      `O usuário ${membro} / **${membro.user.username}** foi cadastrado com sucesso.\n\n` +
      `• **Tier:** \`${t.nome}\`\n` +
      `• **Duração:** ${d.texto}\n` +
      `• **Expira em:** <t:${ts}:f>`
    )
    .setThumbnail(membro.user.displayAvatarURL({ size: 512 }));

  const canalAviso = guild.channels.cache.get(CONFIG.CANAL_AVISO_ID);
  if (canalAviso) await canalAviso.send({ embeds: [embed] }).catch(() => null);
  await membro.send({ embeds: [embed] }).catch(() => null);
}

// checagem a cada 1 minuto: aviso 1 dia antes + remoção do cargo
function iniciarChecagemAutomatica() {
  setInterval(async () => {
    const banco = lerDB();
    const agora = Date.now();
    let mudou = false;

    for (const userId in banco) {
      const c = banco[userId];
      const guild = client.guilds.cache.get(c.guildId);
      if (!guild) continue;
      const canalAviso = guild.channels.cache.get(CONFIG.CANAL_AVISO_ID);
      const usuario = await client.users.fetch(userId).catch(() => null);
      if (!usuario) continue;

      // aviso de 1 dia antes
      if (c.avisoEm && agora >= c.avisoEm && !c.avisoEnviado && agora < c.expiraEm) {
        const ts = Math.floor(c.expiraEm / 1000);
        const embedAviso = new EmbedBuilder()
          .setColor(CONFIG.COR)
          .setTitle('⚠️ Seu prazo de vendedor está terminando!')
          .setDescription(
            `Olá ${usuario}, falta cerca de **1 dia** para acabar o seu acesso de vendedor.\n\n` +
            `• **Expira em:** <t:${ts}:F> (<t:${ts}:R>)\n\n` +
            `📋 **Para renovar:** faça um novo pagamento pelo painel de vendedor antes do prazo final e envie o comprovante.`
          )
          .setFooter({ text: 'Evite a remoção automática do seu cargo.' })
          .setTimestamp();
        if (canalAviso) await canalAviso.send({ content: `⚠️ Alerta de vencimento ${usuario}`, embeds: [embedAviso] }).catch(() => null);
        await usuario.send({ embeds: [embedAviso] }).catch(() => null);
        c.avisoEnviado = true;
        mudou = true;
      }

      // fim do prazo
      if (agora >= c.expiraEm) {
        const membro = await guild.members.fetch(userId).catch(() => null);
        if (membro) {
          for (const id of new Set(Object.values(CONFIG.CARGOS))) await membro.roles.remove(id).catch(() => {});
          const embedFim = new EmbedBuilder()
            .setColor(CONFIG.COR)
            .setTitle('❌ Assinatura Expirada')
            .setDescription(
              `O tempo de assinatura de ${usuario} (\`${usuario.username}\`) chegou ao fim.\n\n` +
              `• **Ação tomada:** o cargo de vendedor foi removido automaticamente.\n` +
              `• **Como reativar:** faça um novo pagamento pelo painel de vendedor.`
            )
            .setTimestamp();
          if (canalAviso) await canalAviso.send({ embeds: [embedFim] }).catch(() => null);
          await usuario.send({ content: `❌ Seu período de acesso expirou no servidor **${guild.name}**.`, embeds: [embedFim] }).catch(() => null);
        }
        delete banco[userId];
        mudou = true;
      }
    }
    if (mudou) salvarDB(banco);
  }, 60000);
}

// ================== BOT ==================
const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMembers],
});

let iniciado = false;
const aoFicarOnline = () => {
  if (iniciado) return;
  iniciado = true;
  console.log(`Online como ${client.user.tag}`);
  iniciarChecagemAutomatica();
};
client.once('clientReady', aoFicarOnline);
client.once('ready', aoFicarOnline);

client.on('messageCreate', async (msg) => {
  if (msg.author.bot || !msg.guild) return;
  if (msg.content.trim().toLowerCase() !== CONFIG.COMANDO) return;
  if (!msg.member.permissions.has(PermissionFlagsBits.Administrator)) return;
  await msg.channel.send({ flags: V2, components: [painelPrincipal()] });
  msg.delete().catch(() => {});
});

client.on('interactionCreate', async (i) => {
  try {
    if (i.isStringSelectMenu() && i.customId === 'escolher_tier') {
      return i.reply({ flags: V2 | EPH, components: [painelTier(i.values[0])] });
    }

    if (i.isButton()) {
      if (i.customId.startsWith('pagar:')) {
        const [, key, dk] = i.customId.split(':');
        const valor = TIERS[key].precos[dk];
        const orderId = 'SL-' + Math.random().toString(36).slice(2, 8).toUpperCase();
        const payload = gerarPix(valor);
        const qr = await QRCode.toBuffer(payload, { margin: 1, width: 300 });
        return i.reply({
          flags: V2 | EPH,
          files: [new AttachmentBuilder(qr, { name: 'pix.png' })],
          components: [painelPagamento(key, dk, orderId, payload)],
        });
      }

      if (i.customId.startsWith('copiar:')) {
        const [, key, dk] = i.customId.split(':');
        return i.reply({ flags: EPH, content: gerarPix(TIERS[key].precos[dk]) });
      }

      if (i.customId.startsWith('comp:')) {
        const [, orderId, key, dk] = i.customId.split(':');
        const modal = new ModalBuilder()
          .setCustomId(`modal:${orderId}:${key}:${dk}`)
          .setTitle(`Comprovante · ${orderId}`)
          .addLabelComponents(
            new LabelBuilder()
              .setLabel('Comprovante do Pix')
              .setDescription('Print ou PDF do pagamento.')
              .setFileUploadComponent(
                new FileUploadBuilder().setCustomId('arquivos').setMinValues(1).setMaxValues(3).setRequired(true)
              )
          );
        return i.showModal(modal);
      }

      // admin aprova / recusa
      if (i.customId.startsWith('aprovar:') || i.customId.startsWith('recusar:')) {
        if (!i.memberPermissions.has(PermissionFlagsBits.Administrator))
          return i.reply({ flags: EPH, content: 'Sem permissão.' });

        const [acao, orderId, userId, key, dk] = i.customId.split(':');
        const t = TIERS[key];
        const d = DURACOES[dk];
        const membro = await i.guild.members.fetch(userId).catch(() => null);

        if (acao === 'aprovar') {
          if (!membro) return i.reply({ flags: EPH, content: 'Usuário não está mais no servidor.' });
          try {
            await registrarAssinatura(i.guild, membro, key, dk);
          } catch (e) {
            console.error(e);
            return i.reply({ flags: EPH, content: 'Não consegui dar o cargo. Deixe o cargo do bot acima do cargo de vendedor.' });
          }
          return i.update({ components: [], content: `✅ Pedido \`${orderId}\` (**${t.nome}** · ${d.texto}) **aprovado** por ${i.user}.` });
        }

        membro?.send(`❌ O comprovante do pedido **${orderId}** foi recusado. Fale com a administração.`).catch(() => {});
        return i.update({ components: [], content: `❌ Pedido \`${orderId}\` **recusado** por ${i.user}.` });
      }
    }

    if (i.isModalSubmit() && i.customId.startsWith('modal:')) {
      const [, orderId, key, dk] = i.customId.split(':');
      const t = TIERS[key];
      const d = DURACOES[dk];
      const arquivos = i.fields.getUploadedFiles('arquivos');
      const canal = await client.channels.fetch(CONFIG.CANAL_ADMIN_ID);

      await canal.send({
        content:
          `🧾 **Novo comprovante** · \`${orderId}\`\n` +
          `Usuário: ${i.user} (\`${i.user.id}\`)\n` +
          `Plano: **${t.nome}** · ${d.nome} (${d.texto}) — ${brl(t.precos[dk])}`,
        files: [...arquivos.values()].map((a) => a.url),
        components: [
          new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`aprovar:${orderId}:${i.user.id}:${key}:${dk}`).setLabel('Aprovar').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId(`recusar:${orderId}:${i.user.id}:${key}:${dk}`).setLabel('Recusar').setStyle(ButtonStyle.Danger)
          ),
        ],
      });

      return i.reply({ flags: EPH, content: '✅ Comprovante enviado! Aguarde a administração conferir o pagamento.' });
    }
  } catch (err) {
    console.error(err);
    if (!i.replied && !i.deferred) i.reply({ flags: EPH, content: 'Deu erro, tenta de novo.' }).catch(() => {});
  }
});

client.login(CONFIG.TOKEN);
