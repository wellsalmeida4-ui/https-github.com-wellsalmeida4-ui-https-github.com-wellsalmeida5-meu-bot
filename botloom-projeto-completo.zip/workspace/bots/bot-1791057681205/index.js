const fs = require("fs");
const path = require("path");
const {
  Client,
  GatewayIntentBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  EmbedBuilder,
  ChannelType,
  PermissionFlagsBits,
  MessageFlags,
  SlashCommandBuilder
} = require("discord.js");

// ================= CONFIGURAÇÕES =================
const STAFF_ROLE_IDS = ["1419441539331002489", "1420702867148378203", "1417912504964878497"];
const TICKET_PARENT_CATEGORY_ID = "1477780293829132572";
const BANNER_URL = "https://i.postimg.cc/WzcCtxj9/6e8e2b50ce436a946142e99432b9f6b0.jpg";
const EMOJI_SUCESSO = "<:2974:1438244299564126279>";
const COR_EMBED = 0xFF0000;
const DATABASE_FILE = "tickets.json";

function loadTickets() {
  try {
    if (!fs.existsSync(DATABASE_FILE)) return {};
    return JSON.parse(fs.readFileSync(DATABASE_FILE, "utf8"));
  } catch (e) {
    return {};
  }
}

function saveTicket(channelId, ownerId) {
  try {
    const data = loadTickets();
    data[String(channelId)] = ownerId;
    fs.writeFileSync(DATABASE_FILE, JSON.stringify(data, null, 2), "utf8");
  } catch (e) {
    console.error("Erro ao salvar ticket:", e);
  }
}

function removeTicket(channelId) {
  try {
    const data = loadTickets();
    if (data[String(channelId)]) {
      delete data[String(channelId)];
      fs.writeFileSync(DATABASE_FILE, JSON.stringify(data, null, 2), "utf8");
    }
  } catch (e) {
    console.error("Erro ao remover ticket:", e);
  }
}

function isStaff(member) {
  if (!member) return false;
  if (member.permissions && member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  if (member.roles && member.roles.cache) {
    return STAFF_ROLE_IDS.some(roleId => member.roles.cache.has(roleId));
  }
  return false;
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ]
});

client.once("ready", async (c) => {
  console.log("✅ Sistema de Tickets Online como " + (c.user ? c.user.tag : "Bot"));
  try {
    const setupTicketCmd = new SlashCommandBuilder()
      .setName("setup_ticket")
      .setDescription("Envia o painel oficial para abertura de tickets.");
    if (client.application && client.application.commands) {
      await client.application.commands.create(setupTicketCmd).catch(() => {});
    }
  } catch (e) {}
});

// Comandos de Chat
client.on("messageCreate", async (message) => {
  if (message.author.bot) return;

  const content = message.content.trim().toLowerCase();
  const prefix = process.env.PREFIX || "!";

  if (
    content === "!setup_ticket" ||
    content === prefix + "setup_ticket" ||
    content === "!ticket" ||
    content === prefix + "ticket" ||
    content === "!painelticket" ||
    content === prefix + "painelticket"
  ) {
    if (!isStaff(message.member)) {
      return message.reply("❌ Apenas membros da Staff podem enviar o painel de tickets.").catch(() => {});
    }

    const embed = new EmbedBuilder()
      .setColor(COR_EMBED)
      .setTitle("ABRA SEU TICKET")
      .setDescription(
        "> Oferecemos um suporte **rápido** e **organizado** em nosso servidor. " +
        "Os suportes são resolvidos lá, poderá retirar suas dúvidas, fazer denúncias, " +
        "revogar punições que não concorda, tudo isso com nossa equipe especializada de suporte."
      )
      .setImage(BANNER_URL);

    const select = new StringSelectMenuBuilder()
      .setCustomId("dropdown_ticket")
      .setPlaceholder("Escolha uma categoria")
      .addOptions([
        {
          label: "Ticket Vendas",
          description: "Venda seu brainrot, envie foto e valor.",
          value: "Ticket Vendas",
          emoji: "🧧"
        },
        {
          label: "Ticket Suporte",
          description: "Dúvidas gerais ou solicitar ajuda.",
          value: "Ticket Suporte",
          emoji: "👤"
        },
        {
          label: "Ticket Compras",
          description: "Clique para comprar itens da loja.",
          value: "Ticket Compras",
          emoji: "🛒"
        },
        {
          label: "Ticket Denuncias.",
          description: "Informe o usuário e anexe as provas.",
          value: "Ticket Denuncias.",
          emoji: "❕"
        }
      ]);

    const row = new ActionRowBuilder().addComponents(select);
    await message.channel.send({ embeds: [embed], components: [row] }).catch(console.error);
  }
});

// Interações Nativas (Dropdown, Botões e Modais)
client.on("interactionCreate", async (interaction) => {
  try {
    if (interaction.isChatInputCommand && interaction.isChatInputCommand()) {
      if (interaction.commandName === "setup_ticket") {
        if (!isStaff(interaction.member)) {
          return interaction.reply({ content: "❌ Apenas membros da Staff podem enviar o painel de tickets.", flags: [MessageFlags.Ephemeral] });
        }
        const embed = new EmbedBuilder()
          .setColor(COR_EMBED)
          .setTitle("ABRA SEU TICKET")
          .setDescription(
            "> Oferecemos um suporte **rápido** e **organizado** em nosso servidor. " +
            "Os suportes são resolvidos lá, poderá retirar suas dúvidas, fazer denúncias, " +
            "revogar punições que não concorda, tudo isso com nossa equipe especializada de suporte."
          )
          .setImage(BANNER_URL);

        const select = new StringSelectMenuBuilder()
          .setCustomId("dropdown_ticket")
          .setPlaceholder("Escolha uma categoria")
          .addOptions([
            { label: "Ticket Vendas", description: "Venda seu brainrot, envie foto e valor.", value: "Ticket Vendas", emoji: "🧧" },
            { label: "Ticket Suporte", description: "Dúvidas gerais ou solicitar ajuda.", value: "Ticket Suporte", emoji: "👤" },
            { label: "Ticket Compras", description: "Clique para comprar itens da loja.", value: "Ticket Compras", emoji: "🛒" },
            { label: "Ticket Denuncias.", description: "Informe o usuário e anexe as provas.", value: "Ticket Denuncias.", emoji: "❕" }
          ]);

        const row = new ActionRowBuilder().addComponents(select);
        await interaction.channel.send({ embeds: [embed], components: [row] });
        return interaction.reply({ content: "✅ Painel de tickets enviado com sucesso!", flags: [MessageFlags.Ephemeral] });
      }
    }

    const customId = interaction.customId || "";

    // 1. Dropdown do Ticket
    if (interaction.isStringSelectMenu() && customId === "dropdown_ticket") {
      await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

      const selectedOption = interaction.values[0] || "Ticket Suporte";
      const guild = interaction.guild;
      if (!guild) {
        return interaction.editReply({ content: "❌ Os tickets só podem ser abertos dentro de um servidor." });
      }

      let parentCategory = guild.channels.cache.get(TICKET_PARENT_CATEGORY_ID);
      if (!parentCategory || parentCategory.type !== ChannelType.GuildCategory) {
        parentCategory = guild.channels.cache.find(c => c.type === ChannelType.GuildCategory && c.name.toLowerCase().includes("ticket")) || null;
      }

      const overwrites = [
        {
          id: guild.id,
          deny: [PermissionFlagsBits.ViewChannel]
        },
        {
          id: interaction.user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
            PermissionFlagsBits.AttachFiles
          ]
        },
        {
          id: client.user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ManageChannels
          ]
        }
      ];

      for (const roleId of STAFF_ROLE_IDS) {
        if (guild.roles.cache.has(roleId)) {
          overwrites.push({
            id: roleId,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.ReadMessageHistory,
              PermissionFlagsBits.AttachFiles
            ]
          });
        }
      }

      const channelName = "ticket-" + (interaction.user.username.toLowerCase().replace(/[^a-z0-9]/g, "") || "suporte");
      const channel = await guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: parentCategory ? parentCategory.id : undefined,
        permissionOverwrites: overwrites
      });

      saveTicket(channel.id, interaction.user.id);

      const embedWelcome = new EmbedBuilder()
        .setColor(COR_EMBED)
        .setAuthor({
          name: interaction.user.username,
          iconURL: interaction.user.displayAvatarURL()
        })
        .setDescription("👋 <@" + interaction.user.id + "> seu ticket foi aberto com sucesso!")
        .addFields(
          { name: "Usuário", value: interaction.user.username + "\n(" + interaction.user.id + ")", inline: false },
          { name: "Opção", value: selectedOption, inline: false }
        )
        .setThumbnail(interaction.user.displayAvatarURL())
        .setFooter({ text: "Ticket #" + channel.id });

      const rowButtons = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("claim_btn").setLabel("Atender").setStyle(ButtonStyle.Success).setEmoji("🙋"),
        new ButtonBuilder().setCustomId("admin_btn").setLabel("Painel Admin").setStyle(ButtonStyle.Primary).setEmoji("⚙️"),
        new ButtonBuilder().setCustomId("close_btn").setLabel("Fechar").setStyle(ButtonStyle.Danger).setEmoji("🔒")
      );

      await channel.send({
        content: "<@" + interaction.user.id + ">",
        embeds: [embedWelcome],
        components: [rowButtons]
      });

      await interaction.editReply({
        content: EMOJI_SUCESSO + " Ticket criado com sucesso em <#" + channel.id + ">!"
      });
      return;
    }

    // 2. Botão Atender
    if (interaction.isButton() && customId === "claim_btn") {
      if (!isStaff(interaction.member)) {
        return interaction.reply({ content: "❌ Apenas membros da Staff podem atender este ticket!", flags: [MessageFlags.Ephemeral] });
      }

      const originalMessage = interaction.message;
      const updatedRows = originalMessage.components.map(row => {
        return new ActionRowBuilder().addComponents(
          row.components.map(comp => {
            if (comp.customId === "claim_btn") {
              return ButtonBuilder.from(comp)
                .setDisabled(true)
                .setStyle(ButtonStyle.Secondary)
                .setLabel("Atendido por " + interaction.user.username);
            }
            return ButtonBuilder.from(comp);
          })
        );
      });

      await interaction.channel.setName("✅️・atendido-" + interaction.user.username.slice(0, 15)).catch(() => {});
      await interaction.update({ components: updatedRows });
      await interaction.followUp({ content: "O Staff <@" + interaction.user.id + "> assumiu o ticket!" });
      return;
    }

    // 3. Botão Painel Admin
    if (interaction.isButton() && customId === "admin_btn") {
      if (!isStaff(interaction.member)) {
        return interaction.reply({ content: "❌ Apenas Staff!", flags: [MessageFlags.Ephemeral] });
      }

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("admin_add_user").setLabel("Add Usuário").setStyle(ButtonStyle.Secondary).setEmoji("👤"),
        new ButtonBuilder().setCustomId("admin_rem_user").setLabel("Remover Usuário").setStyle(ButtonStyle.Secondary).setEmoji("🚫"),
        new ButtonBuilder().setCustomId("admin_notify_owner").setLabel("Notificar Dono").setStyle(ButtonStyle.Primary).setEmoji("🔔")
      );

      await interaction.reply({
        content: "⚙️ **Configurações Administrativas do Ticket**",
        components: [row],
        flags: [MessageFlags.Ephemeral]
      });
      return;
    }

    // 4. Modais
    if (interaction.isButton() && customId === "admin_add_user") {
      const modal = new ModalBuilder().setCustomId("modal_add_user").setTitle("Adicionar Membro ao Ticket");
      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId("user_id").setLabel("ID do Usuário").setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder("Insira o ID do membro aqui...")
        )
      );
      await interaction.showModal(modal);
      return;
    }

    if (interaction.isButton() && customId === "admin_rem_user") {
      const modal = new ModalBuilder().setCustomId("modal_rem_user").setTitle("Remover Membro do Ticket");
      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId("user_id").setLabel("ID do Usuário").setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder("Insira o ID do membro a remover...")
        )
      );
      await interaction.showModal(modal);
      return;
    }

    if (interaction.isButton() && customId === "admin_notify_owner") {
      const modal = new ModalBuilder().setCustomId("modal_notify_owner").setTitle("Notificar Dono do Ticket");
      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId("feedback").setLabel("Mensagem de Notificação").setStyle(TextInputStyle.Paragraph).setRequired(true).setPlaceholder("Digite o que deseja enviar na DM do usuário...")
        )
      );
      await interaction.showModal(modal);
      return;
    }

    // Submissões de Modais
    if (interaction.isModalSubmit() && customId === "modal_add_user") {
      const targetId = interaction.fields.getTextInputValue("user_id").trim();
      const targetMember = await interaction.guild.members.fetch(targetId).catch(() => null);
      if (!targetMember) {
        return interaction.reply({ content: "❌ ID inválido ou usuário não encontrado no servidor.", flags: [MessageFlags.Ephemeral] });
      }

      await interaction.channel.permissionOverwrites.edit(targetMember.id, {
        ViewChannel: true,
        SendMessages: true,
        ReadMessageHistory: true
      });
      await interaction.reply({ content: EMOJI_SUCESSO + " Usuário <@" + targetMember.id + "> adicionado com sucesso ao ticket!", flags: [MessageFlags.Ephemeral] });
      return;
    }

    if (interaction.isModalSubmit() && customId === "modal_rem_user") {
      const targetId = interaction.fields.getTextInputValue("user_id").trim();
      await interaction.channel.permissionOverwrites.delete(targetId).catch(() => {});
      await interaction.reply({ content: EMOJI_SUCESSO + " Usuário removido do ticket!", flags: [MessageFlags.Ephemeral] });
      return;
    }

    if (interaction.isModalSubmit() && customId === "modal_notify_owner") {
      const tickets = loadTickets();
      const ownerId = tickets[interaction.channel.id];
      if (!ownerId) {
        return interaction.reply({ content: "❌ Erro ao localizar o criador deste ticket.", flags: [MessageFlags.Ephemeral] });
      }
      const owner = await client.users.fetch(ownerId).catch(() => null);
      if (!owner) {
        return interaction.reply({ content: "❌ Usuário não encontrado.", flags: [MessageFlags.Ephemeral] });
      }

      const msg = interaction.fields.getTextInputValue("feedback");
      const embedDM = new EmbedBuilder()
        .setColor(COR_EMBED)
        .setTitle("🔔 Notificação de Suporte")
        .setDescription("O suporte de **" + interaction.guild.name + "** enviou uma atualização:\n\n" + msg);

      const sent = await owner.send({ embeds: [embedDM] }).catch(() => null);
      if (!sent) {
        return interaction.reply({ content: "❌ O usuário está com a DM fechada.", flags: [MessageFlags.Ephemeral] });
      }
      await interaction.reply({ content: EMOJI_SUCESSO + " Notificação enviada com sucesso na DM do usuário!", flags: [MessageFlags.Ephemeral] });
      return;
    }

    // 5. Botão Fechar Ticket
    if (interaction.isButton() && customId === "close_btn") {
      const tickets = loadTickets();
      const ownerId = tickets[interaction.channel.id];
      const isOwner = interaction.user.id === ownerId;
      const staff = isStaff(interaction.member);

      if (!staff && !isOwner) {
        return interaction.reply({ content: "❌ Apenas a Staff ou o criador do ticket pode fechá-lo!", flags: [MessageFlags.Ephemeral] });
      }

      removeTicket(interaction.channel.id);
      await interaction.reply({ content: "🔒 **Este ticket será deletado em 5 segundos...**" });
      setTimeout(() => {
        interaction.channel && interaction.channel.delete().catch(() => {});
      }, 5000);
      return;
    }
  } catch (err) {
    console.error("Erro na interação do Bot Ticket:", err);
  }
});

client.login(process.env.DISCORD_TOKEN || process.env.TOKEN);
