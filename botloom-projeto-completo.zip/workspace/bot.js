const fs = require("fs");
const path = require("path");
const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");

// ==========================================================================================
// ⚡ BOT MIDLDLEMAN & VOUCH SYSTEM (COMPLETO / INTEGRADO)
// Contém o gerador do VouchCard, PerfilCard, Comandos Slash (/vouch, /ranking, /perfil...)
// e sistema de intermediação de trocas 24/7.
// ==========================================================================================

/* ==========================================================================================
 * [SEÇÃO 1] GERADOR DE CARTÕES - VOUCH CARD (VOUCHCARD)
 * Permite modificar livremente o design, proporções, textos, selos e cores do vouch.
 * ========================================================================================== */




/* ------------------------------------------------------------------ *
 *  CARREGAMENTO E REGISTRO DE FONTES CUSTOMIZADAS (Poppins + NotoCJK)
 * ------------------------------------------------------------------ */
const FONT_FAMILY = "Poppins";

function getActiveFontFamilies() {
    try {
        if (GlobalFonts && Array.isArray(GlobalFonts.families)) {
            return GlobalFonts.families.map(f => typeof f === "string" ? f : (f && f.family ? f.family : String(f)));
        }
        if (GlobalFonts && typeof GlobalFonts.getFamilies === "function") {
            const raw = GlobalFonts.getFamilies();
            const str = Buffer.isBuffer(raw) ? raw.toString("utf8") : String(raw);
            const parsed = JSON.parse(str);
            if (Array.isArray(parsed)) {
                return parsed.map(f => typeof f === "string" ? f : (f && f.family ? f.family : String(f)));
            }
        }
        if (GlobalFonts && typeof GlobalFonts.has === "function" && GlobalFonts.has("Poppins")) {
            return ["Poppins"];
        }
    } catch (e) {
        console.warn("[vouchCard] Aviso ao obter famílias de fontes:", e.message);
    }
    return [];
}

function registerAllFonts() {
    const searchDirs = [
        path.join(__dirname, "fonts"),
        path.join(process.cwd(), "fonts"),
        path.join(__dirname, "..", "fonts"),
        path.join(process.cwd(), "dist", "fonts")
    ];

    const registeredFiles = new Set();
    let poppinsCount = 0;
    let notoCount = 0;

    console.log("=================================================");
    console.log("[vouchCard LOG] Iniciando verificação e registro de fontes...");

    for (const fontsDir of searchDirs) {
        console.log(`[vouchCard LOG] Verificando diretório de fontes: ${fontsDir} (existe: ${fs.existsSync(fontsDir)})`);
        if (!fs.existsSync(fontsDir)) continue;
        try {
            const files = fs.readdirSync(fontsDir);
            for (const file of files) {
                if (registeredFiles.has(file)) continue;
                const filePath = path.join(fontsDir, file);
                const exists = fs.existsSync(filePath);
                console.log(`[vouchCard LOG] Arquivo de fonte em disk: ${file} -> existe: ${exists}`);
                if (!exists) continue;

                const lower = file.toLowerCase();
                if (lower.startsWith("poppins") && (lower.endsWith(".ttf") || lower.endsWith(".otf"))) {
                    try {
                        const fontKey = GlobalFonts.registerFromPath(filePath, FONT_FAMILY);
                        registeredFiles.add(file);
                        poppinsCount++;
                        console.log(`[vouchCard LOG] Sucesso ao registrar ${file} como '${FONT_FAMILY}' (Key: ${fontKey ? "OK" : "null"})`);
                    } catch (e) {
                        console.error(`[vouchCard ERRO] Falha ao registrar ${file}:`, e.message);
                    }
                } else if ((lower.includes("noto") || lower.includes("cjk")) && (lower.endsWith(".ttf") || lower.endsWith(".otf"))) {
                    try {
                        const fontKey = GlobalFonts.registerFromPath(filePath, "NotoCJK");
                        registeredFiles.add(file);
                        notoCount++;
                        console.log(`[vouchCard LOG] Sucesso ao registrar ${file} como 'NotoCJK' (Key: ${fontKey ? "OK" : "null"})`);
                    } catch (e) {
                        console.error(`[vouchCard ERRO] Falha ao registrar ${file}:`, e.message);
                    }
                }
            }
        } catch (e) {
            console.error("[vouchCard ERRO] Erro ao ler pasta de fontes:", e.message);
        }
    }

    const activeFamilies = getActiveFontFamilies();
    console.log(`[vouchCard LOG] Resumo do Registro: Poppins=${poppinsCount}, NotoCJK=${notoCount}`);
    console.log(`[vouchCard LOG] Famílias ativas no GlobalFonts: [${activeFamilies.join(", ")}]`);
    console.log("=================================================");

    return { poppinsCount, notoCount, activeFamilies };
}

const fontRegStatus = registerAllFonts();

const FONT_STACK = `'${FONT_FAMILY}', 'NotoCJK', 'DejaVu Sans', 'Noto Sans', 'Liberation Sans', sans-serif`;
// Stack específico para o nome de destaque (staff): pede Inter/SF Pro Display
// primeiro; cai pros sans-serif do sistema quando essas não estão instaladas.
const NAME_FONT_STACK = `'Inter', 'SF Pro Display', 'DejaVu Sans', 'Liberation Sans', 'Noto Sans', sans-serif`;

function getCardConfig() {
    try {
        const configPath = path.join(process.cwd(), "cardConfig.json");
        if (fs.existsSync(configPath)) {
            return JSON.parse(fs.readFileSync(configPath, "utf8"));
        }
    } catch (e) {}
    return {};
}

/* ------------------------------------------------------------------ *
 *  PALETAS DE TEMAS METÁLICOS DIVERSIFICADOS
 * ------------------------------------------------------------------ */
const THEMES = {
    bicolor_gold: {
        BG: "#050505",
        GOLD_HIGH: "#FFF3C4",
        GOLD_1: "#FFD34E",
        GOLD_2: "#F5B72E",
        GOLD_3: "#E09A1A",
        GOLD_4: "#A66B0A",
        GOLD_SHADOW: "rgba(245,183,46,0.65)",
        GOLD_SOLID: "#F0B92E",
        TEXT_MUTED: "#c9ac6a",
        DARK_STAR: "#2a2412"
    },
    platinum_silver: {
        BG: "#05070A",
        GOLD_HIGH: "#F1F5F9",
        GOLD_1: "#CBD5E1",
        GOLD_2: "#94A3B8",
        GOLD_3: "#64748B",
        GOLD_4: "#334155",
        GOLD_SHADOW: "rgba(226,232,240,0.45)",
        GOLD_SOLID: "#CBD5E1",
        TEXT_MUTED: "#94a3b8",
        DARK_STAR: "#1e293b"
    },
    emerald_gold: {
        BG: "#040D0A",
        GOLD_HIGH: "#A7F3D0",
        GOLD_1: "#6EE7B7",
        GOLD_2: "#34D399",
        GOLD_3: "#10B981",
        GOLD_4: "#047857",
        GOLD_SHADOW: "rgba(52,211,153,0.45)",
        GOLD_SOLID: "#34D399",
        TEXT_MUTED: "#6ee7b7",
        DARK_STAR: "#064e3b"
    },
    ruby_gold: {
        BG: "#0D0406",
        GOLD_HIGH: "#FECDD3",
        GOLD_1: "#FDA4AF",
        GOLD_2: "#FB7185",
        GOLD_3: "#F43F5E",
        GOLD_4: "#BE123C",
        GOLD_SHADOW: "rgba(251,113,133,0.45)",
        GOLD_SOLID: "#FB7185",
        TEXT_MUTED: "#fda4af",
        DARK_STAR: "#4c0519"
    },
    diamond_blue: {
        BG: "#040914",
        GOLD_HIGH: "#BAE6FD",
        GOLD_1: "#7DD3FC",
        GOLD_2: "#38BDF8",
        GOLD_3: "#0EA5E9",
        GOLD_4: "#0369A1",
        GOLD_SHADOW: "rgba(56,189,248,0.45)",
        GOLD_SOLID: "#38BDF8",
        TEXT_MUTED: "#7dd3fc",
        DARK_STAR: "#0c4a6e"
    }
};

function getPalette(themeName) {
    if (!themeName) return THEMES.bicolor_gold;
    const t = String(themeName).toLowerCase();
    if (THEMES[t]) return THEMES[t];
    if (t.includes("silver") || t.includes("prata") || t.includes("platinum")) return THEMES.platinum_silver;
    if (t.includes("emerald") || t.includes("esmeralda") || t.includes("green") || t.includes("verde")) return THEMES.emerald_gold;
    if (t.includes("ruby") || t.includes("rubi") || t.includes("red") || t.includes("vermelho")) return THEMES.ruby_gold;
    if (t.includes("blue") || t.includes("azul") || t.includes("diamond") || t.includes("diamante")) return THEMES.diamond_blue;
    return THEMES.bicolor_gold;
}

/* ------------------------------------------------------------------ *
 *  CRIAÇÃO PRECISA DE GRADIENTE E UTILITÁRIOS DE DESENHO
 * ------------------------------------------------------------------ */

function criarGradienteOuro(ctx, y, altura, palette, direcao = "vertical") {
    const p = palette || THEMES.bicolor_gold;
    const gHigh = p.GOLD_HIGH || "#FFE885";
    const g1 = p.GOLD_1 || "#F3C84B";
    const g2 = p.GOLD_2 || "#E5A93C";
    const g3 = p.GOLD_3 || "#C48A22";
    const g4 = p.GOLD_4 || "#80520D";

    if (direcao === "horizontal") {
        const grad = ctx.createLinearGradient(y, 0, y + altura, 0);
        grad.addColorStop(0.00, gHigh);
        grad.addColorStop(0.25, g1);
        grad.addColorStop(0.55, g2);
        grad.addColorStop(0.80, g3);
        grad.addColorStop(1.00, g4);
        return grad;
    }

    // Para textos: y é a linha de base (baseline).
    const yTop = y - Math.max(altura * 0.78, 1);
    const yBottom = y + Math.max(altura * 0.12, 1);
    const grad = ctx.createLinearGradient(0, yTop, 0, yBottom);
    grad.addColorStop(0.00, gHigh);
    grad.addColorStop(0.25, g1);
    grad.addColorStop(0.55, g2);
    grad.addColorStop(0.80, g3);
    grad.addColorStop(1.00, g4);
    return grad;
}

/**
 * Desenha texto com efeito de gradiente metálico (5 tons, de cima pra baixo).
 *
 * Técnica: em vez de usar fillStyle=gradiente (que causava texto invisível)
 * ou globalCompositeOperation (que não é suportado nesse ambiente e cobria
 * tudo com retângulo sólido), usamos ctx.clip() com faixas horizontais —
 * isso É suportado (é a mesma técnica usada nos avatares circulares, que
 * sempre recortaram certinho). O texto é desenhado 5 vezes, cada vez
 * recortado numa faixa horizontal diferente com uma cor sólida diferente,
 * criando o efeito de degradê sem depender de gradiente nativo em texto.
 */
function fillTextGradient(ctx, text, x, y, fontSizePx, palette, align = "left", customStops = null) {
    if (!text) return;
    const p = palette || THEMES.bicolor_gold;

    // Mais pontos de cor = transição mais suave/realista (menos "faixado").
    // customStops permite um degradê mais simples (ex: 2 tons) para textos específicos.
    const stopColors = customStops || [
        p.GOLD_HIGH || "#FFE885",
        p.GOLD_1 || "#F3C84B",
        p.GOLD_1 || "#F3C84B",
        p.GOLD_2 || "#E5A93C",
        p.GOLD_2 || "#E5A93C",
        p.GOLD_3 || "#C48A22",
        p.GOLD_3 || "#C48A22",
        p.GOLD_4 || "#80520D"
    ];

    ctx.save();
    ctx.textAlign = align;

    let width;
    try {
        const metrics = ctx.measureText(text);
        width = metrics.width || (fontSizePx * text.length * 0.55);
    } catch (e) {
        width = fontSizePx * text.length * 0.55;
    }

    let rectX;
    if (align === "center") rectX = x - width / 2;
    else if (align === "right") rectX = x - width;
    else rectX = x;

    const ascent = fontSizePx * 0.85;
    const descent = fontSizePx * 0.28;
    const top = y - ascent - 2;
    const totalH = ascent + descent + 4;
    const bandH = totalH / stopColors.length;

    for (let i = 0; i < stopColors.length; i++) {
        ctx.save();
        ctx.beginPath();
        ctx.rect(rectX - 6, top + i * bandH - 0.5, width + 12, bandH + 1);
        ctx.clip();
        ctx.fillStyle = stopColors[i];
        ctx.fillText(text, x, y);
        ctx.restore();
    }

    ctx.restore();
}

function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
}

/**
 * Contorno dourado com brilho reforçado. Ajustado para ficar como UMA linha
 * única, nítida e bem dourada (usa o degradê metálico completo em vez de
 * cor sólida chapada, com um blur bem mais leve para não borrar o traço).
 */
function strokeGlowRoundRect(ctx, x, y, w, h, r, palette, lineWidth = 2) {
    // Camada 1: brilho suave e largo por trás da linha (halo dourado)
    ctx.save();
    ctx.shadowColor = palette.GOLD_SHADOW;
    ctx.shadowBlur = 16;
    ctx.strokeStyle = palette.GOLD_SOLID;
    ctx.lineWidth = lineWidth + 2;
    roundRect(ctx, x, y, w, h, r);
    ctx.stroke();
    ctx.restore();

    // Camada 2: linha fina e nítida por cima, em degradê metálico completo
    ctx.save();
    const grad = ctx.createLinearGradient(x, y, x, y + h);
    grad.addColorStop(0.00, palette.GOLD_HIGH || "#FFE885");
    grad.addColorStop(0.30, palette.GOLD_1 || "#F3C84B");
    grad.addColorStop(0.60, palette.GOLD_2 || "#E5A93C");
    grad.addColorStop(0.85, palette.GOLD_3 || "#C48A22");
    grad.addColorStop(1.00, palette.GOLD_4 || "#80520D");
    ctx.strokeStyle = grad;
    ctx.lineWidth = lineWidth;
    roundRect(ctx, x, y, w, h, r);
    ctx.stroke();
    ctx.restore();
}

function strokeGlowCircle(ctx, cx, cy, r, palette, lineWidth = 3) {
    ctx.save();
    ctx.shadowColor = palette.GOLD_SHADOW;
    ctx.shadowBlur = 14;
    ctx.strokeStyle = palette.GOLD_2;
    ctx.lineWidth = lineWidth;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();

    ctx.save();
    const grad = ctx.createLinearGradient(cx, cy - r, cx, cy + r);
    grad.addColorStop(0, palette.GOLD_HIGH);
    grad.addColorStop(0.5, palette.GOLD_2);
    grad.addColorStop(1, palette.GOLD_4);
    ctx.strokeStyle = grad;
    ctx.lineWidth = lineWidth;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
}

function strokeGlowLine(ctx, x1, y1, x2, y2, palette, lineWidth = 1.5) {
    ctx.save();
    ctx.shadowColor = palette.GOLD_SHADOW;
    ctx.shadowBlur = 4;
    ctx.strokeStyle = palette.GOLD_SOLID;
    ctx.lineWidth = lineWidth;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
    ctx.restore();
}

/**
 * Linha dourada "quebrada" (efeito rachadura/raio), usada como decoração
 * discreta nos cantos do cartão. `points` é uma lista de [x, y].
 */
function drawCrackLine(ctx, points, palette, width = 2) {
    ctx.save();
    ctx.shadowColor = palette.GOLD_SHADOW;
    ctx.shadowBlur = 3;
    ctx.strokeStyle = palette.GOLD_SOLID;
    ctx.lineWidth = width;
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(points[0][0], points[0][1]);
    for (let i = 1; i < points.length; i++) ctx.lineTo(points[i][0], points[i][1]);
    ctx.stroke();
    ctx.restore();
}

function desenharRachadurasCanto(ctx, W, H, palette) {
    // Canto superior direito
    drawCrackLine(ctx, [[W - 230, 10], [W - 170, 55], [W - 190, 60], [W - 120, 110], [W - 140, 115], [W - 70, 160]], palette, 2);
    drawCrackLine(ctx, [[W - 110, 15], [W - 80, 45], [W - 95, 50], [W - 40, 90]], palette, 2);
    // Canto inferior esquerdo
    drawCrackLine(ctx, [[20, H - 80], [80, H - 50], [60, H - 45], [120, H - 15]], palette, 2);
    drawCrackLine(ctx, [[15, H - 130], [55, H - 105], [40, H - 100], [90, H - 70]], palette, 2);
}

/**
 * Estrela dourada. Ativa: preenchimento em gradiente metálico com brilho.
 * Inativa: fundo escuro, mas com contorno dourado (em vez de ficar apagada),
 * para que o conjunto de estrelas sempre "leia" como dourado.
 */
function drawStar(ctx, cx, cy, outerR, ativa, palette, innerRatio = 0.45) {
    const p = palette || THEMES.bicolor_gold;
    const innerR = outerR * innerRatio;
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
        const r = i % 2 === 0 ? outerR : innerR;
        const angle = (Math.PI / 5) * i - Math.PI / 2;
        const x = cx + r * Math.cos(angle);
        const y = cy + r * Math.sin(angle);
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.closePath();
    if (ativa) {
        // Cor sólida e saturada, sem depender de gradiente + sombra: no ambiente
        // de canvas usado aqui, gradiente + shadowBlur em formas pequenas como a
        // estrela renderiza esbranquiçado. Cor sólida garante o dourado visível.
        ctx.save();
        ctx.fillStyle = p.GOLD_SOLID || p.GOLD_2 || "#E5A93C";
        ctx.fill();
        ctx.lineWidth = Math.max(1, outerR * 0.08);
        ctx.strokeStyle = p.GOLD_4 || "#80520D";
        ctx.stroke();
        ctx.restore();
    } else {
        ctx.save();
        ctx.fillStyle = p.DARK_STAR || "#2a2412";
        ctx.fill();
        ctx.lineWidth = Math.max(1, outerR * 0.08);
        ctx.strokeStyle = p.GOLD_4 || "#80520D";
        ctx.stroke();
        ctx.restore();
    }
}

function drawCheckBadge(ctx, cx, cy, r, palette) {
    ctx.save();
    ctx.shadowColor = palette.GOLD_SHADOW;
    ctx.shadowBlur = 4;
    const grad = ctx.createLinearGradient(cx, cy - r, cx, cy + r);
    grad.addColorStop(0, palette.GOLD_1);
    grad.addColorStop(1, palette.GOLD_4);
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.fill();
    ctx.restore();

    ctx.beginPath();
    ctx.moveTo(cx - r * 0.5, cy);
    ctx.lineTo(cx - r * 0.1, cy + r * 0.4);
    ctx.lineTo(cx + r * 0.55, cy - r * 0.4);
    ctx.lineWidth = r * 0.3;
    ctx.strokeStyle = "#1a1206";
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke();
}

function drawCheckOutlineBadge(ctx, cx, cy, r, palette) {
    ctx.save();
    ctx.shadowColor = palette.GOLD_SHADOW;
    ctx.shadowBlur = 4;
    const grad = ctx.createLinearGradient(cx, cy - r, cx, cy + r);
    grad.addColorStop(0, palette.GOLD_1);
    grad.addColorStop(1, palette.GOLD_4);
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.lineWidth = r * 0.16;
    ctx.strokeStyle = grad;
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.5, cy);
    ctx.lineTo(cx - r * 0.1, cy + r * 0.4);
    ctx.lineTo(cx + r * 0.55, cy - r * 0.4);
    ctx.lineWidth = r * 0.24;
    ctx.strokeStyle = grad;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke();
    ctx.restore();
}

function drawCalendar(ctx, cx, cy, size, palette) {
    const w = size * 1.5, h = size * 1.3;
    ctx.strokeStyle = palette.GOLD_SOLID;
    ctx.lineWidth = size * 0.12;
    roundRect(ctx, cx - w / 2, cy - h / 2, w, h, size * 0.18);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx - w / 2, cy - h * 0.15);
    ctx.lineTo(cx + w / 2, cy - h * 0.15);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx - w * 0.25, cy - h / 2 - size * 0.12);
    ctx.lineTo(cx - w * 0.25, cy - h / 2 + size * 0.12);
    ctx.moveTo(cx + w * 0.25, cy - h / 2 - size * 0.12);
    ctx.lineTo(cx + w * 0.25, cy - h / 2 + size * 0.12);
    ctx.stroke();
}

function drawList(ctx, cx, cy, size, cor) {
    const w = size * 1.3, h = size * 1.5;
    ctx.strokeStyle = cor;
    ctx.lineWidth = size * 0.1;
    roundRect(ctx, cx - w / 2, cy - h / 2, w, h, size * 0.15);
    ctx.stroke();
    for (let i = 0; i < 3; i++) {
        const ly = cy - h / 2 + h * 0.28 + i * (h * 0.22);
        ctx.beginPath();
        ctx.moveTo(cx - w / 2 + w * 0.18, ly);
        ctx.lineTo(cx + w / 2 - w * 0.18, ly);
        ctx.stroke();
    }
}

function drawCopyIcon(ctx, cx, cy, size, palette) {
    ctx.strokeStyle = palette.GOLD_SOLID;
    ctx.lineWidth = size * 0.12;
    roundRect(ctx, cx - size * 0.1, cy - size * 0.5, size * 0.75, size * 0.9, size * 0.12);
    ctx.stroke();
    roundRect(ctx, cx - size * 0.5, cy - size * 0.25, size * 0.75, size * 0.9, size * 0.12);
    ctx.fillStyle = palette.BG;
    ctx.fill();
    ctx.stroke();
}

function desenharPontosFundo(ctx, W, H, palette) {
    for (let i = 0; i < 90; i++) {
        const r = Math.random() * 2.6 + 1.2;
        ctx.save();
        ctx.globalAlpha = Math.random() * 0.35 + 0.28;
        ctx.shadowColor = "#C9A44A";
        ctx.shadowBlur = r * 2.5;
        ctx.beginPath();
        ctx.arc(Math.random() * W, Math.random() * H, r, 0, Math.PI * 2);
        ctx.fillStyle = "#C9A44A";
        ctx.fill();
        ctx.restore();
    }
}

/**
 * Reduz gradualmente o tamanho da fonte até que o texto caiba dentro de
 * maxWidth, mantendo um tamanho mínimo legível. Mantida disponível para uso
 * futuro (ex: em outros campos), mas não é mais aplicada ao valor
 * intermediado — que agora usa fonte sempre fixa, igual à referência.
 */
function ajustarTamanhoFonteParaLargura(ctx, text, fontWeight, fontSizeInicial, maxWidth, fontSizeMinimo = 40) {
    let fontSize = fontSizeInicial;
    ctx.font = `${fontWeight} ${fontSize}px ${FONT_STACK}`;
    let largura = ctx.measureText(text).width;

    while (largura > maxWidth && fontSize > fontSizeMinimo) {
        fontSize -= 2;
        ctx.font = `${fontWeight} ${fontSize}px ${FONT_STACK}`;
        largura = ctx.measureText(text).width;
    }

    return fontSize;
}

async function desenharAvatarCirculo(ctx, cx, cy, r, urlOuLetra, palette) {
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();

    let desenhouImagem = false;
    if (urlOuLetra && String(urlOuLetra).startsWith("http")) {
        try {
            const img = await loadImage(urlOuLetra);
            ctx.drawImage(img, cx - r, cy - r, r * 2, r * 2);
            desenhouImagem = true;
        } catch (e) { /* fallback */ }
    }
    if (!desenhouImagem) {
        ctx.fillStyle = "#161310";
        ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
        ctx.restore();
        ctx.save();
        ctx.fillStyle = criarGradienteOuro(ctx, cy, r * 1.6, palette);
        ctx.font = `bold ${Math.round(r)}px ${FONT_STACK}`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        const letra = (typeof urlOuLetra === "string" && urlOuLetra.length) ? urlOuLetra[0].toUpperCase() : "?";
        ctx.fillText(letra, cx, cy + 4);
        ctx.textAlign = "left";
        ctx.textBaseline = "alphabetic";
        ctx.restore();
        return;
    }
    ctx.restore();
}

/**
 * Gera o cartão de vouch (Buffer PNG) — suporte a temas, Poppins e NotoCJK
 * para caracteres internacionais. Posições e tamanhos calibrados para
 * baterem com a referência pixel a pixel (1729x910): título, ID da
 * transação, caixa do código, valor intermediado (fixo, alinhado à
 * direita), avatar do staff com selo/estrelas, e rodapé com
 * comprador/vendedor/data/marca.
 */
async function gerarCartaoVouch(opts = {}) {
    // Verificação estrita de segurança de fonte
    const loadedFamilies = getActiveFontFamilies();
    const poppinsLoaded = (fontRegStatus && fontRegStatus.poppinsCount > 0) ||
        loadedFamilies.includes("Poppins") ||
        (GlobalFonts && typeof GlobalFonts.has === "function" && GlobalFonts.has("Poppins"));

    if (!poppinsLoaded) {
        const errMsg = `[vouchCard ERRO CRÍTICO] A fonte 'Poppins' não foi carregada no GlobalFonts! Famílias ativas: [${loadedFamilies.join(", ")}]. ` +
            `Certifique-se de que Poppins-Bold.ttf e Poppins-Regular.ttf estejam presentes na pasta ./fonts/. ` +
            `Geração de card interrompida para evitar texto invisível.`;
        console.error(errMsg);
        throw new Error(errMsg);
    }

    const globalConfig = getCardConfig().vouchOptions || {};
    const vOpts = Object.assign({}, globalConfig, opts);

    const themeKey = vOpts.theme || vOpts.vouchTheme || "bicolor_gold";
    const palette = getPalette(themeKey);

    const titleText = vOpts.title || vOpts.vouchTitle || "VOUCH DE INTERMEDIAÇÃO";
    const seloTexto = vOpts.seloTexto || vOpts.vouchSeloTexto || "INTERMEDIADOR VERIFICADO";
    // Texto do rodapé (antes "NEUX MEDIAÇÃO" / "SPEED MEDIAÇÃO") — agora "NEUX MIDDLE" por padrão.
    // Texto fixo do rodapé — sempre "NEUX MIDDLE", independente de qualquer
    // opts.brandFooter/cardConfig.json que tente sobrescrever (era isso que
    // fazia aparecer "NEUX MEDIAÇÃO" mesmo depois de trocado).
    const brandFooter = vOpts.brandFooter || "NEUX MEDIAÇÃO";
    const showStars = vOpts.showStars !== undefined ? vOpts.showStars : (vOpts.vouchShowStars !== undefined ? vOpts.vouchShowStars : true);

    const nameFontSize = vOpts.nameFontSize || vOpts.vouchNameFontSize || 56;
    // Título principal — usado também como referência de tamanho para o
    // valor intermediado (mesmo tamanho do título "VOUCH DE INTERMEDIAÇÃO").
    const titleFontSize = vOpts.titleFontSize || vOpts.vouchTitleFontSize || 62;
    // Valor intermediado: agora do MESMO tamanho do título por padrão
    // (antes era 260px, bem maior). Só encolhe automaticamente se o valor
    // for muito comprido pra largura disponível.
    const valorFontSize = vOpts.valorFontSize || vOpts.vouchValorFontSize || Math.round(titleFontSize * 1.8);
    // Label "VALOR INTERMEDIADO" também bem maior que antes (era 22px).
    const valorLabelFontSize = vOpts.valorLabelFontSize || vOpts.vouchValorLabelFontSize || 34;
    const interFontSize = vOpts.interFontSize || vOpts.vouchInterFontSize || 24;
    const codeFontSize = vOpts.codeFontSize || vOpts.vouchCodeFontSize || 58;
    const avatarZoomR = Math.round(vOpts.avatarZoom || vOpts.vouchAvatarZoom || 133);

    const transacaoId = vOpts.transacaoId || "MM-1785439368477803";
    const vouchCodigo = vOpts.vouchCodigo || "#01645";
    const valorNum = typeof vOpts.valor === "number" ? vOpts.valor : (parseFloat(String(vOpts.valor || "1499.90").replace(",", ".")) || 1499.90);
    const staffNome = vOpts.staffNome || "Seu nome ...";
    const staffAvatarURL = vOpts.staffAvatarURL || "";
    const staffNota = typeof vOpts.staffNota === "number" ? vOpts.staffNota : 5.0;
    const staffIntermediacoes = vOpts.staffIntermediacoes !== undefined ? vOpts.staffIntermediacoes : 128;
    const compradorNome = vOpts.compradorNome || "Neeux MM Services (2)";
    const compradorAvatarURL = vOpts.compradorAvatarURL || "";
    const vendedorNome = vOpts.vendedorNome || "Neeux MM Services (2)";
    const vendedorAvatarURL = vOpts.vendedorAvatarURL || "";
    const dataStr = vOpts.data || "30/07/2026";

    const W = 1729, H = 910;
    const canvas = createCanvas(W, H);
    const ctx = canvas.getContext("2d");

    // Fundo "luxury black & gold": gradiente radial de vinheta (centro
    // ligeiramente mais claro #070707, bordas em preto absoluto #000000)
    // + um único glow dourado desfocado e discreto no centro + partículas.
    const vignette = ctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, Math.max(W, H) * 0.8);
    vignette.addColorStop(0, "#070707");
    vignette.addColorStop(1, "#000000");
    ctx.fillStyle = vignette;
    ctx.fillRect(0, 0, W, H);

    // Glow dourado único, desfocado e contido no centro (não cobre o cartão
    // inteiro, só dá um brilho ambiente sutil atrás do conteúdo central)
    ctx.save();
    ctx.filter = "blur(100px)";
    ctx.globalAlpha = 0.38;
    ctx.fillStyle = "#8F6A1D";
    ctx.beginPath();
    ctx.ellipse(W * 0.5, H * 0.42, W * 0.26, H * 0.32, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    desenharPontosFundo(ctx, W, H, palette);

    // Borda/Moldura externa do cartão — fina, igual à referência, mas com
    // bastante brilho/saturação pra ficar bem visível mesmo sendo fina.
    strokeGlowRoundRect(ctx, 14, 14, W - 28, H - 28, 12, palette, 2);

    // 1. TÍTULO PRINCIPAL ("VOUCH DE INTERMEDIAÇÃO") — bem maior que antes
    ctx.font = `800 ${titleFontSize}px ${FONT_STACK}`;
    ctx.textAlign = "left";
    fillTextGradient(ctx, titleText, 65, 118, titleFontSize, palette, "left");

    // Linha dourada sob o título
    const titleUnderlineW = Math.max(157, ctx.measureText(titleText).width * 0.42);
    strokeGlowLine(ctx, 89, 168, 89 + titleUnderlineW, 168, palette, 2.5);

    // 2. ID DA TRANSAÇÃO (Canto Superior Direito)
    const rightColX = 1179;
    ctx.textAlign = "left";
    ctx.font = `600 22px ${FONT_STACK}`;
    fillTextGradient(ctx, "ID DA TRANSAÇÃO", rightColX, 82, 22, palette, "left");

    ctx.fillStyle = "#FFFFFF";
    ctx.font = `500 26px ${FONT_STACK}`;
    ctx.fillText(transacaoId, rightColX, 122);
    const idValW = ctx.measureText(transacaoId).width;
    drawCopyIcon(ctx, rightColX + idValW + 30, 108, 24, palette);

    // 3. CÓDIGO DO VOUCH (Caixa Central Direita — posição original, fixa)
    const boxW = 530, boxH = 94;
    const boxX = 1112, boxY = 215;
    const labelCx = boxX + boxW / 2;

    // Label "CÓDIGO DO VOUCH" em dourado metálico
    ctx.font = `600 20px ${FONT_STACK}`;
    fillTextGradient(ctx, "CÓDIGO DO VOUCH", labelCx, 210, 20, palette, "center");
    const labelW = ctx.measureText("CÓDIGO DO VOUCH").width;
    strokeGlowLine(ctx, boxX, 203, labelCx - labelW / 2 - 20, 203, palette, 1.5);
    strokeGlowLine(ctx, labelCx + labelW / 2 + 20, 203, boxX + boxW, 203, palette, 1.5);

    strokeGlowRoundRect(ctx, boxX, boxY, boxW, boxH, 12, palette, 2);
    ctx.font = `800 ${codeFontSize}px ${FONT_STACK}`;
    fillTextGradient(ctx, vouchCodigo, labelCx, boxY + 64, codeFontSize, palette, "center");

    // 4. VALOR INTERMEDIADO — movido mais pra cima (logo abaixo da caixa
    // "CÓDIGO DO VOUCH", com menos espaço vazio). "R$" e o número no MESMO
    // tamanho de fonte (como era originalmente), maior que antes — só
    // encolhendo automaticamente se o valor for muito comprido pra largura
    // do cartão.
    const valorMaxWidth = 640;
    const valorPrefixStr = "R$ ";
    const valorNumeroStr = valorNum.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
    const valorFmt = `${valorPrefixStr}${valorNumeroStr}`;

    // Tamanho base maior que antes (era titleFontSize * 1.8 ≈ 112px).
    const valorFontSizeBase = Math.round(titleFontSize * 2.0);
    const valorFontSizeAjustado = ajustarTamanhoFonteParaLargura(ctx, valorFmt, 800, valorFontSizeBase, valorMaxWidth, 40);
    // "R$" no mesmo tamanho do número (igual ao comportamento original)
    const valorPrefixFontSize = valorFontSizeAjustado;

    ctx.font = `800 ${valorFontSizeAjustado}px ${FONT_STACK}`;
    const valorNumeroW = ctx.measureText(valorNumeroStr).width;
    const valorPrefixW = ctx.measureText(valorPrefixStr).width;
    const valorTotalW = valorNumeroW + valorPrefixW;

    const labelValorY = 388;
    const valorY = labelValorY + valorFontSizeAjustado + 40;

    ctx.font = `700 ${valorLabelFontSize}px ${FONT_STACK}`;
    fillTextGradient(ctx, "VALOR INTERMEDIADO", labelCx, labelValorY, valorLabelFontSize, palette, "center");

    // Degradê dourado de apenas 2 tons (claro em cima, escuro embaixo) para o valor
    // Gradiente fixo pedido pelo usuário: claro no topo, dourado escuro na base
    const valorStops = [
        "#F7E7B8", "#F7E7B8",
        "#D4B97A", "#D4B97A", "#D4B97A",
        "#B88926", "#B88926", "#B88926"
    ];

    const valorStartX = labelCx - valorTotalW / 2;

    ctx.font = `800 ${valorPrefixFontSize}px ${FONT_STACK}`;
    fillTextGradient(ctx, valorPrefixStr, valorStartX, valorY, valorPrefixFontSize, palette, "left", valorStops);

    ctx.font = `800 ${valorFontSizeAjustado}px ${FONT_STACK}`;
    fillTextGradient(ctx, valorNumeroStr, valorStartX + valorPrefixW, valorY, valorFontSizeAjustado, palette, "left", valorStops);

    // 5. AVATAR + INFORMAÇÕES DO STAFF / USER (Esquerda)
    const avX = 222, avY = 350, avR = avatarZoomR;
    await desenharAvatarCirculo(ctx, avX, avY, avR, staffAvatarURL || staffNome, palette);
    strokeGlowCircle(ctx, avX, avY, avR + 3, palette, 5);

    const infoX = avX + avR + 58;
    ctx.fillStyle = "#F5F5F5";
    ctx.font = `600 ${nameFontSize}px ${NAME_FONT_STACK}`;
    ctx.fillText(staffNome, infoX, 299);

    // Selo "INTERMEDIADOR VERIFICADO"
    ctx.font = `600 22px ${FONT_STACK}`;
    const seloTextW = ctx.measureText(seloTexto).width;
    const seloPillW = Math.max(392, seloTextW + 80), seloPillH = 47, seloPillY = 341;
    strokeGlowRoundRect(ctx, infoX, seloPillY, seloPillW, seloPillH, 12, palette, 2);
    drawCheckOutlineBadge(ctx, infoX + 28, seloPillY + seloPillH / 2, 13, palette);
    fillTextGradient(ctx, seloTexto, infoX + 50, seloPillY + 31, 22, palette, "left");

    // Estrelas + Nota
    let nextY = 436;
    if (showStars) {
        const notaArred = Math.max(0, Math.min(5, Math.round(staffNota)));
        let starX = infoX;
        const starY = 436, starR = 15;
        for (let i = 0; i < 5; i++) {
            drawStar(ctx, starX + starR, starY, starR, i < notaArred, palette);
            starX += starR * 2 + 16;
        }
        fillTextGradient(ctx, staffNota.toFixed(1), starX + 13, 448, 28, palette, "left");
        nextY = 503;
    }

    // Intermediações
    drawList(ctx, infoX + 14, nextY, 18, palette.TEXT_MUTED);
    ctx.fillStyle = palette.TEXT_MUTED;
    ctx.font = `500 ${interFontSize}px ${FONT_STACK}`;
    ctx.fillText(`${staffIntermediacoes} INTERMEDIAÇÕES`, infoX + 36, nextY + 9);

    // 6. BLOCO RODAPÉ (Comprador / Vendedor / Data / Brand)
    // -----------------------------------------------------------------
    // Sem caixa ao redor e sem divisórias "|" verticais — só uma linha
    // dourada fina acima do bloco. Conteúdo deslocado mais pra baixo,
    // e os rótulos (COMPRADOR/VENDEDOR/DATA) mais discretos/finos, mais
    // próximos do nome/valor abaixo deles.
    // -----------------------------------------------------------------
    const footX = 83, footY = 633, footW = 1563, footH = 194;
    const cyCirc = footY + footH / 2 + 26; // conteúdo mais pra baixo

    // Linha divisória única e fina no lugar da antiga caixa — desenhada de
    // ponta a ponta do bloco (footX até footX+footW) com um gradiente
    // horizontal sólido (mesma técnica da moldura externa), sem depender de
    // shadowBlur — que em alguns backends de canvas pode fazer as pontas da
    // linha saírem desbotadas/incompletas.
    const footLineY = footY + 18;
    ctx.save();
    const footLineGrad = ctx.createLinearGradient(footX, 0, footX + footW, 0);
    footLineGrad.addColorStop(0.00, palette.GOLD_4 || "#80520D");
    footLineGrad.addColorStop(0.15, palette.GOLD_2 || "#E5A93C");
    footLineGrad.addColorStop(0.50, palette.GOLD_HIGH || "#FFE885");
    footLineGrad.addColorStop(0.85, palette.GOLD_2 || "#E5A93C");
    footLineGrad.addColorStop(1.00, palette.GOLD_4 || "#80520D");
    ctx.strokeStyle = footLineGrad;
    ctx.lineWidth = 2;
    ctx.lineCap = "butt";
    ctx.beginPath();
    ctx.moveTo(footX, footLineY);
    ctx.lineTo(footX + footW, footLineY);
    ctx.stroke();
    ctx.restore();

    const circR = 38; // círculos de Comprador/Vendedor mais finos/discretos

    async function desenharParte(cx, letra, avatarURL, label, nome) {
        await desenharAvatarCirculo(ctx, cx, cyCirc, circR, avatarURL || letra, palette);
        strokeGlowCircle(ctx, cx, cyCirc, circR + 2, palette, 1.5);

        const textX = cx + 70;

        // Rótulo mais fraco: peso menor, cor apagada, mais colado no nome
        ctx.save();
        ctx.globalAlpha = 0.65;
        ctx.fillStyle = palette.TEXT_MUTED;
        ctx.font = `500 17px ${FONT_STACK}`;
        ctx.fillText(label, textX, cyCirc - 4);
        ctx.restore();

        ctx.fillStyle = "#FFFFFF";
        ctx.font = `600 25px ${FONT_STACK}`;
        ctx.fillText(nome, textX, cyCirc + 30);
        const nomeW = ctx.measureText(nome).width;
        drawCheckOutlineBadge(ctx, textX + nomeW + 22, cyCirc + 14, 14, palette);
    }

    await desenharParte(footX + 82, "C", compradorAvatarURL, "COMPRADOR", compradorNome);
    await desenharParte(footX + footW * 0.330 + 73, "V", vendedorAvatarURL, "VENDEDOR", vendedorNome);

    const dataCx = footX + footW * 0.651 + 63, dataCy = cyCirc;
    drawCalendar(ctx, dataCx, dataCy, 24, palette);

    ctx.save();
    ctx.globalAlpha = 0.65;
    ctx.fillStyle = palette.TEXT_MUTED;
    ctx.font = `500 17px ${FONT_STACK}`;
    ctx.fillText("DATA", dataCx + 42, dataCy - 4);
    ctx.restore();

    ctx.fillStyle = "#FFFFFF";
    ctx.font = `600 25px ${FONT_STACK}`;
    ctx.fillText(dataStr, dataCx + 42, dataCy + 30);

    // (sem linha "|" antes do texto de marca)
    ctx.font = `600 20px ${FONT_STACK}`;
    fillTextGradient(ctx, brandFooter, footX + footW * 0.832 + 6, cyCirc + 8, 20, palette, "left");

    // Decoração: linhas douradas quebradas (rachadura) nos cantos do cartão
    desenharRachadurasCanto(ctx, W, H, palette);

    return canvas.toBuffer("image/png");
}




/* ==========================================================================================
 * [SEÇÃO 2] GERADOR DE CARTÕES - PERFIL CARD (PERFILCARD)
 * Permite modificar livremente o design, estatísticas e badges do perfil.
 * ========================================================================================== */




/* Register Poppins and NotoCJK fonts */
function registerPerfilFonts() {
    const searchDirs = [
        path.join(__dirname, "fonts"),
        path.join(process.cwd(), "fonts"),
        path.join(__dirname, "..", "fonts")
    ];
    const registeredFiles = new Set();
    for (const fontsDir of searchDirs) {
        if (!fs.existsSync(fontsDir)) continue;
        try {
            const files = fs.readdirSync(fontsDir);
            for (const file of files) {
                if (registeredFiles.has(file)) continue;
                const filePath = path.join(fontsDir, file);
                const lower = file.toLowerCase();
                if (lower.startsWith("poppins") && (lower.endsWith(".ttf") || lower.endsWith(".otf"))) {
                    try {
                        GlobalFonts.registerFromPath(filePath, "Poppins");
                        registeredFiles.add(file);
                    } catch (e) {}
                } else if ((lower.includes("noto") || lower.includes("cjk")) && (lower.endsWith(".ttf") || lower.endsWith(".otf"))) {
                    try {
                        GlobalFonts.registerFromPath(filePath, "NotoCJK");
                        registeredFiles.add(file);
                    } catch (e) {}
                }
            }
        } catch (e) {}
    }
}
registerPerfilFonts();

// getCardConfig already defined

function cleanCanvasText(str) {
    if (!str) return "";
    let s = String(str).replace(/[\u0000-\u001F\u007F-\u009F]/g, "");
    s = s.replace(/\|/g, "").trim();
    s = s.replace(/[\uE000-\uF8FF]|\uD83C[\uDF00-\uDFFF]|\uD83D[\uDC00-\uDDFF]/g, "").trim();
    return s || str;
}

function drawRoundedRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
}

function truncateText(ctx, text, maxWidth) {
    if (!text) return "";
    if (ctx.measureText(text).width <= maxWidth) return text;
    let truncated = text;
    while (truncated.length > 0 && ctx.measureText(truncated + "...").width > maxWidth) {
        truncated = truncated.slice(0, -1);
    }
    return truncated + "...";
}

function drawVectorStar(ctx, cx, cy, spikes, outerRadius, innerRadius, fillStyle, strokeStyle) {
    let rot = (Math.PI / 2) * 3;
    let x = cx;
    let y = cy;
    let step = Math.PI / spikes;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(cx, cy - outerRadius);
    for (let i = 0; i < spikes; i++) {
        x = cx + Math.cos(rot) * outerRadius;
        y = cy + Math.sin(rot) * outerRadius;
        ctx.lineTo(x, y);
        rot += step;
        x = cx + Math.cos(rot) * innerRadius;
        y = cy + Math.sin(rot) * innerRadius;
        ctx.lineTo(x, y);
        rot += step;
    }
    ctx.lineTo(cx, cy - outerRadius);
    ctx.closePath();
    if (fillStyle) {
        ctx.fillStyle = fillStyle;
        ctx.shadowColor = fillStyle;
        ctx.shadowBlur = 6;
        ctx.fill();
    }
    if (strokeStyle) {
        ctx.strokeStyle = strokeStyle;
        ctx.lineWidth = 1.8;
        ctx.stroke();
    }
    ctx.restore();
}

function drawSparkle(ctx, cx, cy, size, color) {
    ctx.save();
    ctx.fillStyle = color || "#c084fc";
    ctx.shadowColor = color || "#c084fc";
    ctx.shadowBlur = 8;
    ctx.beginPath();
    ctx.moveTo(cx, cy - size);
    ctx.quadraticCurveTo(cx, cy, cx + size, cy);
    ctx.quadraticCurveTo(cx, cy, cx, cy + size);
    ctx.quadraticCurveTo(cx, cy, cx - size, cy);
    ctx.quadraticCurveTo(cx, cy, cx, cy - size);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
}

function drawVectorLock(ctx, cx, cy, size, color) {
    ctx.save();
    ctx.strokeStyle = color || "#64748b";
    ctx.fillStyle = color || "#64748b";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(cx, cy - size * 0.3, size * 0.35, Math.PI, 0);
    ctx.stroke();
    drawRoundedRect(ctx, cx - size * 0.4, cy - size * 0.1, size * 0.8, size * 0.7, 3);
    ctx.fill();
    ctx.restore();
}

function drawVectorBadgeIcon(ctx, type, cx, cy, size, color) {
    ctx.save();
    if (type === "money" || type === "💰" || String(type).includes("movim")) {
        ctx.fillStyle = color;
        ctx.shadowColor = color;
        ctx.shadowBlur = 6;
        ctx.beginPath();
        ctx.arc(cx, cy + size * 0.1, size * 0.65, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#120f21";
        ctx.font = `bold ${Math.round(size * 0.85)}px Arial, sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText("$", cx, cy + size * 0.12);
    } else if (type === "diamond" || type === "💎" || String(type).includes("Trade")) {
        ctx.fillStyle = color;
        ctx.shadowColor = color;
        ctx.shadowBlur = 6;
        ctx.beginPath();
        ctx.moveTo(cx, cy - size * 0.7);
        ctx.lineTo(cx + size * 0.7, cy - size * 0.2);
        ctx.lineTo(cx, cy + size * 0.7);
        ctx.lineTo(cx - size * 0.7, cy - size * 0.2);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = "#ffffff";
        ctx.globalAlpha = 0.6;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(cx - size * 0.7, cy - size * 0.2);
        ctx.lineTo(cx + size * 0.7, cy - size * 0.2);
        ctx.stroke();
    } else if (type === "flame" || type === "🔥" || String(type).includes("250") || String(type).includes("500")) {
        ctx.fillStyle = color;
        ctx.shadowColor = color;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.moveTo(cx, cy + size * 0.7);
        ctx.quadraticCurveTo(cx - size * 0.8, cy, cx - size * 0.3, cy - size * 0.4);
        ctx.quadraticCurveTo(cx - size * 0.1, cy - size * 0.9, cx + size * 0.6, cy - size * 0.6);
        ctx.quadraticCurveTo(cx + size * 0.6, cy - size * 0.2, cx + size * 0.4, cy + size * 0.4);
        ctx.quadraticCurveTo(cx + size * 0.2, cy + size * 0.8, cx, cy + size * 0.7);
        ctx.fill();
    } else {
        drawVectorStar(ctx, cx, cy, 5, size * 0.7, size * 0.32, color, null);
    }
    ctx.restore();
}

function formatValueForDisplay(val) {
    if (typeof val !== "number") val = parseFloat(String(val).replace(",", ".")) || 0;
    return "R$ " + val.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function createGoldMetallicGradient(ctx, yTop, yBottom) {
    const grad = ctx.createLinearGradient(0, yTop, 0, yBottom);
    grad.addColorStop(0.00, "#FFE885"); // Warm bright gold shine
    grad.addColorStop(0.25, "#F3C84B"); // Vibrant gold
    grad.addColorStop(0.55, "#E5B83B"); // Rich metallic gold
    grad.addColorStop(0.85, "#C49222"); // Deep amber gold
    grad.addColorStop(1.00, "#8F6510"); // Dark golden bronze base
    return grad;
}

async function gerarCartaoPerfil(opts) {
    opts = opts || {};
    const globalConfig = getCardConfig().perfilOptions || {};

    const perfilTitle = cleanCanvasText(opts.perfilTitle || globalConfig.title || "PERFIL DE ATENDIMENTO");
    const perfilTheme = opts.perfilTheme || globalConfig.theme || "bicolor_gold";
    const avatarR = Math.round((opts.perfilAvatarZoom || globalConfig.avatarZoom || 160) * 0.41);
    const rankBadgeStr = cleanCanvasText(opts.perfilRankBadge || globalConfig.rankBadge || "TOP #1 MIDDLEMAN");
    const brandFooterStr = cleanCanvasText(opts.perfilBrandFooter || globalConfig.brandFooter || "NEUX MIDDLE MEDIAÇÕES");
    const statsFontSize = opts.perfilStatsSize || globalConfig.statsSize || 38;

    const width = 1645;
    const height = 956;
    const scale = 1.3;
    const canvas = createCanvas(Math.round(width * scale), Math.round(height * scale));
    const ctx = canvas.getContext("2d");
    ctx.scale(scale, scale);

    const mainFont = "'Poppins', 'NotoCJK', 'DejaVu Sans', 'Noto Sans', Arial, sans-serif";
    const roleColor = opts.rankCorHex || "#e2b740";

    // 1. Dark Space Background with Glow
    ctx.fillStyle = "#07040d";
    ctx.fillRect(0, 0, width, height);

    const bgGlow = ctx.createRadialGradient(width * 0.4, height * 0.35, 80, width * 0.5, height * 0.5, width * 0.85);
    bgGlow.addColorStop(0, "rgba(35, 18, 65, 0.85)");
    bgGlow.addColorStop(0.5, "rgba(18, 10, 36, 0.95)");
    bgGlow.addColorStop(1, "rgba(7, 4, 13, 1)");
    ctx.fillStyle = bgGlow;
    ctx.fillRect(0, 0, width, height);

    const gradientTopRight = ctx.createRadialGradient(width, 0, 0, width, 0, 750);
    gradientTopRight.addColorStop(0, roleColor + "40");
    gradientTopRight.addColorStop(0.5, roleColor + "15");
    gradientTopRight.addColorStop(1, "transparent");
    ctx.fillStyle = gradientTopRight;
    ctx.fillRect(0, 0, width, height);

    const blGlow = ctx.createRadialGradient(0, height, 0, 0, height, 750);
    blGlow.addColorStop(0, roleColor + "30");
    blGlow.addColorStop(1, "transparent");
    ctx.fillStyle = blGlow;
    ctx.fillRect(0, 0, width, height);

    // Vector Sparkles
    const fixedSparkles = [
        { x: 120, y: 70, s: 10, c: "#c084fc" }, { x: 920, y: 45, s: 12, c: "#93c5fd" }, { x: 1270, y: 90, s: 8, c: "#e0e7ff" },
        { x: 1560, y: 75, s: 14, c: "#c084fc" }, { x: 770, y: 120, s: 7, c: "#ffffff" }, { x: 470, y: 320, s: 9, c: "#c084fc" },
        { x: 1390, y: 350, s: 10, c: "#93c5fd" }, { x: 270, y: 640, s: 9, c: "#e0e7ff" }, { x: 860, y: 920, s: 12, c: "#c084fc" },
        { x: 1550, y: 490, s: 10, c: "#ffffff" }, { x: 50, y: 420, s: 8, c: "#93c5fd" }, { x: 1180, y: 870, s: 8, c: "#e0e7ff" }
    ];
    fixedSparkles.forEach(st => {
        drawSparkle(ctx, st.x, st.y, st.s, st.c);
    });

    // Background Dots
    for (let i = 0; i < 40; i++) {
        const dotX = (i * 137 + 43) % width;
        const dotY = (i * 97 + 29) % height;
        ctx.globalAlpha = 0.35;
        ctx.fillStyle = "#ffffff";
        ctx.beginPath();
        ctx.arc(dotX, dotY, (i % 3) + 1, 0, Math.PI * 2);
        ctx.fill();
    }
    ctx.globalAlpha = 1;

    // 2. Avatar Section
    const avatarX = 75;
    const avatarY = 70;

    // Outer Glowing Border matching role color!
    ctx.save();
    ctx.beginPath();
    ctx.arc(avatarX + avatarR, avatarY + avatarR, avatarR + 6, 0, Math.PI * 2);
    ctx.strokeStyle = roleColor;
    ctx.lineWidth = 4.5;
    ctx.shadowColor = roleColor;
    ctx.shadowBlur = 16;
    ctx.stroke();
    ctx.restore();

    try {
        if (opts.avatarURL && opts.avatarURL.startsWith("http")) {
            const avatarImg = await loadImage(opts.avatarURL);
            ctx.save();
            ctx.beginPath();
            ctx.arc(avatarX + avatarR, avatarY + avatarR, avatarR, 0, Math.PI * 2);
            ctx.clip();
            ctx.drawImage(avatarImg, avatarX, avatarY, avatarR * 2, avatarR * 2);
            ctx.restore();
        } else {
            throw new Error("No avatar URL");
        }
    } catch (e) {
        ctx.save();
        ctx.fillStyle = "#1e1b2e";
        ctx.beginPath();
        ctx.arc(avatarX + avatarR, avatarY + avatarR, avatarR, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#c9c9c9";
        ctx.font = `bold ${avatarR}px ${mainFont}`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        const rawLetter = (opts.username || "U");
        const letter = (cleanCanvasText(rawLetter)[0] || "U").toUpperCase();
        ctx.fillText(letter, avatarX + avatarR, avatarY + avatarR + 4);
        ctx.restore();
    }

    // Rank Sun Badge on Avatar
    const badgeCx = avatarX + avatarR * 2 - 10;
    const badgeCy = avatarY + avatarR * 2 - 10;
    ctx.save();
    ctx.beginPath();
    ctx.arc(badgeCx, badgeCy, 16, 0, Math.PI * 2);
    ctx.fillStyle = "#1c1432";
    ctx.fill();
    ctx.strokeStyle = roleColor;
    ctx.lineWidth = 2;
    ctx.stroke();
    drawVectorStar(ctx, badgeCx, badgeCy, 8, 9, 5, "#f59e0b", null);
    ctx.restore();

    // 3. User Name & Rank Title Info
    const textX = 230;
    ctx.save();
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "#FFFFFF";
    ctx.font = `bold 42px ${mainFont}`;
    const rawUsername = cleanCanvasText(opts.username) || "Cliente VIP";
    const usernameStr = truncateText(ctx, rawUsername, 480);
    ctx.fillText(usernameStr, textX, avatarY + 48);

    const nameWidth = ctx.measureText(usernameStr).width;
    ctx.font = `bold 26px ${mainFont}`;
    const titleX = textX + nameWidth + 20;

    // Draw Vector Star in actual golden color
    drawVectorStar(ctx, titleX + 12, avatarY + 38, 8, 10, 5, "#f59e0b", null);
    ctx.fillStyle = roleColor;
    ctx.fillText(" · ", titleX + 26, avatarY + 46);

    ctx.fillStyle = createGoldMetallicGradient(ctx, avatarY + 20, avatarY + 60);
    const rankTitleStr = cleanCanvasText(opts.rankNome) || "Cliente Iniciante";
    ctx.fillText(rankTitleStr, titleX + 50, avatarY + 46);

    ctx.fillStyle = createGoldMetallicGradient(ctx, avatarY + 70, avatarY + 95);
    ctx.font = `bold 16px ${mainFont}`;
    const pos = opts.rankPosicao || opts.rank || 1;
    const tot = opts.rankTotal || (opts.rank ? 768 : 7);
    ctx.fillText(`RANKING GERAL • #${pos} de ${tot}`, textX, avatarY + 84);
    ctx.restore();

    // 4. Top Right Total Movimentado with Signature Gold Metallic Gradient
    const rightX = 1570;
    ctx.save();
    ctx.textAlign = "right";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "#94a3b8";
    ctx.font = `bold 18px ${mainFont}`;
    ctx.fillText("TOTAL MOVIMENTADO", rightX, avatarY + 42);

    ctx.font = `bold 68px ${mainFont}`;
    ctx.fillStyle = createGoldMetallicGradient(ctx, avatarY + 50, avatarY + 120);
    const totalMov = opts.totalMovimentado !== undefined ? opts.totalMovimentado : (opts.total !== undefined ? opts.total : (opts.totalValor !== undefined ? opts.totalValor : 0));
    ctx.fillText(formatValueForDisplay(totalMov), rightX, avatarY + 115);
    ctx.restore();

    // 5. Progress Bar Section
    const barX = 75;
    const barY = 320;
    const barW = 1495;
    const barH = 16;

    ctx.save();
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
    ctx.font = `bold 20px ${mainFont}`;
    ctx.fillStyle = createGoldMetallicGradient(ctx, barY - 30, barY);
    ctx.fillText(`• ${rankTitleStr}`, barX, barY - 14);

    ctx.textAlign = "right";
    let faltaStr = "";
    let proximoNome = "Cliente Nobre";
    if (opts.proximoRank) {
        faltaStr = formatValueForDisplay(opts.proximoRank.faltam);
        proximoNome = cleanCanvasText(opts.proximoRank.nome) || "Cliente Nobre";
    } else {
        faltaStr = "R$ 500,00";
    }
    ctx.fillStyle = "#94a3b8";
    ctx.font = `18px ${mainFont}`;
    const sufStr = `• ${proximoNome}`;
    const sufW = ctx.measureText(sufStr).width;
    ctx.fillText(`faltam ${faltaStr} para `, rightX - sufW - 6, barY - 14);

    ctx.fillStyle = createGoldMetallicGradient(ctx, barY - 30, barY);
    ctx.font = `bold 18px ${mainFont}`;
    ctx.fillText(sufStr, rightX, barY - 14);

    ctx.fillStyle = "#1e1833";
    drawRoundedRect(ctx, barX, barY, barW, barH, 8);
    ctx.fill();

    const progressVal = typeof opts.progresso === "number" ? opts.progresso : 0.45;
    const fillW = Math.max(Math.min(progressVal, 1) * barW, 20);
    const pGrad = ctx.createLinearGradient(barX, 0, barX + fillW, 0);
    pGrad.addColorStop(0, "#7c3aed");
    pGrad.addColorStop(0.5, roleColor);
    pGrad.addColorStop(1, "#c084fc");
    ctx.fillStyle = pGrad;
    ctx.shadowColor = roleColor;
    ctx.shadowBlur = 12;
    drawRoundedRect(ctx, barX, barY, fillW, barH, 8);
    ctx.fill();
    ctx.restore();

    // 6. 4 Stat Cards Row
    const stats = [
        { label: "INTERMEDIAÇÕES", value: opts.intermediacoes !== undefined ? opts.intermediacoes : (opts.trocas !== undefined ? opts.trocas : (opts.totalTrocas !== undefined ? opts.totalTrocas : 0)), isCurrency: false },
        { label: "MAIOR TRANSAÇÃO", value: opts.maiorTransacao !== undefined ? opts.maiorTransacao : (opts.maiorTrend !== undefined ? opts.maiorTrend : (opts.maiorTroca !== undefined ? opts.maiorTroca : 0)), isCurrency: true },
        { label: "NO MÊS", value: opts.noMes !== undefined ? opts.noMes : (opts.valorMensal !== undefined ? opts.valorMensal : (opts.totalMensal !== undefined ? opts.totalMensal : (opts.totalMes !== undefined ? opts.totalMes : 0))), isCurrency: true },
        { label: "CLIENTE DESDE", value: opts.clienteDesde || 2026, isCurrency: false }
    ];

    const cardW = 352;
    const cardH = 140;
    const cardGap = 29;
    const cardY = 410;

    stats.forEach((s, i) => {
        const x = barX + i * (cardW + cardGap);
        ctx.save();
        ctx.fillStyle = "rgba(18, 15, 33, 0.85)";
        ctx.strokeStyle = "rgba(120, 90, 200, 0.25)";
        ctx.lineWidth = 1.5;
        drawRoundedRect(ctx, x, cardY, cardW, cardH, 16);
        ctx.fill();
        ctx.stroke();

        ctx.textAlign = "left";
        ctx.textBaseline = "alphabetic";
        ctx.fillStyle = "#94a3b8";
        ctx.font = `bold 15px ${mainFont}`;
        ctx.fillText(s.label, x + 24, cardY + 40);

        const textVal = s.isCurrency ? formatValueForDisplay(s.value) : String(s.value);
        ctx.font = `bold ${statsFontSize}px ${mainFont}`;
        ctx.fillStyle = createGoldMetallicGradient(ctx, cardY + 50, cardY + 105);
        ctx.fillText(textVal, x + 24, cardY + 98);
        ctx.restore();
    });

    // 7. 6 Achievement Cards Row
    const conquistasDefault = [
        { label: "100 intermédios", icone: "handshake", desbloqueado: false },
        { label: "R$ 1k movim.", icone: "money", desbloqueado: false },
        { label: "R$ 10k movim.", icone: "money", desbloqueado: false },
        { label: "Trade R$ 500+", icone: "diamond", desbloqueado: false },
        { label: "250 intermédios", icone: "flame", desbloqueado: false },
        { label: "500 intermédios", icone: "flame", desbloqueado: false }
    ];

    const conqs = opts.conquistas && opts.conquistas.length >= 6 ? opts.conquistas : conquistasDefault;
    const conqGap = 22;
    const conqW = (barW - (conqs.length - 1) * conqGap) / conqs.length;
    const conqH = 210;
    const conqY = 590;

    for (let i = 0; i < conqs.length; i++) {
        const c = conqs[i];
        const x = barX + i * (conqW + conqGap);
        const active = c.desbloqueado;

        ctx.save();
        if (active) {
            ctx.fillStyle = "rgba(18, 15, 33, 0.9)";
            ctx.strokeStyle = roleColor;
            ctx.lineWidth = 2.5;
            ctx.shadowColor = roleColor;
            ctx.shadowBlur = 10;
        } else {
            ctx.fillStyle = "rgba(14, 11, 27, 0.7)";
            ctx.strokeStyle = "rgba(255, 255, 255, 0.08)";
            ctx.lineWidth = 1.5;
        }

        drawRoundedRect(ctx, x, conqY, conqW, conqH, 16);
        ctx.fill();
        ctx.stroke();
        ctx.restore();

        if (!active) {
            drawVectorLock(ctx, x + conqW - 22, conqY + 28, 14, "#475569");
        }

        const iconColor = active ? roleColor : "#475569";
        drawVectorBadgeIcon(ctx, c.icone || c.label, x + conqW / 2, conqY + conqH / 2 - 15, 24, iconColor);

        ctx.save();
        ctx.textAlign = "center";
        ctx.textBaseline = "alphabetic";
        ctx.font = `bold 16px ${mainFont}`;
        ctx.fillStyle = active ? "#FFFFFF" : "#64748b";
        const cleanConqLabel = cleanCanvasText(c.label || c.name || "");
        ctx.fillText(cleanConqLabel, x + conqW / 2, conqY + conqH / 2 + 45);
        ctx.restore();
    }

    // 8. Watermark
    ctx.save();
    ctx.textAlign = "right";
    ctx.textBaseline = "alphabetic";
    ctx.font = `bold 16px ${mainFont}`;
    ctx.fillStyle = createGoldMetallicGradient(ctx, height - 65, height - 35);
    ctx.fillText(brandFooterStr, rightX, height - 50);
    ctx.restore();

    return canvas.toBuffer("image/png");
}




/* ==========================================================================================
 * [SEÇÃO 3] BOT CORE - COMANDOS SLASH, TICKETS E MEDIAÇÕES
 * ========================================================================================== */


const {
    Client,
    GatewayIntentBits,
    EmbedBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    UserSelectMenuBuilder,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ChannelType,
    PermissionFlagsBits,
    ButtonBuilder,
    ButtonStyle,
    Events,
    MessageFlags,
    SlashCommandBuilder,
    REST,
    Routes,
    AttachmentBuilder,
    ContainerBuilder,
    TextDisplayBuilder,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder
} = require("discord.js");



const QRCode = require("qrcode");

const TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = "1438353823235051642";
const GUILD_ID = "1417672403382960130";

const CATEGORIA_TICKETS = '1451246353735880857';
const CANAL_LOGS_ID = '1491989024276091004';
const CANAL_PROOFS = "1451245692042477752";
const CANAL_BIG_TRADE = "1455755067046236251";
const CANAL_TAXAS = "1470177275881455627";
const CANAL_AVALIACOES = "1417967103360630916";

const CARGO_STAFF_ID = "1422050552371740702";
const ID_AFILIADO = "1493722160269623367";
const CARGO_AFILIADO_ID = "1493722160269623367"; // Definido para evitar erros de referência

const RANK_COLORS = {
    "1472761782555771060": "#5865F2", // 200K  (limite 200000) - equivalente a "Master" - Azul Índigo
    "1470874824627716217": "#FFA500", // 100K  (limite 100000) - equivalente a "Nebula" - Laranja Dourado
    "1455064011413393515": "#00CED1", // Cliente Divino (limite 50000) - equivalente a "Imperador" - Ciano
    "1455064010033594549": "#9B30FF", // Cliente Lendário (limite 25000) - equivalente a "Galático" - Roxo
    "1455064008699805799": "#FF3B3B", // Cliente Sagrado (limite 10000) - equivalente a "Eterno" - Vermelho
    "1452028593268981964": "#10B981", // Cliente Celestial (limite 5000) - equivalente a "Esmeralda" - Verde
    "1455064005604540447": "#2196F3", // Cliente Imperial (limite 1000) - equivalente a "Platina" - AZUL
    "1455064003922366524": "#C0C0C0", // Cliente Nobre (limite 500) - equivalente a "Premium" - PRATA (era roxo, corrigido)
    "1417913178779549767": "#C0C0C0"  // Cliente Iniciante (limite 0) - equivalente a "Cliente" - PRATA (consistente com a paleta do vouch)
};

const RANK_CARGOS = [
  { nome: "200K", limite: 200000, id: "1472761782555771060", iconType: "crown" },
  { nome: "100K", limite: 100000, id: "1470874824627716217", iconType: "crown" },
  { nome: "Cliente Divino", limite: 50000, id: "1455064011413393515", iconType: "diamond" },
  { nome: "Cliente Lendário", limite: 25000, id: "1455064010033594549", iconType: "star" },
  { nome: "Cliente Sagrado", limite: 10000, id: "1455064008699805799", iconType: "star" },
  { nome: "Cliente Celestial", limite: 5000, id: "1452028593268981964", iconType: "diamond" },
  { nome: "Cliente Imperial", limite: 1000, id: "1455064005604540447", iconType: "shield" },
  { nome: "Cliente Nobre", limite: 500, id: "1455064003922366524", iconType: "shield" },
  { nome: "Cliente Iniciante", limite: 0, id: "1417913178779549767", iconType: "star" },
];

const CARGO_TOP_1 = "1475045304444256296";
const CARGO_TOP_2 = "1497401431739732019";
const CARGO_TOP_3 = "1442589543487373444";

const EMOJI_CHECK = '<:2974:1438244299564126279>';
const EMOJI_PIX_TITULO = "✅";
const THUMBNAIL_SPEED = "https://i.postimg.cc/ZKp8yjpK/nex1-2.gif"; // Link direto fornecido pelo usuário

const dbPixPath = path.join(__dirname, 'pix_database.json');
const dbUsersPath = path.join(__dirname, 'users_mm.json');
const dbGlobalPath = path.join(__dirname, 'proofs_global.json');
const dbTaxasPath = path.join(__dirname, 'taxas_diarias.json');

let globalCounter = 1447;
if (fs.existsSync(dbGlobalPath)) {
    try {
        const savedGlobal = JSON.parse(fs.readFileSync(dbGlobalPath));
        if (typeof savedGlobal === 'number') globalCounter = savedGlobal;
    } catch (e) { console.error("Erro ao carregar globalCounter:", e); }
}

let userData = {};
if (fs.existsSync(dbUsersPath)) {
    try {
        userData = JSON.parse(fs.readFileSync(dbUsersPath));
    } catch (e) { console.error("Erro ao carregar userData:", e); }
}

let taxasDiarias = {};
if (fs.existsSync(dbTaxasPath)) {
    try {
        taxasDiarias = JSON.parse(fs.readFileSync(dbTaxasPath));
    } catch (e) { console.error("Erro ao carregar taxasDiarias:", e); }
}

let pixConfig = new Map();
if (fs.existsSync(dbPixPath)) {
    try {
        pixConfig = new Map(Object.entries(JSON.parse(fs.readFileSync(dbPixPath))));
    } catch (e) { console.error("Erro ao carregar banco de dados PIX:", e); }
}

function saveGlobal() { fs.writeFileSync(dbGlobalPath, JSON.stringify(globalCounter)); }
function saveUsers() { fs.writeFileSync(dbUsersPath, JSON.stringify(userData, null, 2)); }
function saveTaxas() { fs.writeFileSync(dbTaxasPath, JSON.stringify(taxasDiarias, null, 2)); }
function salvarDadosPix() {
    const obj = Object.fromEntries(pixConfig);
    fs.writeFileSync(dbPixPath, JSON.stringify(obj, null, 2));
}

function sanitizarValor(valorStr) {
    if (typeof valorStr !== 'string') return 0;
    let limpo = valorStr.trim();

    if (limpo.includes('.') && limpo.includes(',')) {
        limpo = limpo.replace(/\./g, '').replace(',', '.');
    }
    else if (limpo.includes(',') && limpo.indexOf(',') < limpo.indexOf('.')) {
        limpo = limpo.replace(/,/g, '');
    }
    else if (limpo.includes('.') && !limpo.includes(',')) {
        const partes = limpo.split('.');
        const ultimaParte = partes[partes.length - 1];
        if (ultimaParte.length === 3) {
            limpo = limpo.replace(/\./g, '');
        }
    }
    else if (limpo.includes(',') && !limpo.includes('.')) {
        limpo = limpo.replace(',', '.');
    }

    const num = parseFloat(limpo);
    return isNaN(num) ? 0 : num;
}

const tradeData = new Map();
function loadTradeDataFromDisk() {
    try {
        if (fs.existsSync('trade_data.json')) {
            const content = fs.readFileSync('trade_data.json', 'utf8');
            if (content && content.trim().length > 2) {
                const parsed = JSON.parse(content);
                for (const [k, v] of Object.entries(parsed)) {
                    tradeData.set(k, v);
                }
            }
        }
    } catch (e) {
        console.error('Erro ao carregar trade_data.json:', e);
    }
}
function saveTradeDataToDisk() {
    try {
        const obj = {};
        for (const [k, v] of tradeData.entries()) {
            obj[k] = { ...v, colValor: null, colItem: null, msgValor: null, msgItem: null };
        }
        fs.writeFileSync('trade_data.json', JSON.stringify(obj, null, 2));
    } catch (e) {
        console.error('Erro ao salvar trade_data.json:', e);
    }
}
loadTradeDataFromDisk();
const pixStorage = new Map();
const chaveFinalStorage = new Map();
const dbAvaliacoesPath = path.join(__dirname, 'avaliacoes_pendentes.json');
const avaliacoesPendentes = new Map();
function loadAvaliacoesPendentes() {
    try {
        if (fs.existsSync(dbAvaliacoesPath)) {
            const data = JSON.parse(fs.readFileSync(dbAvaliacoesPath, 'utf8'));
            for (const [k, v] of Object.entries(data)) {
                avaliacoesPendentes.set(k, v);
            }
        }
    } catch (e) {
        console.error('Erro ao carregar avaliacoes_pendentes.json:', e);
    }
}
function saveAvaliacoesPendentes() {
    try {
        const obj = {};
        for (const [k, v] of avaliacoesPendentes.entries()) {
            obj[k] = v;
        }
        fs.writeFileSync(dbAvaliacoesPath, JSON.stringify(obj, null, 2));
    } catch (e) {
        console.error('Erro ao salvar avaliacoes_pendentes.json:', e);
    }
}
loadAvaliacoesPendentes();

function gerarIdAvaliacao() {
    return `AVL${Date.now()}${Math.floor(Math.random() * 900 + 100)}`;
}

function registerTrade(userId, valor, contraparteId = null) {
  if (!userData[userId]) userData[userId] = { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
  if (!userData[userId].clienteDesde) userData[userId].clienteDesde = new Date().getFullYear();
  userData[userId].totalTrocas++;
  userData[userId].totalValor += valor;
  userData[userId].totalMes += valor;
  if (valor > userData[userId].maiorTroca) userData[userId].maiorTroca = valor;

  if (contraparteId) {
    if (!userData[userId].listaPessoas) userData[userId].listaPessoas = [];
    if (!userData[userId].listaPessoas.includes(contraparteId)) {
      userData[userId].listaPessoas.push(contraparteId);
      userData[userId].pessoasIntermediadas = userData[userId].listaPessoas.length;
    }
  }

  saveUsers();
}

function registerStaffTrade(userId, valor, contraparteIds = []) {
  if (!userData[userId]) userData[userId] = { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
  if (!userData[userId].clienteDesde) userData[userId].clienteDesde = new Date().getFullYear();
  userData[userId].totalTrocas++;

  if (!userData[userId].listaPessoas) userData[userId].listaPessoas = [];
  for (const cid of contraparteIds) {
    if (cid && !userData[userId].listaPessoas.includes(cid)) {
      userData[userId].listaPessoas.push(cid);
    }
  }
  userData[userId].pessoasIntermediadas = userData[userId].listaPessoas.length;

  saveUsers();
}

async function atualizarCargos(guild, userId) {
  try {
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) return;
    const data = userData[userId];

    for (const rank of RANK_CARGOS) {
        if (data && data.totalValor >= rank.limite) {
            try {
                if (!member.roles.cache.has(rank.id)) {
                    await member.roles.add(rank.id);
                }
            } catch (e) {
                console.error(`Erro ao adicionar cargo ${rank.nome} para ${userId}:`, e.message);
            }
        }
    }

    const allUsersMonthly = Object.entries(userData).sort(([, a], [, b]) => b.totalMes - a.totalMes);
    const rolesTop = [CARGO_TOP_1, CARGO_TOP_2, CARGO_TOP_3];

    for (let i = 0; i < 3; i++) {
      if (allUsersMonthly[i]) {
        const topUserId = allUsersMonthly[i][0];
        const topMember = await guild.members.fetch(topUserId).catch(() => null);
        const roleId = rolesTop[i];

        if (topMember) {
          const role = guild.roles.cache.get(roleId);
          if (role) {
            await Promise.all(role.members.map(m => {
                if(m.id !== topUserId) return m.roles.remove(roleId).catch(() => {});
            }));
            if (!topMember.roles.cache.has(roleId)) await topMember.roles.add(roleId).catch(() => {});
          }
        }
      }
    }
  } catch (err) { console.error("Erro ao atualizar cargos:", err); }
}

// tipoTaxa: 'normal' (middleman padrão, !middleman) ou 'baixa' (middleman2, !middleman2)
// A diferença hoje é só na primeira faixa (R$0,50 vira R$0,25), mas dá pra ajustar
// as outras faixas do "baixa" aqui se quiser deixar tudo mais barato também.
function calcularTaxaBase(v, tipoTaxa = 'normal') {
  v = parseFloat(v) || 0;
  const taxaMinima = tipoTaxa === 'baixa' ? 0.25 : 0.50;
  if (v >= 700) return v * 0.01;
  if (v >= 400) return 6.50;
  if (v >= 200) return 4.00;
  if (v >= 100) return 2.00;
  if (v >= 8) return taxaMinima;
  return 0;
}

function calcularTaxa(tipo, valor, enviadorId, recebedorId) {
  let taxaBase = 0;
  if (tipo === "crosstrade") taxaBase = 1.0;
  else if (valor >= 700) taxaBase = valor * 0.01;
  else if (valor >= 400) taxaBase = 6.50;
  else if (valor >= 200) taxaBase = 4.00;
  else if (valor >= 100) taxaBase = 2.00;
  else if (valor >= 8) taxaBase = 0.50;
  if (enviadorId === ID_AFILIADO || recebedorId === ID_AFILIADO) taxaBase /= 2;
  return taxaBase;
}

function crc16(payload) {
    let polinomio = 0x1021;
    let resultado = 0xFFFF;
    for (let i = 0; i < payload.length; i++) {
        resultado ^= payload.charCodeAt(i) << 8;
        for (let j = 0; j < 8; j++) {
            if (resultado & 0x8000) resultado = (resultado << 1) ^ polinomio;
            else resultado <<= 1;
            resultado &= 0xFFFF;
        }
    }
    return resultado.toString(16).toUpperCase().padStart(4, "0");
}

function gerarPix(chave, nome, valor) {
    if (typeof chave !== "string" || !chave.trim()) {
        throw new Error("Chave PIX vazia ou inválida");
    }

    const valorNumerico = Number(valor);
    if (!Number.isFinite(valorNumerico) || valorNumerico <= 0) {
        throw new Error(`Valor PIX inválido: ${valor}`);
    }

    const chaveF = chave.trim();
    const nomeF = String(nome || "PAGAMENTO")
        .trim()
        .substring(0, 25)
        .toUpperCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "");
    const valorF = valorNumerico.toFixed(2);

    const merchantAccount =
        "0014br.gov.bcb.pix01" +
        chaveF.length.toString().padStart(2, "0") +
        chaveF;

    const payload =
        "00020101021126" +
        merchantAccount.length.toString().padStart(2, "0") +
        merchantAccount +
        "52040000530398654" +
        valorF.length.toString().padStart(2, "0") +
        valorF +
        "5802BR59" +
        nomeF.length.toString().padStart(2, "0") +
        nomeF +
        "6009SAO PAULO62070503***6304";

    return payload + crc16(payload);
}

async function getRankingEmbed(guild, tipo, pagina) {
  const isGeral = tipo === "geral";
  const sortedUsers = Object.entries(userData).sort(([, a], [, b]) => (isGeral ? b.totalValor - a.totalValor : b.totalMes - a.totalMes));

  const itensPorPagina = 10;
  const totalPaginas = Math.ceil(sortedUsers.length / itensPorPagina) || 1;
  if (pagina < 1) pagina = 1;
  if (pagina > totalPaginas) pagina = totalPaginas;

  const indexInicio = (pagina - 1) * itensPorPagina;
  const slice = sortedUsers.slice(indexInicio, indexInicio + itensPorPagina);

  const embedTitulo = new EmbedBuilder()
    .setColor("#DE4548")
    .setTitle(`🏆 Ranking de Movimentação - ${isGeral ? "Geral" : "Mensal"}`)
    .setThumbnail(THUMBNAIL_SPEED);

  const rowMenu = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId("rank_select")
      .setPlaceholder("Alterar tipo de ranking...")
      .addOptions(
        { label: "Ranking Geral", value: "geral", default: isGeral },
        { label: "Ranking Mensal", value: "mensal", default: !isGeral }
      )
  );

  let listaCorpo = "";
  for (let i = 0; i < slice.length; i++) {
    const [id, data] = slice[i];
    const posicao = indexInicio + i + 1;
    const valor = isGeral ? data.totalValor : data.totalMes;
    const valorFormatado = valor.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
    listaCorpo += `${posicao}. <@${id}> total de R$ \`${valorFormatado}\` gastos e \`${data.totalTrocas}\` troca(s)\n`;
  }

  const embedLista = new EmbedBuilder()
    .setColor("#DE4548")
    .setDescription(listaCorpo || "Nenhum resultado encontrado.")
    .setFooter({ text: `Página ${pagina} de ${totalPaginas} • ${sortedUsers.length} trader(s)` });

  const rowBotoes = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`rankprev_${tipo}_${pagina}`).setLabel("Anterior").setEmoji("◀️").setStyle(ButtonStyle.Secondary).setDisabled(pagina <= 1),
    new ButtonBuilder().setCustomId(`ranknext_${tipo}_${pagina}`).setLabel("Próximo").setEmoji("▶️").setStyle(ButtonStyle.Secondary).setDisabled(pagina >= totalPaginas)
  );

  return { embeds: [embedTitulo, embedLista], components: [rowMenu, rowBotoes] };
}

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.DirectMessages
    ]
});

client.once(Events.ClientReady, () => {
    console.log(`✅ Santa MM\'s V2 Integrado Online!`);
    checkScheduledTasks();
    setInterval(checkScheduledTasks, 60 * 1000); // Executa a cada minuto
});

process.on('unhandledRejection', (reason) => console.log(' [ANTI-CRASH] Rejeição:', reason));
process.on('uncaughtException', (err) => console.log(' [ANTI-CRASH] Exceção:', err));

function construirContainerFuncoes(data) {
    const mencoes = data.participantes.map(id => `<@${id}>`).join(' ') || '';

    return new ContainerBuilder()
        .setAccentColor(0xDE4548)
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `${mencoes}\n` +
                `# <:parceria:1485054250429054986> ━ Seleção de Funções\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `Confirmem as funções de vocês: quem vai enviar o PIX pro MM e quem vai receber o PIX do MM depois da troca.\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `<:emoji_166:1541616981348851763> **Vou enviar o pix** — Você vai enviar o PIX para o middleman.\n` +
                `<:emoji_164:1541612138756579439> **Vou receber** — Você vai receber o PIX do middleman.\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `**Enviador:** ${data.enviador ? `<@${data.enviador}>` : 'Aguardando...'}\n` +
                `**Recebedor:** ${data.recebedor ? `<@${data.recebedor}>` : 'Aguardando...'}`
            )
        )
        .addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('set_enviador').setLabel('Vou enviar o Pix').setEmoji('<:emoji_166:1541616981348851763>').setStyle(ButtonStyle.Secondary).setDisabled(!!data.enviador),
                new ButtonBuilder().setCustomId('set_recebedor').setLabel('Vou Receber').setEmoji('<:emoji_164:1541612138756579439>').setStyle(ButtonStyle.Secondary).setDisabled(!!data.recebedor),
                new ButtonBuilder().setCustomId('resetar_fluxo').setLabel('Resetar').setEmoji('<:emoji_167:1541618912238768148>').setStyle(ButtonStyle.Secondary)
            )
        )
        .addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('btn_fechar').setLabel('Excluir intermediação').setEmoji('<:emoji_167:1541618912238768148>').setStyle(ButtonStyle.Secondary)
            )
        );
}

async function iniciarFluxoImagens(channel) {
    let data = tradeData.get(channel.id);
    if (!data) {
        data = { enviador: null, recebedor: null, valor: null, item: null, staffReivindicou: null, msgDmId: null, confirmacoes: [], confirmacoesEntrega: [], participantes: [], colValor: null, colItem: null, msgValor: null, msgItem: null };
        tradeData.set(channel.id, data);
    } else {
        data.colValor?.stop();
        data.colItem?.stop();
        data.colValor = null;
        data.colItem = null;
        data.msgValor = null;
        data.msgItem = null;
        data.enviador = null; data.recebedor = null; data.valor = null; data.item = null; data.staffReivindicou = null; data.confirmacoes = []; data.confirmacoesEntrega = []; data.lockValor = false; data.lockItem = false;
    }

    const container = construirContainerFuncoes(data);

    await channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(console.error);
}

async function getCanal(guild, channelId) {
    if (!guild || !channelId) return null;
    try {
        return guild.channels.cache.get(channelId) || await guild.channels.fetch(channelId).catch(() => null);
    } catch (e) {
        return null;
    }
}

async function responderSeguro(interaction, options) {
    const isDM = !interaction.guildId;
    const opts = typeof options === 'string' ? { content: options } : { ...options };
    if (isDM) {
        delete opts.flags;
        if (opts.ephemeral) delete opts.ephemeral;
    } else {
        if (opts.ephemeral && !opts.flags) opts.flags = [MessageFlags.Ephemeral];
    }
    try {
        if (interaction.deferred || interaction.replied) {
            return await interaction.followUp(opts).catch(console.error);
        }
        return await interaction.reply(opts).catch(console.error);
    } catch (e) {
        console.error("Erro ao responder interação:", e);
    }
}

async function enviarLog(guild, embed, files = []) {
    const canalLog = await getCanal(guild, CANAL_LOGS_ID);
    if (!canalLog) {
        console.error("Canal de logs não encontrado:", CANAL_LOGS_ID);
        return false;
    }

    try {
        await canalLog.send({ embeds: [embed], files });
        return true;
    } catch (erro) {
        console.error("Erro ao enviar embed para o canal de logs:", erro);
        return false;
    }
}

// ── Sistema Anti-Duplicação (Cooldown) ──
// Evita que a mesma pessoa dispare a mesma ação duas vezes clicando/respondendo
// rápido demais (double-click, lag do Discord reenviando a interação, etc).
const interactionCooldowns = new Map();
const COOLDOWN_MS = 2500; // tempo mínimo de espera entre ações repetidas

function estaEmCooldown(key) {
    const ultimo = interactionCooldowns.get(key);
    if (!ultimo) return false;
    return (Date.now() - ultimo) < COOLDOWN_MS;
}

function registrarCooldown(key) {
    interactionCooldowns.set(key, Date.now());
}

// Limpa entradas antigas periodicamente para não crescer a memória infinitamente
setInterval(() => {
    const agora = Date.now();
    for (const [key, timestamp] of interactionCooldowns) {
        if (agora - timestamp > COOLDOWN_MS * 4) interactionCooldowns.delete(key);
    }
}, 60 * 1000);

// Evita registrar o handler mais de uma vez caso o painel de hospedagem
// recarregue este arquivo sem reiniciar o processo Node por completo
// (o que causaria a mesma interação sendo processada 2x e gerando erros
// "Unknown Message" ao tentar editar uma resposta já usada).
// client.removeAllListeners(Events.InteractionCreate) bypassed

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (interaction.inGuild() && !interaction.isModalSubmit() && (!interaction.member || !interaction.member.roles?.cache)) {
        try {
            interaction.member = await interaction.guild.members.fetch(interaction.user.id);
        } catch (e) {
            console.error("Falha ao buscar o member da interação:", e);
        }
    }

    // Bloqueia cliques/seleções repetidas do MESMO usuário no MESMO botão/menu
    // dentro do MESMO canal antes do tempo de cooldown passar.
    // Modais e comandos de barra não entram nesse bloqueio.
    if (interaction.isButton() || interaction.isStringSelectMenu() || interaction.isUserSelectMenu()) {
        const cooldownKey = `${interaction.channelId}_${interaction.customId}_${interaction.user.id}`;
        if (estaEmCooldown(cooldownKey)) {
            return await interaction.reply({ content: "⏳ Calma! Aguarde um instante antes de clicar novamente.", flags: [MessageFlags.Ephemeral] }).catch(() => {});
        }
        registrarCooldown(cooldownKey);
    }

    let data = tradeData.get(interaction.channelId); if (!data) { loadTradeDataFromDisk(); data = tradeData.get(interaction.channelId); }

    if (interaction.isChatInputCommand()) {
        if (interaction.commandName === "configpix") {
            if (!interaction.member?.permissions?.has(PermissionFlagsBits.Administrator)) {
                return await interaction.reply({ content: "❌ Apenas administradores podem configurar o PIX de um Middleman.", flags: [MessageFlags.Ephemeral] });
            }
            const modal = new ModalBuilder().setCustomId("modal_config_pix").setTitle("Configurar PIX do Middleman");
            modal.addComponents(
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("pix_id").setLabel("ID do usuário (Middleman)").setPlaceholder("Ex: 123456789012345678").setStyle(TextInputStyle.Short).setRequired(true)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("pix_key").setLabel("Chave PIX").setStyle(TextInputStyle.Short).setRequired(true)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("pix_name").setLabel("Nome Completo (Sem acentos)").setStyle(TextInputStyle.Short).setRequired(true)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("pix_limite").setLabel("Valor máximo que pode mediar (R$)").setPlaceholder("Ex: 500  |  deixe 0 para sem limite").setStyle(TextInputStyle.Short).setRequired(false))
            );
            return await interaction.showModal(modal);
        }
        if (interaction.commandName === "ranking") {
            const embedContent = await getRankingEmbed(interaction.guild, "geral", 1);
            return await interaction.reply(embedContent);
        }

        if (interaction.commandName === "perfil") {
            await interaction.deferReply();

            const user = interaction.options.getUser("usuario") || interaction.user;
            const profileUser = await interaction.client.users.fetch(user.id, { force: true }).catch(() => user);
            const dataU = userData[user.id] || { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
            const member = await interaction.guild.members.fetch(user.id).catch(() => null);

            const allUsersGeral = Object.entries(userData).sort(([, a], [, b]) => b.totalValor - a.totalValor);
            const rankGeral = allUsersGeral.findIndex(([id]) => id === user.id) + 1;
            const allUsersMensal = Object.entries(userData).sort(([, a], [, b]) => (b.totalMes || 0) - (a.totalMes || 0));
            const rankMensal = allUsersMensal.findIndex(([id]) => id === user.id) + 1;

            const cargoAtual = RANK_CARGOS.find(r => dataU.totalValor >= r.limite) || RANK_CARGOS[RANK_CARGOS.length - 1];
            const indexAtual = RANK_CARGOS.indexOf(cargoAtual);
            const proximoCargo = RANK_CARGOS[indexAtual - 1];

            try {
                const buffer = await gerarCartaoPerfil({
                    username: profileUser.username,
                    avatarURL: profileUser.displayAvatarURL({ extension: "png", size: 256 }),
                    userHandle: profileUser.username,
                    bannerURL: profileUser.bannerURL({ extension: "png", size: 1024 }),
                    hasNitro: Boolean(profileUser.banner),
                    cargos: member ? [...member.roles.cache.values()]
                        .filter(role => role.id !== interaction.guild.id)
                        .map(role => ({ id: role.id, name: role.name, color: role.hexColor, position: role.position })) : [],
                    rankNome: cargoAtual.nome,
                    rankCorHex: RANK_COLORS[cargoAtual.id] || "#9B30FF",
                    rankIconType: cargoAtual.iconType,
                    rank: rankGeral || allUsersGeral.length + 1,
                    rankMensal: rankMensal || allUsersMensal.length + 1,
                    total: dataU.totalValor || 0,
                    trocas: dataU.totalTrocas || 0,
                    maiorTrend: dataU.maiorTroca || 0,
                    valorMensal: dataU.totalMes || 0,
                    totalMensal: dataU.totalMes || 0,
                    clienteDesde: dataU.clienteDesde || new Date().getFullYear(),
                    proximoRank: proximoCargo ? { nome: proximoCargo.nome, faltam: Math.max(0, proximoCargo.limite - dataU.totalValor) } : null,
                    progresso: proximoCargo ? (dataU.totalValor - cargoAtual.limite) / (proximoCargo.limite - cargoAtual.limite) : 1,
                    conquistas: [
                        { tier: "bronze", iconType: "handshake", label: "100 intermédios", desbloqueado: dataU.totalTrocas >= 100 },
                        { tier: "prata", iconType: "money", label: "R$ 1k movim.", desbloqueado: dataU.totalValor >= 1000 },
                        { tier: "ouro", iconType: "money", label: "R$ 10k movim.", desbloqueado: dataU.totalValor >= 10000 },
                        { tier: "value", iconType: "diamond", label: "Trade R$ 500+", desbloqueado: dataU.maiorTroca >= 500 },
                        { tier: "black", iconType: "flame", label: "250 intermédios", desbloqueado: dataU.totalTrocas >= 250 },
                        { tier: "vermelho", iconType: "flame", label: "500 intermédios", desbloqueado: dataU.totalTrocas >= 500 },
                        { tier: "vermelho", iconType: "crown", label: "Top Trader", desbloqueado: rankGeral === 1 },
                        { tier: "vermelho", iconType: "crown", label: "Maior do mês", desbloqueado: rankMensal === 1 }
                    ]
                });

                const anexo = new AttachmentBuilder(buffer, { name: "perfil.png" });
                return await interaction.editReply({ files: [anexo] });
            } catch (e) {
                console.error("Erro ao gerar cartão de perfil:", e);
                return await interaction.editReply({ content: "❌ Erro ao gerar o cartão de perfil." });
            }
        }

        if (interaction.commandName === "vouch") {
            if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return await interaction.reply({ content: "❌ Sem permissão.", flags: [MessageFlags.Ephemeral] });
            const tipo = interaction.options.getString("tipo");
            const comprador = interaction.options.getUser("comprador");
            const vendedor = interaction.options.getUser("vendedor");
            const valor = sanitizarValor(interaction.options.getString("valor"));
            if (valor <= 0) return await interaction.reply({ content: "❌ Valor inválido.", flags: [MessageFlags.Ephemeral] });
            await interaction.deferReply();
            await executarAprovarPagamento(interaction.guild, interaction.user, tipo, comprador, vendedor, valor);
            return await interaction.editReply({ content: `✅ Pagamento de R$ ${valor.toFixed(2)} aprovado!` });
        }

        if (interaction.commandName === "aprovar_pagamento") {
            if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return await interaction.reply({ content: "❌ Sem permissão.", flags: [MessageFlags.Ephemeral] });
            const tipo = interaction.options.getString("tipo");
            const enviador = interaction.options.getUser("enviador");
            const recebedor = interaction.options.getUser("recebedor");
            const valor = sanitizarValor(interaction.options.getString("valor"));
            if (valor <= 0) return await interaction.reply({ content: "❌ Valor inválido.", flags: [MessageFlags.Ephemeral] });
            await interaction.deferReply();
            await executarAprovarPagamento(interaction.guild, interaction.user, tipo, enviador, recebedor, valor);
            return await interaction.editReply({ content: `✅ Pagamento de R$ ${valor.toFixed(2)} aprovado!` });
        }
        if (interaction.commandName === "remover_valor") {
            if (!interaction.member?.permissions?.has(PermissionFlagsBits.Administrator)) return await interaction.reply({ content: "❌ Sem permissão.", flags: [MessageFlags.Ephemeral] });
            const user = interaction.options.getUser("usuario");
            const valor = sanitizarValor(interaction.options.getString("valor"));
            if (valor <= 0) return await interaction.reply({ content: "❌ Valor inválido.", flags: [MessageFlags.Ephemeral] });
            if (userData[user.id]) {
                userData[user.id].totalValor -= valor;
                userData[user.id].totalMes -= valor;
                if (userData[user.id].totalValor < 0) userData[user.id].totalValor = 0;
                if (userData[user.id].totalMes < 0) userData[user.id].totalMes = 0;
                saveUsers();
                await atualizarCargos(interaction.guild, user.id);
                return await interaction.reply({ content: `✅ Removido R$ ${valor.toFixed(2)} de <@${user.id}>.` });
            }
            return await interaction.reply({ content: "❌ Usuário não encontrado no banco.", flags: [MessageFlags.Ephemeral] });
        }
    }

    if (interaction.isStringSelectMenu() && interaction.customId === "rank_select") {
        const tipo = interaction.values[0];
        const embedContent = await getRankingEmbed(interaction.guild, tipo, 1);
        return await interaction.update(embedContent);
    }

    if (interaction.isButton() && interaction.customId.startsWith("rank")) {
        const parts = interaction.customId.split("_");
        const action = parts[0];
        const tipo = parts[1];
        let pagina = parseInt(parts[2]);
        if (action === "rankprev") pagina--; else pagina++;
        const embedContent = await getRankingEmbed(interaction.guild, tipo, pagina);
        return await interaction.update(embedContent);
    }

    if (interaction.isButton() && ["mm_perfil", "mm_mes", "mm_dia", "mm_pessoas"].includes(interaction.customId)) {
        if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) {
            return await interaction.reply({ content: "❌ Esse painel é exclusivo para a staff.", flags: [MessageFlags.Ephemeral] });
        }

        const d = userData[interaction.user.id] || {};

        if (interaction.customId === "mm_perfil") {
            const avaliacoesStaff = d.avaliacoes || [];
            const notaMedia = avaliacoesStaff.length ? (avaliacoesStaff.reduce((a, b) => a + b, 0) / avaliacoesStaff.length).toFixed(1) : "Sem avaliações";
            const embed = new EmbedBuilder()
                .setColor("#DE4548")
                .setTitle(`👤 Perfil de Middleman — ${interaction.user.username}`)
                .setThumbnail(interaction.user.displayAvatarURL({ extension: "png", size: 128 }))
                .addFields(
                    { name: "🤝 Intermediações totais", value: `${d.totalTrocas || 0}`, inline: true },
                    { name: "👥 Pessoas atendidas", value: `${d.pessoasIntermediadas || 0}`, inline: true },
                    { name: "⭐ Nota média", value: `${notaMedia}`, inline: true },
                    { name: "💰 Taxa faturada (total)", value: `R$ ${(d.taxaTotal || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`, inline: true },
                    { name: "📅 Taxa faturada (mês)", value: `R$ ${(d.taxaMes || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`, inline: true },
                    { name: "🕐 Taxa faturada (hoje)", value: `R$ ${(taxasDiarias[interaction.user.id] || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`, inline: true }
                );
            return await interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
        }

        if (interaction.customId === "mm_mes") {
            const taxaMes = d.taxaMes || 0;
            return await interaction.reply({ content: `💰 Você faturou **R$ ${taxaMes.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}** em taxas este mês.`, flags: [MessageFlags.Ephemeral] });
        }

        if (interaction.customId === "mm_dia") {
            const taxaDia = taxasDiarias[interaction.user.id] || 0;
            return await interaction.reply({ content: `📅 Você faturou **R$ ${taxaDia.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}** em taxas hoje (ainda não repassado no fechamento diário).`, flags: [MessageFlags.Ephemeral] });
        }

        if (interaction.customId === "mm_pessoas") {
            const lista = d.listaPessoas || [];
            if (!lista.length) return await interaction.reply({ content: "👥 Você ainda não intermediou ninguém.", flags: [MessageFlags.Ephemeral] });
            const exibidos = lista.slice(0, 30).map(id => `<@${id}>`).join(", ");
            const resto = lista.length > 30 ? `\n-# ...e mais ${lista.length - 30} pessoa(s).` : "";
            return await interaction.reply({ content: `👥 **Pessoas que você já atendeu (${lista.length}):**\n${exibidos}${resto}`, flags: [MessageFlags.Ephemeral] });
        }
    }

    if (interaction.isButton() && interaction.customId.startsWith("abrir_transcript_")) {
        const pendingId = interaction.customId.replace("abrir_transcript_", "");
        const pend = avaliacoesPendentes.get(pendingId);
        if (!pend || !pend.transcript) return await responderSeguro(interaction, { content: "❌ Transcript não encontrado ou expirado.", ephemeral: true });
        const anexoTranscript = new AttachmentBuilder(Buffer.from(pend.transcript), { name: `transcript-${pendingId}.txt` });
        return await responderSeguro(interaction, { content: "📄 Aqui está o transcript da sua negociação:", files: [anexoTranscript], ephemeral: true });
    }

    if (interaction.isButton() && interaction.customId.startsWith("av_")) {
        const partesId = interaction.customId.split("_");
        const nota = partesId[1];
        const pendingId = partesId.slice(2).join("_");
        const pend = avaliacoesPendentes.get(pendingId);
        if (!pend) return await responderSeguro(interaction, { content: "❌ Essa avaliação já expirou ou não foi encontrada.", ephemeral: true });
        if (pend.avaliacoes && pend.avaliacoes[interaction.user.id]) return await responderSeguro(interaction, { content: "✅ Você já avaliou esta mediação, obrigado!", ephemeral: true });
        if (interaction.user.id !== pend.enviador && interaction.user.id !== pend.recebedor) return await responderSeguro(interaction, { content: "❌ Você não faz parte dessa negociação.", ephemeral: true });

        const modalAvaliacao = new ModalBuilder()
            .setCustomId(`modal_avaliacao_${nota}_${pendingId}`)
            .setTitle("Deixe seu comentário")
            .addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId("comentario_avaliacao")
                        .setLabel("Como foi sua experiência com o MM?")
                        .setStyle(TextInputStyle.Paragraph)
                        .setPlaceholder("Conte como foi a mediação, o atendimento, a agilidade...")
                        .setMaxLength(300)
                        .setRequired(true)
                )
            );
        return await interaction.showModal(modalAvaliacao);
    }

    if (data && interaction.isButton() && !interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) {
        if (!data.participantes.includes(interaction.user.id)) return await interaction.reply({ content: "❌ Você não faz parte desta negociação!", flags: [MessageFlags.Ephemeral] });
    }

    if (interaction.isModalSubmit() && interaction.customId === "modal_config_pix") {
        const idDigitado = interaction.fields.getTextInputValue("pix_id").trim();
        if (!/^\d{17,20}$/.test(idDigitado)) {
            return await interaction.reply({ content: "❌ ID inválido. Clique com o botão direito no usuário no Discord → **Copiar ID de Usuário** e cole exatamente esse valor.", flags: [MessageFlags.Ephemeral] });
        }
        const membroAlvo = await interaction.guild.members.fetch(idDigitado).catch(() => null);
        if (!membroAlvo) {
            return await interaction.reply({ content: "❌ Não encontrei ninguém com esse ID neste servidor. Confira se copiou o ID certo.", flags: [MessageFlags.Ephemeral] });
        }

        const limiteStr = interaction.fields.getTextInputValue("pix_limite");
        const limite = sanitizarValor(limiteStr); // 0 (ou vazio) = sem limite
        pixConfig.set(idDigitado, { chave: interaction.fields.getTextInputValue("pix_key"), nome: interaction.fields.getTextInputValue("pix_name"), limite });
        salvarDadosPix();
        if (fs.existsSync(dbPixPath)) {
            try { pixConfig = new Map(Object.entries(JSON.parse(fs.readFileSync(dbPixPath)))); } catch (e) {}
        }
        const limiteTexto = limite > 0 ? `R$ ${limite.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}` : "Sem limite";
        return await interaction.reply({ content: `${EMOJI_CHECK} PIX configurado com sucesso para <@${idDigitado}>!\n> Limite de mediação: **${limiteTexto}**`, flags: [MessageFlags.Ephemeral] });
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith("modal_avaliacao_")) {
        const semPrefixo = interaction.customId.replace("modal_avaliacao_", "");
        const partesModal = semPrefixo.split("_");
        const notaModal = partesModal[0];
        const pendingIdModal = partesModal.slice(1).join("_");
        const pendModal = avaliacoesPendentes.get(pendingIdModal);
        if (!pendModal) return await responderSeguro(interaction, { content: "❌ Essa avaliação expirou, sinto muito.", ephemeral: true });

        const comentarioModal = interaction.fields.getTextInputValue("comentario_avaliacao");
        if (interaction.guildId) {
            await interaction.deferReply({ flags: [MessageFlags.Ephemeral] }).catch(() => {});
        } else {
            await interaction.deferReply().catch(() => {});
        }

        if (!pendModal.avaliacoes) pendModal.avaliacoes = {};
        pendModal.avaliacoes[interaction.user.id] = { nota: notaModal, comentario: comentarioModal };
        saveAvaliacoesPendentes();

        if (pendModal.staffId) {
            if (!userData[pendModal.staffId]) userData[pendModal.staffId] = { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
            if (!userData[pendModal.staffId].avaliacoes) userData[pendModal.staffId].avaliacoes = [];
            userData[pendModal.staffId].avaliacoes.push(parseInt(notaModal) || 5);
            saveUsers();
        }

        try {
            const guildAvaliacao = client.guilds.cache.get(GUILD_ID) || await client.guilds.fetch(GUILD_ID).catch(() => null);
            const mediadorU = pendModal.staffId ? await client.users.fetch(pendModal.staffId).catch(() => null) : null;
            const estrelasTexto = "⭐".repeat(Math.max(1, Math.min(5, parseInt(notaModal) || 0)));

            const embedAvaliacao = new EmbedBuilder()
                .setColor(0xDE4548)
                .setTitle('⭐ Nova avaliação de intermediação')
                .setThumbnail("https://i.postimg.cc/hPqvpDtX/nex1-2.gif")
                .addFields(
                    { name: 'Nota', value: `${estrelasTexto} ${notaModal}/5` },
                    { name: 'Usuário', value: `<@${interaction.user.id}>` },
                    { name: 'Middleman', value: mediadorU ? `<@${mediadorU.id}>` : "Não informado" },
                    { name: 'Avaliação', value: comentarioModal || "Sem comentário" }
                )
                .setFooter({ text: `Intermediação ${pendModal.transacaoId || pendingIdModal}` })
                .setTimestamp();

            const canalAvaliacoes = await getCanal(guildAvaliacao, CANAL_AVALIACOES);
            if (canalAvaliacoes) await canalAvaliacoes.send({ embeds: [embedAvaliacao] }).catch(console.error);
        } catch (e) {
            console.error("Erro ao enviar embed de avaliação:", e);
        }

        await responderSeguro(interaction, { content: "✅ Obrigado pela sua avaliação!", ephemeral: true });

        if (pendModal.avaliacoes[pendModal.enviador] && pendModal.avaliacoes[pendModal.recebedor]) {
            avaliacoesPendentes.delete(pendingIdModal);
            saveAvaliacoesPendentes();
        }
        return;
    }

    if ((interaction.isStringSelectMenu() && interaction.customId === 'menu_mm') || (interaction.isButton() && (interaction.customId === 'abrir_mediacao' || interaction.customId === 'abrir_mediacao_baixa'))) {
        const tipoMM = interaction.isStringSelectMenu() ? interaction.values[0] : 'PIX';
        // abrir_mediacao = !middleman (taxa normal) | abrir_mediacao_baixa = !middleman2 (taxa reduzida)
        const tipoTaxa = (interaction.isButton() && interaction.customId === 'abrir_mediacao_baixa') ? 'baixa' : 'normal';
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

        const ticketExistente = interaction.guild.channels.cache.find(c => c.name.includes(interaction.user.username) && c.parentId === CATEGORIA_TICKETS);
        if (ticketExistente) {
            const containerAviso = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ❌ Você já possui um ticket de MM aberto!\nSeu ticket em <#${ticketExistente.id}> ainda está aberto.`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setLabel('Ir para o Ticket').setURL(`https://discord.com/channels/${interaction.guild.id}/${ticketExistente.id}`).setStyle(ButtonStyle.Secondary)));
            return await interaction.editReply({ components: [containerAviso], flags: MessageFlags.IsComponentsV2 });
        }

        const canalTicket = await interaction.guild.channels.create({
            name: `🛡・middleman${tipoTaxa === 'baixa' ? '2' : ''}-${tipoMM}-${interaction.user.username}`, type: ChannelType.GuildText, parent: CATEGORIA_TICKETS,
            permissionOverwrites: [{ id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] }, { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] }, { id: CARGO_STAFF_ID, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ManageMessages] }]
        });

        tradeData.set(canalTicket.id, { enviador: null, recebedor: null, valor: null, item: null, staffReivindicou: null, msgDmId: null, confirmacoes: [], confirmacoesEntrega: [], participantes: [interaction.user.id], criadorTicketId: interaction.user.id, colValor: null, colItem: null, msgValor: null, msgItem: null, tipoTaxa }); saveTradeDataToDisk();

        const container1 = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`||<@${interaction.user.id}> <@&${CARGO_STAFF_ID}>||\n\n# <:parceria:1485054250429054986> ╺╸ Middleman de PIX criado.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\nSeja bem vindo ao novo ticket **AUTOMÁTICO** de MiddleMan, com segurança e agilidade. É importante que você selecione as opções ao longo do ticket corretamente e responda as perguntas que o bot fizer. Reveja sempre antes de prosseguir qualquer passo para evitar scams e erros.\n\n**Passos:**\n1. Adicione o usuário com quem vai negociar usando o menu ou botão abaixo.\n2. O bot pedirá para ambos descreverem os itens no chat.\n3. Após confirmação, o pix automático é gerado.`));
        const container2 = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Notificação de Segurança\nNossa equipe e nosso bot jamais entram em contato por mensagem direta.\n\nToda comunicação da negociação deve acontecer exclusivamente por este ticket.\n\nIgnorar isso pode te colocar em risco de golpe ou fraude. Não aceitamos pagamentos via Inter ou PicPay.\n\nSolicitações indevidas de reembolso podem gerar medidas cabíveis, inclusive ação judicial.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Quem abriu o ticket** pode encerrar aqui se desistir antes de concluir a configuração.`));
        const container3 = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Com Quem Você Está Negociando?\nSelecione o usuário Discord da outra parte.\nSó quem abriu o ticket pode escolher.\n\nUse o menu abaixo **ou** envie o ID /\n@menção do usuário diretamente no chat.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`))
            .addActionRowComponents(new ActionRowBuilder().addComponents(new UserSelectMenuBuilder().setCustomId('add_user_menu').setPlaceholder('Selecione o outro usuário...')))
            .addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('btn_termos').setLabel('Termos MM').setEmoji('<:emoji_166:1541614807621443604>').setStyle(ButtonStyle.Secondary), new ButtonBuilder().setCustomId('btn_fechar').setLabel('Cancelar Ticket').setEmoji('<:emoji_167:1541618912238768148>').setStyle(ButtonStyle.Secondary)));

        await canalTicket.send({ components: [container1], flags: MessageFlags.IsComponentsV2 });
        await canalTicket.send({ components: [container2], flags: MessageFlags.IsComponentsV2 });
        await canalTicket.send({ components: [container3], flags: MessageFlags.IsComponentsV2 });

        enviarLog(interaction.guild, new EmbedBuilder().setColor('#DE4548').setTitle('Ticket Aberto').setDescription(`O usuário <@${interaction.user.id}> abriu um ticket de MM (${tipoMM}).\nCanal: ${canalTicket}`));
        await interaction.editReply({ content: `${EMOJI_CHECK} **|** Seu middleman foi criado com sucesso ${canalTicket}` });
    }

    if (interaction.isUserSelectMenu() && interaction.customId === 'add_user_menu') {
        const alvoId = interaction.values[0];
        if (alvoId === interaction.user.id) return await interaction.reply({ content: "> ❌ Você não pode adicionar a si mesmo.", flags: [MessageFlags.Ephemeral] });
        const container = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Confirmar Contraparte\nVocê selecionou <@${alvoId}>. Confirme que é a pessoa certa ou escolha outra.\n\nSó quem abriu o ticket pode confirmar.\nEvita convidar o usuário errado.`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`confirm_target_${alvoId}`).setLabel('Confirmar pessoa').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId('escolher_outro').setLabel('Escolher outra pessoa').setStyle(ButtonStyle.Secondary)));
        await interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
    }

    if (interaction.isButton() && interaction.customId.startsWith('confirm_target_')) {
        const alvoId = interaction.customId.split('_')[2];
        if (data) { if (!data.participantes.includes(alvoId)) data.participantes.push(alvoId); }
        await interaction.channel.permissionOverwrites.edit(alvoId, { ViewChannel: true, SendMessages: true });
        const fetched = await interaction.channel.messages.fetch({ limit: 10 }); if (fetched) await interaction.channel.bulkDelete(fetched);
        await interaction.reply({ content: `> ${EMOJI_CHECK} ╺╸ Usuário <@${alvoId}> adicionado!`, flags: [MessageFlags.Ephemeral] });
        await iniciarFluxoImagens(interaction.channel);
    }

    if (interaction.isButton() && interaction.customId === 'escolher_outro') {
        const container = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Com Quem Você Está Negociando?\nSelecione o usuário Discord da outra parte.\nSó quem abriu o ticket pode escolher.\n\nUse o menu abaixo **ou** envie o ID /\n@menção do usuário diretamente no chat.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(new UserSelectMenuBuilder().setCustomId('add_user_menu').setPlaceholder('Selecione o outro usuário...')));
        await interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
    }

    if (interaction.isButton() && (interaction.customId === 'set_enviador' || interaction.customId === 'set_recebedor')) {
        if (!data) { return await interaction.reply({ content: "❌ Os dados deste ticket não foram encontrados ou a sessão expirou. Por favor, reabra a mediação.", flags: [MessageFlags.Ephemeral] }).catch(() => {}); }
        if ((interaction.customId === 'set_enviador' && data.recebedor === interaction.user.id) || (interaction.customId === 'set_recebedor' && data.enviador === interaction.user.id)) return await interaction.reply({ content: "❌ Você não pode ocupar as duas vagas!", flags: [MessageFlags.Ephemeral] });
        if (interaction.customId === 'set_enviador' && data.enviador) return await interaction.reply({ content: "❌ Essa vaga já foi ocupada!", flags: [MessageFlags.Ephemeral] });
        if (interaction.customId === 'set_recebedor' && data.recebedor) return await interaction.reply({ content: "❌ Essa vaga já foi ocupada!", flags: [MessageFlags.Ephemeral] });
        if (interaction.customId === 'set_enviador') data.enviador = interaction.user.id; else data.recebedor = interaction.user.id;

        if (data.enviador && data.recebedor) {
            await interaction.deferUpdate().catch(() => {});
            await interaction.message.delete().catch(() => {});

            const containerV = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:emoji_166:1541613481646882987> ╺ Valor da negociação\n<@${data.enviador}> ou <@${data.recebedor}> — **qualquer um** pode digitar no chat o **valor total** da transação (ex.: \`80,50\` ou \`125.50\`).\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\nDepois, **ambos** devem confirmar na mensagem seguinte (**Confirmar valor**).`));
            data.msgValor = await interaction.channel.send({ components: [containerV], flags: MessageFlags.IsComponentsV2 });

            data.colValor?.stop();
            const colV = interaction.channel.createMessageCollector({ filter: m => data.participantes.includes(m.author.id) });
            data.colValor = colV;
            colV.on('collect', async m => {
                if (data.colValor !== colV || data.lockValor) return;
                const valorNumerico = sanitizarValor(m.content);
                if (valorNumerico <= 0) return interaction.channel.send({ content: `<@${m.author.id}> ❌ Valor inválido. Digite novamente o valor (ex: 1.000 ou 50,00).` });
                data.lockValor = true;
                data.valor = valorNumerico.toString(); colV.stop(); data.colValor = null;

                await data.msgValor?.delete().catch(() => {});
                data.msgValor = null;
                await m.delete().catch(() => {});

                const containerI = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:emoji_166:1541613481646882987>╺ Itens da negociação\n<@${data.enviador}> ou <@${data.recebedor}> — **qualquer um** pode digitar no chat o **item / produto** que você enviará.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\nDepois, **ambos** devem confirmar na mensagem seguinte (**Confirmar itens**).`));
                data.msgItem = await interaction.channel.send({ components: [containerI], flags: MessageFlags.IsComponentsV2 });

                data.colItem?.stop();
                const colI = interaction.channel.createMessageCollector({ filter: m => data.participantes.includes(m.author.id), max: 1 });
                data.colItem = colI;
                colI.on('collect', async m2 => {
                    if (data.colItem !== colI || data.lockItem) return;
                    data.lockItem = true;
                    data.item = m2.content; data.colItem = null;

                    await data.msgItem?.delete().catch(() => {});
                    data.msgItem = null;
                    await m2.delete().catch(() => {});

                    const taxaEstimada = calcularTaxaBase(data.valor, data.tipoTaxa);
                    const containerTaxa = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:parceria:1485054250429054986> ╺ Escolha o pagador da taxa\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n> Selecione corretamente o pagador da taxa. Caso o vendedor seja o pagador, ele receberá o valor total menos a taxa.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Taxa da MM:** R$ ${taxaEstimada.toFixed(2)}\n**Comprador:** <@${data.enviador}>\n**Vendedor:** <@${data.recebedor}>`))
                        .addActionRowComponents(new ActionRowBuilder().addComponents(
                            new ButtonBuilder().setCustomId('taxa_comprador').setLabel('Comprador').setEmoji('<:emoji_165:1499214852990832671>').setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId('taxa_dividir').setLabel('Dividir taxa').setEmoji('<:emoji_166:1541614807621443604>').setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId('taxa_vendedor').setLabel('Vendedor').setEmoji('<:emoji_164:1541612138756579439>').setStyle(ButtonStyle.Secondary)
                        ));
                    data.msgTaxa = await interaction.channel.send({ components: [containerTaxa], flags: MessageFlags.IsComponentsV2 });
                });
            });
        } else {
            await interaction.update({ components: [construirContainerFuncoes(data)], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        }
    }

    if (interaction.isButton() && ['taxa_comprador', 'taxa_dividir', 'taxa_vendedor'].includes(interaction.customId)) {
        if (!data) { return await interaction.reply({ content: "❌ Os dados deste ticket não foram encontrados ou a sessão expirou. Por favor, reabra a mediação.", flags: [MessageFlags.Ephemeral] }).catch(() => {}); }
        data.pagadorTaxa = interaction.customId.replace('taxa_', ''); // 'comprador' | 'dividir' | 'vendedor'
        await interaction.deferUpdate().catch(() => {});
        await interaction.message.delete().catch(() => {});
        data.msgTaxa = null;

        const labelPagador = { comprador: '<:emoji_165:1499214852990832671> Comprador', dividir: '<:emoji_166:1541614807621443604> Dividida entre ambos', vendedor: '<:emoji_164:1541612138756579439> Vendedor' }[data.pagadorTaxa];
        const containerF = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:parceria:1485054250429054986> — Confirmação Final\n<@${data.enviador}> <@${data.recebedor}>\nAmbas as partes devem confirmar se os dados abaixo estão corretos. Após a confirmação de ambos, o pagamento será gerado.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n<:emoji_165:1499214852990832671> **Enviador:** <@${data.enviador}>\n<:emoji_170:1505047772049702932> **Recebedor:** <@${data.recebedor}>\n<:emoji_165:1499214852990832671>  **Valor PIX:** R$ ${data.valor}\n<:emoji_171:1505047910667259924> **Itens/Serviço:** ${data.item}\n💰 **Pagador da Taxa:** ${labelPagador}\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Status:**\n⏳ <@${data.enviador}> Aguardando...\n⏳ <@${data.recebedor}> Aguardando...`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('confirm_trade').setLabel('Confirmar tudo').setStyle(ButtonStyle.Secondary), new ButtonBuilder().setCustomId('resetar_fluxo').setLabel('Tentar novamente').setStyle(ButtonStyle.Secondary)));
        await interaction.channel.send({ components: [containerF], flags: MessageFlags.IsComponentsV2 });
    }

    if (interaction.isButton() && interaction.customId === 'confirm_trade') {
        if (!data) { return await interaction.reply({ content: "❌ Os dados deste ticket não foram encontrados ou a sessão expirou. Por favor, reabra a mediação.", flags: [MessageFlags.Ephemeral] }).catch(() => {}); } if (data.confirmacoes.includes(interaction.user.id)) return await interaction.reply({ content: "Você já confirmou!", flags: [MessageFlags.Ephemeral] });
        data.confirmacoes.push(interaction.user.id);
        const statusE = data.confirmacoes.includes(data.enviador) ? `✅ <@${data.enviador}> Confirmou` : `⏳ <@${data.enviador}> Aguardando...`;
        const statusR = data.confirmacoes.includes(data.recebedor) ? `✅ <@${data.recebedor}> Confirmou` : `⏳ <@${data.recebedor}> Aguardando...`;
        const labelPagadorAtual = { comprador: '💳 Comprador', dividir: '<:emoji_166:1541614807621443604> Dividida entre ambos', vendedor: '🌿 Vendedor' }[data.pagadorTaxa] || '💳 Comprador';
        const container = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:parceria:1485054250429054986> — Confirmação Final\n<@${data.enviador}> <@${data.recebedor}>\nAmbas as partes devem confirmar se os dados abaixo estão corretos.\nApós a confirmação de ambos, o pagamento será gerado.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n<:emoji_165:1499214852990832671> **Enviador:** <@${data.enviador}>\n<:emoji_170:1505047772049702932> **Recebedor:** <@${data.recebedor}>\n<:emoji_165:1499214852990832671>  **Valor PIX:** R$ ${data.valor}\n<:emoji_171:1505047910667259924> **Itens/Serviço:** ${data.item}\n💰 **Pagador da Taxa:** ${labelPagadorAtual}\n\u200B\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Status:**\n${statusE}\n${statusR}`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('confirm_trade').setLabel('Confirmar tudo').setStyle(ButtonStyle.Secondary), new ButtonBuilder().setCustomId('resetar_fluxo').setLabel('Tentar novamente').setStyle(ButtonStyle.Secondary)));
        await interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        if (data.confirmacoes.length === 2) {
            const fetched = await interaction.channel.messages.fetch({ limit: 100 });
            if (fetched) await interaction.channel.bulkDelete(fetched.filter(m => !m.pinned));
            await interaction.channel.send({ content: `${EMOJI_CHECK} — **Ambas as partes confirmaram a negociação!**` });
            setTimeout(async () => {
                const containerRes = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`Midldleman imediato aqui!! <@&${CARGO_STAFF_ID}>\n\n# <:parce:1442163891462344798> | Resumo do Middleman\nConsulte este resumo do negócio para quaisquer reafirmações.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Enviador:** <@${data.enviador}>\n**Recebedor:** <@${data.recebedor}>\n**Valor:** R$ ${data.valor}\n**Itens:** ${data.item}\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('btn_reivindicar').setLabel('Reivindicar').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId('btn_fechar').setLabel('Cancelar').setStyle(ButtonStyle.Danger)));
                await interaction.channel.send({ components: [containerRes], flags: MessageFlags.IsComponentsV2 });
            }, 1500);
        }
    }

    if (interaction.isButton() && interaction.customId === 'btn_reivindicar') {
        if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return await interaction.reply({ content: "❌ Apenas a staff pode reivindicar!", flags: [MessageFlags.Ephemeral] });
        if (!data) return await interaction.reply({ content: "❌ Os dados desse ticket foram perdidos. Peça pro cliente clicar em 'Resetar' ou reabrir o fluxo.", flags: [MessageFlags.Ephemeral] });
        if (data.staffReivindicou) return await interaction.reply({ content: "❌️ | Esse mm já foi Assumido", flags: [MessageFlags.Ephemeral] });

        const config = pixConfig.get(interaction.user.id);
        if (!config) return await interaction.reply({ content: " ❌ Você não configurou seu PIX! Use `/configpix` primeiro.", flags: [MessageFlags.Ephemeral] });

        const vCheck = parseFloat(data.valor) || 0;
        if (config.limite && config.limite > 0 && vCheck > config.limite) {
            const limiteFormatado = config.limite.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
            return await interaction.reply({ content: `❌ Essa negociação é de **R$ ${vCheck.toFixed(2)}**, mas seu limite atual de mediação é **R$ ${limiteFormatado}**.\nPeça pra um staff com limite maior assumir, ou fale com um admin pra aumentar seu limite.`, flags: [MessageFlags.Ephemeral] });
        }

        data.staffReivindicou = interaction.user.id;
        saveTradeDataToDisk();

        const v = parseFloat(data.valor) || 0;
        let taxa = calcularTaxaBase(v, data.tipoTaxa);

        const mE = await interaction.guild.members.fetch(data.enviador).catch(() => null);
        const mR = await interaction.guild.members.fetch(data.recebedor).catch(() => null);
        if (mE?.roles.cache.has(CARGO_AFILIADO_ID) || mR?.roles.cache.has(CARGO_AFILIADO_ID)) taxa /= 2;

        data.taxaValor = taxa;
        const pagador = data.pagadorTaxa || 'comprador';
        // comprador: comprador paga v + taxa cheia | dividir: comprador paga v + metade da taxa | vendedor: comprador paga só v
        const totalCobradoComprador = pagador === 'vendedor' ? v : (pagador === 'dividir' ? v + taxa / 2 : v + taxa);
        const total = totalCobradoComprador.toFixed(2);
        const pixId = Date.now().toString();

        const pixPayload = gerarPix(config.chave, config.nome, total);
        pixStorage.set(pixId, { payload: pixPayload, total });

        const containerOriginal = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`Midldleman imediato aqui!! <@&${CARGO_STAFF_ID}>\n\n# <:parce:1442163891462344798> | Resumo do Middleman\nConsulte este resumo do negócio para quaisquer reafirmações.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Enviador:** <@${data.enviador}>\n**Recebedor:** <@${data.recebedor}>\n**Valor:** R$ ${data.valor}\n**Itens:** ${data.item}\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('btn_reivindicar_disabled').setLabel(`Assumido por ${interaction.user.username}`).setStyle(ButtonStyle.Secondary).setDisabled(true), new ButtonBuilder().setCustomId('btn_fechar').setLabel('Cancelar').setStyle(ButtonStyle.Danger)));
        await interaction.update({ components: [containerOriginal], flags: MessageFlags.IsComponentsV2 });
        await interaction.channel.send({ content: `> ${EMOJI_CHECK} ╺╸ Opa! O Middleman <@${interaction.user.id}> assumiu a mediação deste ticket.` });

        // Enviar log de reivindicação para o canal de logs da staff
        const embedLogClaim = new EmbedBuilder()
            .setColor(0xDE4548)
            .setTitle('🛡️ Ticket Reivindicado')
            .setDescription(`O staff <@${interaction.user.id}> assumiu a mediação deste ticket.`)
            .addFields(
                { name: 'Staff Responsável', value: `<@${interaction.user.id}> (\`${interaction.user.tag || interaction.user.username}\`)`, inline: true },
                { name: 'Ticket', value: `<#${interaction.channel.id}>`, inline: true },
                { name: 'Valor', value: `R$ ${v.toFixed(2)}`, inline: true },
                { name: 'Comprador', value: `<@${data.enviador}>`, inline: true },
                { name: 'Vendedor', value: `<@${data.recebedor}>`, inline: true },
                { name: 'Itens', value: `${data.item || 'Não informado'}` }
            )
            .setFooter({ text: `Ticket ID: ${interaction.channel.id}` })
            .setTimestamp();
        await enviarLog(interaction.guild, embedLogClaim).catch(console.error);

        setTimeout(async () => {
            const botoesPagamento = [
                new ButtonBuilder().setCustomId(`qr_${pixId}`).setLabel('QR Code').setEmoji('📷').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`copy_${pixId}`).setLabel('Copia e Cola').setEmoji('📋').setStyle(ButtonStyle.Secondary)
            ];
            if (data.pagadorTaxa === 'dividir') {
                botoesPagamento.push(new ButtonBuilder().setCustomId(`dividirtaxa_${pixId}`).setLabel('Dividir Taxa').setEmoji('<:emoji_166:1541614807621443604>').setStyle(ButtonStyle.Secondary));
            }
            botoesPagamento.push(new ButtonBuilder().setCustomId('btn_recebi_valor').setLabel('Confirmei Recebimento (Staff)').setStyle(ButtonStyle.Success));

            const containerPix = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`<@${data.enviador}>\n\n## <:parceria:1485054250429054986> ╺╸ MM Automático - Pagamento PIX\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n> ${config.nome} Deve pagar o valor de **R$ ${total}**.\n> A troca é automática sem intervenção humana, caso haja problemas há um botão de disputa.\n\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n* <:emoji_164:1498773852585463929> **Valor da Transação:** R$ ${v.toFixed(2)}\n* <:emoji_151:1487942140037304370> **Taxa da MM:** R$ ${taxa.toFixed(2)}\n* <:emoji_164:1498773734402556095> **Detalhes do Pedido:** ${data.item}\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n\n**Total a Pagar:** R$ ${total}`)).addActionRowComponents(new ActionRowBuilder().addComponents(...botoesPagamento));
            await interaction.channel.send({ components: [containerPix], flags: MessageFlags.IsComponentsV2 });
        }, 2000);
    }

    // ── Dividir Taxa ──
    // O comprador já embutiu a metade da taxa no PIX principal (botão "Copia e Cola").
    // Este botão gera um segundo PIX (payload + QR), só com a metade da taxa,
    // pra mesma chave do middleman que reivindicou o ticket, pro vendedor mandar essa parte.
    if (interaction.isButton() && interaction.customId.startsWith('dividirtaxa_')) {
        if (!data) return await interaction.reply({ content: "❌ Dados desse ticket foram perdidos.", flags: [MessageFlags.Ephemeral] });

        const pixIdOriginal = interaction.customId.replace('dividirtaxa_', '');

        let taxaTotal = data.taxaValor;

        // Fallback: se por algum motivo taxaValor não foi salvo (ex: bot reiniciou), recalcula na hora
        if (!taxaTotal) {
            const v = parseFloat(data.valor) || 0;
            taxaTotal = calcularTaxaBase(v, data.tipoTaxa);

            try {
                const mE = await interaction.guild.members.fetch(data.enviador).catch(() => null);
                const mR = await interaction.guild.members.fetch(data.recebedor).catch(() => null);
                if (mE?.roles.cache.has(CARGO_AFILIADO_ID) || mR?.roles.cache.has(CARGO_AFILIADO_ID)) taxaTotal /= 2;
            } catch (e) {}

            data.taxaValor = taxaTotal;
            console.log(`[dividirtaxa] taxaValor estava vazio no ticket ${interaction.channelId}, recalculado: ${taxaTotal}`);
        }

        const metade = (taxaTotal / 2).toFixed(2);

        const configStaff = pixConfig.get(data.staffReivindicou);
        if (!configStaff) {
            return await interaction.reply({ content: "❌ O Middleman responsável não tem PIX configurado, não dá pra gerar a cobrança da metade da taxa.", flags: [MessageFlags.Ephemeral] });
        }

        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] }).catch(() => {});

        try {
            const pixMetadeId = `${pixIdOriginal}_metade`;
            const pixPayloadMetade = gerarPix(configStaff.chave, configStaff.nome, metade);
            pixStorage.set(pixMetadeId, { payload: pixPayloadMetade, total: metade });

            const rowMetade = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`qr_${pixMetadeId}`).setLabel('QR Code (metade)').setEmoji('📷').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`copy_${pixMetadeId}`).setLabel('Copia e Cola (metade)').setEmoji('📋').setStyle(ButtonStyle.Secondary)
            );

            await interaction.editReply({
                content: `🌙 **Taxa dividida entre as partes**\n> Taxa total: R$ ${taxaTotal.toFixed(2)}\n\n<@${data.enviador}> já pagou **R$ ${metade}** de taxa a mais no PIX principal.\n<@${data.recebedor}> precisa mandar **R$ ${metade}** pro Middleman (pix abaixo) referente à sua parte da taxa.`,
                components: [rowMetade]
            });
        } catch (err) {
            console.error("Erro ao gerar PIX da metade da taxa:", err);
            await interaction.editReply({ content: "❌ Não consegui gerar o PIX da metade da taxa. Tenta de novo." }).catch(() => {});
        }
    }

    if (interaction.isButton() && interaction.customId === 'btn_recebi_valor') {
        if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return await interaction.reply({ content: "❌ Apenas a staff pode confirmar recebimento!", flags: [MessageFlags.Ephemeral] });
        if (!data) return await interaction.reply({ content: "❌ Dados desse ticket foram perdidos.", flags: [MessageFlags.Ephemeral] });
        if (data.staffReivindicou && data.staffReivindicou !== interaction.user.id && !interaction.member?.permissions?.has(PermissionFlagsBits.Administrator)) {
            return await interaction.reply({ content: "Apenas o staff que reivindicou pode confirmar!", flags: [MessageFlags.Ephemeral] });
        }
        if (data.pagamentoConfirmado) {
            return await interaction.reply({ content: "ℹ️ O recebimento já foi confirmado anteriormente.", flags: [MessageFlags.Ephemeral] });
        }

        data.pagamentoConfirmado = true;
        saveTradeDataToDisk();

        // Atualizar o botão na mensagem original para desabilitar
        try {
            if (interaction.message && interaction.message.components && interaction.message.components.length > 0) {
                const rowOriginal = ActionRowBuilder.from(interaction.message.components[0]);
                for (const comp of rowOriginal.components) {
                    if (comp.data.custom_id === 'btn_recebi_valor') {
                        comp.setDisabled(true).setLabel(`Recebido por ${interaction.user.username}`).setStyle(ButtonStyle.Secondary);
                    }
                }
                await interaction.update({ components: [rowOriginal], flags: MessageFlags.IsComponentsV2 }).catch(async () => {
                    await interaction.update({ components: [rowOriginal] }).catch(() => {});
                });
            } else {
                await interaction.reply({ content: "✅ Recebimento confirmado pelo staff.", flags: [MessageFlags.Ephemeral] });
            }
        } catch (e) {
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({ content: "✅ Recebimento confirmado pelo staff.", flags: [MessageFlags.Ephemeral] }).catch(() => {});
            }
        }

        // Log de confirmação de pagamento do comprador para staff logs
        const embedLogPagamento = new EmbedBuilder()
            .setColor(0xDE4548)
            .setTitle('💰 Pagamento do Comprador Confirmado (Staff)')
            .setDescription(`O staff <@${interaction.user.id}> confirmou o recebimento do PIX do comprador.`)
            .addFields(
                { name: 'Staff', value: `<@${interaction.user.id}>`, inline: true },
                { name: 'Ticket', value: `<#${interaction.channel.id}>`, inline: true },
                { name: 'Valor', value: `R$ ${parseFloat(data.valor || 0).toFixed(2)}`, inline: true },
                { name: 'Comprador', value: `<@${data.enviador}>`, inline: true },
                { name: 'Vendedor', value: `<@${data.recebedor}>`, inline: true }
            )
            .setFooter({ text: `Ticket ID: ${interaction.channel.id}` })
            .setTimestamp();
        await enviarLog(interaction.guild, embedLogPagamento).catch(console.error);

        const containerT = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ⚠️ PIX RECEBIDO - INICIAR TROCA\nO Middleman já está com o dinheiro em mãos.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Instruções:**\n• O vendedor deve entregar o item agora.\n• Após a entrega, ambos cliquem no botão abaixo.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('confirmar_entrega_user').setLabel('Confirmar Entrega').setEmoji('✅').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId('btn_fechar').setLabel('Fechar Ticket').setStyle(ButtonStyle.Danger)));
        await interaction.channel.send({ components: [containerT], flags: MessageFlags.IsComponentsV2 });
    }

    if (interaction.isButton() && interaction.customId === 'confirmar_entrega_user') {
        if (!data) { return await interaction.reply({ content: "❌ Os dados deste ticket não foram encontrados ou a sessão expirou. Por favor, reabra a mediação.", flags: [MessageFlags.Ephemeral] }).catch(() => {}); } if (interaction.user.id !== data.enviador && interaction.user.id !== data.recebedor) return await interaction.reply({ content: "Você não é participante da trade!", flags: [MessageFlags.Ephemeral] });
        if (data.confirmacoesEntrega.includes(interaction.user.id)) return await interaction.reply({ content: "Você já confirmou!", flags: [MessageFlags.Ephemeral] });
        data.confirmacoesEntrega.push(interaction.user.id);
        if (data.confirmacoesEntrega.length === 2) {
            const containerM = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`<@${data.recebedor}>\n\n# Selecione o tipo de chave PIX\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\nEscolha abaixo o tipo de chave que você deseja utilizar para receber o pagamento do staff.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('selecionar_tipo_pix').setPlaceholder('Clique aqui para selecionar o tipo...').addOptions([{ label: 'Celular', value: 'celular', emoji: '📱' }, { label: 'CPF/CNPJ', value: 'cpf_cnpj', emoji: '👤' }, { label: 'E-mail', value: 'email', emoji: '📧' }, { label: 'Chave Aleatória', value: 'aleatoria', emoji: '🆔' }, { label: 'USDT Wallet', value: 'usdt', emoji: '🪙' }])));
            await interaction.channel.send({ components: [containerM], flags: MessageFlags.IsComponentsV2 });
        } else { await interaction.reply({ content: `${EMOJI_CHECK} — <@${interaction.user.id}> confirmou a entrega. Aguardando a outra parte.` }); }
    }

    if (interaction.isStringSelectMenu() && interaction.customId === 'selecionar_tipo_pix') {
        if (!data || interaction.user.id !== data.recebedor) {
            return await interaction.reply({
                content: "❌ | Apenas o recebedor pode fornecer a chave PIX.",
                flags: [MessageFlags.Ephemeral]
            });
        }

        const tipo = String(interaction.values[0] || 'pix').toLowerCase();
        const nomesTipo = {
            celular: 'celular',
            cpf_cnpj: 'CPF/CNPJ',
            email: 'e-mail',
            aleatoria: 'aleatória',
            usdt: 'USDT Wallet'
        };
        const nomeTipo = nomesTipo[tipo] || 'PIX';

        try {
            const modal = new ModalBuilder()
                .setCustomId(`modal_chave_final_${tipo}`)
                .setTitle(`Chave PIX: ${nomeTipo.toUpperCase()}`)
                .addComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('chave_input')
                            .setLabel(`Digite sua chave ${nomeTipo}`)
                            .setPlaceholder(`Informe sua chave ${nomeTipo}`)
                            .setStyle(TextInputStyle.Short)
                            .setRequired(true)
                            .setMaxLength(200)
                    ),
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('nome_input')
                            .setLabel('Nome do recebedor')
                            .setPlaceholder('Nome que aparecerá no pagamento PIX')
                            .setStyle(TextInputStyle.Short)
                            .setRequired(true)
                            .setMaxLength(25)
                    )
                );

            return await interaction.showModal(modal);
        } catch (erroModal) {
            console.error('Erro ao abrir modal da chave PIX:', erroModal);
            if (!interaction.replied && !interaction.deferred) {
                return await interaction.reply({
                    content: '❌ Não foi possível abrir o formulário da chave PIX. Tente novamente.',
                    flags: [MessageFlags.Ephemeral]
                });
            }
        }
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith('modal_chave_final_')) {
        if (!data) {
            return await interaction.reply({ content: "❌ Os dados desse ticket foram perdidos. Reabra o fluxo da negociação.", flags: [MessageFlags.Ephemeral] });
        }

        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

        try {
            const chave = interaction.fields.getTextInputValue('chave_input')?.trim();
            const nomeRecebedor = interaction.fields.getTextInputValue('nome_input')?.trim();
            if (!chave) return await interaction.editReply("❌ A chave PIX não pode ficar vazia.");
            if (!nomeRecebedor) return await interaction.editReply("❌ O nome do recebedor não pode ficar vazio.");

            if (!data.staffReivindicou) {
                console.error("Staff não definido no ticket:", interaction.channelId);
                return await interaction.editReply("❌ O staff responsável não foi encontrado. Peça para a staff reivindicar o ticket novamente.");
            }

            const staff = await client.users.fetch(data.staffReivindicou).catch(err => {
                console.error("Erro ao buscar staff:", err);
                return null;
            });

            const vRecebedor = parseFloat(data.valor) || 0;
            const taxaRegistrada = data.taxaValor || 0;
            const pagadorAtual = data.pagadorTaxa || 'comprador';
            const valorPagarNumerico = pagadorAtual === 'vendedor' ? (vRecebedor - taxaRegistrada) : (pagadorAtual === 'dividir' ? (vRecebedor - taxaRegistrada / 2) : vRecebedor);
            const valorPagar = Math.max(0, valorPagarNumerico).toFixed(2);
            const chaveId = `${Date.now()}_${interaction.user.id}`;
            const pixIdFinal = `${chaveId}f`;
            const pixPayloadFinal = gerarPix(chave, nomeRecebedor, valorPagar);
            let qrBuffer = null;
            try {
                qrBuffer = await QRCode.toBuffer(pixPayloadFinal, {
                    type: 'png',
                    width: 700,
                    margin: 2,
                    errorCorrectionLevel: 'M'
                });
            } catch (erroQR) {
                console.error('Falha ao gerar QR Code; seguindo com copia e cola:', erroQR);
            }
            const qrFileName = `pix-${pixIdFinal}.png`;

            chaveFinalStorage.set(chaveId, chave);
            pixStorage.set(pixIdFinal, { payload: pixPayloadFinal, total: valorPagar });

            const paymentRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`copy_${pixIdFinal}`).setLabel('Copia e Cola').setEmoji('📋').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`copychave_${chaveId}`).setLabel('Copiar Chave PIX').setEmoji('📋').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('btn_paguei_vendedor').setLabel('Confirmei o pagamento ao Vendedor').setStyle(ButtonStyle.Success)
            );

            const notaTaxaVendedor = pagadorAtual === 'vendedor'
                ? `\n> 💰 Taxa de **R$ ${taxaRegistrada.toFixed(2)}** já descontada (vendedor ficou responsável pela taxa).`
                : pagadorAtual === 'dividir'
                    ? `\n> 💰 Metade da taxa (**R$ ${(taxaRegistrada / 2).toFixed(2)}**) já descontada (taxa dividida entre as partes).`
                    : '';
            const embedPagamento = new EmbedBuilder()
                .setColor(0xDE4548)
                .setTitle('<:ravisoshelt:1439092081024041063> PAGAMENTO PENDENTE')
                .setDescription(
                    `**O administrador deve pagar este valor ao recebedor.**\n\n` +
                    `**Recebedor:** ${nomeRecebedor} (<@${interaction.user.id}>)\n` +
                    `**Chave PIX:** \`${chave}\`\n` +
                    `**Valor exato a pagar:** **R$ ${valorPagar}**${notaTaxaVendedor}\n\n` +
                    `Escaneie o QR Code ou use o Pix copia e cola abaixo. Confirme o recebimento somente depois de conferir o valor.`
                )
                .addFields({ name: 'PIX copia e cola', value: `\`${pixPayloadFinal}\`` })
                .setFooter({ text: 'Confira o valor antes de realizar o pagamento.' });
            if (qrBuffer) embedPagamento.setImage(`attachment://${qrFileName}`);

            const embedLogChave = new EmbedBuilder()
                .setColor(0xDE4548)
                .setTitle('Chave Pix Fornecida')
                .setDescription(`Vendedor: <@${interaction.user.id}>\nChave: ${chave}\nPara: ${staff?.username || data.staffReivindicou}`)
                .addFields(
                    { name: 'Chave PIX informada', value: `\`${chave}\`` },
                    { name: 'Nome do recebedor', value: nomeRecebedor, inline: true },
                    { name: 'Recebedor', value: `<@${interaction.user.id}>`, inline: true },
                    { name: 'Staff responsável', value: `<@${data.staffReivindicou}>`, inline: true },
                    { name: 'Ticket', value: `<#${interaction.channel.id}>`, inline: true },
                    { name: 'Valor a pagar', value: `R$ ${valorPagar}`, inline: true }
                )
                .setFooter({ text: `Ticket ID: ${interaction.channel.id}` })
                .setTimestamp();

            const logEnviado = await enviarLog(interaction.guild, embedLogChave).catch(erroLog => {
                console.error('Falha ao enviar log da chave PIX; continuando o pagamento:', erroLog);
                return false;
            });
            if (!logEnviado) console.warn('Cobrança PIX publicada sem confirmação do log.');

            try {
                await interaction.channel.send({
                    content: `<@${data.enviador}> <@${data.recebedor}> <@${data.staffReivindicou}>`,
                    embeds: [embedPagamento],
                    components: [paymentRow],
                    ...(qrBuffer ? { files: [new AttachmentBuilder(qrBuffer, { name: qrFileName })] } : {})
                });

                await interaction.message?.delete().catch(() => {});
            } catch (erroCanal) {
                console.error('Não foi possível publicar a cobrança no ticket:', erroCanal);
                return await interaction.editReply('❌ Não foi possível publicar a cobrança no ticket. Tente novamente ou avise a staff.');
            }

            await interaction.editReply({
                content: `${EMOJI_CHECK} Chave enviada com sucesso ao Staff!`,
                flags: [MessageFlags.Ephemeral]
            });
        } catch (err) {
            console.error("Erro ao processar chave PIX:", err);
            await interaction.editReply("❌ Ocorreu um erro ao processar essa chave PIX. Tente novamente ou avise a staff.").catch(console.error);
        }
    }

    if (interaction.isButton() && interaction.customId === 'btn_paguei_vendedor') {
        if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return await interaction.reply({ content: "❌ Apenas a staff pode confirmar pagamento ao vendedor!", flags: [MessageFlags.Ephemeral] });
        if (!data) return await interaction.reply({ content: "❌ Dados deste ticket foram perdidos.", flags: [MessageFlags.Ephemeral] });
        if (data.staffReivindicou && data.staffReivindicou !== interaction.user.id && !interaction.member?.permissions?.has(PermissionFlagsBits.Administrator)) {
            return await interaction.reply({ content: "Apenas o staff que reivindicou pode finalizar a mediação!", flags: [MessageFlags.Ephemeral] });
        }
        if (data.pagamentoVendedorConfirmado) {
            return await interaction.reply({ content: "ℹ️ O pagamento ao vendedor já foi confirmado.", flags: [MessageFlags.Ephemeral] });
        }

        data.pagamentoVendedorConfirmado = true;
        saveTradeDataToDisk();

        // Desabilitar o botão na mensagem de pagamento ao vendedor
        try {
            if (interaction.message && interaction.message.components && interaction.message.components.length > 0) {
                const rowOriginal = ActionRowBuilder.from(interaction.message.components[0]);
                for (const comp of rowOriginal.components) {
                    if (comp.data.custom_id === 'btn_paguei_vendedor') {
                        comp.setDisabled(true).setLabel(`Pago ao Vendedor por ${interaction.user.username}`).setStyle(ButtonStyle.Secondary);
                    }
                }
                await interaction.update({ components: [rowOriginal] }).catch(() => {});
            } else {
                await interaction.reply({ content: "✅ Pagamento ao vendedor confirmado.", flags: [MessageFlags.Ephemeral] }).catch(() => {});
            }
        } catch (e) {
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({ content: "✅ Pagamento ao vendedor confirmado.", flags: [MessageFlags.Ephemeral] }).catch(() => {});
            }
        }

        let transacaoIdFinal = null;
        try {
            const enviadorU = await client.users.fetch(data.enviador).catch(() => null);
            const recebedorU = await client.users.fetch(data.recebedor).catch(() => null);
            const staffMediadorU = await client.users.fetch(data.staffReivindicou || interaction.user.id).catch(() => null);
            if (enviadorU && recebedorU && staffMediadorU) {
                transacaoIdFinal = await executarAprovarPagamento(interaction.guild, staffMediadorU, "pix", enviadorU, recebedorU, parseFloat(data.valor || 0));
                data.vouchGerado = true;
                saveTradeDataToDisk();
            }
        } catch (err) {
            console.error("Erro ao registrar proof automática em btn_paguei_vendedor:", err);
        }

        const messages = await interaction.channel.messages.fetch({ limit: 100 }).catch(() => new Map());
        const transcript = Array.from(messages.values()).reverse().map(m => `[${m.createdAt ? m.createdAt.toLocaleString() : ''}] ${m.author ? m.author.tag : 'User'}: ${m.content}`).join('\n');

        const v = parseFloat(data.valor || 0);
        let taxa = data.taxaValor || calcularTaxaBase(v, data.tipoTaxa);

        // Enviar log de encerramento para o canal de logs da staff
        const embedLogEncerrado = new EmbedBuilder()
            .setColor('#DE4548')
            .setTitle('Middle encerrado com Sucesso (Logs)')
            .addFields(
                { name: 'Administrador / MM', value: `<@${interaction.user.id}>` },
                { name: 'Canal', value: `#${interaction.channel.name}` },
                { name: 'Valor', value: `R$ ${v.toFixed(2)}`, inline: true },
                { name: 'Taxa', value: `R$ ${taxa.toFixed(2)}`, inline: true },
                { name: 'Transação ID', value: `${transacaoIdFinal || 'MM-' + Date.now()}`, inline: true }
            )
            .setTimestamp();
        await enviarLog(interaction.guild, embedLogEncerrado, [new AttachmentBuilder(Buffer.from(transcript), { name: `transcript-${interaction.channel.name}.txt` })]).catch(console.error);

        const pendingId = gerarIdAvaliacao();
        avaliacoesPendentes.set(pendingId, {
            enviador: data.enviador,
            recebedor: data.recebedor,
            valor: v,
            item: data.item,
            staffId: data.staffReivindicou || interaction.user.id,
            transacaoId: transacaoIdFinal || pendingId,
            transcript,
            avaliacoes: {}
        });
        saveAvaliacoesPendentes();

        const protocoloResumo = transacaoIdFinal || pendingId;
        const dataFechamentoTxt = new Date().toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" });

        const containerResumo = new ContainerBuilder().setAccentColor(0x5865F2).addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `## 📋 Resumo do Ticket Encerrado\n` +
                `**Protocolo:** ${protocoloResumo}\n` +
                `**Valor:** R$ ${v.toFixed(2)}\n` +
                `**Servidor:** ${interaction.guild.name}\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `**Comprador:** <@${data.enviador}>\n` +
                `**Vendedor:** <@${data.recebedor}>\n` +
                `**Intermediador:** <@${data.staffReivindicou || interaction.user.id}>\n\n` +
                `✅ **Ticket encerrado com sucesso.**\n` +
                `🗓️ ${dataFechamentoTxt}\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `📄 **Transcrição**\n` +
                `-# Histórico completo das mensagens deste ticket.`
            )
        ).addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`abrir_transcript_${pendingId}`).setLabel('Abrir transcrição').setEmoji('📄').setStyle(ButtonStyle.Secondary)
            )
        );

        const containerEstrelas = new ContainerBuilder().setAccentColor(0xf2a20e).addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`# ⭐ Avalie o Atendimento ⭐\nPor favor, avalie a mediação que você recebeu!`)
        ).addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`av_1_${pendingId}`).setEmoji('⭐').setLabel('1').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`av_2_${pendingId}`).setEmoji('⭐').setLabel('2').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`av_3_${pendingId}`).setEmoji('⭐').setLabel('3').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`av_4_${pendingId}`).setEmoji('⭐').setLabel('4').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`av_5_${pendingId}`).setEmoji('⭐').setLabel('5').setStyle(ButtonStyle.Success)
            )
        );

        // Enviar no PV (DM) dos participantes em Components V2
        for (const uid of [data.enviador, data.recebedor]) {
            try {
                const userDM = await client.users.fetch(uid).catch(() => null);
                if (userDM) {
                    await userDM.send({ components: [containerResumo], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
                    await userDM.send({ components: [containerEstrelas], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
                }
            } catch (e) {}
        }

        // Enviar no canal do ticket
        await interaction.channel.send({
            content: `🎉 **Mediação finalizada com sucesso!** <@${data.enviador}> <@${data.recebedor}>\nFechando ticket em 5 segundos...`,
            components: [containerResumo],
            flags: MessageFlags.IsComponentsV2
        }).catch(() => {});

        setTimeout(() => {
            interaction.channel.delete().catch(() => {});
            tradeData.delete(interaction.channelId);
            saveTradeDataToDisk();
        }, 5000);
    }

    if (interaction.isButton() && interaction.customId.startsWith('copychave_')) {
        const chaveId = interaction.customId.replace('copychave_', '');
        const chave = chaveFinalStorage.get(chaveId);
        if (!chave) return await interaction.reply({ content: "❌ Chave expirada ou não encontrada.", flags: [MessageFlags.Ephemeral] });
        await interaction.reply({ content: chave, flags: [MessageFlags.Ephemeral] });
    }

    if (interaction.isButton() && interaction.customId.startsWith('qr_')) {
        const id = interaction.customId.slice(3);
        const item = pixStorage.get(id);
        if (!item) return await interaction.reply({ content: "❌ QR Code expirado ou não encontrado.", flags: [MessageFlags.Ephemeral] });

        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        try {
            const qrBuffer = await QRCode.toBuffer(item.payload, {
                type: "png",
                width: 600,
                margin: 2,
                errorCorrectionLevel: "M"
            });

            const containerQR = new ContainerBuilder()
                .setAccentColor(0xDE4548)
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(
                    `# 📷 Escaneie o QR Code\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `> 💰 **Valor exato a pagar: R$ ${item.total}**`
                ));

            await interaction.editReply({
                content: "Escaneie o QR Code abaixo:",
                components: [containerQR],
                files: [new AttachmentBuilder(qrBuffer, { name: `pix-${id}.png` })],
                flags: MessageFlags.IsComponentsV2
            });
        } catch (err) {
            console.error("Erro ao gerar QR Code PIX:", err);
            await interaction.editReply("❌ Não foi possível gerar o QR Code. Use o botão Copia e Cola.").catch(console.error);
        }
    }

    if (interaction.isButton() && interaction.customId.startsWith('copy_')) {
        const id = interaction.customId.slice(5);
        const item = pixStorage.get(id);
        if (item) await interaction.reply({ content: item.payload, flags: [MessageFlags.Ephemeral] });
    }

    if (interaction.isButton() && interaction.customId === 'btn_termos') {
        const container = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:parceria:1485054250429054986> ╺╸ **Termos e Regras do MM Automático**\n\n**<:discotoolsxyzicon111:1470855659909284104> Segurança em Primeiro Lugar**\nPara garantir a segurança de ambas as partes, siga rigorosamente as instruções abaixo.\n\n**<:discotoolsxyzicon6:1470345157391155301> Para o Vendedor (Quem entrega o item):**\n> **GRAVE TUDO!** Recomendamos fortemente que você grave todo o processo de entrega do produto, desde o momento que inicia a troca até a confirmação de recebimento. Em caso de disputa, essa será sua principal prova.\n\n**<:discotoolsxyzicon28:1470856248122409171> Para o Comprador (Quem paga):**\n> **CONFIRA TUDO!** Verifique se o item recebido é exatamente o combinado antes de confirmar o recebimento no bot. Após confirmado, o dinheiro é liberado automaticamente e não há estorno.\n\n**<:discotoolsxyzicon13:1470342793716174880> Regras Gerais:**\n1. Não tente burlar o sistema de taxas.\n2. Mantenha toda a negociação dentro deste ticket.\n3. O bot não se responsabiliza por erros humanos (ex: enviar item para nick errado).\n4. Em caso de problemas, abra uma **Disputa** imediatamente.`));
        await interaction.reply({ components: [container], flags: [MessageFlags.Ephemeral, MessageFlags.IsComponentsV2] });
    }

    if (interaction.isButton() && interaction.customId === 'resetar_fluxo') {
        const fetched = await interaction.channel.messages.fetch({ limit: 100 }); if (fetched) await interaction.channel.bulkDelete(fetched.filter(m => !m.pinned));
        await iniciarFluxoImagens(interaction.channel);
    }

    if (interaction.isButton() && interaction.customId === 'btn_fechar') {
        await interaction.deferReply().catch(() => {});

        const v = parseFloat(data?.valor || 0);
        let taxa = data?.taxaValor || calcularTaxaBase(v, data?.tipoTaxa);
        try {
            const mE = data?.enviador ? await interaction.guild.members.fetch(data.enviador).catch(() => null) : null;
            const mR = data?.recebedor ? await interaction.guild.members.fetch(data.recebedor).catch(() => null) : null;
            if (mE?.roles.cache.has(CARGO_AFILIADO_ID) || mR?.roles.cache.has(CARGO_AFILIADO_ID)) taxa /= 2;
        } catch (err) {}

        let transacaoIdFinal = null;
        if (data && data.pagamentoConfirmado && !data.vouchGerado && data.enviador && data.recebedor && data.valor) {
            try {
                const enviadorU = await client.users.fetch(data.enviador).catch(() => null);
                const recebedorU = await client.users.fetch(data.recebedor).catch(() => null);
                const staffMediadorU = await client.users.fetch(data.staffReivindicou || interaction.user.id).catch(() => null);
                if (enviadorU && recebedorU && staffMediadorU) {
                    transacaoIdFinal = await executarAprovarPagamento(interaction.guild, staffMediadorU, "pix", enviadorU, recebedorU, parseFloat(data.valor));
                    data.vouchGerado = true;
                    saveTradeDataToDisk();
                }
            } catch (err) {
                console.error("Erro ao registrar proof automática no fechamento:", err);
            }
        }

        const messages = await interaction.channel.messages.fetch({ limit: 100 }).catch(() => new Map());
        const transcript = Array.from(messages.values()).reverse().map(m => `[${m.createdAt ? m.createdAt.toLocaleString() : ''}] ${m.author ? m.author.tag : 'User'}: ${m.content}`).join('\n');

        const embedLogEncerrado = new EmbedBuilder()
            .setColor('#DE4548')
            .setTitle('Middle encerrado (Logs)')
            .addFields(
                { name: 'Administrador / MM', value: `<@${interaction.user.id}>` },
                { name: 'Canal', value: `#${interaction.channel.name}` },
                { name: 'Valor', value: `R$ ${v.toFixed(2)}`, inline: true },
                { name: 'Taxa', value: `R$ ${taxa.toFixed(2)}`, inline: true }
            )
            .setTimestamp();
        await enviarLog(interaction.guild, embedLogEncerrado, [new AttachmentBuilder(Buffer.from(transcript), { name: `transcript-${interaction.channel.name}.txt` })]).catch(console.error);

        if (data && data.enviador && data.recebedor) {
            const pendingId = gerarIdAvaliacao();
            avaliacoesPendentes.set(pendingId, {
                enviador: data.enviador,
                recebedor: data.recebedor,
                valor: v,
                item: data.item,
                staffId: data.staffReivindicou || interaction.user.id,
                transacaoId: transacaoIdFinal || pendingId,
                transcript,
                avaliacoes: {}
            });
            saveAvaliacoesPendentes();

            const protocoloResumo = transacaoIdFinal || pendingId;
            const dataFechamentoTxt = new Date().toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" });

            const containerResumo = new ContainerBuilder().setAccentColor(0x5865F2).addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `## 📋 Resumo do Ticket Encerrado\n` +
                    `**Protocolo:** ${protocoloResumo}\n` +
                    `**Valor:** R$ ${v.toFixed(2)}\n` +
                    `**Servidor:** ${interaction.guild.name}\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `**Comprador:** <@${data.enviador}>\n` +
                    `**Vendedor:** <@${data.recebedor}>\n` +
                    `**Intermediador:** <@${data.staffReivindicou || interaction.user.id}>\n\n` +
                    `✅ **Ticket encerrado com sucesso.**\n` +
                    `🗓️ ${dataFechamentoTxt}\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `📄 **Transcrição**\n` +
                    `-# Histórico completo das mensagens deste ticket.`
                )
            ).addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`abrir_transcript_${pendingId}`).setLabel('Abrir transcrição').setEmoji('📄').setStyle(ButtonStyle.Secondary)
                )
            );

            const containerEstrelas = new ContainerBuilder().setAccentColor(0xf2a20e).addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`# ⭐ Avalie o Atendimento ⭐\nPor favor, avalie a mediação que você recebeu!`)
            ).addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`av_1_${pendingId}`).setEmoji('⭐').setLabel('1').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`av_2_${pendingId}`).setEmoji('⭐').setLabel('2').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`av_3_${pendingId}`).setEmoji('⭐').setLabel('3').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`av_4_${pendingId}`).setEmoji('⭐').setLabel('4').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`av_5_${pendingId}`).setEmoji('⭐').setLabel('5').setStyle(ButtonStyle.Success)
                )
            );

            for (const uid of [data.enviador, data.recebedor]) {
                try {
                    const userDM = await client.users.fetch(uid).catch(() => null);
                    if (userDM) {
                        await userDM.send({ components: [containerResumo], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
                        await userDM.send({ components: [containerEstrelas], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
                    }
                } catch (e) {}
            }
        }

        await interaction.editReply({ content: 'Fechando ticket em 5 segundos...' }).catch(() => {});
        setTimeout(() => {
            interaction.channel.delete().catch(() => {});
            tradeData.delete(interaction.channelId);
            saveTradeDataToDisk();
        }, 5000);
    }
  } catch (err) {
    console.error("❌ [ERRO NÃO TRATADO em interactionCreate]", err);
    const msgErro = { content: "❌ Ocorreu um erro inesperado ao processar essa ação. Tenta de novo — se persistir, avisa a staff.", flags: [MessageFlags.Ephemeral] };
    try {
        if (interaction.replied || interaction.deferred) {
            await interaction.followUp(msgErro).catch(() => {});
        } else {
            await interaction.reply(msgErro).catch(() => {});
        }
    } catch (e) {}
  }
});

async function executarAprovarPagamento(guild, staffUser, tipo, enviadorUser, recebedorUser, valor) {
    registerStaffTrade(staffUser.id, valor, [enviadorUser.id, recebedorUser.id]);

    registerTrade(enviadorUser.id, valor);
    registerTrade(recebedorUser.id, valor);
    globalCounter++;
    saveGlobal();
    if (userData[enviadorUser.id].contador === undefined) userData[enviadorUser.id].contador = 0;
    userData[enviadorUser.id].contador++;
    saveUsers();
    await atualizarCargos(guild, enviadorUser.id);
    await atualizarCargos(guild, recebedorUser.id);
    await atualizarCargos(guild, staffUser.id);
    const valorFormatado = valor.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
    const taxaTotal = calcularTaxa(tipo, valor, enviadorUser.id, recebedorUser.id);
    if (taxaTotal > 0) {
        taxasDiarias[staffUser.id] = (taxasDiarias[staffUser.id] || 0) + taxaTotal;
        saveTaxas();

        if (!userData[staffUser.id]) userData[staffUser.id] = { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
        userData[staffUser.id].taxaMes = (userData[staffUser.id].taxaMes || 0) + taxaTotal;
        userData[staffUser.id].taxaTotal = (userData[staffUser.id].taxaTotal || 0) + taxaTotal;
        saveUsers();
    }

    const transacaoId = `MM-${Date.now()}${Math.floor(Math.random() * 900 + 100)}`;
    const vouchCodigo = `#${String(globalCounter).padStart(5, '0')}`;

    const avaliacoesStaff = userData[staffUser.id]?.avaliacoes || [];
    const notaMedia = avaliacoesStaff.length
        ? avaliacoesStaff.reduce((a, b) => a + b, 0) / avaliacoesStaff.length
        : 5;

    const [staffMember, enviadorMember, recebedorMember] = await Promise.all([
        guild?.members?.fetch(staffUser.id).catch(() => null),
        guild?.members?.fetch(enviadorUser.id).catch(() => null),
        guild?.members?.fetch(recebedorUser.id).catch(() => null)
    ]);

    const staffDisplayName = staffMember?.displayName || staffUser?.username || "Staff";
    const enviadorDisplayName = enviadorMember?.displayName || enviadorUser?.username || "Comprador";
    const recebedorDisplayName = recebedorMember?.displayName || recebedorUser?.username || "Vendedor";

    const canalAlvoId = (tipo === "pix_grande" || valor >= 500) ? CANAL_BIG_TRADE : CANAL_PROOFS;
    const canal = await getCanal(guild, canalAlvoId) || await getCanal(guild, CANAL_PROOFS);
    if (canal) {
        try {
            const buffer = await gerarCartaoVouch({
                staffNome: staffDisplayName,
                staffAvatarURL: staffUser?.displayAvatarURL ? staffUser.displayAvatarURL({ extension: "png", size: 128 }) : null,
                staffNota: notaMedia,
                staffIntermediacoes: userData[staffUser.id]?.totalTrocas || 0,
                transacaoId,
                vouchCodigo,
                valor,
                compradorNome: enviadorDisplayName,
                compradorAvatarURL: enviadorUser?.displayAvatarURL ? enviadorUser.displayAvatarURL({ extension: "png", size: 128 }) : null,
                vendedorNome: recebedorDisplayName,
                vendedorAvatarURL: recebedorUser?.displayAvatarURL ? recebedorUser.displayAvatarURL({ extension: "png", size: 128 }) : null,
                data: new Date().toLocaleDateString("pt-BR")
            });
            const anexoVouch = new AttachmentBuilder(buffer, { name: `vouch-${vouchCodigo.replace('#', '')}.png` });
            await canal.send({
                files: [anexoVouch]
            }).catch(console.error);
            console.log(`[VOUCH] Cartão de vouch enviado com sucesso para #${canal.name} (${canal.id})`);
        } catch (e) {
            console.error("Erro ao gerar cartão de vouch:", e);
        }
    } else {
        console.error(`[VOUCH] Canal de proofs não encontrado (${canalAlvoId} / ${CANAL_PROOFS})`);
    }

    if (taxaTotal > 0) {
        const canalTaxas = await getCanal(guild, CANAL_TAXAS);
        if (canalTaxas) {
            const embedTaxas = new EmbedBuilder().setColor("#DE4548").setTitle("<:0961:1454624137992474644> — Relatório de Intermediação").setDescription(`**ID da Proof:** \`#${globalCounter}\` | Valor: \`R$ ${valorFormatado}\``).addFields({ name: "💰 Taxa Total", value: `\`R$ ${taxaTotal.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}\`` }, { name: "👑 Parte do Dono (50%)", value: `\`R$ ${(taxaTotal / 2).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}\``, inline: true }, { name: "🤝 Parte do Middleman (50%)", value: `\`R$ ${(taxaTotal / 2).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}\``, inline: true });
            await canalTaxas.send({ content: `🔔 <@${staffUser.id}>`, embeds: [embedTaxas] }).catch(() => {});
        }
    }

    return transacaoId;
}

let lastDailyRun = null;
const dbLastMonthlyPath = path.join(__dirname, 'lastMonthlyRun.json');
let lastMonthlyRun = fs.existsSync(dbLastMonthlyPath) ? JSON.parse(fs.readFileSync(dbLastMonthlyPath)) : null;

function saveLastMonthlyRun() { fs.writeFileSync(dbLastMonthlyPath, JSON.stringify(lastMonthlyRun)); }

function checkScheduledTasks() {
    const now = new Date();
    const options = { timeZone: "America/Sao_Paulo", hour: "numeric", minute: "numeric", day: "numeric" };
    const formatter = new Intl.DateTimeFormat("pt-BR", options);
    const parts = formatter.formatToParts(now);
    const hour = parseInt(parts.find(p => p.type === "hour").value);
    const minute = parseInt(parts.find(p => p.type === "minute").value);
    const day = parseInt(parts.find(p => p.type === "day").value);

    const currentMonthYear = new Date().getMonth() + "-" + new Date().getFullYear();
    if (day === 1 && lastMonthlyRun !== currentMonthYear) {
        console.log("Tentando executar reset mensal...");
        runMonthlyReset();
    }
    if (hour === 23 && minute >= 10) runDailyClosure();
}

async function runDailyClosure() {
    const today = new Date().toDateString();
    if (lastDailyRun === today) return;
    lastDailyRun = today;
    try {
        const guild = client.guilds.cache.get(GUILD_ID);
        if (!guild || Object.keys(taxasDiarias).length === 0) return;
        const canalTaxas = guild.channels.cache.get(CANAL_TAXAS);
        if (!canalTaxas) console.warn("[fechamento diário] Canal de taxas não encontrado:", CANAL_TAXAS);

        for (const [mmId, totalBruto] of Object.entries(taxasDiarias)) {
            // Blindagem: se por algum motivo o valor salvo não for um número válido, pula essa entrada
            // em vez de derrubar o fechamento inteiro (e loga pra facilitar achar a causa).
            const total = parseFloat(totalBruto);
            if (!Number.isFinite(total) || total <= 0) {
                console.warn(`[fechamento diário] Valor inválido para ${mmId}, ignorado:`, totalBruto);
                continue;
            }
            try {
                const metade = total / 2;
                const embed = new EmbedBuilder().setColor("#DE4548").setTitle("📊 Fechamento Diário de Taxas").setDescription(`Relatório de <@${mmId}>\nTotal: \`R$ ${total.toFixed(2)}\` | Repasse: \`R$ ${metade.toFixed(2)}\``);
                const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId("copiar_chave_pix_repasse").setLabel("Chave PIX para Repasse").setStyle(ButtonStyle.Primary));
                if (canalTaxas) await canalTaxas.send({ embeds: [embed], components: [row] }).catch((e) => console.error(`[fechamento diário] Falha ao enviar relatório de ${mmId}:`, e?.message || e));
            } catch (erroItem) {
                console.error(`[fechamento diário] Erro ao processar ${mmId}:`, erroItem?.message || erroItem);
            }
        }
        taxasDiarias = {}; saveTaxas();
    } catch (err) {
        console.error("Erro no fechamento diário:", err?.message || err);
        if (err?.stack) console.error(err.stack);
    }
}

async function runMonthlyReset() {
    const monthYear = new Date().getMonth() + "-" + new Date().getFullYear();
    if (lastMonthlyRun === monthYear) {
        console.log("Reset mensal já executado para este mês.");
        return;
    }
    lastMonthlyRun = monthYear;
    saveLastMonthlyRun();
    try {
        const guild = client.guilds.cache.get(GUILD_ID);
        if (!guild) return;
        const rolesTop = [CARGO_TOP_1, CARGO_TOP_2, CARGO_TOP_3];
        for (const roleId of rolesTop) {
            const role = guild.roles.cache.get(roleId);
            if (role) {
                for (const [mId, m] of role.members) await m.roles.remove(roleId).catch(() => { });
            }
        }
        for (const id in userData) {
            userData[id].totalMes = 0;
            userData[id].taxaMes = 0;
        }
        saveUsers();
        saveLastMonthlyRun(); // Salva a data do último reset mensal
    } catch (err) { console.error("Erro no reset mensal:", err); }
}

const commands = [
    new SlashCommandBuilder().setName("ranking").setDescription("Mostra o ranking de movimentação"),
    new SlashCommandBuilder().setName("perfil").setDescription("Ver perfil financeiro").addUserOption(o => o.setName("usuario").setDescription("Usuário")),
    new SlashCommandBuilder().setName("vouch").setDescription("Aprova um pagamento e gera o vouch de intermediação").addStringOption(o => o.setName("tipo").setDescription("Tipo").setRequired(true).addChoices({ name: "PIX", value: "pix" }, { name: "PIX GRANDE", value: "pix_grande" }, { name: "CROSSTRADE", value: "crosstrade" })).addUserOption(o => o.setName("comprador").setDescription("Comprador").setRequired(true)).addUserOption(o => o.setName("vendedor").setDescription("Vendedor").setRequired(true)).addStringOption(o => o.setName("valor").setDescription("Valor").setRequired(true)),
    new SlashCommandBuilder().setName("aprovar_pagamento").setDescription("Aprova um pagamento").addStringOption(o => o.setName("tipo").setDescription("Tipo").setRequired(true).addChoices({ name: "PIX", value: "pix" }, { name: "PIX GRANDE", value: "pix_grande" }, { name: "CROSSTRADE", value: "crosstrade" })).addUserOption(o => o.setName("enviador").setDescription("Enviador").setRequired(true)).addUserOption(o => o.setName("recebedor").setDescription("Recebedor").setRequired(true)).addStringOption(o => o.setName("valor").setDescription("Valor").setRequired(true)),
    new SlashCommandBuilder().setName("remover_valor").setDescription("Remove um valor do total de um usuário").addUserOption(o => o.setName("usuario").setDescription("Usuário").setRequired(true)).addStringOption(o => o.setName("valor").setDescription("Valor a remover").setRequired(true)),
    new SlashCommandBuilder().setName("configpix").setDescription("Configurar dados de PIX para os Middlemans").setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
];

const rest = new REST({ version: "10" }).setToken(TOKEN);
(async () => {
    try {
        await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body: commands });
        console.log("Comandos registrados.");
    } catch (err) { console.error(err); }
})();

// client.removeAllListeners(Events.MessageCreate) bypassed

client.on(Events.MessageCreate, async (message) => {
    if (message.content === '!middleman') {
        const container = new ContainerBuilder()
            .setAccentColor(0xDE4548)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    '# 🤝 — Solicitar MM\n' +
                    '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    'Selecione abaixo a categoria desejada. Oferecemos serviços de intermediação para qualquer tipo de produto ou negociação, com segurança e agilidade.\n\n' +
                       '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    
                    '## 💳 Taxa Sobre Transação via pix\n' +
                    '**Taxas Normais**\n' +
                    '**R$ 0,50** acima de R$ 8,00.\n' +
                    '**R$ 2,00** acima de R$ 100,00.\n' +
                    '**R$ 4,00** acima de R$ 200,00.\n' +
                    '**R$ 6,50** acima de R$ 400,00.\n' +
                    '**1%** acima de R$ 700,00.\n' +
                    'Em conta adicionamos **R$ 4,00**.\n\n' +
                    '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    '**Abrir MM**'
                )
            )
            .addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('abrir_mediacao')
                        .setLabel('Abrir Mediação')
                        .setStyle(ButtonStyle.Danger)
  
                )
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent('-# NEUX MEDIAÇÃO')
            );

        await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(console.error);
    }

    if (message.content === '!middleman2') {
        const container = new ContainerBuilder()
            .setAccentColor(0xDE4548)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    '# 🤝 — Solicitar MM (Taxa Reduzida)\n' +
                    '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    'Selecione abaixo a categoria desejada. Oferecemos serviços de intermediação para qualquer tipo de produto ou negociação, com segurança e agilidade.\n\n' +
                       '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    
                    '## 💳 Taxa Sobre Transação via pix\n' +
                    '**Taxa Reduzida**\n' +
                    '**R$ 0,25** acima de R$ 8,00.\n' +
                    '**R$ 2,00** acima de R$ 100,00.\n' +
                    '**R$ 4,00** acima de R$ 200,00.\n' +
                    '**R$ 6,50** acima de R$ 400,00.\n' +
                    '**1%** acima de R$ 700,00.\n' +
                    'Em conta adicionamos **R$ 4,00**.\n\n' +
                    '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    '**Abrir MM**'
                )
            )
            .addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('abrir_mediacao_baixa')
                        .setLabel('Abrir Mediação (Taxa Reduzida)')
                        .setStyle(ButtonStyle.Danger)
                )
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent('-# NEUX MEDIAÇÃO')
            );

        await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(console.error);
    }

    if (message.content === '!mm') {
        const container = new ContainerBuilder()
            .setAccentColor(0xDE4548)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# 📊 — Painel do Middleman\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `Estatísticas pessoais das suas intermediações: taxas, valores e clientes atendidos.\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `👤 **Perfil MM** — visão geral (intermediações, nota, taxas).\n` +
                    `💰 **Mês** — total faturado no mês atual.\n` +
                    `📅 **Dia** — faturado hoje, antes do fechamento (23h10).\n` +
                    `👥 **Pessoas** — quem você já atendeu.\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `-# Respostas privadas • Exclusivo staff\n` +
                    `-# NEUX MEDIAÇÃO`
                )
            )
            .addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('mm_perfil').setLabel('Perfil MM').setEmoji('👤').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('mm_mes').setLabel('Faturamento do Mês').setEmoji('💰').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('mm_dia').setLabel('Faturamento do Dia').setEmoji('📅').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('mm_pessoas').setLabel('Pessoas Atendidas').setEmoji('👥').setStyle(ButtonStyle.Secondary)
                )
            );

        await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(console.error);
    }
});

client.login(TOKEN);

