const fs = require("fs");
const path = require("path");
const {
    Client,
    GatewayIntentBits,
    EmbedBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    UserSelectMenuBuilder,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    FileUploadBuilder,
    LabelBuilder,
    ChannelType,
    PermissionFlagsBits,
    ButtonBuilder,
    ButtonStyle,
    Events,
    MessageFlags,
    SlashCommandBuilder,
    REST,
    Routes,
    AttachmentBuilder,
    ContainerBuilder,
    TextDisplayBuilder,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder
} = require("discord.js");

const { gerarCartaoPerfil } = require("./perfilCard");
const { gerarCartaoVouchGif } = require("./vouchCard");
const QRCode = require("qrcode");

const TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = "1438353823235051642";
const GUILD_ID = "1417672403382960130";

const CATEGORIA_TICKETS = '1451246353735880857';
const CANAL_LOGS_ID = '1491989024276091004';
const CANAL_PROOFS = "1451245692042477752";
const CANAL_BIG_TRADE = "1455755067046236251";
const CANAL_TAXAS = "1470177275881455627";
const CANAL_AVALIACOES = "1417967103360630916";

const CARGO_STAFF_ID = "1422050552371740702";
const ID_AFILIADO = "1493722160269623367";
const CARGO_AFILIADO_ID = "1493722160269623367"; // Definido para evitar erros de referência

const RANK_COLORS = {
    "1472761782555771060": "#5865F2", // 200K  (limite 200000) - equivalente a "Master" - Azul Índigo
    "1470874824627716217": "#FFA500", // 100K  (limite 100000) - equivalente a "Nebula" - Laranja Dourado
    "1455064011413393515": "#00CED1", // Cliente Divino (limite 50000) - equivalente a "Imperador" - Ciano
    "1455064010033594549": "#9B30FF", // Cliente Lendário (limite 25000) - equivalente a "Galático" - Roxo
    "1455064008699805799": "#FF3B3B", // Cliente Sagrado (limite 10000) - equivalente a "Eterno" - Vermelho
    "1452028593268981964": "#10B981", // Cliente Celestial (limite 5000) - equivalente a "Esmeralda" - Verde
    "1455064005604540447": "#2196F3", // Cliente Imperial (limite 1000) - equivalente a "Platina" - AZUL
    "1455064003922366524": "#C0C0C0", // Cliente Nobre (limite 500) - equivalente a "Premium" - PRATA (era roxo, corrigido)
    "1417913178779549767": "#C0C0C0"  // Cliente Iniciante (limite 0) - equivalente a "Cliente" - PRATA (consistente com a paleta do vouch)
};

const RANK_CARGOS = [
  { nome: "200K", limite: 200000, id: "1472761782555771060", iconType: "crown" },
  { nome: "100K", limite: 100000, id: "1470874824627716217", iconType: "crown" },
  { nome: "Cliente Divino", limite: 50000, id: "1455064011413393515", iconType: "diamond" },
  { nome: "Cliente Lendário", limite: 25000, id: "1455064010033594549", iconType: "star" },
  { nome: "Cliente Sagrado", limite: 10000, id: "1455064008699805799", iconType: "star" },
  { nome: "Cliente Celestial", limite: 5000, id: "1452028593268981964", iconType: "diamond" },
  { nome: "Cliente Imperial", limite: 1000, id: "1455064005604540447", iconType: "shield" },
  { nome: "Cliente Nobre", limite: 500, id: "1455064003922366524", iconType: "shield" },
  { nome: "Cliente Iniciante", limite: 0, id: "1417913178779549767", iconType: "star" },
];

// Mesma lista de RANK_CARGOS, só que em ordem crescente e já com a cor
// embutida — é o que perfilCard.js usa pra desenhar a trilha de níveis.
// Não duplica nomes/IDs: é só um reflexo do array acima.
const TODOS_CARGOS_ORDENADOS = [...RANK_CARGOS].reverse().map(r => ({
    nome: r.nome,
    limite: r.limite,
    corHex: RANK_COLORS[r.id] || "#9B30FF"
}));

const CARGO_TOP_1 = "1475045304444256296";
const CARGO_TOP_2 = "1497401431739732019";
const CARGO_TOP_3 = "1442589543487373444";

const EMOJI_CHECK = '<:2974:1438244299564126279>';
const EMOJI_PIX_TITULO = "<:emoji_172:1541636098005016576>";
const EMOJI_CARTAO_TITULO = '<:emoji_169:1541632596700561490>';
const EMOJI_CARTAO_BOTAO = '<:emoji_169:1541633492725661848>';
const THUMBNAIL_SPEED = "https://i.postimg.cc/ZKp8yjpK/nex1-2.gif"; // Link direto fornecido pelo usuário

const dbPixPath = path.join(__dirname, 'pix_database.json');
const dbUsersPath = path.join(__dirname, 'users_mm.json');
const dbGlobalPath = path.join(__dirname, 'proofs_global.json');
const dbTaxasPath = path.join(__dirname, 'taxas_diarias.json');

let globalCounter = 1447;
if (fs.existsSync(dbGlobalPath)) {
    try {
        const savedGlobal = JSON.parse(fs.readFileSync(dbGlobalPath));
        if (typeof savedGlobal === 'number') globalCounter = savedGlobal;
    } catch (e) { console.error("Erro ao carregar globalCounter:", e); }
}

let userData = {};
if (fs.existsSync(dbUsersPath)) {
    try {
        userData = JSON.parse(fs.readFileSync(dbUsersPath));
    } catch (e) { console.error("Erro ao carregar userData:", e); }
}

let taxasDiarias = {};
if (fs.existsSync(dbTaxasPath)) {
    try {
        taxasDiarias = JSON.parse(fs.readFileSync(dbTaxasPath));
    } catch (e) { console.error("Erro ao carregar taxasDiarias:", e); }
}

let pixConfig = new Map();
if (fs.existsSync(dbPixPath)) {
    try {
        pixConfig = new Map(Object.entries(JSON.parse(fs.readFileSync(dbPixPath))));
    } catch (e) { console.error("Erro ao carregar banco de dados PIX:", e); }
}

function saveGlobal() { fs.writeFileSync(dbGlobalPath, JSON.stringify(globalCounter)); }
function saveUsers() { fs.writeFileSync(dbUsersPath, JSON.stringify(userData, null, 2)); }
function saveTaxas() { fs.writeFileSync(dbTaxasPath, JSON.stringify(taxasDiarias, null, 2)); }
function salvarDadosPix() {
    const obj = Object.fromEntries(pixConfig);
    fs.writeFileSync(dbPixPath, JSON.stringify(obj, null, 2));
}

function sanitizarValor(valorStr) {
    if (typeof valorStr !== 'string') return 0;
    let limpo = valorStr.trim();

    if (limpo.includes('.') && limpo.includes(',')) {
        limpo = limpo.replace(/\./g, '').replace(',', '.');
    }
    else if (limpo.includes(',') && limpo.indexOf(',') < limpo.indexOf('.')) {
        limpo = limpo.replace(/,/g, '');
    }
    else if (limpo.includes('.') && !limpo.includes(',')) {
        const partes = limpo.split('.');
        const ultimaParte = partes[partes.length - 1];
        if (ultimaParte.length === 3) {
            limpo = limpo.replace(/\./g, '');
        }
    }
    else if (limpo.includes(',') && !limpo.includes('.')) {
        limpo = limpo.replace(',', '.');
    }

    const num = parseFloat(limpo);
    return isNaN(num) ? 0 : num;
}

function sanitizarValorGorjeta(valorStr) {
    if (typeof valorStr !== 'string') return 0;
    const bruto = valorStr.trim().replace(/^R\$\s*/i, '').replace(/\s/g, '');
    if (!bruto) return 0;
    // No comando de gorjeta, um inteiro representa centavos: 10 = R$ 0,10.
    if (/^\d+$/.test(bruto)) return Number(bruto) / 100;

    let real = bruto;
    if (real.includes(',') && real.includes('.')) {
        real = real.lastIndexOf(',') > real.lastIndexOf('.')
            ? real.replace(/\./g, '').replace(',', '.')
            : real.replace(/,/g, '');
    } else if (real.includes(',')) {
        real = real.replace(',', '.');
    }
    const num = Number(real);
    return Number.isFinite(num) ? num : 0;
}

function isDonoOuCargoMaisAlto(member) {
    if (!member) return false;
    const guild = member.guild;
    const userId = member.id || member.user?.id;
    if (!userId) return false;

    // 1. Dono absoluto do servidor
    if (guild && guild.ownerId === userId) return true;

    // 2. Extrai os IDs dos cargos do membro
    let memberRoleIds = [];
    if (member.roles?.cache) {
        memberRoleIds = Array.from(member.roles.cache.keys());
    } else if (Array.isArray(member.roles)) {
        memberRoleIds = member.roles;
    }

    if (guild && guild.roles?.cache && guild.roles.cache.size > 0) {
        // Encontrar os cargos não gerenciados do servidor (excluindo @everyone e integrações/bots)
        const nonManagedRoles = guild.roles.cache
            .filter(r => !r.managed && r.id !== guild.id)
            .sort((a, b) => b.position - a.position);

        const highestServerRole = nonManagedRoles.first();
        if (highestServerRole) {
            // Se o usuário possui o cargo mais alto do servidor
            if (memberRoleIds.includes(highestServerRole.id)) return true;

            // Se o cargo mais alto do membro possui posição igual ou superior
            if (member.roles?.highest && member.roles.highest.position >= highestServerRole.position) return true;
        }

        // 3. Checar nomes típicos de Dono / Fundador / Cargo Máximo
        for (const roleId of memberRoleIds) {
            const r = guild.roles.cache.get(roleId);
            if (!r) continue;
            const nome = r.name.toLowerCase().trim();
            if (
                nome === "dono" ||
                nome === "owner" ||
                nome === "fundador" ||
                nome === "fundadora" ||
                nome === "criador" ||
                nome === "criadora" ||
                nome === "sub-dono" ||
                nome === "sub dono" ||
                nome === "subdono" ||
                nome === "diretoria" ||
                nome === "diretor" ||
                nome === "ceo" ||
                nome === "presidente" ||
                nome.startsWith("👑") ||
                nome.includes("dono") ||
                nome.includes("owner") ||
                nome.includes("fundador")
            ) {
                return true;
            }
        }
    }

    // 4. Se tiver permissão de Administrador e for o cargo mais alto do membro no cache
    if (member.permissions?.has?.(PermissionFlagsBits.Administrator)) {
        if (guild && guild.roles?.cache) {
            const memberRoles = guild.roles.cache.filter(r => memberRoleIds.includes(r.id) && !r.managed);
            const highestMember = memberRoles.sort((a, b) => b.position - a.position).first();
            const topRole = guild.roles.cache.filter(r => !r.managed && r.id !== guild.id).sort((a, b) => b.position - a.position).first();
            if (highestMember && topRole && highestMember.position >= topRole.position) {
                return true;
            }
        }
    }

    return false;
}

const tradeData = new Map();
const posseData = new Map();

function construirPainelPosse(posse) {
    const pagamento = posse.pagamentoConfirmado
        ? `${EMOJI_CHECK} Pagamento confirmado por um Middleman.`
        : '⏳ Aguardando a confirmação de que o valor foi pago ao Middleman.';
    const assumida = posse.assumida
        ? `\n\n${EMOJI_CHECK} Posse assumida por um novo Middleman.`
        : '';

    return new ContainerBuilder()
        .setAccentColor(0xDE4548)
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(
            `# 🔄 Passar posse\n` +
            `O Middleman responsável teve um imprevisto e a posse desta mediação poderá ser passada para outro Middleman.\n` +
            `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
            `**Status do pagamento:** ${pagamento}${assumida}`
        ))
        .addActionRowComponents(new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`posse_pagamento_${posse.id}`)
                .setLabel('Confirmar pagamento')
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(Boolean(posse.pagamentoConfirmado || posse.assumida)),
            new ButtonBuilder()
                .setCustomId(`posse_assumir_${posse.id}`)
                .setLabel('Assumir posse')
                .setStyle(ButtonStyle.Danger)
                .setDisabled(Boolean(posse.assumida))
        ));
}

function construirPainelPagamentoConta(data) {
    const confirmacoes = data.contaPagamentoConfirmacoes || [];
    const ambosConfirmaram = confirmacoes.length >= 2;
    const comprovanteRecebido = Boolean(data.contaComprovante?.url);
    const status = comprovanteRecebido
        ? '⏳ Pagamento pendente — comprovante recebido e em conferência.'
        : ambosConfirmaram
        ? `${EMOJI_CHECK} Os dois participantes confirmaram. O comprador deve enviar o print do pagamento.`
        : `⏳ Confirmações: ${confirmacoes.length}/2`;
    const row = comprovanteRecebido
        ? new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('conta_comprovante_recebido').setLabel('Print recebido — pagamento pendente').setStyle(ButtonStyle.Secondary).setDisabled(true))
        : ambosConfirmaram
        ? new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('conta_enviar_comprovante').setLabel(data.contaAguardandoComprovante ? 'Aguardando envio' : 'Enviar imagem').setStyle(ButtonStyle.Danger).setDisabled(Boolean(data.contaAguardandoComprovante)))
        : new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('conta_confirmar_pagamento').setLabel('Confirmar pagamento').setStyle(ButtonStyle.Secondary));

    return new ContainerBuilder()
        .setAccentColor(0xDE4548)
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(
            `# 🔐 Pagamento da conta\n` +
            `O Middleman confirmou o recebimento do valor. Comprador e vendedor devem confirmar antes do comprovante.\n` +
            `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
            `**Status:** ${status}`
        ))
        .addActionRowComponents(row);
}

function loadTradeDataFromDisk() {
    try {
        const arquivo = path.join(__dirname, 'trade_data.json');
        if (fs.existsSync(arquivo)) {
            const content = fs.readFileSync(arquivo, 'utf8');
            if (content && content.trim().length > 2) {
                const parsed = JSON.parse(content);
                for (const [k, v] of Object.entries(parsed)) {
                    tradeData.set(k, v);
                }
            }
        }
    } catch (e) {
        console.error('Erro ao carregar trade_data.json:', e);
    }
}
function saveTradeDataToDisk() {
    try {
        const obj = {};
        for (const [k, v] of tradeData.entries()) {
            obj[k] = { ...v, colValor: null, colItem: null, msgValor: null, msgItem: null };
        }
        const arquivo = path.join(__dirname, 'trade_data.json');
        const temporario = `${arquivo}.${process.pid}.tmp`;
        fs.writeFileSync(temporario, JSON.stringify(obj, null, 2));
        fs.renameSync(temporario, arquivo);
    } catch (e) {
        console.error('Erro ao salvar trade_data.json:', e);
    }
}
loadTradeDataFromDisk();
const pixStorage = new Map();
const chaveFinalStorage = new Map();
const dbAvaliacoesPath = path.join(__dirname, 'avaliacoes_pendentes.json');
const avaliacoesPendentes = new Map();
function loadAvaliacoesPendentes() {
    try {
        if (fs.existsSync(dbAvaliacoesPath)) {
            const data = JSON.parse(fs.readFileSync(dbAvaliacoesPath, 'utf8'));
            for (const [k, v] of Object.entries(data)) {
                avaliacoesPendentes.set(k, v);
            }
        }
    } catch (e) {
        console.error('Erro ao carregar avaliacoes_pendentes.json:', e);
    }
}
function saveAvaliacoesPendentes() {
    try {
        const obj = {};
        for (const [k, v] of avaliacoesPendentes.entries()) {
            obj[k] = v;
        }
        fs.writeFileSync(dbAvaliacoesPath, JSON.stringify(obj, null, 2));
    } catch (e) {
        console.error('Erro ao salvar avaliacoes_pendentes.json:', e);
    }
}
loadAvaliacoesPendentes();

function gerarIdAvaliacao() {
    return `AVL${Date.now()}${Math.floor(Math.random() * 900 + 100)}`;
}

function registerTrade(userId, valor, contraparteId = null) {
  if (!userData[userId]) userData[userId] = { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
  if (!userData[userId].clienteDesde) userData[userId].clienteDesde = new Date().getFullYear();
  userData[userId].totalTrocas++;
  userData[userId].totalValor += valor;
  userData[userId].totalMes += valor;
  if (valor > userData[userId].maiorTroca) userData[userId].maiorTroca = valor;

  if (contraparteId) {
    if (!userData[userId].listaPessoas) userData[userId].listaPessoas = [];
    if (!userData[userId].listaPessoas.includes(contraparteId)) {
      userData[userId].listaPessoas.push(contraparteId);
      userData[userId].pessoasIntermediadas = userData[userId].listaPessoas.length;
    }
  }

  saveUsers();
}

function registerStaffTrade(userId, valor, contraparteIds = []) {
  if (!userData[userId]) userData[userId] = { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
  if (!userData[userId].clienteDesde) userData[userId].clienteDesde = new Date().getFullYear();
  userData[userId].totalTrocas++;

  if (!userData[userId].listaPessoas) userData[userId].listaPessoas = [];
  for (const cid of contraparteIds) {
    if (cid && !userData[userId].listaPessoas.includes(cid)) {
      userData[userId].listaPessoas.push(cid);
    }
  }
  userData[userId].pessoasIntermediadas = userData[userId].listaPessoas.length;

  saveUsers();
}

async function atualizarCargos(guild, userId) {
  try {
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) return;
    const data = userData[userId];

    for (const rank of RANK_CARGOS) {
        if (data && data.totalValor >= rank.limite) {
            try {
                if (!member.roles.cache.has(rank.id)) {
                    await member.roles.add(rank.id);
                }
            } catch (e) {
                console.error(`Erro ao adicionar cargo ${rank.nome} para ${userId}:`, e.message);
            }
        }
    }

    const allUsersMonthly = Object.entries(userData).sort(([, a], [, b]) => b.totalMes - a.totalMes);
    const rolesTop = [CARGO_TOP_1, CARGO_TOP_2, CARGO_TOP_3];

    for (let i = 0; i < 3; i++) {
      if (allUsersMonthly[i]) {
        const topUserId = allUsersMonthly[i][0];
        const topMember = await guild.members.fetch(topUserId).catch(() => null);
        const roleId = rolesTop[i];

        if (topMember) {
          const role = guild.roles.cache.get(roleId);
          if (role) {
            await Promise.all(role.members.map(m => {
                if(m.id !== topUserId) return m.roles.remove(roleId).catch(() => {});
            }));
            if (!topMember.roles.cache.has(roleId)) await topMember.roles.add(roleId).catch(() => {});
          }
        }
      }
    }
  } catch (err) { console.error("Erro ao atualizar cargos:", err); }
}

// tipoTaxa: 'normal' (middleman padrão, !middleman) ou 'baixa' (middleman2, !middleman2)
// A diferença hoje é só na primeira faixa (R$0,50 vira R$0,25), mas dá pra ajustar
// as outras faixas do "baixa" aqui se quiser deixar tudo mais barato também.
function calcularTaxaBase(v, tipoTaxa = 'normal') {
  v = parseFloat(v) || 0;
  const taxaMinima = tipoTaxa === 'baixa' ? 0.25 : 0.50;
  if (v >= 700) return v * 0.01;
  if (v >= 400) return 6.50;
  if (v >= 200) return 4.00;
  if (v >= 100) return 2.00;
  if (v >= 8) return taxaMinima;
  return 0;
}

function calcularTaxa(tipo, valor, enviadorId, recebedorId) {
  if (tipo === 'conta') return 3.00;
  let taxaBase = 0;
  if (tipo === "crosstrade") taxaBase = 1.0;
  else if (valor >= 700) taxaBase = valor * 0.01;
  else if (valor >= 400) taxaBase = 6.50;
  else if (valor >= 200) taxaBase = 4.00;
  else if (valor >= 100) taxaBase = 2.00;
  else if (valor >= 8) taxaBase = 0.50;
  if (enviadorId === ID_AFILIADO || recebedorId === ID_AFILIADO) taxaBase /= 2;
  return taxaBase;
}

function crc16(payload) {
    let polinomio = 0x1021;
    let resultado = 0xFFFF;
    for (let i = 0; i < payload.length; i++) {
        resultado ^= payload.charCodeAt(i) << 8;
        for (let j = 0; j < 8; j++) {
            resultado = (resultado & 0x8000) ? ((resultado << 1) ^ polinomio) : (resultado << 1);
            resultado &= 0xFFFF;
        }
    }
    return resultado.toString(16).toUpperCase().padStart(4, '0');
}
function pixTlv(id, value) {
    const text = String(value ?? '');
    if (text.length > 99) throw new Error(`Campo PIX ${id} excede 99 caracteres`);
    return `${id}${String(text.length).padStart(2, '0')}${text}`;
}
function gerarPix(chave, nome, valor) {
    const chaveF = String(chave ?? '').trim();
    if (!chaveF) throw new Error('Chave PIX vazia ou inválida');
    const valorNumerico = Number(String(valor).replace(',', '.'));
    if (!Number.isFinite(valorNumerico) || valorNumerico <= 0) throw new Error(`Valor PIX inválido: ${valor}`);
    const nomeF = String(nome || 'PAGAMENTO')
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .toUpperCase().replace(/[^A-Z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 25) || 'PAGAMENTO';
    const valorF = valorNumerico.toFixed(2);
    const merchantAccount = pixTlv('00', 'br.gov.bcb.pix') + pixTlv('01', chaveF);
    const semCrc = [
        pixTlv('00', '01'),
        pixTlv('01', '12'),
        pixTlv('26', merchantAccount),
        pixTlv('52', '0000'),
        pixTlv('53', '986'),
        pixTlv('54', valorF),
        pixTlv('58', 'BR'),
        pixTlv('59', nomeF),
        pixTlv('60', 'SAO PAULO'),
        pixTlv('62', pixTlv('05', '***')),
        '6304'
    ].join('');
    return semCrc + crc16(semCrc);
}

function construirPainelGorjeta({ id, middleman, valor }) {
    return new ContainerBuilder()
        .setAccentColor(0xDE4548)
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(
            `# 💸 — Gorjeta para o Middleman\n` +
            `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
            `**Middleman:** <@${middleman}>\n` +
            `**Valor da gorjeta:** R$ ${Number(valor).toFixed(2).replace('.', ',')}\n` +
            `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
            `Escolha uma das opções abaixo para realizar o pagamento com segurança.`
        ))
        .addActionRowComponents(new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`qr_${id}`).setLabel('QR Code').setEmoji('<:emoji_164:1498778688886407218>').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId(`copy_${id}`).setLabel('Copia e Cola').setEmoji('<:emoji_169:1541632596700561490>').setStyle(ButtonStyle.Secondary)
        ));
}

async function getRankingEmbed(guild, tipo, pagina) {
  const isGeral = tipo === "geral";
  let sortedUsers = Object.entries(userData);
  if (!isGeral) {
    sortedUsers = sortedUsers.filter(([, data]) => (data.totalMes || 0) > 0)
      .sort(([, a], [, b]) => (b.totalMes || 0) - (a.totalMes || 0));
  } else {
    sortedUsers = sortedUsers.filter(([, data]) => (data.totalValor || 0) > 0)
      .sort(([, a], [, b]) => (b.totalValor || 0) - (a.totalValor || 0));
  }

  const itensPorPagina = 10;
  const totalPaginas = Math.ceil(sortedUsers.length / itensPorPagina) || 1;
  if (pagina < 1) pagina = 1;
  if (pagina > totalPaginas) pagina = totalPaginas;

  const indexInicio = (pagina - 1) * itensPorPagina;
  const slice = sortedUsers.slice(indexInicio, indexInicio + itensPorPagina);

  const embedTitulo = new EmbedBuilder()
    .setColor("#DE4548")
    .setTitle(`🏆 Ranking de Movimentação - ${isGeral ? "Geral" : "Mensal"}`)
    .setThumbnail(THUMBNAIL_SPEED);

  const rowMenu = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId("rank_select")
      .setPlaceholder("Alterar tipo de ranking...")
      .addOptions(
        { label: "Ranking Geral", value: "geral", default: isGeral },
        { label: "Ranking Mensal", value: "mensal", default: !isGeral }
      )
  );

  let listaCorpo = "";
  if (slice.length === 0) {
    listaCorpo = isGeral ? "Nenhum resultado encontrado." : "Nenhum trader movimentou este mês ainda após o reset.";
  } else {
    for (let i = 0; i < slice.length; i++) {
      const [id, data] = slice[i];
      const posicao = indexInicio + i + 1;
      const valor = isGeral ? (data.totalValor || 0) : (data.totalMes || 0);
      const trocas = isGeral ? (data.totalTrocas || 0) : (data.trocasMes !== undefined ? data.trocasMes : 1);
      const valorFormatado = valor.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
      listaCorpo += `${posicao}. <@${id}> total de R$ \`${valorFormatado}\` gastos e \`${trocas}\` troca(s)\n`;
    }
  }

  const embedLista = new EmbedBuilder()
    .setColor("#DE4548")
    .setDescription(listaCorpo)
    .setFooter({ text: `Página ${pagina} de ${totalPaginas} • ${sortedUsers.length} trader(s)` });

  const rowBotoes = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`rankprev_${tipo}_${pagina}`).setLabel("Anterior").setEmoji("◀️").setStyle(ButtonStyle.Secondary).setDisabled(pagina <= 1),
    new ButtonBuilder().setCustomId(`ranknext_${tipo}_${pagina}`).setLabel("Próximo").setEmoji("▶️").setStyle(ButtonStyle.Secondary).setDisabled(pagina >= totalPaginas)
  );

  return { embeds: [embedTitulo, embedLista], components: [rowMenu, rowBotoes] };
}

// Segurança de contas: o bot nunca deve receber senha, token ou código de recuperação.
const ACCOUNT_SECRET_PATTERN = /(?:senha|password|pass|token|2fa|c[oó]digo\s*(?:de\s*)?recupera[cç][aã]o|recovery\s*code|backup\s*code|authenticator)\s*[:=]/i;
const ACCOUNT_TOKEN_PATTERN = /(?:mfa\.[\w-]{20,}|eyJ[\w-]{20,}|[A-Za-z0-9_-]{50,})/;

function mensagemPareceCredencialDeConta(content = '') {
    const texto = String(content).trim();
    return ACCOUNT_SECRET_PATTERN.test(texto) || ACCOUNT_TOKEN_PATTERN.test(texto);
}

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.DirectMessages
    ]
});

client.once(Events.ClientReady, () => {
    console.log(`<:emoji_172:1541636098005016576> Santa MM\'s V2 Integrado Online!`);
    checkScheduledTasks();
    setInterval(checkScheduledTasks, 60 * 1000); // Executa a cada minuto
});

process.on('unhandledRejection', (reason) => console.log(' [ANTI-CRASH] Rejeição:', reason));
process.on('uncaughtException', (err) => console.log(' [ANTI-CRASH] Exceção:', err));

function construirContainerFuncoes(data) {
    const mencoes = data.participantes.map(id => `<@${id}>`).join(' ') || '';

    return new ContainerBuilder()
        .setAccentColor(0xDE4548)
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `${mencoes}\n` +
                `# <:parceria:1485054250429054986> ━ Seleção de Funções\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `${data.modoConta ? 'Confirmem as funções: quem está vendendo a conta e quem está comprando.' : 'Confirmem as funções de vocês: quem vai enviar o PIX pro MM e quem vai receber o PIX do MM depois da troca.'}\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `${data.modoConta ? '🛒 **Vou comprar** — Você receberá a conta e pagará ao Middleman.' : '<:emoji_166:1541616981348851763> **Vou enviar o pix** — Você vai enviar o PIX para o middleman.'}\n` +
                `${data.modoConta ? '🏷️ **Vou vender** — Você entregará a conta e receberá o pagamento.' : '<:emoji_164:1541612138756579439> **Vou receber** — Você vai receber o PIX do middleman.'}\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `**Enviador:** ${data.enviador ? `<@${data.enviador}>` : 'Aguardando...'}\n` +
                `**Recebedor:** ${data.recebedor ? `<@${data.recebedor}>` : 'Aguardando...'}`
            )
        )
        .addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('set_enviador').setLabel(data.modoConta ? 'Vou comprar' : 'Vou enviar o Pix').setEmoji('<:emoji_166:1541616981348851763>').setStyle(ButtonStyle.Secondary).setDisabled(!!data.enviador),
                new ButtonBuilder().setCustomId('set_recebedor').setLabel(data.modoConta ? 'Vou vender' : 'Vou Receber').setEmoji('<:emoji_164:1541612138756579439>').setStyle(ButtonStyle.Secondary).setDisabled(!!data.recebedor),
                new ButtonBuilder().setCustomId('resetar_fluxo').setLabel('Resetar').setEmoji('<:emoji_167:1541618912238768148>').setStyle(ButtonStyle.Secondary)
            )
        )
        .addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('btn_fechar').setLabel('Excluir intermediação').setEmoji('<:emoji_167:1541618912238768148>').setStyle(ButtonStyle.Secondary)
            )
        );
}

function construirContainerPrivacidadeVendedor(data) {
    const escolhas = data.exibicaoEscolhas || {};
    const compradorEscolheu = data.enviador && Object.prototype.hasOwnProperty.call(escolhas, data.enviador);
    const vendedorEscolheu = data.recebedor && Object.prototype.hasOwnProperty.call(escolhas, data.recebedor);
    return new ContainerBuilder()
        .setAccentColor(0x5865F2)
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(
            `# <:emoji_166:1541613481646882987> Exibição do vouch\n` +
            `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
            `Cada participante escolhe como aparecer: **Anônimo** oculta nome e foto; **Mostrar tudo** exibe normalmente.\n` +
            `Comprador e vendedor devem clicar uma vez.\n` +
            `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
            `**Comprador:** ${compradorEscolheu ? '<:emoji_172:1541636098005016576>' : '⏳'}  **Vendedor:** ${vendedorEscolheu ? '<:emoji_172:1541636098005016576>' : '⏳'}`
        ))
        .addActionRowComponents(new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('v2_privacidade_anonimo').setLabel('Anônimo').setEmoji('<:emoji_164:1498778688886407218>').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('v2_privacidade_mostrar_tudo').setLabel('Mostrar tudo').setEmoji('<:emoji_169:1541633492725661848>').setStyle(ButtonStyle.Secondary)
        ));
}
async function limparMensagensDoBot(channel) {
    try {
        const mensagens = await channel.messages.fetch({ limit: 100 });
        const minhas = mensagens.filter(m => m.author?.id === client.user?.id && !m.pinned);
        if (minhas.size) await channel.bulkDelete(minhas, true);
    } catch (e) {
        console.error('Não foi possível limpar mensagens antigas do bot:', e.message);
    }
}
async function limparMensagensDoTicket(channel) {
    try {
        const mensagens = await channel.messages.fetch({ limit: 100 });
        const apagar = mensagens.filter(m => !m.pinned);
        if (apagar.size) await channel.bulkDelete(apagar, true);
    } catch (e) {
        console.error('Não foi possível limpar as mensagens do ticket:', e.message);
    }
}
async function iniciarFluxoConta(channel, data) {
    data.contaConfirmacoes = [];
    data.contaDados = { etapa: 0 };
    data.valor = null;
    data.item = 'Conta digital';
    saveTradeDataToDisk();
    await enviarEtapaSegurancaConta(channel, data, 1);
}

async function enviarEtapaSegurancaConta(channel, data, etapa) {
    const vendedor = `<@${data.recebedor}>`;
    const configs = {
        1: {
            titulo: 'Etapa de segurança 1',
            texto: `${vendedor}, realizaremos a primeira etapa de segurança. Responda clicando nos botões abaixo: a conta é sua ou de revenda?`,
            botoes: [['conta_etapa_1_propria', 'Conta própria'], ['conta_etapa_1_revenda', 'Conta de revenda']]
        },
        2: {
            titulo: 'Etapa de segurança 2',
            texto: `${vendedor}, você passará o **OG da conta**?\n-# OG = primeiro e-mail da conta. Não envie o endereço por aqui.`,
            botoes: [['conta_etapa_2_sim', 'Sim, vou passar o OG'], ['conta_etapa_2_nao', 'Não vou passar o OG']]
        },
        3: {
            titulo: 'Etapa de segurança 3',
            texto: `${vendedor}, o OG tem algum e-mail de recuperação?\n-# Responda somente se existe ou não. Não informe o endereço.`,
            botoes: [['conta_etapa_3_sim', 'Sim'], ['conta_etapa_3_nao', 'Não']]
        },
        4: {
            titulo: 'Etapa de segurança 4',
            texto: `${vendedor}, você passará o **e-mail de recuperação**?\n-# O bot nunca deve receber o endereço, senha ou código.`,
            botoes: [['conta_etapa_4_sim', 'Sim, vou passar'], ['conta_etapa_4_nao', 'Não vou passar']]
        }
    }[etapa];
    if (!configs) return;
    data.contaDados.etapa = etapa;
    saveTradeDataToDisk();
    const painel = new ContainerBuilder().setAccentColor(0x8B00FF)
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(
            `# 🔐 — ${configs.titulo}\n\n${configs.texto}\n\n` +
            `-# Não envie senha, token, código 2FA, código de recuperação ou endereços de e-mail neste ticket.`
        ))
        .addActionRowComponents(new ActionRowBuilder().addComponents(
            ...configs.botoes.map(([id, label]) => new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(ButtonStyle.Secondary))
        ));
    await channel.send({ components: [painel], flags: MessageFlags.IsComponentsV2 });
}

async function pedirValorConta(channel, data) {
    const modal = new ModalBuilder().setCustomId('modal_conta_valor').setTitle('Valor da conta');
    modal.addComponents(new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('conta_valor').setLabel('Valor total da conta (R$)').setPlaceholder('Ex.: 250,00').setStyle(TextInputStyle.Short).setMaxLength(20).setRequired(true)
    ));
    // Modal só pode ser aberto por interação; esta função é chamada pelo handler abaixo.
}

function construirResumoConta(data) {
    const c = data.contaDados || {};
    const simNao = v => v === true ? 'Sim' : v === false ? 'Não' : (v || 'Não informado');
    return new ContainerBuilder().setAccentColor(0x5865F2)
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(
            `# 🔎 Revisão das etapas de segurança\n\n` +
            `**Tipo:** ${c.tipo || 'Não informado'}\n` +
            `**OG será transferido:** ${simNao(c.passaraOg)}\n` +
            `**OG possui e-mail de recuperação:** ${simNao(c.ogTemRecuperacao)}\n` +
            `**E-mail de recuperação será transferido:** ${simNao(c.passaraRecuperacao)}\n` +
            `**Valor da conta:** R$ ${Number(data.valor).toFixed(2)}\n\n` +
            `Não há credenciais ou endereços de e-mail neste resumo. Comprador e vendedor devem conferir antes de confirmar.`
        ))
        .addActionRowComponents(new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('conta_confirmar_dados').setLabel('Confirmar informações').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId('conta_reiniciar_etapas').setLabel('Refazer etapas').setStyle(ButtonStyle.Secondary)
        ));
}

async function iniciarColetaValor(channel, data) {
    // Evita recriar coletores/painéis se a confirmação chegar duas vezes.
    if (data.coletaValorIniciada) return;
    data.coletaValorIniciada = true;
    const containerV = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:emoji_166:1541613481646882987> ╺ Valor da negociação\n<@${data.enviador}> ou <@${data.recebedor}> — **qualquer um** pode digitar no chat o **valor total** da transação (ex.: \`80,50\` ou \`125.50\`).\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\nDepois, **ambos** devem confirmar na mensagem seguinte (**Confirmar valor**).`));
    data.msgValor = await channel.send({ components: [containerV], flags: MessageFlags.IsComponentsV2 });

    data.colValor?.stop();
    const colV = channel.createMessageCollector({ filter: m => data.participantes.includes(m.author.id) });
    data.colValor = colV;
    colV.on('collect', async m => {
        if (data.colValor !== colV || data.lockValor) return;
        const valorNumerico = sanitizarValor(m.content);
        if (valorNumerico <= 0) {
            await m.react('<:emoji_167:1541618912238768148>').catch(() => {});
            return;
        }
        // Trava síncrona antes de qualquer await: só a primeira mensagem válida segue adiante.
        data.lockValor = true;
        colV.stop(); data.colValor = null;
        await m.react('<:emoji_172:1541636098005016576>').catch(() => {});
        await new Promise(resolve => setTimeout(resolve, 1000));
        data.valor = valorNumerico.toString();

        data.msgValor = null;
        // Remove o painel anterior, a resposta do valor e qualquer mensagem antiga.
        await limparMensagensDoTicket(channel);

        const containerI = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:emoji_166:1541613481646882987>╺ Itens da negociação\n<@${data.enviador}> ou <@${data.recebedor}> — **qualquer um** pode digitar no chat o **item / produto** que você enviará.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\nDepois, **ambos** devem confirmar na mensagem seguinte (**Confirmar itens**).`));
        data.msgItem = await channel.send({ components: [containerI], flags: MessageFlags.IsComponentsV2 });

        // Mantém somente um collector de item ativo neste ticket.
        data.colItem?.stop('replaced');
        data.colItem = null;
        data.itemMessageId = null;
        data.itemProcessing = false;
        const colI = channel.createMessageCollector({
            filter: m => Boolean(m && !m.author?.bot && !m.webhookId && data.participantes.includes(m.author.id) && m.content?.trim()),
            max: 1
        });
        data.colItem = colI;
        colI.on('collect', async m2 => {
            // Trava síncrona antes de qualquer await: só a primeira mensagem entra.
            if (data.colItem !== colI || data.lockItem || data.itemProcessing || data.itemMessageId === m2.id) return;
            data.itemProcessing = true;
            data.itemMessageId = m2.id;
            data.lockItem = true;
            colI.stop('accepted');
            data.colItem = null;
            data.item = m2.content.trim();

            data.msgItem = null;
            // Remove o painel do item, a resposta do usuário e qualquer mensagem antiga.
            await limparMensagensDoTicket(channel);

            const taxaEstimada = data.modoConta ? 3.00 : calcularTaxaBase(data.valor, data.tipoTaxa);
            const containerTaxa = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:parceria:1485054250429054986> ╺ Escolha o pagador da taxa\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n> Selecione corretamente o pagador da taxa. Caso o vendedor seja o pagador, ele receberá o valor total menos a taxa.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Taxa da MM:** R$ ${taxaEstimada.toFixed(2)}\n**Comprador:** <@${data.enviador}>\n**Vendedor:** <@${data.recebedor}>`))
                .addActionRowComponents(new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('taxa_comprador').setLabel('Comprador').setEmoji('<:emoji_165:1499214852990832671>').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('taxa_dividir').setLabel('Dividir taxa').setEmoji('<:emoji_166:1541614807621443604>').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('taxa_vendedor').setLabel('Vendedor').setEmoji('<:emoji_164:1541612138756579439>').setStyle(ButtonStyle.Secondary)
                ));
            data.msgTaxa = await channel.send({ components: [containerTaxa], flags: MessageFlags.IsComponentsV2 });
        });
    });
}
async function iniciarFluxoImagens(channel) {
    let data = tradeData.get(channel.id);
    if (!data) {
        data = { enviador: null, recebedor: null, valor: null, item: null, staffReivindicou: null, msgDmId: null, confirmacoes: [], confirmacoesEntrega: [], participantes: [], colValor: null, colItem: null, msgValor: null, msgItem: null };
        tradeData.set(channel.id, data);
    } else {
        data.colValor?.stop();
        data.colItem?.stop();
        data.colValor = null;
        data.colItem = null;
        data.itemMessageId = null;
        data.itemProcessing = false;
        data.msgValor = null;
        data.msgItem = null;
        data.enviador = null; data.recebedor = null; data.valor = null; data.item = null; data.staffReivindicou = null; data.confirmacoes = []; data.confirmacoesEntrega = []; data.lockValor = false; data.lockItem = false; data.itemMessageId = null; data.itemProcessing = false;
    }

    data.coletaValorIniciada = false;
    const container = construirContainerFuncoes(data);

    await channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(console.error);
}

async function getCanal(guild, channelId) {
    if (!guild || !channelId) return null;
    try {
        return guild.channels.cache.get(channelId) || await guild.channels.fetch(channelId).catch(() => null);
    } catch (e) {
        return null;
    }
}

async function responderSeguro(interaction, options) {
    const isDM = !interaction.guildId;
    const opts = typeof options === 'string' ? { content: options } : { ...options };
    if (isDM) {
        delete opts.flags;
        if (opts.ephemeral) delete opts.ephemeral;
    } else {
        if (opts.ephemeral && !opts.flags) opts.flags = [MessageFlags.Ephemeral];
    }
    try {
        if (interaction.deferred || interaction.replied) {
            return await interaction.followUp(opts).catch(console.error);
        }
        return await interaction.reply(opts).catch(console.error);
    } catch (e) {
        console.error("Erro ao responder interação:", e);
    }
}

async function enviarLog(guild, embed, files = []) {
    const canalLog = await getCanal(guild, CANAL_LOGS_ID);
    if (!canalLog) {
        console.error("Canal de logs não encontrado:", CANAL_LOGS_ID);
        return false;
    }

    try {
        await canalLog.send({ embeds: [embed], files });
        return true;
    } catch (erro) {
        console.error("Erro ao enviar embed para o canal de logs:", erro);
        return false;
    }
}

async function solicitarChavePixDoRecebedor(channel, data) {
    const containerM = new ContainerBuilder().setAccentColor(0xDE4548)
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(`<@${data.recebedor}>\n\n# Selecione o tipo de chave PIX\nEscolha abaixo o tipo de chave para receber o pagamento do staff.`))
        .addActionRowComponents(new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('selecionar_tipo_pix').setPlaceholder('Selecione o tipo...').addOptions([{ label: 'Celular', value: 'celular', emoji: '📱' }, { label: 'CPF/CNPJ', value: 'cpf_cnpj', emoji: '👤' }, { label: 'E-mail', value: 'email', emoji: '📧' }, { label: 'Chave Aleatória', value: 'aleatoria', emoji: '🆔' }, { label: 'USDT Wallet', value: 'usdt', emoji: '🪙' }])));
    await channel.send({ components: [containerM], flags: MessageFlags.IsComponentsV2 });
}

async function iniciarChecklistPosConta(channel, data) {
    data.contaProvas = {}; saveTradeDataToDisk();
    const painel = new ContainerBuilder().setAccentColor(0xDE4548)
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# 🔐 Checklist pós-entrega da conta\n\nCada participante deve preencher o checklist e enviar uma imagem da tela de segurança.\n\n**Vendedor:** recuperação, pagamentos e sessões antigas removidos.\n**Comprador:** senha trocada, 2FA ativado e sessões antigas encerradas.\n\nNão envie prints com senha, token, códigos, e-mail completo ou documento.`))
        .addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('conta_prova').setLabel('Enviar checklist e comprovante').setStyle(ButtonStyle.Primary)));
    await channel.send({ components: [painel], flags: MessageFlags.IsComponentsV2 });
}

// ── Sistema Anti-Duplicação (Cooldown) ──
// Evita que a mesma pessoa dispare a mesma ação duas vezes clicando/respondendo
// rápido demais (double-click, lag do Discord reenviando a interação, etc).
const interactionCooldowns = new Map();
// Fila isolada por canal: um ticket não interfere nas ações de outro ticket.
const ticketInteractionQueues = new Map();
async function aguardarFilaDoTicket(channelId) {
    const key = channelId || 'dm-sem-canal';
    const anterior = ticketInteractionQueues.get(key) || Promise.resolve();
    let liberar;
    const atual = new Promise(resolve => { liberar = resolve; });
    const encadeada = anterior.then(() => atual);
    ticketInteractionQueues.set(key, encadeada);
    await anterior.catch(() => {});
    return () => {
        liberar();
        if (ticketInteractionQueues.get(key) === encadeada) ticketInteractionQueues.delete(key);
    };
}

const COOLDOWN_MS = 2500; // tempo mínimo de espera entre ações repetidas

function estaEmCooldown(key) {
    const ultimo = interactionCooldowns.get(key);
    if (!ultimo) return false;
    return (Date.now() - ultimo) < COOLDOWN_MS;
}

function registrarCooldown(key) {
    interactionCooldowns.set(key, Date.now());
}

// Limpa entradas antigas periodicamente para não crescer a memória infinitamente
setInterval(() => {
    const agora = Date.now();
    for (const [key, timestamp] of interactionCooldowns) {
        if (agora - timestamp > COOLDOWN_MS * 4) interactionCooldowns.delete(key);
    }
}, 60 * 1000);

// Trava de execução única por interação: se o painel de hospedagem recarregar
// este arquivo sem reiniciar o processo Node por completo (ou se o Discord
// reentregar o mesmo evento), o MESMO id de interação não roda 2x — mas isso
// NUNCA afeta outras interações, outros tickets ou outras funções/códigos
// que estejam rodando junto no mesmo client. Nada de removeAllListeners aqui,
// pois isso apagaria também os listeners de outros módulos/comandos.
const interacoesEmAndamento = new Set();

client.on(Events.InteractionCreate, async (interaction) => {
  if (interacoesEmAndamento.has(interaction.id)) return; // mesma interação já está sendo processada — quebra na hora
  interacoesEmAndamento.add(interaction.id);
  try {
  const liberarFila = await aguardarFilaDoTicket(interaction.channelId);
  try {
    if (interaction.inGuild() && !interaction.isModalSubmit() && (!interaction.member || !interaction.member.roles?.cache)) {
        try {
            interaction.member = await interaction.guild.members.fetch(interaction.user.id);
        } catch (e) {
            console.error("Falha ao buscar o member da interação:", e);
        }
    }

    // Bloqueia cliques/seleções repetidas do MESMO usuário no MESMO botão/menu
    // dentro do MESMO canal antes do tempo de cooldown passar.
    // Modais e comandos de barra não entram nesse bloqueio.
    if (interaction.isButton() || interaction.isStringSelectMenu() || interaction.isUserSelectMenu()) {
        const cooldownKey = `${interaction.channelId}_${interaction.customId}_${interaction.user.id}`;
        if (estaEmCooldown(cooldownKey)) {
            return await interaction.reply({ content: "⏳ Calma! Aguarde um instante antes de clicar novamente.", flags: [MessageFlags.Ephemeral] }).catch(() => {});
        }
        registrarCooldown(cooldownKey);
    }

    let data = tradeData.get(interaction.channelId); if (!data) { loadTradeDataFromDisk(); data = tradeData.get(interaction.channelId); }

    if (interaction.isChatInputCommand()) {
        if (interaction.commandName === 'passar-posse') {
            if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) {
                return await interaction.reply({ content: '<:emoji_167:1541618912238768148> Apenas um Middleman da staff pode passar a posse.', flags: [MessageFlags.Ephemeral] });
            }
            const posse = { id: `${interaction.channel.id}_${Date.now()}`, channelId: interaction.channel.id, criadaPor: interaction.user.id, pagamentoConfirmado: false, assumida: false, assumidaPor: null };
            posseData.set(posse.id, posse);
            return await interaction.reply({ components: [construirPainelPosse(posse)], flags: MessageFlags.IsComponentsV2 });
        }

        if (interaction.commandName === "configpix") {
            if (!interaction.member?.permissions?.has(PermissionFlagsBits.Administrator)) {
                return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Apenas administradores podem configurar o PIX de um Middleman.", flags: [MessageFlags.Ephemeral] });
            }
            const modal = new ModalBuilder().setCustomId("modal_config_pix").setTitle("Configurar PIX do Middleman");
            modal.addComponents(
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("pix_id").setLabel("ID do usuário (Middleman)").setPlaceholder("Ex: 123456789012345678").setStyle(TextInputStyle.Short).setRequired(true)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("pix_key").setLabel("Chave PIX").setStyle(TextInputStyle.Short).setRequired(true)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("pix_name").setLabel("Nome Completo (Sem acentos)").setStyle(TextInputStyle.Short).setRequired(true)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("pix_limite").setLabel("Valor máximo que pode mediar (R$)").setPlaceholder("Ex: 500  |  deixe 0 para sem limite").setStyle(TextInputStyle.Short).setRequired(false)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("pix_trocas").setLabel("Intermediações do MM (ex: 81)").setPlaceholder("Ex: 81  |  deixe vazio para manter atual").setStyle(TextInputStyle.Short).setRequired(false))
            );
            return await interaction.showModal(modal);
        }
        if (interaction.commandName === "ranking") {
            const embedContent = await getRankingEmbed(interaction.guild, "geral", 1);
            return await interaction.reply(embedContent);
        }

        if (interaction.commandName === "perfil") {
            await interaction.deferReply();

            const user = interaction.options.getUser("usuario") || interaction.user;
            const profileUser = await interaction.client.users.fetch(user.id, { force: true }).catch(() => user);
            const dataU = userData[user.id] || { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear(), trocasMes: 0 };
            const member = await interaction.guild.members.fetch(user.id).catch(() => null);

            const allUsersGeral = Object.entries(userData).filter(([, u]) => (u.totalValor || 0) > 0).sort(([, a], [, b]) => (b.totalValor || 0) - (a.totalValor || 0));
            const rankGeral = allUsersGeral.findIndex(([id]) => id === user.id) + 1;
            const allUsersMensal = Object.entries(userData).filter(([, u]) => (u.totalMes || 0) > 0).sort(([, a], [, b]) => (b.totalMes || 0) - (a.totalMes || 0));
            const rankMensal = allUsersMensal.findIndex(([id]) => id === user.id) + 1;

            const cargoAtual = RANK_CARGOS.find(r => dataU.totalValor >= r.limite) || RANK_CARGOS[RANK_CARGOS.length - 1];
            const indexAtual = RANK_CARGOS.indexOf(cargoAtual);
            const proximoCargo = RANK_CARGOS[indexAtual - 1];

            try {
                const buffer = await gerarCartaoPerfil({
                    username: profileUser.username,
                    avatarURL: profileUser.displayAvatarURL({ extension: "png", size: 256 }),
                    userHandle: profileUser.username,
                    bannerURL: profileUser.bannerURL({ extension: "png", size: 1024 }),
                    hasNitro: Boolean(profileUser.banner),
                    cargos: member ? [...member.roles.cache.values()]
                        .filter(role => role.id !== interaction.guild.id)
                        .map(role => ({ id: role.id, name: role.name, color: role.hexColor, position: role.position })) : [],
                    rankNome: cargoAtual.nome,
                    rankCorHex: RANK_COLORS[cargoAtual.id] || "#9B30FF",
                    rankIconType: cargoAtual.iconType,
                    rank: rankGeral || allUsersGeral.length + 1,
                    rankTotal: Math.max(allUsersGeral.length, 954),
                    rankMensal: rankMensal > 0 ? rankMensal : 0,
                    total: dataU.totalValor || 0,
                    trocas: dataU.totalTrocas || 0,
                    maiorTrend: dataU.maiorTroca || 0,
                    valorMensal: dataU.totalMes || 0,
                    totalMensal: dataU.totalMes || 0,
                    clienteDesde: dataU.clienteDesde || new Date().getFullYear(),
                    pessoasAtendidas: dataU.pessoasIntermediadas || 0,
                    todosCargos: TODOS_CARGOS_ORDENADOS,
                    proximoRank: proximoCargo ? { nome: proximoCargo.nome, faltam: Math.max(0, proximoCargo.limite - dataU.totalValor) } : null,
                    progresso: proximoCargo ? (dataU.totalValor - cargoAtual.limite) / (proximoCargo.limite - cargoAtual.limite) : 1,
                    conquistas: [
                        { tier: "bronze", iconType: "handshake", label: "100 intermédios", desbloqueado: dataU.totalTrocas >= 100 },
                        { tier: "prata", iconType: "money", label: "R$ 1k movim.", desbloqueado: dataU.totalValor >= 1000 },
                        { tier: "ouro", iconType: "money", label: "R$ 10k movim.", desbloqueado: dataU.totalValor >= 10000 },
                        { tier: "value", iconType: "diamond", label: "Trade R$ 500+", desbloqueado: dataU.maiorTroca >= 500 },
                        { tier: "black", iconType: "flame", label: "250 intermédios", desbloqueado: dataU.totalTrocas >= 250 },
                        { tier: "vermelho", iconType: "flame", label: "500 intermédios", desbloqueado: dataU.totalTrocas >= 500 },
                        { tier: "vermelho", iconType: "crown", label: "Top Trader", desbloqueado: rankGeral === 1 },
                        { tier: "vermelho", iconType: "crown", label: "Maior do mês", desbloqueado: rankMensal === 1 }
                    ]
                });

                const anexo = new AttachmentBuilder(buffer, { name: "perfil.png" });
                return await interaction.editReply({ files: [anexo] });
            } catch (e) {
                console.error("Erro ao gerar cartão de perfil:", e);
                return await interaction.editReply({ content: "<:emoji_167:1541618912238768148> Erro ao gerar o cartão de perfil." });
            }
        }

        if (interaction.commandName === "vouch") {
            if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Sem permissão.", flags: [MessageFlags.Ephemeral] });
            const tipo = interaction.options.getString("tipo");
            const comprador = interaction.options.getUser("comprador");
            const vendedor = interaction.options.getUser("vendedor");
            const valor = sanitizarValor(interaction.options.getString("valor"));
            if (valor <= 0) return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Valor inválido.", flags: [MessageFlags.Ephemeral] });
            await interaction.deferReply();
            await executarAprovarPagamento(interaction.guild, interaction.user, tipo, comprador, vendedor, valor);
            return await interaction.editReply({ content: `<:emoji_172:1541636098005016576> Pagamento de R$ ${valor.toFixed(2)} aprovado!` });
        }

        if (interaction.commandName === "aprovar_pagamento") {
            if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Sem permissão.", flags: [MessageFlags.Ephemeral] });
            const tipo = interaction.options.getString("tipo");
            const enviador = interaction.options.getUser("enviador");
            const recebedor = interaction.options.getUser("recebedor");
            const valor = sanitizarValor(interaction.options.getString("valor"));
            if (valor <= 0) return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Valor inválido.", flags: [MessageFlags.Ephemeral] });
            await interaction.deferReply();
            await executarAprovarPagamento(interaction.guild, interaction.user, tipo, enviador, recebedor, valor);
            return await interaction.editReply({ content: `<:emoji_172:1541636098005016576> Pagamento de R$ ${valor.toFixed(2)} aprovado!` });
        }
        if (interaction.commandName === "remover_valor") {
            if (!isDonoOuCargoMaisAlto(interaction.member)) {
                return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Acesso negado! Apenas o **Dono do servidor** (cargo mais alto) pode remover valores.", flags: [MessageFlags.Ephemeral] });
            }
            const user = interaction.options.getUser("usuario");
            const valor = sanitizarValor(interaction.options.getString("valor"));
            if (valor <= 0) return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Valor inválido.", flags: [MessageFlags.Ephemeral] });
            if (userData[user.id]) {
                userData[user.id].totalValor -= valor;
                userData[user.id].totalMes -= valor;
                if (userData[user.id].totalValor < 0) userData[user.id].totalValor = 0;
                if (userData[user.id].totalMes < 0) userData[user.id].totalMes = 0;
                saveUsers();
                await atualizarCargos(interaction.guild, user.id);
                return await interaction.reply({ content: `<:emoji_172:1541636098005016576> Removido R$ ${valor.toFixed(2)} de <@${user.id}>.` });
            }
            return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Usuário não encontrado no banco.", flags: [MessageFlags.Ephemeral] });
        }

        if (interaction.commandName === "alterar_intermediacoes") {
            if (!isDonoOuCargoMaisAlto(interaction.member)) {
                return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Acesso negado! Apenas o **Dono do servidor** (cargo mais alto) pode alterar intermediações e movimentos.", flags: [MessageFlags.Ephemeral] });
            }
            const user = interaction.options.getUser("usuario");
            const qtd = interaction.options.getInteger("quantidade");
            const tipo = interaction.options.getString("tipo") || "ambos";
            if (qtd === null || qtd < 0) return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Quantidade inválida.", flags: [MessageFlags.Ephemeral] });

            if (!userData[user.id]) {
                userData[user.id] = { totalTrocas: 0, trocasMes: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
            }

            if (tipo === "geral" || tipo === "ambos") {
                userData[user.id].totalTrocas = qtd;
                userData[user.id].pessoasIntermediadas = Math.max(userData[user.id].pessoasIntermediadas || 0, qtd);
            }
            if (tipo === "mensal" || tipo === "ambos") {
                userData[user.id].trocasMes = qtd;
            }

            saveUsers();
            await atualizarCargos(interaction.guild, user.id).catch(() => {});
            return await interaction.reply({
                content: `<:emoji_172:1541636098005016576> Intermediações de <@${user.id}> alteradas com sucesso pelo Dono para **${qtd}** (${tipo === 'geral' ? 'Total Geral' : tipo === 'mensal' ? 'Mensal' : 'Geral e Mensal'})!`
            });
        }
    }

    if (interaction.isStringSelectMenu() && interaction.customId === "rank_select") {
        const tipo = interaction.values[0];
        const embedContent = await getRankingEmbed(interaction.guild, tipo, 1);
        return await interaction.update(embedContent);
    }

    if (interaction.isButton() && interaction.customId.startsWith("rank")) {
        const parts = interaction.customId.split("_");
        const action = parts[0];
        const tipo = parts[1];
        let pagina = parseInt(parts[2]);
        if (action === "rankprev") pagina--; else pagina++;
        const embedContent = await getRankingEmbed(interaction.guild, tipo, pagina);
        return await interaction.update(embedContent);
    }

    if (interaction.isButton() && ["mm_perfil", "mm_mes", "mm_dia", "mm_pessoas"].includes(interaction.customId)) {
        if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) {
            return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Esse painel é exclusivo para a staff.", flags: [MessageFlags.Ephemeral] });
        }

        const d = userData[interaction.user.id] || {};

        if (interaction.customId === "mm_perfil") {
            const avaliacoesStaff = d.avaliacoes || [];
            const notaMedia = avaliacoesStaff.length ? (avaliacoesStaff.reduce((a, b) => a + b, 0) / avaliacoesStaff.length).toFixed(1) : "Sem avaliações";
            const embed = new EmbedBuilder()
                .setColor("#DE4548")
                .setTitle(`👤 Perfil de Middleman — ${interaction.user.username}`)
                .setThumbnail(interaction.user.displayAvatarURL({ extension: "png", size: 128 }))
                .addFields(
                    { name: "🤝 Intermediações totais", value: `${d.totalTrocas || 0}`, inline: true },
                    { name: "👥 Pessoas atendidas", value: `${d.pessoasIntermediadas || 0}`, inline: true },
                    { name: "⭐ Nota média", value: `${notaMedia}`, inline: true },
                    { name: "💰 Taxa faturada (total)", value: `R$ ${(d.taxaTotal || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`, inline: true },
                    { name: "📅 Taxa faturada (mês)", value: `R$ ${(d.taxaMes || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`, inline: true },
                    { name: "🕐 Taxa faturada (hoje)", value: `R$ ${(taxasDiarias[interaction.user.id] || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`, inline: true }
                );
            return await interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
        }

        if (interaction.customId === "mm_mes") {
            const taxaMes = d.taxaMes || 0;
            return await interaction.reply({ content: `💰 Você faturou **R$ ${taxaMes.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}** em taxas este mês.`, flags: [MessageFlags.Ephemeral] });
        }

        if (interaction.customId === "mm_dia") {
            const taxaDia = taxasDiarias[interaction.user.id] || 0;
            return await interaction.reply({ content: `📅 Você faturou **R$ ${taxaDia.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}** em taxas hoje (ainda não repassado no fechamento diário).`, flags: [MessageFlags.Ephemeral] });
        }

        if (interaction.customId === "mm_pessoas") {
            const lista = d.listaPessoas || [];
            if (!lista.length) return await interaction.reply({ content: "👥 Você ainda não intermediou ninguém.", flags: [MessageFlags.Ephemeral] });
            const exibidos = lista.slice(0, 30).map(id => `<@${id}>`).join(", ");
            const resto = lista.length > 30 ? `\n-# ...e mais ${lista.length - 30} pessoa(s).` : "";
            return await interaction.reply({ content: `👥 **Pessoas que você já atendeu (${lista.length}):**\n${exibidos}${resto}`, flags: [MessageFlags.Ephemeral] });
        }
    }

    if (interaction.isButton() && interaction.customId === "mm_config_intermed") {
        if (!isDonoOuCargoMaisAlto(interaction.member)) {
            return await interaction.reply({ 
                content: "<:emoji_167:1541618912238768148> Acesso negado! Apenas o **Dono do servidor** (cargo mais alto) tem permissão para alterar as intermediações e movimentos dos MMs.", 
                flags: [MessageFlags.Ephemeral] 
            });
        }
        const modal = new ModalBuilder().setCustomId("modal_ajustar_intermed").setTitle("Ajustar Intermediações / Movimentos");
        modal.addComponents(
            new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                    .setCustomId("intermed_user_id")
                    .setLabel("ID do Middleman / Usuário")
                    .setValue(interaction.user.id)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)
            ),
            new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                    .setCustomId("intermed_qtd")
                    .setLabel("Intermediações Gerais (ex: 81)")
                    .setPlaceholder("Ex: 81 (ou deixe vazio para manter atual)")
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)
            ),
            new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                    .setCustomId("intermed_qtd_mes")
                    .setLabel("Intermediações do Mês (ex: 81)")
                    .setPlaceholder("Ex: 81 (ou deixe vazio para manter atual)")
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)
            ),
            new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                    .setCustomId("intermed_total_mes")
                    .setLabel("Movimentação do Mês R$ (ex: 28600)")
                    .setPlaceholder("Ex: 28600 ou 28.6k (ou deixe vazio)")
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)
            ),
            new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                    .setCustomId("intermed_total_geral")
                    .setLabel("Movimentação Geral R$ (ex: 28600)")
                    .setPlaceholder("Ex: 28600 ou 28.6k (ou deixe vazio)")
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)
            )
        );
        return await interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId === "modal_ajustar_intermed") {
        if (!isDonoOuCargoMaisAlto(interaction.member)) {
            return await interaction.reply({ 
                content: "<:emoji_167:1541618912238768148> Acesso negado! Apenas o **Dono do servidor** (cargo mais alto) tem permissão para alterar as intermediações e movimentos dos MMs.", 
                flags: [MessageFlags.Ephemeral] 
            });
        }
        const idAlvo = interaction.fields.getTextInputValue("intermed_user_id").trim();
        const qtdStr = interaction.fields.getTextInputValue("intermed_qtd")?.trim() || "";
        const qtdMesStr = interaction.fields.getTextInputValue("intermed_qtd_mes")?.trim() || "";
        const totalMesStr = interaction.fields.getTextInputValue("intermed_total_mes")?.trim() || "";
        const totalGeralStr = interaction.fields.getTextInputValue("intermed_total_geral")?.trim() || "";

        if (!userData[idAlvo]) {
            userData[idAlvo] = { 
                totalTrocas: 0, 
                trocasMes: 0, 
                totalValor: 0, 
                maiorTroca: 0, 
                totalMes: 0, 
                contador: 0, 
                pessoasIntermediadas: 0, 
                listaPessoas: [], 
                clienteDesde: new Date().getFullYear() 
            };
        }

        const alteracoes = [];

        if (qtdStr.length > 0) {
            const qtd = parseInt(qtdStr.replace(/\D/g, ''), 10);
            if (!isNaN(qtd) && qtd >= 0) {
                userData[idAlvo].totalTrocas = qtd;
                userData[idAlvo].pessoasIntermediadas = Math.max(userData[idAlvo].pessoasIntermediadas || 0, qtd);
                alteracoes.push(`🤝 Intermediações Gerais: **${qtd}**`);
            }
        }

        if (qtdMesStr.length > 0) {
            const qtdMes = parseInt(qtdMesStr.replace(/\D/g, ''), 10);
            if (!isNaN(qtdMes) && qtdMes >= 0) {
                userData[idAlvo].trocasMes = qtdMes;
                alteracoes.push(`📅 Intermediações do Mês: **${qtdMes}**`);
            }
        }

        if (totalMesStr.length > 0) {
            let s = totalMesStr.toLowerCase().replace(/\s/g, '');
            let mult = 1;
            if (s.endsWith('k')) {
                mult = 1000;
                s = s.slice(0, -1);
            }
            const vMes = sanitizarValor(s) * mult;
            if (!isNaN(vMes) && vMes >= 0) {
                userData[idAlvo].totalMes = vMes;
                alteracoes.push(`💰 Movimentação do Mês: **R$ ${vMes.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}**`);
            }
        }

        if (totalGeralStr.length > 0) {
            let s = totalGeralStr.toLowerCase().replace(/\s/g, '');
            let mult = 1;
            if (s.endsWith('k')) {
                mult = 1000;
                s = s.slice(0, -1);
            }
            const vGeral = sanitizarValor(s) * mult;
            if (!isNaN(vGeral) && vGeral >= 0) {
                userData[idAlvo].totalValor = vGeral;
                alteracoes.push(`🏆 Movimentação Geral: **R$ ${vGeral.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}**`);
            }
        }

        if (!alteracoes.length) {
            return await interaction.reply({ 
                content: "<:emoji_167:1541618912238768148> Nenhum valor foi informado para alteração.", 
                flags: [MessageFlags.Ephemeral] 
            });
        }

        saveUsers();
        await atualizarCargos(interaction.guild, idAlvo).catch(() => {});
        return await interaction.reply({ 
            content: `${EMOJI_CHECK} **Dados de <@${idAlvo}> ajustados com sucesso pelo Dono:**\n${alteracoes.join('\n')}`, 
            flags: [MessageFlags.Ephemeral] 
        });
    }

    if (interaction.isButton() && interaction.customId.startsWith("abrir_transcript_")) {
        const pendingId = interaction.customId.replace("abrir_transcript_", "");
        const pend = avaliacoesPendentes.get(pendingId);
        if (!pend || !pend.transcript) return await responderSeguro(interaction, { content: "<:emoji_167:1541618912238768148> Transcript não encontrado ou expirado.", ephemeral: true });
        const anexoTranscript = new AttachmentBuilder(Buffer.from(pend.transcript), { name: `transcript-${pendingId}.txt` });
        return await responderSeguro(interaction, { content: "📄 Aqui está o transcript da sua negociação:", files: [anexoTranscript], ephemeral: true });
    }

    if (interaction.isButton() && interaction.customId.startsWith("av_")) {
        const partesId = interaction.customId.split("_");
        const nota = partesId[1];
        const pendingId = partesId.slice(2).join("_");
        const pend = avaliacoesPendentes.get(pendingId);
        if (!pend) return await responderSeguro(interaction, { content: "<:emoji_167:1541618912238768148> Essa avaliação já expirou ou não foi encontrada.", ephemeral: true });
        if (pend.avaliacoes && pend.avaliacoes[interaction.user.id]) return await responderSeguro(interaction, { content: "<:emoji_172:1541636098005016576> Você já avaliou esta mediação, obrigado!", ephemeral: true });
        if (interaction.user.id !== pend.enviador && interaction.user.id !== pend.recebedor) return await responderSeguro(interaction, { content: "<:emoji_167:1541618912238768148> Você não faz parte dessa negociação.", ephemeral: true });

        const modalAvaliacao = new ModalBuilder()
            .setCustomId(`modal_avaliacao_${nota}_${pendingId}`)
            .setTitle("Deixe seu comentário")
            .addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId("comentario_avaliacao")
                        .setLabel("Como foi sua experiência com o MM?")
                        .setStyle(TextInputStyle.Paragraph)
                        .setPlaceholder("Conte como foi a mediação, o atendimento, a agilidade...")
                        .setMaxLength(300)
                        .setRequired(true)
                )
            );
        return await interaction.showModal(modalAvaliacao);
    }

    if (data && interaction.isButton() && !interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) {
        if (!data.participantes.includes(interaction.user.id)) return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Você não faz parte desta negociação!", flags: [MessageFlags.Ephemeral] });
    }

    if (interaction.isModalSubmit() && interaction.customId === "modal_config_pix") {
        const idDigitado = interaction.fields.getTextInputValue("pix_id").trim();
        if (!/^\d{17,20}$/.test(idDigitado)) {
            return await interaction.reply({ content: "<:emoji_167:1541618912238768148> ID inválido. Clique com o botão direito no usuário no Discord → **Copiar ID de Usuário** e cole exatamente esse valor.", flags: [MessageFlags.Ephemeral] });
        }
        const membroAlvo = await interaction.guild.members.fetch(idDigitado).catch(() => null);
        if (!membroAlvo) {
            return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Não encontrei ninguém com esse ID neste servidor. Confira se copiou o ID certo.", flags: [MessageFlags.Ephemeral] });
        }

        const limiteStr = interaction.fields.getTextInputValue("pix_limite");
        const limite = sanitizarValor(limiteStr); // 0 (ou vazio) = sem limite
        pixConfig.set(idDigitado, { chave: interaction.fields.getTextInputValue("pix_key"), nome: interaction.fields.getTextInputValue("pix_name"), limite });
        salvarDadosPix();
        if (fs.existsSync(dbPixPath)) {
            try { pixConfig = new Map(Object.entries(JSON.parse(fs.readFileSync(dbPixPath)))); } catch (e) {}
        }
        let trocasMsg = "";
        try {
            const trocasStr = interaction.fields.getTextInputValue("pix_trocas");
            if (trocasStr && trocasStr.trim().length > 0) {
                if (!isDonoOuCargoMaisAlto(interaction.member)) {
                    trocasMsg = "\n> ⚠️ *Apenas o Dono (cargo mais alto) tem permissão para alterar o número de intermediações.*";
                } else {
                    const trocasVal = parseInt(trocasStr.trim().replace(/\D/g, ''));
                    if (!isNaN(trocasVal) && trocasVal >= 0) {
                        if (!userData[idDigitado]) {
                            userData[idDigitado] = { totalTrocas: trocasVal, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: trocasVal, listaPessoas: [], clienteDesde: new Date().getFullYear(), trocasMes: 0 };
                        } else {
                            userData[idDigitado].totalTrocas = trocasVal;
                            userData[idDigitado].pessoasIntermediadas = Math.max(userData[idDigitado].pessoasIntermediadas || 0, trocasVal);
                        }
                        saveUsers();
                        trocasMsg = `\n> Intermediações do MM definidas para: **${trocasVal}**`;
                    }
                }
            }
        } catch (e) {}
        const limiteTexto = limite > 0 ? `R$ ${limite.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}` : "Sem limite";
        return await interaction.reply({ content: `${EMOJI_CHECK} PIX configurado com sucesso para <@${idDigitado}>!\n> Limite de mediação: **${limiteTexto}**${trocasMsg}`, flags: [MessageFlags.Ephemeral] });
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith("modal_avaliacao_")) {
        const semPrefixo = interaction.customId.replace("modal_avaliacao_", "");
        const partesModal = semPrefixo.split("_");
        const notaModal = partesModal[0];
        const pendingIdModal = partesModal.slice(1).join("_");
        const pendModal = avaliacoesPendentes.get(pendingIdModal);
        if (!pendModal) return await responderSeguro(interaction, { content: "<:emoji_167:1541618912238768148> Essa avaliação expirou, sinto muito.", ephemeral: true });

        const comentarioModal = interaction.fields.getTextInputValue("comentario_avaliacao");
        if (interaction.guildId) {
            await interaction.deferReply({ flags: [MessageFlags.Ephemeral] }).catch(() => {});
        } else {
            await interaction.deferReply().catch(() => {});
        }

        if (!pendModal.avaliacoes) pendModal.avaliacoes = {};
        pendModal.avaliacoes[interaction.user.id] = { nota: notaModal, comentario: comentarioModal };
        saveAvaliacoesPendentes();

        if (pendModal.staffId) {
            if (!userData[pendModal.staffId]) userData[pendModal.staffId] = { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
            if (!userData[pendModal.staffId].avaliacoes) userData[pendModal.staffId].avaliacoes = [];
            userData[pendModal.staffId].avaliacoes.push(parseInt(notaModal) || 5);
            saveUsers();
        }

        try {
            const guildAvaliacao = client.guilds.cache.get(GUILD_ID) || await client.guilds.fetch(GUILD_ID).catch(() => null);
            const mediadorU = pendModal.staffId ? await client.users.fetch(pendModal.staffId).catch(() => null) : null;
            const estrelasTexto = "⭐".repeat(Math.max(1, Math.min(5, parseInt(notaModal) || 0)));

            const embedAvaliacao = new EmbedBuilder()
                .setColor(0xDE4548)
                .setTitle('⭐ Nova avaliação de intermediação')
                .setThumbnail("https://i.postimg.cc/hPqvpDtX/nex1-2.gif")
                .addFields(
                    { name: 'Nota', value: `${estrelasTexto} ${notaModal}/5` },
                    { name: 'Usuário', value: `<@${interaction.user.id}>` },
                    { name: 'Middleman', value: mediadorU ? `<@${mediadorU.id}>` : "Não informado" },
                    { name: 'Avaliação', value: comentarioModal || "Sem comentário" }
                )
                .setFooter({ text: `Intermediação ${pendModal.transacaoId || pendingIdModal}` })
                .setTimestamp();

            const canalAvaliacoes = await getCanal(guildAvaliacao, CANAL_AVALIACOES);
            if (canalAvaliacoes) await canalAvaliacoes.send({ embeds: [embedAvaliacao] }).catch(console.error);
        } catch (e) {
            console.error("Erro ao enviar embed de avaliação:", e);
        }

        await responderSeguro(interaction, { content: "<:emoji_172:1541636098005016576> Obrigado pela sua avaliação!", ephemeral: true });

        if (pendModal.avaliacoes[pendModal.enviador] && pendModal.avaliacoes[pendModal.recebedor]) {
            avaliacoesPendentes.delete(pendingIdModal);
            saveAvaliacoesPendentes();
        }
        return;
    }

    if ((interaction.isStringSelectMenu() && interaction.customId === 'menu_mm') || (interaction.isButton() && ['abrir_mediacao', 'abrir_mediacao_baixa', 'abrir_conta', 'abrir_conta_baixa'].includes(interaction.customId))) {
        const modoConta = interaction.isButton() && interaction.customId.startsWith('abrir_conta');
        const tipoMM = modoConta ? 'CONTA' : (interaction.isStringSelectMenu() ? interaction.values[0] : 'PIX');
        // Conta usa a mesma cobrança, mas a entrega ocorre fora do bot e sem credenciais no ticket.
        const tipoTaxa = (interaction.isButton() && ['abrir_mediacao_baixa', 'abrir_conta_baixa'].includes(interaction.customId)) ? 'baixa' : 'normal';
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

        const ticketExistente = interaction.guild.channels.cache.find(c => c.name.includes(interaction.user.username) && c.parentId === CATEGORIA_TICKETS);
        if (ticketExistente) {
            const containerAviso = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:emoji_167:1541618912238768148> Você já possui um ticket de MM aberto!\nSeu ticket em <#${ticketExistente.id}> ainda está aberto.`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setLabel('Ir para o Ticket').setURL(`https://discord.com/channels/${interaction.guild.id}/${ticketExistente.id}`).setStyle(ButtonStyle.Secondary)));
            return await interaction.editReply({ components: [containerAviso], flags: MessageFlags.IsComponentsV2 });
        }

        const canalTicket = await interaction.guild.channels.create({
            name: `・mm${tipoTaxa === 'baixa' ? '2' : ''}-${tipoMM}-${interaction.user.username}`, type: ChannelType.GuildText, parent: CATEGORIA_TICKETS,
            permissionOverwrites: [{ id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] }, { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] }, { id: CARGO_STAFF_ID, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ManageMessages] }]
        });

        tradeData.set(canalTicket.id, { enviador: null, recebedor: null, valor: null, item: null, staffReivindicou: null, msgDmId: null, confirmacoes: [], confirmacoesEntrega: [], participantes: [interaction.user.id], criadorTicketId: interaction.user.id, colValor: null, colItem: null, msgValor: null, msgItem: null, tipoTaxa, modoConta, vendedorAnonimo: false }); saveTradeDataToDisk();

        const container1 = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`||<@${interaction.user.id}> <@&${CARGO_STAFF_ID}>||\n\n# <:parceria:1485054250429054986> ╺╸ Middleman de ${modoConta ? 'CONTA' : 'PIX'} criado.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\nSeja bem vindo ao ticket **AUTOMÁTICO** de MiddleMan.\n\n**Passos:**\n1. Adicione o usuário com quem vai negociar.\n2. O bot registra somente o valor e uma descrição pública da negociação.\n3. Após confirmação, o PIX automático é gerado.\n4. Na modalidade **CONTA**, nunca envie senha, token, 2FA ou código de recuperação; a entrega ocorre apenas na plataforma oficial.`));
        const container2 = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Notificação de Segurança\nNossa equipe e nosso bot jamais entram em contato por mensagem direta.\n\nToda comunicação da negociação deve acontecer exclusivamente por este ticket.\n\nIgnorar isso pode te colocar em risco de golpe ou fraude. Não aceitamos pagamentos via Inter ou PicPay.\n\nSolicitações indevidas de reembolso podem gerar medidas cabíveis, inclusive ação judicial.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Quem abriu o ticket** pode encerrar aqui se desistir antes de concluir a configuração.`));
        const container3 = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Com Quem Você Está Negociando?\nSelecione o usuário Discord da outra parte.\nSó quem abriu o ticket pode escolher.\n\nUse o menu abaixo **ou** envie o ID /\n@menção do usuário diretamente no chat.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`))
            .addActionRowComponents(new ActionRowBuilder().addComponents(new UserSelectMenuBuilder().setCustomId('add_user_menu').setPlaceholder('Selecione o outro usuário...')))
            .addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('btn_termos').setLabel('Termos MM').setEmoji('<:emoji_166:1541614807621443604>').setStyle(ButtonStyle.Secondary), new ButtonBuilder().setCustomId('btn_fechar').setLabel('Cancelar Ticket').setEmoji('<:emoji_167:1541618912238768148>').setStyle(ButtonStyle.Secondary)));

        await canalTicket.send({ components: [container1], flags: MessageFlags.IsComponentsV2 });
        await canalTicket.send({ components: [container2], flags: MessageFlags.IsComponentsV2 });
        await canalTicket.send({ components: [container3], flags: MessageFlags.IsComponentsV2 });

        enviarLog(interaction.guild, new EmbedBuilder().setColor('#DE4548').setTitle('Ticket Aberto').setDescription(`O usuário <@${interaction.user.id}> abriu um ticket de MM (${tipoMM}).\nCanal: ${canalTicket}`));
        await interaction.editReply({ content: `${EMOJI_CHECK} **|** Seu middleman foi criado com sucesso ${canalTicket}` });
    }

    if (interaction.isUserSelectMenu() && interaction.customId === 'add_user_menu') {
        const alvoId = interaction.values[0];
        if (alvoId === interaction.user.id) return await interaction.reply({ content: "> <:emoji_167:1541618912238768148> Você não pode adicionar a si mesmo.", flags: [MessageFlags.Ephemeral] });
        const container = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Confirmar Contraparte\nVocê selecionou <@${alvoId}>. Confirme que é a pessoa certa ou escolha outra.\n\nSó quem abriu o ticket pode confirmar.\nEvita convidar o usuário errado.`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`confirm_target_${alvoId}`).setLabel('Confirmar pessoa').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId('escolher_outro').setLabel('Escolher outra pessoa').setStyle(ButtonStyle.Secondary)));
        await interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
    }

    if (interaction.isButton() && interaction.customId.startsWith('confirm_target_')) {
        if (!data || interaction.user.id !== data.criadorTicketId) return await interaction.reply({ content: 'Somente quem abriu o ticket pode confirmar a contraparte.', flags: [MessageFlags.Ephemeral] });
        const alvoId = interaction.customId.split('_')[2];
        if (data) { if (!data.participantes.includes(alvoId)) data.participantes.push(alvoId); }
        await interaction.channel.permissionOverwrites.edit(alvoId, { ViewChannel: true, SendMessages: true });
        const fetched = await interaction.channel.messages.fetch({ limit: 10 }); if (fetched) await interaction.channel.bulkDelete(fetched);
        await interaction.reply({ content: `> ${EMOJI_CHECK} ╺╸ Usuário <@${alvoId}> adicionado!`, flags: [MessageFlags.Ephemeral] });
        if (data?.modoConta) {
            await interaction.channel.send({ components: [new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(
                `# 🔐 Primeiro: definam as funções\n\n` +
                `O Middleman verá somente o valor e o status do pagamento.\n` +
                `Não enviem senha, e-mail de login, token, 2FA, código de recuperação, cookie ou chave de API.\n\n` +
                `Clique em **Vou comprar** se você pagará ao Middleman, ou em **Vou vender** se você é o vendedor da conta.`
            ))], flags: MessageFlags.IsComponentsV2 });
            await interaction.channel.send({ components: [construirContainerFuncoes(data)], flags: MessageFlags.IsComponentsV2 });
        } else {
            await iniciarFluxoImagens(interaction.channel);
        }
    }

    if (interaction.isButton() && interaction.customId === 'escolher_outro') {
        const container = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Com Quem Você Está Negociando?\nSelecione o usuário Discord da outra parte.\nSó quem abriu o ticket pode escolher.\n\nUse o menu abaixo **ou** envie o ID /\n@menção do usuário diretamente no chat.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(new UserSelectMenuBuilder().setCustomId('add_user_menu').setPlaceholder('Selecione o outro usuário...')));
        await interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
    }

    if (interaction.isButton() && interaction.customId === 'conta_iniciar_dados') {
        if (!data?.modoConta || !data.participantes.includes(interaction.user.id)) return await responderSeguro(interaction, { content: 'Ação inválida para este ticket.', ephemeral: true });
        await interaction.deferUpdate().catch(() => {});
        await limparMensagensDoBot(interaction.channel);
        await iniciarFluxoConta(interaction.channel, data);
        return;
    }

    if (interaction.isButton() && interaction.customId === 'conta_reiniciar_etapas') {
        if (!data?.modoConta || interaction.user.id !== data.recebedor) return await responderSeguro(interaction, { content: 'Somente o vendedor pode refazer as etapas.', ephemeral: true });
        await interaction.deferUpdate().catch(() => {});
        await limparMensagensDoBot(interaction.channel);
        return await iniciarFluxoConta(interaction.channel, data);
    }

    if (interaction.isButton() && /^conta_etapa_[1-4]_/.test(interaction.customId)) {
        if (!data?.modoConta || interaction.user.id !== data.recebedor) return await responderSeguro(interaction, { content: 'Somente o vendedor pode responder às etapas de segurança.', ephemeral: true });
        const [, , etapaTxt, resposta] = interaction.customId.split('_');
        const etapa = Number(etapaTxt);
        data.contaDados = data.contaDados || {};
        if (data.contaDados.etapa !== etapa) return await responderSeguro(interaction, { content: 'Essa etapa não está mais ativa.', ephemeral: true });
        if (etapa === 1) data.contaDados.tipo = resposta === 'propria' ? 'Conta própria' : 'Conta de revenda';
        if (etapa === 2) data.contaDados.passaraOg = resposta === 'sim';
        if (etapa === 3) data.contaDados.ogTemRecuperacao = resposta === 'sim';
        if (etapa === 4) data.contaDados.passaraRecuperacao = resposta === 'sim';
        if (etapa < 4) {
            await interaction.deferUpdate().catch(() => {});
            await limparMensagensDoBot(interaction.channel);
            return await enviarEtapaSegurancaConta(interaction.channel, data, etapa + 1);
        }
        const modal = new ModalBuilder().setCustomId('modal_conta_valor').setTitle('Valor da conta');
        modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('conta_valor').setLabel('Valor total da conta (R$)').setPlaceholder('Ex.: 250,00').setStyle(TextInputStyle.Short).setMaxLength(20).setRequired(true)));
        return await interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId === 'modal_conta_valor') {
        if (!data?.modoConta || interaction.user.id !== data.recebedor) return await responderSeguro(interaction, { content: 'Somente o vendedor pode informar o valor.', ephemeral: true });
        const valorTexto = interaction.fields.getTextInputValue('conta_valor').trim();
        const valor = sanitizarValor(valorTexto);
        if (valor <= 0) return await responderSeguro(interaction, { content: 'Informe um valor válido, por exemplo: `250,00`.', ephemeral: true });
        data.valor = valor.toString();
        data.item = `Conta — ${data.contaDados?.tipo || 'Conta digital'}`;
        data.contaDados.valor = valor;
        data.contaConfirmacoes = [];
        saveTradeDataToDisk();
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
        await limparMensagensDoBot(interaction.channel);
        await interaction.channel.send({ components: [construirResumoConta(data)], flags: MessageFlags.IsComponentsV2 });
        return await interaction.editReply({ content: `${EMOJI_CHECK} Etapas e valor registrados. Agora comprador e vendedor devem conferir e confirmar.` });
    }

    if (interaction.isButton() && interaction.customId === 'conta_confirmar_dados') {
        if (!data?.modoConta || !data.contaDados || ![data.enviador, data.recebedor].includes(interaction.user.id)) return await responderSeguro(interaction, { content: 'Somente comprador e vendedor podem confirmar.', ephemeral: true });
        if (!data.contaConfirmacoes) data.contaConfirmacoes = [];
        if (data.contaConfirmacoes.includes(interaction.user.id)) return await responderSeguro(interaction, { content: 'Você já confirmou essas informações.', ephemeral: true });
        data.contaConfirmacoes.push(interaction.user.id);
        saveTradeDataToDisk();
        if (data.contaConfirmacoes.length < 2) return await responderSeguro(interaction, { content: `${EMOJI_CHECK} Sua confirmação foi registrada. Aguardando a outra parte.`, ephemeral: true });
        await interaction.update({ components: [new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent('# 💳 Conta aprovada para pagamento\nAs duas partes confirmaram o checklist. Escolham agora quem paga a taxa da mediação.')).addActionRowComponents(new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('taxa_comprador').setLabel('Comprador').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('taxa_dividir').setLabel('Dividir taxa').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('taxa_vendedor').setLabel('Vendedor').setStyle(ButtonStyle.Secondary)
        ))], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        return;
    }

    if (interaction.isButton() && (interaction.customId === 'set_enviador' || interaction.customId === 'set_recebedor')) {
        if (!data) { return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Os dados deste ticket não foram encontrados ou a sessão expirou. Por favor, reabra a mediação.", flags: [MessageFlags.Ephemeral] }).catch(() => {}); }
        if ((interaction.customId === 'set_enviador' && data.recebedor === interaction.user.id) || (interaction.customId === 'set_recebedor' && data.enviador === interaction.user.id)) return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Você não pode ocupar as duas vagas!", flags: [MessageFlags.Ephemeral] });
        if (interaction.customId === 'set_enviador' && data.enviador) return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Essa vaga já foi ocupada!", flags: [MessageFlags.Ephemeral] });
        if (interaction.customId === 'set_recebedor' && data.recebedor) return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Essa vaga já foi ocupada!", flags: [MessageFlags.Ephemeral] });
        if (interaction.customId === 'set_enviador') data.enviador = interaction.user.id; else data.recebedor = interaction.user.id;

        if (data.enviador && data.recebedor) {
            data.exibicaoEscolhas = {};
            await interaction.deferUpdate().catch(() => {});
            await interaction.message.delete().catch(() => {});
            await limparMensagensDoBot(interaction.channel);
            if (data.modoConta) {
                await iniciarFluxoConta(interaction.channel, data);
            } else {
                await interaction.channel.send({ components: [construirContainerPrivacidadeVendedor(data)], flags: MessageFlags.IsComponentsV2 });
            }
        } else {
            await interaction.update({ components: [construirContainerFuncoes(data)], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        }
    }

    if (interaction.isButton() && ['taxa_comprador', 'taxa_dividir', 'taxa_vendedor'].includes(interaction.customId)) {
        if (!data) { return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Os dados deste ticket não foram encontrados ou a sessão expirou. Por favor, reabra a mediação.", flags: [MessageFlags.Ephemeral] }).catch(() => {}); }
        data.pagadorTaxa = interaction.customId.replace('taxa_', ''); // 'comprador' | 'dividir' | 'vendedor'
        await interaction.deferUpdate().catch(() => {});
        await interaction.message.delete().catch(() => {});
        data.msgTaxa = null;

        const labelPagador = { comprador: '<:emoji_165:1499214852990832671> Comprador', dividir: '<:emoji_166:1541614807621443604> Dividida entre ambos', vendedor: '<:emoji_164:1541612138756579439> Vendedor' }[data.pagadorTaxa];
        const containerF = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:parceria:1485054250429054986> — Confirmação Final\n<@${data.enviador}> <@${data.recebedor}>\nAmbas as partes devem confirmar se os dados abaixo estão corretos. Após a confirmação de ambos, o pagamento será gerado.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n<:emoji_165:1499214852990832671> **Enviador:** <@${data.enviador}>\n<:emoji_170:1505047772049702932> **Recebedor:** <@${data.recebedor}>\n<:emoji_165:1499214852990832671>  **Valor PIX:** R$ ${data.valor}\n<:emoji_171:1505047910667259924> **Itens/Serviço:** ${data.item}\n💰 **Pagador da Taxa:** ${labelPagador}\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Status:**\n⏳ <@${data.enviador}> Aguardando...\n⏳ <@${data.recebedor}> Aguardando...`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('confirm_trade').setLabel('Confirmar tudo').setStyle(ButtonStyle.Secondary), new ButtonBuilder().setCustomId('resetar_fluxo').setLabel('Tentar novamente').setStyle(ButtonStyle.Secondary)));

        await interaction.channel.send({ components: [containerF], flags: MessageFlags.IsComponentsV2 });
    }

    if (interaction.isButton() && ['v2_privacidade_anonimo', 'v2_privacidade_mostrar_tudo'].includes(interaction.customId)) {
        if (!data) return await interaction.reply({ content: '<:emoji_167:1541618912238768148> Dados deste ticket foram perdidos.', flags: [MessageFlags.Ephemeral] });
        if (!data.enviador || !data.recebedor) return await interaction.reply({ content: '⏳ Primeiro, os dois participantes precisam selecionar suas funções.', flags: [MessageFlags.Ephemeral] });
        if (interaction.user.id !== data.enviador && interaction.user.id !== data.recebedor) {
            return await interaction.reply({ content: '<:emoji_167:1541618912238768148> Somente o comprador e o vendedor deste ticket podem escolher essa opção.', flags: [MessageFlags.Ephemeral] });
        }
        if (!data.exibicaoEscolhas) data.exibicaoEscolhas = {};
        const anonimo = interaction.customId === 'v2_privacidade_anonimo';
        data.exibicaoEscolhas[interaction.user.id] = anonimo;
        data.compradorAnonimo = interaction.user.id === data.enviador ? anonimo : data.compradorAnonimo === true;
        data.vendedorAnonimo = interaction.user.id === data.recebedor ? anonimo : data.vendedorAnonimo === true;
        const ambosEscolheram = Object.prototype.hasOwnProperty.call(data.exibicaoEscolhas, data.enviador) && Object.prototype.hasOwnProperty.call(data.exibicaoEscolhas, data.recebedor);
        data.v2Configurado = ambosEscolheram;
        saveTradeDataToDisk();
        if (!ambosEscolheram) {
            return await interaction.update({ components: [construirContainerPrivacidadeVendedor(data)], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        }
        await interaction.deferUpdate().catch(() => {});
        await interaction.message.delete().catch(() => {});
        await limparMensagensDoBot(interaction.channel);
        await iniciarColetaValor(interaction.channel, data);
        return;
    }

    if (interaction.isButton() && interaction.customId === 'confirm_trade') {
        if (!data) { return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Os dados deste ticket não foram encontrados ou a sessão expirou. Por favor, reabra a mediação.", flags: [MessageFlags.Ephemeral] }).catch(() => {}); } if (data.confirmacoes.includes(interaction.user.id)) return await interaction.reply({ content: "Você já confirmou!", flags: [MessageFlags.Ephemeral] });
        data.confirmacoes.push(interaction.user.id);
        const statusE = data.confirmacoes.includes(data.enviador) ? `<:emoji_172:1541636098005016576> <@${data.enviador}> Confirmou` : `⏳ <@${data.enviador}> Aguardando...`;
        const statusR = data.confirmacoes.includes(data.recebedor) ? `<:emoji_172:1541636098005016576> <@${data.recebedor}> Confirmou` : `⏳ <@${data.recebedor}> Aguardando...`;
        const labelPagadorAtual = { comprador: '💳 Comprador', dividir: '<:emoji_166:1541614807621443604> Dividida entre ambos', vendedor: '🌿 Vendedor' }[data.pagadorTaxa] || '💳 Comprador';
        const container = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:parceria:1485054250429054986> — Confirmação Final\n<@${data.enviador}> <@${data.recebedor}>\nAmbas as partes devem confirmar se os dados abaixo estão corretos.\nApós a confirmação de ambos, o pagamento será gerado.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n<:emoji_165:1499214852990832671> **Enviador:** <@${data.enviador}>\n<:emoji_170:1505047772049702932> **Recebedor:** <@${data.recebedor}>\n<:emoji_165:1499214852990832671>  **Valor PIX:** R$ ${data.valor}\n<:emoji_171:1505047910667259924> **Itens/Serviço:** ${data.item}\n💰 **Pagador da Taxa:** ${labelPagadorAtual}\n\u200B\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Status:**\n${statusE}\n${statusR}`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('confirm_trade').setLabel('Confirmar tudo').setStyle(ButtonStyle.Secondary), new ButtonBuilder().setCustomId('resetar_fluxo').setLabel('Tentar novamente').setStyle(ButtonStyle.Secondary)));
        await interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        if (data.confirmacoes.length === 2) {
            const fetched = await interaction.channel.messages.fetch({ limit: 100 });
            if (fetched) await interaction.channel.bulkDelete(fetched.filter(m => !m.pinned));
            await interaction.channel.send({ content: `${EMOJI_CHECK} — **Ambas as partes confirmaram a negociação!**` });
            setTimeout(async () => {
                const containerRes = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`Midldleman imediato aqui!! <@&${CARGO_STAFF_ID}>\n\n# <:parce:1442163891462344798> | Resumo do Middleman\nConsulte este resumo do negócio para quaisquer reafirmações.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Enviador:** <@${data.enviador}>\n**Recebedor:** <@${data.recebedor}>\n**Valor:** R$ ${data.valor}\n**Itens:** ${data.item}\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('btn_reivindicar').setLabel('Reivindicar').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId('btn_fechar').setLabel('Cancelar').setStyle(ButtonStyle.Danger)));
                await interaction.channel.send({ components: [containerRes], flags: MessageFlags.IsComponentsV2 });
            }, 1500);
        }
    }

    if (interaction.isButton() && interaction.customId === 'btn_reivindicar') {
        if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Apenas a staff pode reivindicar!", flags: [MessageFlags.Ephemeral] });
        if (!data) return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Os dados desse ticket foram perdidos. Peça pro cliente clicar em 'Resetar' ou reabrir o fluxo.", flags: [MessageFlags.Ephemeral] });
        if (data.staffReivindicou) return await interaction.reply({ content: "<:emoji_167:1541618912238768148>️ | Esse mm já foi Assumido", flags: [MessageFlags.Ephemeral] });

        const config = pixConfig.get(interaction.user.id);
        if (!config) return await interaction.reply({ content: " <:emoji_167:1541618912238768148> Você não configurou seu PIX! Use `/configpix` primeiro.", flags: [MessageFlags.Ephemeral] });

        const vCheck = parseFloat(data.valor) || 0;
        if (config.limite && config.limite > 0 && vCheck > config.limite) {
            const limiteFormatado = config.limite.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
            return await interaction.reply({ content: `<:emoji_167:1541618912238768148> Essa negociação é de **R$ ${vCheck.toFixed(2)}**, mas seu limite atual de mediação é **R$ ${limiteFormatado}**.\nPeça pra um staff com limite maior assumir, ou fale com um admin pra aumentar seu limite.`, flags: [MessageFlags.Ephemeral] });
        }

        data.staffReivindicou = interaction.user.id;
        saveTradeDataToDisk();

        const v = parseFloat(data.valor) || 0;
        let taxa = data.modoConta ? 3.00 : calcularTaxaBase(v, data.tipoTaxa);

        const mE = await interaction.guild.members.fetch(data.enviador).catch(() => null);
        const mR = await interaction.guild.members.fetch(data.recebedor).catch(() => null);
        if (mE?.roles.cache.has(CARGO_AFILIADO_ID) || mR?.roles.cache.has(CARGO_AFILIADO_ID)) taxa /= 2;

        data.taxaValor = taxa;
        const pagador = data.pagadorTaxa || 'comprador';
        // comprador: comprador paga v + taxa cheia | dividir: comprador paga v + metade da taxa | vendedor: comprador paga só v
        const totalCobradoComprador = pagador === 'vendedor' ? v : (pagador === 'dividir' ? v + taxa / 2 : v + taxa);
        const total = totalCobradoComprador.toFixed(2);
        const pixId = Date.now().toString();

        const pixPayload = gerarPix(config.chave, config.nome, total);
        pixStorage.set(pixId, { payload: pixPayload, total, channelId: interaction.channel.id });

        const containerOriginal = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`Midldleman imediato aqui!! <@&${CARGO_STAFF_ID}>\n\n# <:parce:1442163891462344798> | Resumo do Middleman\nConsulte este resumo do negócio para quaisquer reafirmações.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Enviador:** <@${data.enviador}>\n**Recebedor:** <@${data.recebedor}>\n**Valor:** R$ ${data.valor}\n**Itens:** ${data.item}\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('btn_reivindicar_disabled').setLabel(`Assumido por ${interaction.user.username}`).setStyle(ButtonStyle.Secondary).setDisabled(true), new ButtonBuilder().setCustomId('btn_fechar').setLabel('Cancelar').setStyle(ButtonStyle.Danger)));
        await interaction.update({ components: [containerOriginal], flags: MessageFlags.IsComponentsV2 });
        await interaction.channel.send({ content: `> ${EMOJI_CHECK} ╺╸ Opa! O Middleman <@${interaction.user.id}> assumiu a mediação deste ticket.` });

        // Enviar log de reivindicação para o canal de logs da staff
        const embedLogClaim = new EmbedBuilder()
            .setColor(0xDE4548)
            .setTitle('🛡️ Ticket Reivindicado')
            .setDescription(`O staff <@${interaction.user.id}> assumiu a mediação deste ticket.`)
            .addFields(
                { name: 'Staff Responsável', value: `<@${interaction.user.id}> (\`${interaction.user.tag || interaction.user.username}\`)`, inline: true },
                { name: 'Ticket', value: `<#${interaction.channel.id}>`, inline: true },
                { name: 'Valor', value: `R$ ${v.toFixed(2)}`, inline: true },
                { name: 'Comprador', value: `<@${data.enviador}>`, inline: true },
                { name: 'Vendedor', value: `<@${data.recebedor}>`, inline: true },
                { name: 'Itens', value: `${data.item || 'Não informado'}` }
            )
            .setFooter({ text: `Ticket ID: ${interaction.channel.id}` })
            .setTimestamp();
        await enviarLog(interaction.guild, embedLogClaim).catch(console.error);

        setTimeout(async () => {
            const botoesPagamento = [
                new ButtonBuilder().setCustomId(`qr_${pixId}`).setLabel('QR Code').setEmoji('<:emoji_164:1498778688886407218>').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`copy_${pixId}`).setLabel('Copia e Cola').setEmoji('<:emoji_169:1541632596700561490>').setStyle(ButtonStyle.Secondary)
            ];
            if (data.pagadorTaxa === 'dividir') {
                botoesPagamento.push(new ButtonBuilder().setCustomId(`dividirtaxa_${pixId}`).setLabel('Dividir Taxa').setEmoji('<:emoji_166:1541614807621443604>').setStyle(ButtonStyle.Secondary));
            }
            botoesPagamento.push(new ButtonBuilder().setCustomId('btn_recebi_valor').setLabel('Confirmei Recebimento (Staff)').setStyle(ButtonStyle.Success));

            const containerPix = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`<@${data.enviador}>\n\n## <:parceria:1485054250429054986> ╺╸ MM Automático - Pagamento PIX\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n> ${config.nome} Deve pagar o valor de **R$ ${total}**.\n> A troca é automática sem intervenção humana, caso haja problemas há um botão de disputa.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n* <:emoji_164:1498773852585463929> **Valor da Transação:** R$ ${v.toFixed(2)}\n* <:emoji_151:1487942140037304370> **Taxa da MM:** R$ ${taxa.toFixed(2)}\n* <:emoji_164:1498773734402556095> **Detalhes do Pedido:** ${data.item}\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Total a Pagar:** R$ ${total}`)).addActionRowComponents(new ActionRowBuilder().addComponents(...botoesPagamento));
            await interaction.channel.send({ components: [containerPix], flags: MessageFlags.IsComponentsV2 });
        }, 2000);
    }

    // ── Dividir Taxa ──
    // O comprador já embutiu a metade da taxa no PIX principal (botão "Copia e Cola").
    // Este botão gera um segundo PIX (payload + QR), só com a metade da taxa,
    // pra mesma chave do middleman que reivindicou o ticket, pro vendedor mandar essa parte.
    if (interaction.isButton() && interaction.customId.startsWith('dividirtaxa_')) {
        if (!data) return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Dados desse ticket foram perdidos.", flags: [MessageFlags.Ephemeral] });

        const pixIdOriginal = interaction.customId.replace('dividirtaxa_', '');

        let taxaTotal = data.taxaValor;

        // Fallback: se por algum motivo taxaValor não foi salvo (ex: bot reiniciou), recalcula na hora
        if (!taxaTotal) {
            const v = parseFloat(data.valor) || 0;
            taxaTotal = data.modoConta ? 3.00 : calcularTaxaBase(v, data.tipoTaxa);

            try {
                const mE = await interaction.guild.members.fetch(data.enviador).catch(() => null);
                const mR = await interaction.guild.members.fetch(data.recebedor).catch(() => null);
                if (mE?.roles.cache.has(CARGO_AFILIADO_ID) || mR?.roles.cache.has(CARGO_AFILIADO_ID)) taxaTotal /= 2;
            } catch (e) {}

            data.taxaValor = taxaTotal;
            console.log(`[dividirtaxa] taxaValor estava vazio no ticket ${interaction.channelId}, recalculado: ${taxaTotal}`);
        }

        const metade = (taxaTotal / 2).toFixed(2);

        const configStaff = pixConfig.get(data.staffReivindicou);
        if (!configStaff) {
            return await interaction.reply({ content: "<:emoji_167:1541618912238768148> O Middleman responsável não tem PIX configurado, não dá pra gerar a cobrança da metade da taxa.", flags: [MessageFlags.Ephemeral] });
        }

        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] }).catch(() => {});

        try {
            const pixMetadeId = `${pixIdOriginal}_metade`;
            const pixPayloadMetade = gerarPix(configStaff.chave, configStaff.nome, metade);
            pixStorage.set(pixMetadeId, { payload: pixPayloadMetade, total: metade, channelId: interaction.channel.id });

            const rowMetade = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`qr_${pixMetadeId}`).setLabel('QR Code (metade)').setEmoji('<:emoji_164:1498778688886407218>').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`copy_${pixMetadeId}`).setLabel('Copia e Cola (metade)').setEmoji('<:emoji_169:1541632596700561490>').setStyle(ButtonStyle.Secondary)
            );

            await interaction.editReply({
                content: `<:emoji_166:1541614807621443604>  **Taxa dividida entre as partes**\n> Taxa total: R$ ${taxaTotal.toFixed(2)}\n\n<@${data.enviador}> já pagou **R$ ${metade}** de taxa a mais no PIX principal.\n<@${data.recebedor}> precisa mandar **R$ ${metade}** pro Middleman (pix abaixo) referente à sua parte da taxa.`,
                components: [rowMetade]
            });
        } catch (err) {
            console.error("Erro ao gerar PIX da metade da taxa:", err);
            await interaction.editReply({ content: "<:emoji_167:1541618912238768148> Não consegui gerar o PIX da metade da taxa. Tenta de novo." }).catch(() => {});
        }
    }

    if (interaction.isButton() && interaction.customId === 'conta_confirmar_pagamento') {
        if (!data?.modoConta || ![data.enviador, data.recebedor].includes(interaction.user.id)) return await responderSeguro(interaction, { content: 'Somente comprador e vendedor podem confirmar.', ephemeral: true });
        data.contaPagamentoConfirmacoes = data.contaPagamentoConfirmacoes || [];
        if (data.contaPagamentoConfirmacoes.includes(interaction.user.id)) return await responderSeguro(interaction, { content: 'Você já confirmou o pagamento.', ephemeral: true });
        data.contaPagamentoConfirmacoes.push(interaction.user.id);
        saveTradeDataToDisk();
        await interaction.update({ components: [construirPainelPagamentoConta(data)], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        return;
    }

    if (interaction.isButton() && interaction.customId === 'conta_enviar_comprovante') {
        if (!data?.modoConta || interaction.user.id !== data.enviador) return await responderSeguro(interaction, { content: 'Somente o comprador, que enviou o PIX, pode enviar o print.', ephemeral: true });
        if ((data.contaPagamentoConfirmacoes || []).length < 2) return await responderSeguro(interaction, { content: 'Aguarde os dois participantes confirmarem o pagamento.', ephemeral: true });
        if (data.contaComprovante?.url) return await responderSeguro(interaction, { content: 'O print já foi recebido e está em conferência.', ephemeral: true });
        const modal = new ModalBuilder().setCustomId('modal_conta_comprovante').setTitle('Comprovante do PIX');
        modal.addComponents(new LabelBuilder()
            .setLabel('Comprovante do PIX')
            .setDescription('Print ou PDF do pagamento. Não envie links.')
            .setComponent(new FileUploadBuilder().setCustomId('conta_comprovante_arquivo').setMinValues(1).setMaxValues(3).setRequired(true))
        );
        return await interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId === 'modal_conta_comprovante') {
        if (!data?.modoConta || interaction.user.id !== data.enviador) return await responderSeguro(interaction, { content: 'Somente o comprador pode enviar o comprovante.', ephemeral: true });
        if ((data.contaPagamentoConfirmacoes || []).length < 2) return await responderSeguro(interaction, { content: 'Aguarde as duas confirmações antes de enviar o print.', ephemeral: true });
        if (data.contaComprovante?.url) return await responderSeguro(interaction, { content: 'O comprovante já foi recebido.', ephemeral: true });
        const arquivos = interaction.fields.getUploadedFiles('conta_comprovante_arquivo');
        const arquivo = arquivos?.first?.() || Array.from(arquivos?.values?.() || [])[0];
        if (!arquivo?.url) return await responderSeguro(interaction, { content: 'Selecione pelo menos um arquivo de comprovante.', ephemeral: true });
        if (arquivo.contentType && !arquivo.contentType.startsWith('image/') && arquivo.contentType !== 'application/pdf') return await responderSeguro(interaction, { content: 'Envie somente print em imagem ou PDF do pagamento.', ephemeral: true });

        data.contaComprovante = { url: arquivo.url, nome: arquivo.name || 'comprovante', tipo: arquivo.contentType || 'application/octet-stream', enviadoPor: interaction.user.id, enviadoEm: new Date().toISOString() };
        saveTradeDataToDisk();
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        await new Promise(resolve => setTimeout(resolve, 2000));
        const pendente = new ContainerBuilder()
            .setAccentColor(0xDE4548)
            .addTextDisplayComponents(new TextDisplayBuilder().setContent(
                `# ⏳ Pagamento pendente\n` +
                `O comprovante foi recebido pelo formulário e está sendo conferido pelo Middleman.\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `O pagamento só será liberado após a conferência.`
            ))
            .addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(arquivo.url)));
        await interaction.channel.send({ components: [pendente], files: [{ attachment: arquivo.url, name: data.contaComprovante.nome }], flags: MessageFlags.IsComponentsV2 }).catch(async () => {
            await interaction.channel.send({ content: '⏳ **Pagamento pendente** — comprovante recebido pelo formulário e em conferência.' }).catch(() => {});
        });
        await interaction.editReply({ content: 'Comprovante enviado. O pagamento está pendente de conferência.' });
        return;
    }

    if (interaction.isButton() && interaction.customId === 'btn_recebi_valor') {
        if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Apenas a staff pode confirmar recebimento!", flags: [MessageFlags.Ephemeral] });
        if (!data) return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Dados desse ticket foram perdidos.", flags: [MessageFlags.Ephemeral] });
        if (data.staffReivindicou && data.staffReivindicou !== interaction.user.id && !interaction.member?.permissions?.has(PermissionFlagsBits.Administrator)) {
            return await interaction.reply({ content: "Apenas o staff que reivindicou pode confirmar!", flags: [MessageFlags.Ephemeral] });
        }
        if (data.pagamentoConfirmado) {
            return await interaction.reply({ content: "ℹ️ O recebimento já foi confirmado anteriormente.", flags: [MessageFlags.Ephemeral] });
        }

        data.pagamentoConfirmado = true;
        saveTradeDataToDisk();

        if (data.modoConta) {
            data.contaPagamentoConfirmacoes = [];
            data.contaComprovante = null;
            saveTradeDataToDisk();
            await interaction.update({ components: [construirPainelPagamentoConta(data)], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
            return;
        }

        // Atualizar o botão na mensagem original para desabilitar
        try {
            if (interaction.message && interaction.message.components && interaction.message.components.length > 0) {
                const rowOriginal = ActionRowBuilder.from(interaction.message.components[0]);
                for (const comp of rowOriginal.components) {
                    if (comp.data.custom_id === 'btn_recebi_valor') {
                        comp.setDisabled(true).setLabel(`Recebido por ${interaction.user.username}`).setStyle(ButtonStyle.Secondary);
                    }
                }
                await interaction.update({ components: [rowOriginal], flags: MessageFlags.IsComponentsV2 }).catch(async () => {
                    await interaction.update({ components: [rowOriginal] }).catch(() => {});
                });
            } else {
                await interaction.reply({ content: "<:emoji_172:1541636098005016576> Recebimento confirmado pelo staff.", flags: [MessageFlags.Ephemeral] });
            }
        } catch (e) {
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({ content: "<:emoji_172:1541636098005016576> Recebimento confirmado pelo staff.", flags: [MessageFlags.Ephemeral] }).catch(() => {});
            }
        }

        // Log de confirmação de pagamento do comprador para staff logs
        const embedLogPagamento = new EmbedBuilder()
            .setColor(0xDE4548)
            .setTitle('💰 Pagamento do Comprador Confirmado (Staff)')
            .setDescription(`O staff <@${interaction.user.id}> confirmou o recebimento do PIX do comprador.`)
            .addFields(
                { name: 'Staff', value: `<@${interaction.user.id}>`, inline: true },
                { name: 'Ticket', value: `<#${interaction.channel.id}>`, inline: true },
                { name: 'Valor', value: `R$ ${parseFloat(data.valor || 0).toFixed(2)}`, inline: true },
                { name: 'Comprador', value: `<@${data.enviador}>`, inline: true },
                { name: 'Vendedor', value: `<@${data.recebedor}>`, inline: true }
            )
            .setFooter({ text: `Ticket ID: ${interaction.channel.id}` })
            .setTimestamp();
        await enviarLog(interaction.guild, embedLogPagamento).catch(console.error);

        const containerT = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(data.modoConta ? `# 🔐 PAGAMENTO RECEBIDO - TRANSFERÊNCIA SEGURA\nO Middleman confirmou o recebimento do valor.\n\n**Vendedor:** transfira a conta somente pela página oficial do serviço; remova métodos de pagamento, sessões e dispositivos antigos.\n**Comprador:** faça login pelo site/app oficial, troque a senha, ative 2FA e remova sessões anteriores.\n\nNão publique nenhuma credencial neste ticket. O bot não armazena nem recupera contas.` : `# ⚠️ PIX RECEBIDO - INICIAR TROCA\nO Middleman já está com o dinheiro em mãos.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Instruções:**\n• O vendedor deve entregar o item agora.\n• Após a entrega, ambos cliquem no botão abaixo.\n• A **Disputa** ainda não está habilitada.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('confirmar_entrega_user').setLabel(data.modoConta ? 'Conta recebida e protegida' : 'Confirmar Entrega').setEmoji('<:emoji_172:1541636098005016576>').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId('disputa_desabilitada').setLabel('Disputa (indisponível)').setStyle(ButtonStyle.Secondary).setDisabled(true),
            new ButtonBuilder().setCustomId('btn_fechar').setLabel('Cancelar Ticket').setStyle(ButtonStyle.Danger)
        ));
        await interaction.channel.send({ components: [containerT], flags: MessageFlags.IsComponentsV2 });
    }

    if (interaction.isButton() && interaction.customId === 'confirmar_entrega_user') {
        if (!data) { return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Os dados deste ticket não foram encontrados ou a sessão expirou. Por favor, reabra a mediação.", flags: [MessageFlags.Ephemeral] }).catch(() => {}); } if (interaction.user.id !== data.enviador && interaction.user.id !== data.recebedor) return await interaction.reply({ content: "Você não é participante da trade!", flags: [MessageFlags.Ephemeral] });
        if (data.confirmacoesEntrega.includes(interaction.user.id)) return await interaction.reply({ content: "Você já confirmou!", flags: [MessageFlags.Ephemeral] });
        data.confirmacoesEntrega.push(interaction.user.id);
        if (data.confirmacoesEntrega.length === 2) {
            if (data.modoConta) await iniciarChecklistPosConta(interaction.channel, data);
            else await solicitarChavePixDoRecebedor(interaction.channel, data);
        } else { await interaction.reply({ content: `${EMOJI_CHECK} — <@${interaction.user.id}> confirmou a entrega. Aguardando a outra parte.` }); }
    }

    if (interaction.isButton() && interaction.customId === 'conta_prova') {
        if (!data?.modoConta || interaction.user.id !== data.enviador) return await responderSeguro(interaction, { content: 'Somente o comprador pode enviar o comprovante.', ephemeral: true });
        const modal = new ModalBuilder().setCustomId('modal_conta_pos_entrega').setTitle('Checklist pós-entrega');
        modal.addComponents(
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('pos_status').setLabel('Digite SIM se tudo foi concluído').setStyle(TextInputStyle.Paragraph).setMaxLength(300).setRequired(true)),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('pos_email').setLabel('A conta possui e-mail? Responda SIM ou NÃO').setStyle(TextInputStyle.Short).setMaxLength(20).setRequired(true)),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('pos_observacao').setLabel('Observação sem dados pessoais').setStyle(TextInputStyle.Short).setMaxLength(120).setRequired(false)),
            new LabelBuilder().setLabel('Comprovante').setDescription('Selecione o print ou PDF.').setComponent(new FileUploadBuilder().setCustomId('pos_comprovante_arquivo').setMinValues(1).setMaxValues(1).setRequired(true))
        );
        return await interaction.showModal(modal);
    }
    if (interaction.isModalSubmit() && interaction.customId === 'modal_conta_pos_entrega') {
        if (!data?.modoConta || interaction.user.id !== data.enviador) return await responderSeguro(interaction, { content: 'Somente o comprador pode enviar o comprovante.', ephemeral: true });
        const status = interaction.fields.getTextInputValue('pos_status').trim();
        const email = interaction.fields.getTextInputValue('pos_email').trim();
        const obs = interaction.fields.getTextInputValue('pos_observacao')?.trim() || 'Sem observação';
        const arquivos = interaction.fields.getUploadedFiles('pos_comprovante_arquivo');
        const arquivo = arquivos?.first?.() || Array.from(arquivos?.values?.() || [])[0];
        if (!arquivo?.url) return await responderSeguro(interaction, { content: 'Selecione o print ou PDF do comprovante.', ephemeral: true });
        if (mensagemPareceCredencialDeConta(`${status} ${email} ${obs}`) || /@[\w.-]+\.[a-z]{2,}/i.test(`${status} ${email} ${obs}`)) return await responderSeguro(interaction, { content: 'Não envie senha, token, código ou e-mail completo.', ephemeral: true });
        if (!/(^|\b)(sim|s|yes)\b/i.test(status)) return await responderSeguro(interaction, { content: 'Confirme SIM somente após concluir a segurança.', ephemeral: true });
        if (!/(^|\b)(sim|não|nao|s|n)\b/i.test(email)) return await responderSeguro(interaction, { content: 'Informe apenas SIM ou NÃO sobre a existência de e-mail.', ephemeral: true });
        data.contaProvas[interaction.user.id] = { status, email, obs, imagemUrl: arquivo.url, imagemNome: arquivo.name || 'comprovante', em: new Date().toISOString(), anexo: true }; saveTradeDataToDisk();
        return await interaction.reply({ content: 'Checklist e comprovante registrados pelo formulário.', flags: [MessageFlags.Ephemeral] });
    }

    if (interaction.isStringSelectMenu() && interaction.customId === 'selecionar_tipo_pix') {
        if (!data || interaction.user.id !== data.recebedor) {
            return await interaction.reply({
                content: "<:emoji_167:1541618912238768148> | Apenas o recebedor pode fornecer a chave PIX.",
                flags: [MessageFlags.Ephemeral]
            });
        }

        const tipo = String(interaction.values[0] || 'pix').toLowerCase();
        const nomesTipo = {
            celular: 'celular',
            cpf_cnpj: 'CPF/CNPJ',
            email: 'e-mail',
            aleatoria: 'aleatória',
            usdt: 'USDT Wallet'
        };
        const nomeTipo = nomesTipo[tipo] || 'PIX';

        try {
            const modal = new ModalBuilder()
                .setCustomId(`modal_chave_final_${tipo}`)
                .setTitle(`Chave PIX: ${nomeTipo.toUpperCase()}`)
                .addComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('chave_input')
                            .setLabel(`Digite sua chave ${nomeTipo}`)
                            .setPlaceholder(`Informe sua chave ${nomeTipo}`)
                            .setStyle(TextInputStyle.Short)
                            .setRequired(true)
                            .setMaxLength(200)
                    ),
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('nome_input')
                            .setLabel('Nome do recebedor')
                            .setPlaceholder('Nome que aparecerá no pagamento PIX')
                            .setStyle(TextInputStyle.Short)
                            .setRequired(true)
                            .setMaxLength(25)
                    )
                );

            return await interaction.showModal(modal);
        } catch (erroModal) {
            console.error('Erro ao abrir modal da chave PIX:', erroModal);
            if (!interaction.replied && !interaction.deferred) {
                return await interaction.reply({
                    content: '<:emoji_167:1541618912238768148> Não foi possível abrir o formulário da chave PIX. Tente novamente.',
                    flags: [MessageFlags.Ephemeral]
                });
            }
        }
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith('modal_chave_final_')) {
        if (!data) {
            return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Os dados desse ticket foram perdidos. Reabra o fluxo da negociação.", flags: [MessageFlags.Ephemeral] });
        }

        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

        try {
            const chave = interaction.fields.getTextInputValue('chave_input')?.trim();
            const nomeRecebedor = interaction.fields.getTextInputValue('nome_input')?.trim();
            if (!chave) return await interaction.editReply("<:emoji_167:1541618912238768148> A chave PIX não pode ficar vazia.");
            if (!nomeRecebedor) return await interaction.editReply("<:emoji_167:1541618912238768148> O nome do recebedor não pode ficar vazio.");

            if (!data.staffReivindicou) {
                console.error("Staff não definido no ticket:", interaction.channelId);
                return await interaction.editReply("<:emoji_167:1541618912238768148> O staff responsável não foi encontrado. Peça para a staff reivindicar o ticket novamente.");
            }

            const staff = await client.users.fetch(data.staffReivindicou).catch(err => {
                console.error("Erro ao buscar staff:", err);
                return null;
            });

            const vRecebedor = parseFloat(data.valor) || 0;
            const taxaRegistrada = data.taxaValor || 0;
            const pagadorAtual = data.pagadorTaxa || 'comprador';
            const valorPagarNumerico = pagadorAtual === 'vendedor' ? (vRecebedor - taxaRegistrada) : (pagadorAtual === 'dividir' ? (vRecebedor - taxaRegistrada / 2) : vRecebedor);
            const valorPagar = Math.max(0, valorPagarNumerico).toFixed(2);
            const chaveId = `${interaction.channel.id}_${Date.now()}_${interaction.user.id}`;
            const pixIdFinal = `${chaveId}f`;
            const pixPayloadFinal = gerarPix(chave, nomeRecebedor, valorPagar);
            const qrFileName = `pix-${pixIdFinal}.png`;
            const qrBuffer = await QRCode.toBuffer(pixPayloadFinal, {
                type: 'png', width: 700, margin: 3, errorCorrectionLevel: 'M'
            });

            const pixData = {
                payload: pixPayloadFinal,
                total: valorPagar,
                chave,
                nomeRecebedor,
                channelId: interaction.channel.id,
                qrFileName
            };
            data.pixPagamento = pixData;
            chaveFinalStorage.set(chaveId, chave);
            pixStorage.set(pixIdFinal, pixData);
            saveTradeDataToDisk();

            const paymentRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`copy_${pixIdFinal}`).setLabel('Copia e Cola').setEmoji('📋').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`copychave_${chaveId}`).setLabel('Copiar Chave PIX').setEmoji('📋').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('btn_paguei_vendedor').setLabel('Confirmei o pagamento ao Vendedor').setStyle(ButtonStyle.Success)
            );
            const notaTaxaVendedor = pagadorAtual === 'vendedor'
                ? `\n> 💰 Taxa de **R$ ${taxaRegistrada.toFixed(2)}** já descontada (vendedor ficou responsável pela taxa).`
                : pagadorAtual === 'dividir'
                    ? `\n> 💰 Metade da taxa (**R$ ${(taxaRegistrada / 2).toFixed(2)}**) já descontada (taxa dividida entre as partes).`
                    : '';
            const pagamentoV2 = new ContainerBuilder()
                .setAccentColor(0xDE4548)
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(
                    `# <:ravisoshelt:1439092081024041063> PAGAMENTO PENDENTE\n` +
                    `<@${data.enviador}> <@${data.recebedor}> <@${data.staffReivindicou}>\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `**O administrador deve pagar este valor ao recebedor.**\n` +
                    `**Recebedor:** ${nomeRecebedor} (<@${interaction.user.id}>)\n` +
                    `**Chave PIX:** \`${chave}\`\n` +
                    `**Valor exato a pagar:** **R$ ${valorPagar}**${notaTaxaVendedor}\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `Escaneie o QR Code ou use o Pix copia e cola. Confira o valor antes de pagar.\n` +
                    `**PIX copia e cola:**\n\`${pixPayloadFinal}\``
                ))
                .addMediaGalleryComponents(new MediaGalleryBuilder().addItems(
                    new MediaGalleryItemBuilder().setURL(`attachment://${qrFileName}`)
                ))
                .addActionRowComponents(paymentRow);
            const embedLogChave = new EmbedBuilder()
                .setColor(0xDE4548)
                .setTitle('Chave Pix Fornecida')
                .setDescription(`Vendedor: <@${interaction.user.id}>\nChave: ${chave}\nPara: ${staff?.username || data.staffReivindicou}`)
                .addFields(
                    { name: 'Chave PIX informada', value: `\`${chave}\`` },
                    { name: 'Nome do recebedor', value: nomeRecebedor, inline: true },
                    { name: 'Recebedor', value: `<@${interaction.user.id}>`, inline: true },
                    { name: 'Staff responsável', value: `<@${data.staffReivindicou}>`, inline: true },
                    { name: 'Ticket', value: `<#${interaction.channel.id}>`, inline: true },
                    { name: 'Valor a pagar', value: `R$ ${valorPagar}`, inline: true }
                )
                .setFooter({ text: `Ticket ID: ${interaction.channel.id}` })
                .setTimestamp();

            const logEnviado = await enviarLog(interaction.guild, embedLogChave).catch(erroLog => {
                console.error('Falha ao enviar log da chave PIX; continuando o pagamento:', erroLog);
                return false;
            });
            if (!logEnviado) console.warn('Cobrança PIX publicada sem confirmação do log.');

            try {
                await interaction.channel.send({
                    components: [pagamentoV2],
                    files: [new AttachmentBuilder(qrBuffer, { name: qrFileName })],
                    flags: MessageFlags.IsComponentsV2
                });
                await interaction.message?.delete().catch(() => {});
            } catch (erroCanal) {
                console.error('Não foi possível publicar a cobrança no ticket:', erroCanal);
                return await interaction.editReply('<:emoji_167:1541618912238768148> Não foi possível publicar a cobrança no ticket. Tente novamente ou avise a staff.');
            }

            await interaction.editReply({
                content: `${EMOJI_CHECK} Chave enviada com sucesso ao Staff!`,
                flags: [MessageFlags.Ephemeral]
            });
        } catch (err) {
            console.error("Erro ao processar chave PIX:", err);
            await interaction.editReply("<:emoji_167:1541618912238768148> Ocorreu um erro ao processar essa chave PIX. Tente novamente ou avise a staff.").catch(console.error);
        }
    }

    async function finalizarPagamentoVendedorConfirmado(interaction, data) {
        let transacaoIdFinal = null;
        try {
            const enviadorU = await client.users.fetch(data.enviador).catch(() => null);
            const recebedorU = await client.users.fetch(data.recebedor).catch(() => null);
            const staffMediadorU = await client.users.fetch(data.staffReivindicou || interaction.user.id).catch(() => null);
            if (enviadorU && recebedorU && staffMediadorU) {
                transacaoIdFinal = await executarAprovarPagamento(interaction.guild, staffMediadorU, data.modoConta ? "conta" : "pix", enviadorU, recebedorU, parseFloat(data.valor || 0), { vendedorAnonimo: data.vendedorAnonimo === true, compradorAnonimo: data.compradorAnonimo === true });
                data.vouchGerado = true;
                saveTradeDataToDisk();
            }
        } catch (err) {
            console.error("Erro ao registrar proof automática em btn_paguei_vendedor:", err);
        }

        const messages = await interaction.channel.messages.fetch({ limit: 100 }).catch(() => new Map());
        const transcript = Array.from(messages.values()).reverse().map(m => `[${m.createdAt ? m.createdAt.toLocaleString() : ''}] ${m.author ? m.author.tag : 'User'}: ${m.content}`).join('\n');

        const v = parseFloat(data.valor || 0);
        let taxa = data.taxaValor || calcularTaxaBase(v, data.tipoTaxa);

        // Enviar log de encerramento para o canal de logs da staff
        const embedLogEncerrado = new EmbedBuilder()
            .setColor('#DE4548')
            .setTitle('Middle encerrado com Sucesso (Logs)')
            .addFields(
                { name: 'Administrador / MM', value: `<@${interaction.user.id}>` },
                { name: 'Canal', value: `#${interaction.channel.name}` },
                { name: 'Valor', value: `R$ ${v.toFixed(2)}`, inline: true },
                { name: 'Taxa', value: `R$ ${taxa.toFixed(2)}`, inline: true },
                { name: 'Transação ID', value: `${transacaoIdFinal || 'MM-' + Date.now()}`, inline: true }
            )
            .setTimestamp();
        await enviarLog(interaction.guild, embedLogEncerrado, [new AttachmentBuilder(Buffer.from(transcript), { name: `transcript-${interaction.channel.name}.txt` })]).catch(console.error);

        const pendingId = gerarIdAvaliacao();
        avaliacoesPendentes.set(pendingId, {
            enviador: data.enviador,
            recebedor: data.recebedor,
            valor: v,
            item: data.item,
            staffId: data.staffReivindicou || interaction.user.id,
            transacaoId: transacaoIdFinal || pendingId,
            transcript,
            avaliacoes: {}
        });
        saveAvaliacoesPendentes();

        const protocoloResumo = transacaoIdFinal || pendingId;
        const dataFechamentoTxt = new Date().toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" });

        const containerResumo = new ContainerBuilder().setAccentColor(0x5865F2).addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `## 📋 Resumo do Ticket Encerrado\n` +
                `**Protocolo:** ${protocoloResumo}\n` +
                `**Valor:** R$ ${v.toFixed(2)}\n` +
                `**Servidor:** ${interaction.guild.name}\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `**Comprador:** <@${data.enviador}>\n` +
                `**Vendedor:** <@${data.recebedor}>\n` +
                `**Intermediador:** <@${data.staffReivindicou || interaction.user.id}>\n\n` +
                `<:emoji_172:1541636098005016576> **Ticket encerrado com sucesso.**\n` +
                `🗓️ ${dataFechamentoTxt}\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `📄 **Transcrição**\n` +
                `-# Histórico completo das mensagens deste ticket.`
            )
        ).addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`abrir_transcript_${pendingId}`).setLabel('Abrir transcrição').setEmoji('📄').setStyle(ButtonStyle.Secondary)
            )
        );

        const containerEstrelas = new ContainerBuilder().setAccentColor(0xf2a20e).addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`# ⭐ Avalie o Atendimento ⭐\nPor favor, avalie a mediação que você recebeu!`)
        ).addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`av_1_${pendingId}`).setEmoji('⭐').setLabel('1').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`av_2_${pendingId}`).setEmoji('⭐').setLabel('2').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`av_3_${pendingId}`).setEmoji('⭐').setLabel('3').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`av_4_${pendingId}`).setEmoji('⭐').setLabel('4').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId(`av_5_${pendingId}`).setEmoji('⭐').setLabel('5').setStyle(ButtonStyle.Success)
            )
        );

        // Enviar no PV (DM) dos participantes em Components V2
        for (const uid of [data.enviador, data.recebedor]) {
            try {
                const userDM = await client.users.fetch(uid).catch(() => null);
                if (userDM) {
                    await userDM.send({ components: [containerResumo], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
                    await userDM.send({ components: [containerEstrelas], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
                }
            } catch (e) {}
        }

        // Enviar no canal do ticket
        await interaction.channel.send({
            content: `🎉 **Mediação finalizada com sucesso!** <@${data.enviador}> <@${data.recebedor}>\nFechando ticket em 5 segundos...`,
            components: [containerResumo],
            flags: MessageFlags.IsComponentsV2
        }).catch(() => {});

        setTimeout(() => {
            interaction.channel.delete().catch(() => {});
            tradeData.delete(interaction.channelId);
            ticketInteractionQueues.delete(interaction.channelId);
            saveTradeDataToDisk();
        }, 5000);
    }

    if (interaction.isButton() && interaction.customId === 'btn_paguei_vendedor') {
        if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Apenas a staff pode confirmar pagamento ao vendedor!", flags: [MessageFlags.Ephemeral] });
        if (!data) return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Dados deste ticket foram perdidos.", flags: [MessageFlags.Ephemeral] });
        if (!data.staffReivindicou || data.staffReivindicou !== interaction.user.id) {
            return await interaction.reply({ content: "<:emoji_167:1541618912238768148> Somente o staff que assumiu este ticket pode confirmar o pagamento.", flags: [MessageFlags.Ephemeral] });
        }
        if (data.pagamentoVendedorConfirmado) {
            return await interaction.reply({ content: "ℹ️ O pagamento já foi marcado como efetuado e está aguardando a confirmação do vendedor.", flags: [MessageFlags.Ephemeral] });
        }
        data.pagamentoVendedorConfirmado = true;
        data.pagamentoVendedorRecebido = false;
        saveTradeDataToDisk();

        const confirmacaoPagamento = new ContainerBuilder()
            .setAccentColor(0xDE4548)
            .addTextDisplayComponents(new TextDisplayBuilder().setContent(
                `<@${data.recebedor}>\n` +
                `# Confirmar\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `Confirme se o valor foi pago ao vendedor.\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`
            ))
            .addActionRowComponents(new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('confirmar_pagamento_vendedor').setLabel('Foi pago o valor').setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId('nao_recebi_pagamento_vendedor').setLabel('Não recebi o valor').setStyle(ButtonStyle.Danger)
            ));
        // Confirma a interação antes de apagar a mensagem; isso evita o erro de interação não respondida.
        await interaction.deferUpdate().catch(() => {});
        await interaction.message?.delete().catch(() => {});
        await interaction.channel.send({
            components: [confirmacaoPagamento],
            flags: MessageFlags.IsComponentsV2
        }).catch(async err => {
            console.error('Erro ao enviar confirmação do pagamento ao vendedor:', err);
            await interaction.channel.send({ content: '<:emoji_167:1541618912238768148> Não foi possível enviar a confirmação. Avise a staff.' }).catch(() => {});
        });
        return;
    }

    if (interaction.isButton() && (interaction.customId === 'confirmar_pagamento_vendedor' || interaction.customId === 'nao_recebi_pagamento_vendedor')) {
        if (!data) return await interaction.reply({ content: '<:emoji_167:1541618912238768148> Dados deste ticket foram perdidos.', flags: [MessageFlags.Ephemeral] });
        if (interaction.user.id !== data.recebedor) return await interaction.reply({ content: '<:emoji_167:1541618912238768148> Somente o vendedor deste ticket pode confirmar o recebimento.', flags: [MessageFlags.Ephemeral] });
        if (!data.pagamentoVendedorConfirmado) return await interaction.reply({ content: 'O staff ainda não marcou o pagamento como efetuado.', flags: [MessageFlags.Ephemeral] });

        if (interaction.customId === 'nao_recebi_pagamento_vendedor') {
            const modal = new ModalBuilder()
                .setCustomId('modal_motivo_nao_recebi_pagamento')
                .setTitle('Motivo do não recebimento')
                .addComponents(new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('motivo_nao_recebimento')
                        .setLabel('Por que o valor não foi recebido?')
                        .setPlaceholder('Explique brevemente o que aconteceu...')
                        .setStyle(TextInputStyle.Paragraph)
                        .setRequired(true)
                        .setMaxLength(1000)
                ));
            return await interaction.showModal(modal);
        }

        if (data.pagamentoVendedorRecebido) return await interaction.reply({ content: 'O recebimento já foi confirmado.', flags: [MessageFlags.Ephemeral] });
        data.pagamentoVendedorRecebido = true;
        data.pagamentoVendedorConfirmadoEm = new Date().toISOString();
        saveTradeDataToDisk();
        await interaction.deferUpdate().catch(() => {});
        await interaction.message?.delete().catch(() => {});

        const fechamento = new ContainerBuilder()
            .setAccentColor(0xDE4548)
            .addTextDisplayComponents(new TextDisplayBuilder().setContent(
                `# Pagamento foi pago\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `O vendedor confirmou que recebeu o valor informado pelo Middleman.\n` +
                `O pagamento foi confirmado e o atendimento será finalizado conforme o fluxo do ticket.\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `O ticket será fechado automaticamente.`
            ));
        await interaction.channel.send({ components: [fechamento], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        await finalizarPagamentoVendedorConfirmado(interaction, data);
        return;
    }

    if (interaction.isModalSubmit() && interaction.customId === 'modal_motivo_nao_recebi_pagamento') {
        if (!data) return await interaction.reply({ content: '<:emoji_167:1541618912238768148> Dados deste ticket foram perdidos.', flags: [MessageFlags.Ephemeral] });
        if (interaction.user.id !== data.recebedor) return await interaction.reply({ content: '<:emoji_167:1541618912238768148> Somente o vendedor deste ticket pode informar o motivo.', flags: [MessageFlags.Ephemeral] });
        const motivo = interaction.fields.getTextInputValue('motivo_nao_recebimento')?.trim();
        if (!motivo) return await interaction.reply({ content: '<:emoji_167:1541618912238768148> Informe o motivo para continuar.', flags: [MessageFlags.Ephemeral] });

        data.pagamentoVendedorRecebido = false;
        data.motivoNaoRecebimento = motivo;
        data.motivoNaoRecebimentoEm = new Date().toISOString();
        saveTradeDataToDisk();
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] }).catch(() => {});

        const mensagens = await interaction.channel.messages.fetch({ limit: 30 }).catch(() => new Map());
        const painelAnterior = Array.from(mensagens.values()).find(m => m.components?.some(row => row.components?.some(c => ['confirmar_pagamento_vendedor', 'nao_recebi_pagamento_vendedor'].includes(c.customId || c.data?.custom_id))));
        await painelAnterior?.delete().catch(() => {});
        const quando = new Date(data.motivoNaoRecebimentoEm).toLocaleString('pt-BR');
        const aviso = new ContainerBuilder()
            .setAccentColor(0xDE4548)
            .addTextDisplayComponents(new TextDisplayBuilder().setContent(
                `# O pagamento não foi pago\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `O vendedor informou que ainda não recebeu o valor que deveria ser enviado pelo Middleman.\n` +
                `O pagamento precisa ser verificado pela staff responsável antes do encerramento do ticket.\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `**Motivo informado:** ${motivo}\n` +
                `**Data do registro:** ${quando}\n` +
                `**Vendedor:** <@${data.recebedor}>\n` +
                `**Staff responsável:** <@${data.staffReivindicou}>\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `A staff deve confirmar se o pagamento foi feito ou se o pagamento foi esquecido.`
            ))
            .addActionRowComponents(new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('staff_confirmar_pagamento_vendedor').setLabel('Confirmar que foi pago').setStyle(ButtonStyle.Success)
            ));
        await interaction.channel.send({ components: [aviso], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        await interaction.editReply({ content: 'Motivo registrado e enviado para a staff.' }).catch(() => {});
        return;
    }

    if (interaction.isButton() && interaction.customId === 'staff_confirmar_pagamento_vendedor') {
        if (!data) return await interaction.reply({ content: '<:emoji_167:1541618912238768148> Dados deste ticket foram perdidos.', flags: [MessageFlags.Ephemeral] });
        if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID) || !data.staffReivindicou || interaction.user.id !== data.staffReivindicou) {
            return await interaction.reply({ content: '<:emoji_167:1541618912238768148> Somente o staff que assumiu este ticket pode confirmar o pagamento.', flags: [MessageFlags.Ephemeral] });
        }
        data.pagamentoVendedorRecebido = true;
        data.pagamentoVendedorConfirmadoEm = new Date().toISOString();
        saveTradeDataToDisk();
        await interaction.deferUpdate().catch(() => {});
        await interaction.message?.delete().catch(() => {});
        await finalizarPagamentoVendedorConfirmado(interaction, data);
        return;
    }

    if (interaction.isButton() && interaction.customId.startsWith('copychave_')) {
        const chaveId = interaction.customId.slice('copychave_'.length);
        const chave = data?.pixPagamento?.chave || chaveFinalStorage.get(chaveId);
        if (!chave) return await interaction.reply({ content: '<:emoji_167:1541618912238768148> Chave expirada ou não encontrada neste ticket.', flags: [MessageFlags.Ephemeral] });
        await interaction.reply({ content: chave, flags: [MessageFlags.Ephemeral] }).catch(() => {});
    }

    if (interaction.isButton() && interaction.customId.startsWith('qr_')) {
        const id = interaction.customId.slice(3);
        const stored = pixStorage.get(id);
        const item = (data?.pixPagamento?.payload && data.pixPagamento.channelId === interaction.channel.id) ? data.pixPagamento : (stored && (!stored.channelId || stored.channelId === interaction.channel.id) ? stored : null);
        if (!item) return await interaction.reply({ content: "<:emoji_167:1541618912238768148> QR Code expirado ou não encontrado.", flags: [MessageFlags.Ephemeral] });

        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        try {
            const qrBuffer = await QRCode.toBuffer(item.payload, {
                type: "png",
                width: 600,
                margin: 2,
                errorCorrectionLevel: "M"
            });

            const containerQR = new ContainerBuilder()
                .setAccentColor(0xDE4548)
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(
                    `# 📷 Escaneie o QR Code\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `> 💰 **Valor exato a pagar: R$ ${item.total}**`
                ))
                .addMediaGalleryComponents(new MediaGalleryBuilder().addItems(
                    new MediaGalleryItemBuilder().setURL(`attachment://pix-${id}.png`)
                ));

            await interaction.editReply({
                components: [containerQR],
                files: [new AttachmentBuilder(qrBuffer, { name: `pix-${id}.png` })],
                flags: MessageFlags.IsComponentsV2
            });
        } catch (err) {
            console.error("Erro ao gerar QR Code PIX:", err);
            await interaction.editReply("<:emoji_167:1541618912238768148> Não foi possível gerar o QR Code. Use o botão Copia e Cola.").catch(console.error);
        }
    }

    if (interaction.isButton() && interaction.customId.startsWith('posse_pagamento_')) {
        if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return await responderSeguro(interaction, { content: 'Apenas um Middleman pode confirmar o pagamento.', ephemeral: true });
        const id = interaction.customId.slice('posse_pagamento_'.length);
        const posse = posseData.get(id);
        if (!posse || posse.channelId !== interaction.channelId) return await responderSeguro(interaction, { content: 'Esse painel de posse expirou.', ephemeral: true });
        if (posse.assumida) return await responderSeguro(interaction, { content: 'A posse já foi assumida.', ephemeral: true });
        posse.pagamentoConfirmado = true;
        await interaction.update({ components: [construirPainelPosse(posse)], flags: MessageFlags.IsComponentsV2 });
        return;
    }

    if (interaction.isButton() && interaction.customId.startsWith('posse_assumir_')) {
        if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return await responderSeguro(interaction, { content: 'Apenas um Middleman pode assumir a posse.', ephemeral: true });
        const id = interaction.customId.slice('posse_assumir_'.length);
        const posse = posseData.get(id);
        if (!posse || posse.channelId !== interaction.channelId) return await responderSeguro(interaction, { content: 'Esse painel de posse expirou.', ephemeral: true });
        if (posse.assumida) return await responderSeguro(interaction, { content: 'Essa posse já foi assumida por outro Middleman.', ephemeral: true });
        if (!posse.pagamentoConfirmado) return await responderSeguro(interaction, { content: 'Antes de assumir, confirme primeiro que o valor foi pago ao Middleman.', ephemeral: true });
        posse.assumida = true;
        posse.assumidaPor = interaction.user.id;
        await interaction.update({ components: [construirPainelPosse(posse)], flags: MessageFlags.IsComponentsV2 });
        await interaction.channel.send({ content: '🔄 A posse da mediação foi passada para outro Middleman porque o responsável teve um imprevisto.' });
        return;
    }

    if (interaction.isButton() && interaction.customId.startsWith('copy_')) {
        const id = interaction.customId.slice('copy_'.length);
        const stored = pixStorage.get(id);
        const item = (data?.pixPagamento?.payload && data.pixPagamento.channelId === interaction.channel.id)
            ? data.pixPagamento
            : (stored && (!stored.channelId || stored.channelId === interaction.channel.id) ? stored : null);
        if (!item?.payload) return await interaction.reply({ content: '<:emoji_167:1541618912238768148> PIX expirado ou não encontrado neste ticket.', flags: [MessageFlags.Ephemeral] });
        await interaction.reply({ content: item.payload, flags: [MessageFlags.Ephemeral] }).catch(() => {});
    }

    if (interaction.isButton() && interaction.customId === 'btn_termos') {
        const container = new ContainerBuilder().setAccentColor(0xDE4548).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:parceria:1485054250429054986> ╺╸ **Termos e Regras do MM Automático**\n\n**<:discotoolsxyzicon111:1470855659909284104> Segurança em Primeiro Lugar**\nPara garantir a segurança de ambas as partes, siga rigorosamente as instruções abaixo.\n\n**<:discotoolsxyzicon6:1470345157391155301> Para o Vendedor (Quem entrega o item):**\n> **GRAVE TUDO!** Recomendamos fortemente que você grave todo o processo de entrega do produto, desde o momento que inicia a troca até a confirmação de recebimento. Em caso de disputa, essa será sua principal prova.\n\n**<:discotoolsxyzicon28:1470856248122409171> Para o Comprador (Quem paga):**\n> **CONFIRA TUDO!** Verifique se o item recebido é exatamente o combinado antes de confirmar o recebimento no bot. Após confirmado, o dinheiro é liberado automaticamente e não há estorno.\n\n**<:discotoolsxyzicon13:1470342793716174880> Regras Gerais:**\n1. Não tente burlar o sistema de taxas.\n2. Mantenha toda a negociação dentro deste ticket.\n3. O bot não se responsabiliza por erros humanos (ex: enviar item para nick errado).\n4. Em caso de problemas, abra uma **Disputa** imediatamente.`));
        await interaction.reply({ components: [container], flags: [MessageFlags.Ephemeral, MessageFlags.IsComponentsV2] });
    }

    if (interaction.isButton() && interaction.customId === 'resetar_fluxo') {
        const fetched = await interaction.channel.messages.fetch({ limit: 100 }); if (fetched) await interaction.channel.bulkDelete(fetched.filter(m => !m.pinned));
        await iniciarFluxoImagens(interaction.channel);
    }

    if (interaction.isButton() && interaction.customId === 'btn_fechar') {
        await interaction.deferReply().catch(() => {});

        const v = parseFloat(data?.valor || 0);
        let taxa = data?.taxaValor || calcularTaxaBase(v, data?.tipoTaxa);
        try {
            const mE = data?.enviador ? await interaction.guild.members.fetch(data.enviador).catch(() => null) : null;
            const mR = data?.recebedor ? await interaction.guild.members.fetch(data.recebedor).catch(() => null) : null;
            if (mE?.roles.cache.has(CARGO_AFILIADO_ID) || mR?.roles.cache.has(CARGO_AFILIADO_ID)) taxa /= 2;
        } catch (err) {}

        let transacaoIdFinal = null;
        if (data && data.pagamentoConfirmado && !data.vouchGerado && data.enviador && data.recebedor && data.valor) {
            try {
                const enviadorU = await client.users.fetch(data.enviador).catch(() => null);
                const recebedorU = await client.users.fetch(data.recebedor).catch(() => null);
                const staffMediadorU = await client.users.fetch(data.staffReivindicou || interaction.user.id).catch(() => null);
                if (enviadorU && recebedorU && staffMediadorU) {
                    transacaoIdFinal = await executarAprovarPagamento(interaction.guild, staffMediadorU, data.modoConta ? "conta" : "pix", enviadorU, recebedorU, parseFloat(data.valor), { vendedorAnonimo: data.vendedorAnonimo === true, compradorAnonimo: data.compradorAnonimo === true });
                    data.vouchGerado = true;
                    saveTradeDataToDisk();
                }
            } catch (err) {
                console.error("Erro ao registrar proof automática no fechamento:", err);
            }
        }

        const messages = await interaction.channel.messages.fetch({ limit: 100 }).catch(() => new Map());
        const transcript = Array.from(messages.values()).reverse().map(m => `[${m.createdAt ? m.createdAt.toLocaleString() : ''}] ${m.author ? m.author.tag : 'User'}: ${m.content}`).join('\n');

        const embedLogEncerrado = new EmbedBuilder()
            .setColor('#DE4548')
            .setTitle('Middle encerrado (Logs)')
            .addFields(
                { name: 'Administrador / MM', value: `<@${interaction.user.id}>` },
                { name: 'Canal', value: `#${interaction.channel.name}` },
                { name: 'Valor', value: `R$ ${v.toFixed(2)}`, inline: true },
                { name: 'Taxa', value: `R$ ${taxa.toFixed(2)}`, inline: true }
            )
            .setTimestamp();
        await enviarLog(interaction.guild, embedLogEncerrado, [new AttachmentBuilder(Buffer.from(transcript), { name: `transcript-${interaction.channel.name}.txt` })]).catch(console.error);

        if (data && data.enviador && data.recebedor) {
            const pendingId = gerarIdAvaliacao();
            avaliacoesPendentes.set(pendingId, {
                enviador: data.enviador,
                recebedor: data.recebedor,
                valor: v,
                item: data.item,
                staffId: data.staffReivindicou || interaction.user.id,
                transacaoId: transacaoIdFinal || pendingId,
                transcript,
                avaliacoes: {}
            });
            saveAvaliacoesPendentes();

            const protocoloResumo = transacaoIdFinal || pendingId;
            const dataFechamentoTxt = new Date().toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" });

            const containerResumo = new ContainerBuilder().setAccentColor(0x5865F2).addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `## 📋 Resumo do Ticket Encerrado\n` +
                    `**Protocolo:** ${protocoloResumo}\n` +
                    `**Valor:** R$ ${v.toFixed(2)}\n` +
                    `**Servidor:** ${interaction.guild.name}\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `**Comprador:** <@${data.enviador}>\n` +
                    `**Vendedor:** <@${data.recebedor}>\n` +
                    `**Intermediador:** <@${data.staffReivindicou || interaction.user.id}>\n\n` +
                    `<:emoji_172:1541636098005016576> **Ticket encerrado com sucesso.**\n` +
                    `🗓️ ${dataFechamentoTxt}\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `📄 **Transcrição**\n` +
                    `-# Histórico completo das mensagens deste ticket.`
                )
            ).addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`abrir_transcript_${pendingId}`).setLabel('Abrir transcrição').setEmoji('📄').setStyle(ButtonStyle.Secondary)
                )
            );

            const containerEstrelas = new ContainerBuilder().setAccentColor(0xf2a20e).addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`# ⭐ Avalie o Atendimento ⭐\nPor favor, avalie a mediação que você recebeu!`)
            ).addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`av_1_${pendingId}`).setEmoji('⭐').setLabel('1').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`av_2_${pendingId}`).setEmoji('⭐').setLabel('2').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`av_3_${pendingId}`).setEmoji('⭐').setLabel('3').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`av_4_${pendingId}`).setEmoji('⭐').setLabel('4').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`av_5_${pendingId}`).setEmoji('⭐').setLabel('5').setStyle(ButtonStyle.Success)
                )
            );

            for (const uid of [data.enviador, data.recebedor]) {
                try {
                    const userDM = await client.users.fetch(uid).catch(() => null);
                    if (userDM) {
                        await userDM.send({ components: [containerResumo], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
                        await userDM.send({ components: [containerEstrelas], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
                    }
                } catch (e) {}
            }
        }

        await interaction.editReply({ content: 'Fechando ticket em 5 segundos...' }).catch(() => {});
        setTimeout(() => {
            interaction.channel.delete().catch(() => {});
            tradeData.delete(interaction.channelId);
            saveTradeDataToDisk();
        }, 5000);
    }
  } catch (err) {
    console.error("<:emoji_167:1541618912238768148> [ERRO NÃO TRATADO em interactionCreate]", err);
    const msgErro = { content: "<:emoji_167:1541618912238768148> Ocorreu um erro inesperado ao processar essa ação. Tenta de novo — se persistir, avisa a staff.", flags: [MessageFlags.Ephemeral] };
    try {
        if (interaction.replied || interaction.deferred) {
            await interaction.followUp(msgErro).catch(() => {});
        } else {
            await interaction.reply(msgErro).catch(() => {});
        }
    } catch (e) {}
  } finally {
    liberarFila();
  }
  } finally {
    interacoesEmAndamento.delete(interaction.id);
  }
});

async function executarAprovarPagamento(guild, staffUser, tipo, enviadorUser, recebedorUser, valor, opcoesVouch = {}) {
    registerStaffTrade(staffUser.id, valor, [enviadorUser.id, recebedorUser.id]);

    registerTrade(enviadorUser.id, valor);
    registerTrade(recebedorUser.id, valor);
    globalCounter++;
    saveGlobal();
    if (userData[enviadorUser.id].contador === undefined) userData[enviadorUser.id].contador = 0;
    userData[enviadorUser.id].contador++;
    saveUsers();
    await atualizarCargos(guild, enviadorUser.id);
    await atualizarCargos(guild, recebedorUser.id);
    await atualizarCargos(guild, staffUser.id);
    const valorFormatado = valor.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
    const taxaTotal = calcularTaxa(tipo, valor, enviadorUser.id, recebedorUser.id);
    if (taxaTotal > 0) {
        taxasDiarias[staffUser.id] = (taxasDiarias[staffUser.id] || 0) + taxaTotal;
        saveTaxas();

        if (!userData[staffUser.id]) userData[staffUser.id] = { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
        userData[staffUser.id].taxaMes = (userData[staffUser.id].taxaMes || 0) + taxaTotal;
        userData[staffUser.id].taxaTotal = (userData[staffUser.id].taxaTotal || 0) + taxaTotal;
        saveUsers();
    }

    const transacaoId = `MM-${Date.now()}${Math.floor(Math.random() * 900 + 100)}`;
    const vouchCodigo = `#${String(globalCounter).padStart(5, '0')}`;

    const avaliacoesStaff = userData[staffUser.id]?.avaliacoes || [];
    const notaMedia = avaliacoesStaff.length
        ? avaliacoesStaff.reduce((a, b) => a + b, 0) / avaliacoesStaff.length
        : 5;

    const [staffMember, enviadorMember, recebedorMember] = await Promise.all([
        guild?.members?.fetch(staffUser.id).catch(() => null),
        guild?.members?.fetch(enviadorUser.id).catch(() => null),
        guild?.members?.fetch(recebedorUser.id).catch(() => null)
    ]);

    const staffDisplayName = staffMember?.displayName || staffUser?.username || "Staff";
    const enviadorDisplayName = enviadorMember?.displayName || enviadorUser?.username || "Comprador";
    const recebedorDisplayName = recebedorMember?.displayName || recebedorUser?.username || "Vendedor";

    const canalAlvoId = (tipo === "pix_grande" || valor >= 500) ? CANAL_BIG_TRADE : CANAL_PROOFS;
    const canal = await getCanal(guild, canalAlvoId) || await getCanal(guild, CANAL_PROOFS);
    if (canal) {
        try {
            const buffer = await gerarCartaoVouchGif({
                staffNome: staffDisplayName,
                staffAvatarURL: staffUser?.displayAvatarURL ? staffUser.displayAvatarURL({ extension: "png", size: 128 }) : null,
                staffNota: notaMedia,
                staffIntermediacoes: userData[staffUser.id]?.totalTrocas || 0,
                transacaoId,
                vouchCodigo,
                valor,
                compradorNome: opcoesVouch.compradorAnonimo ? "ANÔNIMO" : enviadorDisplayName,
                compradorAvatarURL: opcoesVouch.compradorAnonimo ? "__ANONYMOUS__" : (enviadorUser?.displayAvatarURL ? enviadorUser.displayAvatarURL({ extension: "png", size: 128 }) : null),
                vendedorNome: opcoesVouch.vendedorAnonimo ? "ANÔNIMO" : recebedorDisplayName,
                vendedorAvatarURL: opcoesVouch.vendedorAnonimo ? "__ANONYMOUS__" : (recebedorUser?.displayAvatarURL ? recebedorUser.displayAvatarURL({ extension: "png", size: 128 }) : null),
                vendedorAnonimo: opcoesVouch.vendedorAnonimo === true,
                compradorAnonimo: opcoesVouch.compradorAnonimo === true,
                data: new Date().toLocaleDateString("pt-BR")
            });
            const anexoVouch = new AttachmentBuilder(buffer, { name: `vouch-${vouchCodigo.replace('#', '')}.gif` });
            await canal.send({
                files: [anexoVouch]
            }).catch(console.error);
            console.log(`[VOUCH] Cartão de vouch enviado com sucesso para #${canal.name} (${canal.id})`);
        } catch (e) {
            console.error("Erro ao gerar cartão de vouch:", e);
        }
    } else {
        console.error(`[VOUCH] Canal de proofs não encontrado (${canalAlvoId} / ${CANAL_PROOFS})`);
    }

    if (taxaTotal > 0) {
        const canalTaxas = await getCanal(guild, CANAL_TAXAS);
        if (canalTaxas) {
            const embedTaxas = new EmbedBuilder().setColor("#DE4548").setTitle("<:0961:1454624137992474644> — Relatório de Intermediação").setDescription(`**ID da Proof:** \`#${globalCounter}\` | Valor: \`R$ ${valorFormatado}\``).addFields({ name: "💰 Taxa Total", value: `\`R$ ${taxaTotal.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}\`` }, { name: "👑 Parte do Dono (50%)", value: `\`R$ ${(taxaTotal / 2).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}\``, inline: true }, { name: "🤝 Parte do Middleman (50%)", value: `\`R$ ${(taxaTotal / 2).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}\``, inline: true });
            await canalTaxas.send({ content: `🔔 <@${staffUser.id}>`, embeds: [embedTaxas] }).catch(() => {});
        }
    }

    return transacaoId;
}

let lastDailyRun = null;
const dbLastMonthlyPath = path.join(__dirname, 'lastMonthlyRun.json');
let lastMonthlyRun = null;
try {
    if (fs.existsSync(dbLastMonthlyPath)) {
        const rawLast = JSON.parse(fs.readFileSync(dbLastMonthlyPath, 'utf8'));
        lastMonthlyRun = (typeof rawLast === 'object' && rawLast !== null && rawLast.lastRun) ? String(rawLast.lastRun) : String(rawLast || '');
    }
} catch (e) {
    lastMonthlyRun = null;
}

function saveLastMonthlyRun() {
    try {
        const currentVal = typeof lastMonthlyRun === 'string' ? lastMonthlyRun : (lastMonthlyRun?.lastRun || '');
        fs.writeFileSync(dbLastMonthlyPath, JSON.stringify({ lastRun: currentVal, history: [currentVal] }, null, 2));
    } catch (e) {
        console.error("Erro ao salvar lastMonthlyRun:", e);
    }
}

function checkScheduledTasks() {
    const now = new Date();
    const options = { timeZone: "America/Sao_Paulo", hour: "numeric", minute: "numeric", day: "numeric" };
    const formatter = new Intl.DateTimeFormat("pt-BR", options);
    const parts = formatter.formatToParts(now);
    const hour = parseInt(parts.find(p => p.type === "hour").value);
    const minute = parseInt(parts.find(p => p.type === "minute").value);
    const day = parseInt(parts.find(p => p.type === "day").value);

    const currentMonthYear = new Date().getMonth() + "-" + new Date().getFullYear();
    const recordedMonthYear = typeof lastMonthlyRun === 'object' && lastMonthlyRun !== null ? lastMonthlyRun.lastRun : lastMonthlyRun;
    if (day === 1 && recordedMonthYear !== currentMonthYear) {
        console.log("Tentando executar reset mensal...");
        runMonthlyReset();
    }
    if (hour === 23 && minute >= 10) runDailyClosure();
}

async function runDailyClosure() {
    const today = new Date().toDateString();
    if (lastDailyRun === today) return;
    lastDailyRun = today;
    try {
        const guild = client.guilds.cache.get(GUILD_ID);
        if (!guild || Object.keys(taxasDiarias).length === 0) return;
        const canalTaxas = guild.channels.cache.get(CANAL_TAXAS);
        if (!canalTaxas) console.warn("[fechamento diário] Canal de taxas não encontrado:", CANAL_TAXAS);

        for (const [mmId, totalBruto] of Object.entries(taxasDiarias)) {
            // Blindagem: se por algum motivo o valor salvo não for um número válido, pula essa entrada
            // em vez de derrubar o fechamento inteiro (e loga pra facilitar achar a causa).
            const total = parseFloat(totalBruto);
            if (!Number.isFinite(total) || total <= 0) {
                console.warn(`[fechamento diário] Valor inválido para ${mmId}, ignorado:`, totalBruto);
                continue;
            }
            try {
                const metade = total / 2;
                const embed = new EmbedBuilder().setColor("#DE4548").setTitle("📊 Fechamento Diário de Taxas").setDescription(`Relatório de <@${mmId}>\nTotal: \`R$ ${total.toFixed(2)}\` | Repasse: \`R$ ${metade.toFixed(2)}\``);
                const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId("copiar_chave_pix_repasse").setLabel("Chave PIX para Repasse").setStyle(ButtonStyle.Primary));
                if (canalTaxas) await canalTaxas.send({ embeds: [embed], components: [row] }).catch((e) => console.error(`[fechamento diário] Falha ao enviar relatório de ${mmId}:`, e?.message || e));
            } catch (erroItem) {
                console.error(`[fechamento diário] Erro ao processar ${mmId}:`, erroItem?.message || erroItem);
            }
        }
        taxasDiarias = {}; saveTaxas();
    } catch (err) {
        console.error("Erro no fechamento diário:", err?.message || err);
        if (err?.stack) console.error(err.stack);
    }
}

async function runMonthlyReset() {
    const monthYear = new Date().getMonth() + "-" + new Date().getFullYear();
    const recordedMonthYear = typeof lastMonthlyRun === 'object' && lastMonthlyRun !== null ? lastMonthlyRun.lastRun : lastMonthlyRun;
    if (recordedMonthYear === monthYear) {
        console.log("Reset mensal já executado para este mês.");
        return;
    }
    lastMonthlyRun = monthYear;
    saveLastMonthlyRun();
    try {
        const guild = client.guilds.cache.get(GUILD_ID);
        if (guild) {
            const rolesTop = [CARGO_TOP_1, CARGO_TOP_2, CARGO_TOP_3];
            for (const roleId of rolesTop) {
                const role = guild.roles.cache.get(roleId);
                if (role) {
                    for (const [mId, m] of role.members) await m.roles.remove(roleId).catch(() => { });
                }
            }
        }
        for (const id in userData) {
            userData[id].totalMes = 0;
            userData[id].trocasMes = 0;
            userData[id].taxaMes = 0;
        }
        saveUsers();
        saveLastMonthlyRun(); // Salva a data do último reset mensal
    } catch (err) { console.error("Erro no reset mensal:", err); }
}

const commands = [
    new SlashCommandBuilder().setName("ranking").setDescription("Mostra o ranking de movimentação"),
    new SlashCommandBuilder().setName("perfil").setDescription("Ver perfil financeiro").addUserOption(o => o.setName("usuario").setDescription("Usuário")),
    new SlashCommandBuilder().setName("vouch").setDescription("Aprova um pagamento e gera o vouch de intermediação").addStringOption(o => o.setName("tipo").setDescription("Tipo").setRequired(true).addChoices({ name: "PIX", value: "pix" }, { name: "PIX GRANDE", value: "pix_grande" }, { name: "CROSSTRADE", value: "crosstrade" })).addUserOption(o => o.setName("comprador").setDescription("Comprador").setRequired(true)).addUserOption(o => o.setName("vendedor").setDescription("Vendedor").setRequired(true)).addStringOption(o => o.setName("valor").setDescription("Valor").setRequired(true)),
    new SlashCommandBuilder().setName("aprovar_pagamento").setDescription("Aprova um pagamento").addStringOption(o => o.setName("tipo").setDescription("Tipo").setRequired(true).addChoices({ name: "PIX", value: "pix" }, { name: "PIX GRANDE", value: "pix_grande" }, { name: "CROSSTRADE", value: "crosstrade" })).addUserOption(o => o.setName("enviador").setDescription("Enviador").setRequired(true)).addUserOption(o => o.setName("recebedor").setDescription("Recebedor").setRequired(true)).addStringOption(o => o.setName("valor").setDescription("Valor").setRequired(true)),
    new SlashCommandBuilder().setName("remover_valor").setDescription("Remove um valor do total de um usuário").addUserOption(o => o.setName("usuario").setDescription("Usuário").setRequired(true)).addStringOption(o => o.setName("valor").setDescription("Valor a remover").setRequired(true)),
    new SlashCommandBuilder().setName("alterar_intermediacoes").setDescription("Altera a quantidade de intermediações de um Middleman ou usuário").addUserOption(o => o.setName("usuario").setDescription("Usuário / Middleman").setRequired(true)).addIntegerOption(o => o.setName("quantidade").setDescription("Nova quantidade de intermediações (ex: 60)").setRequired(true)).addStringOption(o => o.setName("tipo").setDescription("Onde aplicar").addChoices({ name: "Total Geral", value: "geral" }, { name: "Mensal", value: "mensal" }, { name: "Ambos (Geral e Mensal)", value: "ambos" })),
    new SlashCommandBuilder().setName("configpix").setDescription("Configurar dados de PIX para os Middlemans").setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    new SlashCommandBuilder().setName("passar-posse").setDescription("Abrir um painel para passar a posse da mediação a outro Middleman")
];

const rest = new REST({ version: "10" }).setToken(TOKEN);
(async () => {
    try {
        await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body: commands });
        console.log("Comandos registrados.");
    } catch (err) { console.error(err); }
})();

// Mesma lógica: trava só a MESMA mensagem repetida, sem tocar nos listeners
// de outras funções/outros tickets/outros códigos que rodem no mesmo client.
const mensagensEmAndamento = new Set();

client.on(Events.MessageCreate, async (message) => {
    if (mensagensEmAndamento.has(message.id)) return; // mesma mensagem já está sendo processada — quebra na hora
    mensagensEmAndamento.add(message.id);
    try {
    const ticketData = tradeData.get(message.channel.id);
    if (ticketData?.modoConta && !message.author.bot && message.attachments?.size) {
        await message.channel.send({ content: '⚠️ Comprovantes de pagamento devem ser enviados pelo botão **Enviar imagem**. Arquivos enviados diretamente no chat não são processados.' }).then(m => setTimeout(() => m.delete().catch(() => {}), 10000)).catch(() => {});
        return;
    }
    if (ticketData?.modoConta && !message.author.bot && mensagemPareceCredencialDeConta(message.content)) {
        await message.delete().catch(() => {});
        await message.channel.send({ content: `🔐 <@${message.author.id}> mensagem removida: nunca envie senha, token, 2FA ou código de recuperação no ticket. Use somente a página oficial do serviço.` }).then(m => setTimeout(() => m.delete().catch(() => {}), 10000)).catch(() => {});
        return;
    }
    const gorjetaMatch = message.content.match(/^!gorjeta(?:\s+(.+))?$/i);
    if (gorjetaMatch) {
        await message.delete().catch(() => {}); // some o comando do chat pra não ficar zoeira
        if (!ticketData) {
            await message.channel.send({ content: '⚠️ O comando `!gorjeta valor` só funciona dentro de um ticket.' }).then(m => setTimeout(() => m.delete().catch(() => {}), 10000)).catch(() => {});
            return;
        }
        if (!message.member?.roles?.cache?.has(CARGO_STAFF_ID)) return;
        const valorGorjeta = sanitizarValorGorjeta(gorjetaMatch[1] || '');
        if (!Number.isFinite(valorGorjeta) || valorGorjeta <= 0) {
            await message.channel.send({ content: '⚠️ Use o formato `!gorjeta 10`.' }).then(m => setTimeout(() => m.delete().catch(() => {}), 10000)).catch(() => {});
            return;
        }
        const configMM = pixConfig.get(message.author.id);
        if (!configMM?.chave) {
            await message.channel.send({ content: '⚠️ Este Middleman ainda não tem uma chave PIX configurada.' }).then(m => setTimeout(() => m.delete().catch(() => {}), 10000)).catch(() => {});
            return;
        }
        try {
            const idGorjeta = `gorjeta_${message.channel.id}_${Date.now()}`;
            const payloadGorjeta = gerarPix(configMM.chave, configMM.nome, valorGorjeta);
            pixStorage.set(idGorjeta, { payload: payloadGorjeta, total: valorGorjeta.toFixed(2), channelId: message.channel.id });
            await message.channel.send({ components: [construirPainelGorjeta({ id: idGorjeta, middleman: message.author.id, valor: valorGorjeta })], flags: MessageFlags.IsComponentsV2 });
        } catch (err) {
            console.error('Erro ao gerar gorjeta:', err);
            await message.channel.send({ content: '⚠️ Não consegui gerar o PIX da gorjeta. Confira a chave PIX configurada.' }).then(m => setTimeout(() => m.delete().catch(() => {}), 10000)).catch(() => {});
        }
        return;
    }

    const setInterMatch = message.content.match(/^!setintermedio\s+(?:<@!?(\d+)>|(\d+))\s+(\d+)$/i) || message.content.match(/^!setintermedio\s+(\d+)\s+(?:<@!?(\d+)>|(\d+))$/i);
    if (setInterMatch) {
        if (!isDonoOuCargoMaisAlto(message.member)) {
            return await message.reply("<:emoji_167:1541618912238768148> Apenas o **Dono do servidor** (cargo mais alto) pode alterar intermediações.");
        }
        const targetId = setInterMatch[1] || setInterMatch[2] || setInterMatch[5] || setInterMatch[6];
        const qtd = parseInt(setInterMatch[3] || setInterMatch[4] || 0, 10);
        if (targetId && !isNaN(qtd) && qtd >= 0) {
            if (!userData[targetId]) {
                userData[targetId] = { totalTrocas: 0, trocasMes: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
            }
            userData[targetId].totalTrocas = qtd;
            userData[targetId].trocasMes = qtd;
            userData[targetId].pessoasIntermediadas = Math.max(userData[targetId].pessoasIntermediadas || 0, qtd);
            saveUsers();
            await atualizarCargos(message.guild, targetId).catch(() => {});
            return await message.reply({ content: `<:emoji_172:1541636098005016576> Intermediações de <@${targetId}> alteradas com sucesso pelo Dono para **${qtd}**!` });
        }
    }

    if (message.content.toLowerCase() === '!passar posse') {
        await message.delete().catch(() => {}); // some o comando do chat pra não ficar zoeira
        if (!message.member?.roles?.cache?.has(CARGO_STAFF_ID)) return;
        const posse = { id: `${message.channel.id}_${Date.now()}`, channelId: message.channel.id, criadaPor: message.author.id, pagamentoConfirmado: false, assumida: false, assumidaPor: null };
        posseData.set(posse.id, posse);
        await message.channel.send({ components: [construirPainelPosse(posse)], flags: MessageFlags.IsComponentsV2 }).catch(console.error);
        return;
    }
    if (message.content === '!middleman') {
        const containerNormal = new ContainerBuilder()
            .setAccentColor(0xDE4548)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# ${EMOJI_CARTAO_BOTAO} — Solicitar MIDDLEMAN\n` +
                    '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    'Selecione a opção de **mediação normal**. Oferecemos intermediação segura e ágil para sua negociação.\n' +
                    '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    `## ${EMOJI_CARTAO_TITULO} Taxa Sobre Transação via PIX\n` +
                    '**Taxas Normais**\n' +
                    '**R$ 0,50** acima de R$ 8,00.\n' +
                    '**R$ 2,00** acima de R$ 100,00.\n' +
                    '**R$ 4,00** acima de R$ 200,00.\n' +
                    '**R$ 6,50** acima de R$ 400,00.\n' +
                    '**1%** acima de R$ 700,00.\n' +
                    '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    '**Abrir MM normal**'
                )
            )
            .addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('abrir_mediacao')
                        .setLabel('Abrir Mediação')
                        .setStyle(ButtonStyle.Danger)
                )
            )
            .addTextDisplayComponents(new TextDisplayBuilder().setContent('-# NEUX MEDIAÇÃO'));

        const containerConta = new ContainerBuilder()
            .setAccentColor(0xDE4548)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# ${EMOJI_CARTAO_BOTAO} — Negociação de Conta\n` +
                    'Negocie contas com segurança. Nunca envie senha, token, 2FA ou código de recuperação.\n' +
                    '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    `## ${EMOJI_CARTAO_TITULO} Taxa da negociação: R$ 3,00`
                )
            )
            .addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('abrir_conta')
                        .setLabel('Abrir Conta')
                        .setEmoji(EMOJI_CARTAO_BOTAO)
                        .setStyle(ButtonStyle.Danger)
                )
            );

        await message.channel.send({ components: [containerNormal], flags: MessageFlags.IsComponentsV2 }).catch(console.error);
        await message.channel.send({ components: [containerConta], flags: MessageFlags.IsComponentsV2 }).catch(console.error);
    }

    if (message.content === '!middleman2') {
        const containerNormalBaixa = new ContainerBuilder()
            .setAccentColor(0xDE4548)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# ${EMOJI_CARTAO_BOTAO} — Solicitar MIDDLEMAN\n` +
                    '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    'Selecione a opção de **mediação PIX com taxa reduzida**.\n' +
                    '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    `## ${EMOJI_CARTAO_TITULO} Taxa Sobre Transação via PIX\n` +
                    '**Taxa Reduzida**\n' +
                    '**R$ 0,25** acima de R$ 8,00.\n' +
                    '**R$ 2,00** acima de R$ 100,00.\n' +
                    '**R$ 4,00** acima de R$ 200,00.\n' +
                    '**R$ 6,50** acima de R$ 400,00.\n' +
                    '**1%** acima de R$ 700,00.\n' +
                    '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    '**Abrir MM reduzido**'
                )
            )
            .addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('abrir_mediacao_baixa')
                        .setLabel('Abrir Mediação (Taxa Reduzida)')
                        .setStyle(ButtonStyle.Danger)
                )
            )
            .addTextDisplayComponents(new TextDisplayBuilder().setContent('-# NEUX MEDIAÇÃO'));

        const containerContaBaixa = new ContainerBuilder()
            .setAccentColor(0xDE4548)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# ${EMOJI_CARTAO_BOTAO} — Negociação de Conta\n` +
                    'Negocie contas com segurança. Nunca envie senha, token, 2FA ou código de recuperação.\n' +
                    '-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n' +
                    `## ${EMOJI_CARTAO_TITULO} Taxa da negociação: R$ 3,00`
                )
            )
            .addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('abrir_conta_baixa')
                        .setLabel('Abrir Conta (Taxa Reduzida)')
                        .setEmoji(EMOJI_CARTAO_BOTAO)
                        .setStyle(ButtonStyle.Danger)
                )
            );

        await message.channel.send({ components: [containerNormalBaixa], flags: MessageFlags.IsComponentsV2 }).catch(console.error);
        await message.channel.send({ components: [containerContaBaixa], flags: MessageFlags.IsComponentsV2 }).catch(console.error);
    }

    if (message.content.startsWith('!setintermedio')) {
        if (!isDonoOuCargoMaisAlto(message.member)) {
            return message.reply('<:emoji_167:1541618912238768148> Apenas o **Dono do servidor** (cargo mais alto) pode alterar intermediações.');
        }
        const partes = message.content.trim().split(/\s+/);
        let idAlvo = message.author.id;
        let qtd = 0;
        if (partes.length === 2) {
            qtd = parseInt(partes[1].replace(/\D/g, ''));
        } else if (partes.length >= 3) {
            const m = partes[1].match(/\d{17,20}/);
            if (m) idAlvo = m[0];
            qtd = parseInt(partes[2].replace(/\D/g, ''));
        }
        if (isNaN(qtd) || qtd < 0) {
            return message.reply('<:emoji_167:1541618912238768148> Uso: `!setintermedio <quantidade>` ou `!setintermedio @usuario <quantidade>`');
        }
        if (!userData[idAlvo]) {
            userData[idAlvo] = { totalTrocas: qtd, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: qtd, listaPessoas: [], clienteDesde: new Date().getFullYear(), trocasMes: 0 };
        } else {
            userData[idAlvo].totalTrocas = qtd;
            userData[idAlvo].pessoasIntermediadas = Math.max(userData[idAlvo].pessoasIntermediadas || 0, qtd);
        }
        saveUsers();
        await atualizarCargos(message.guild, idAlvo).catch(() => {});
        return message.reply(`${EMOJI_CHECK} Intermediações de <@${idAlvo}> atualizadas para **${qtd}** com sucesso pelo Dono!`);
    }

    if (message.content.startsWith('!setmovimento')) {
        if (!isDonoOuCargoMaisAlto(message.member)) {
            return message.reply('<:emoji_167:1541618912238768148> Apenas o **Dono do servidor** (cargo mais alto) pode alterar valores e movimentações.');
        }
        const partes = message.content.trim().split(/\s+/);
        let idAlvo = message.author.id;
        let valorStr = '';
        if (partes.length === 2) {
            valorStr = partes[1];
        } else if (partes.length >= 3) {
            const m = partes[1].match(/\d{17,20}/);
            if (m) idAlvo = m[0];
            valorStr = partes[2];
        }
        let s = valorStr.toLowerCase().replace(/\s/g, '');
        let mult = 1;
        if (s.endsWith('k')) {
            mult = 1000;
            s = s.slice(0, -1);
        }
        const val = sanitizarValor(s) * mult;
        if (isNaN(val) || val < 0) {
            return message.reply('<:emoji_167:1541618912238768148> Uso: `!setmovimento @usuario <valor>` (ex: `!setmovimento @user 28600` ou `28.6k`)');
        }
        if (!userData[idAlvo]) {
            userData[idAlvo] = { totalTrocas: 0, trocasMes: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
        }
        userData[idAlvo].totalMes = val;
        saveUsers();
        await atualizarCargos(message.guild, idAlvo).catch(() => {});
        return message.reply(`${EMOJI_CHECK} Movimentação mensal de <@${idAlvo}> definida com sucesso para **R$ ${val.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}** pelo Dono!`);
    }

    if (message.content === '!mm' || message.content === '!painel') {
        const container = new ContainerBuilder()
            .setAccentColor(0xDE4548)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# 📊 — Painel do Middleman\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `Estatísticas pessoais das suas intermediações: taxas, valores e clientes atendidos.\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `👤 **Perfil MM** — visão geral (intermediações, nota, taxas).\n` +
                    `💰 **Mês** — total faturado no mês atual.\n` +
                    `📅 **Dia** — faturado hoje, antes do fechamento (23h10).\n` +
                    `👥 **Pessoas** — quem você já atendeu.\n` +
                    `⚙️ **Ajustar Intermediações / Movimentos** — alterar intermediações e movimentação do mês (exclusivo do Dono).\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `-# Respostas privadas • Exclusivo staff (Ajustes restritos ao Dono)\n` +
                    `-# NEUX MEDIAÇÃO`
                )
            )
            .addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('mm_perfil').setLabel('Perfil MM').setEmoji('👤').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('mm_mes').setLabel('Faturamento do Mês').setEmoji('💰').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('mm_dia').setLabel('Faturamento do Dia').setEmoji('📅').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('mm_pessoas').setLabel('Pessoas Atendidas').setEmoji('👥').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('mm_config_intermed').setLabel('Ajustar Intermediações / Movimentos').setEmoji('⚙️').setStyle(ButtonStyle.Primary)
                )
            );

        await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(console.error);
    }
    } finally {
        mensagensEmAndamento.delete(message.id);
    }
});

client.login(TOKEN);
