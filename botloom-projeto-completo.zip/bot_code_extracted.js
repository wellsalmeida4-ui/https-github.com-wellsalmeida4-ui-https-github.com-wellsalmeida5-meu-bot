const fs = require("fs");
const path = require("path");
const {
    Client,
    GatewayIntentBits,
    EmbedBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    UserSelectMenuBuilder,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ChannelType,
    PermissionFlagsBits,
    ButtonBuilder,
    ButtonStyle,
    Events,
    MessageFlags,
    SlashCommandBuilder,
    REST,
    Routes,
    AttachmentBuilder,
    ContainerBuilder,
    TextDisplayBuilder,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder
} = require("discord.js");

// Geradores de imagem (cartão de perfil e vouch) — ver /mm-cards/perfilCard.js e /mm-cards/vouchCard.js
const { gerarCartaoPerfil } = require("./perfilCard");
const { gerarCartaoVouch } = require("./vouchCard");

// ==========================================================================================
//                                      CONFIGURAÇÕES
// ==========================================================================================
// ⚠️ IMPORTANTE: NÃO deixe o token direto no código. Use variável de ambiente.
// Ex: const TOKEN = process.env.DISCORD_TOKEN;
// E rode o bot com o token setado no ambiente (arquivo .env + dotenv, ou no painel de hospedagem).
// ⚠️ O token que estava aqui antes ficou exposto em texto puro. Revogue-o no Discord
// Developer Portal e gere um novo — nunca deixe o token literal no código.
const TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = "1438353823235051642";
const GUILD_ID = "1417672403382960130";

const CATEGORIA_TICKETS = '1451246353735880857';
const CANAL_LOGS_ID = '1491989024276091004';
const CANAL_PROOFS = "1451245692042477752";
const CANAL_BIG_TRADE = "1455755067046236251";
const CANAL_TAXAS = "1470177275881455627";
const CANAL_AVALIACOES = "1417967103360630916";

const CARGO_STAFF_ID = "1422050552371740702";
const ID_AFILIADO = "1493722160269623367";
const CARGO_AFILIADO_ID = "1493722160269623367"; // Definido para evitar erros de referência

// Cores redefinidas seguindo a paleta do print de referência (Cliente -> Master),
// mapeadas por ordem de "limite" (valor exigido) para os IDs de cargo já existentes.
// O cargo de 500 (antes roxo) agora é PRATA, igual ao "Premium" do print.
const RANK_COLORS = {
    "1472761782555771060": "#5865F2", // 200K  (limite 200000) - equivalente a "Master" - Azul Índigo
    "1470874824627716217": "#FFA500", // 100K  (limite 100000) - equivalente a "Nebula" - Laranja Dourado
    "1455064011413393515": "#00CED1", // Cliente Divino (limite 50000) - equivalente a "Imperador" - Ciano
    "1455064010033594549": "#9B30FF", // Cliente Lendário (limite 25000) - equivalente a "Galático" - Roxo
    "1455064008699805799": "#FF3B3B", // Cliente Sagrado (limite 10000) - equivalente a "Eterno" - Vermelho
    "1452028593268981964": "#10B981", // Cliente Celestial (limite 5000) - equivalente a "Esmeralda" - Verde
    "1455064005604540447": "#2196F3", // Cliente Imperial (limite 1000) - equivalente a "Platina" - AZUL
    "1455064003922366524": "#C0C0C0", // Cliente Nobre (limite 500) - equivalente a "Premium" - PRATA (era roxo, corrigido)
    "1417913178779549767": "#C0C0C0"  // Cliente Iniciante (limite 0) - equivalente a "Cliente" - PRATA (consistente com a paleta do vouch)
};

const RANK_CARGOS = [
  { nome: "200K", limite: 200000, id: "1472761782555771060", iconType: "crown" },
  { nome: "100K", limite: 100000, id: "1470874824627716217", iconType: "crown" },
  { nome: "Cliente Divino", limite: 50000, id: "1455064011413393515", iconType: "diamond" },
  { nome: "Cliente Lendário", limite: 25000, id: "1455064010033594549", iconType: "star" },
  { nome: "Cliente Sagrado", limite: 10000, id: "1455064008699805799", iconType: "star" },
  { nome: "Cliente Celestial", limite: 5000, id: "1452028593268981964", iconType: "diamond" },
  { nome: "Cliente Imperial", limite: 1000, id: "1455064005604540447", iconType: "shield" },
  { nome: "Cliente Nobre", limite: 500, id: "1455064003922366524", iconType: "shield" },
  { nome: "Cliente Iniciante", limite: 0, id: "1417913178779549767", iconType: "star" },
];

const CARGO_TOP_1 = "1475045304444256296";
const CARGO_TOP_2 = "1497401431739732019";
const CARGO_TOP_3 = "1442589543487373444";

const EMOJI_CHECK = '<:2974:1438244299564126279>';
const EMOJI_PIX_TITULO = "✅";
const THUMBNAIL_SPEED = "https://i.postimg.cc/ZKp8yjpK/nex1-2.gif"; // Link direto fornecido pelo usuário

// ==========================================================================================
//                                 SISTEMA DE ARQUIVOS
// ==========================================================================================
const dbPixPath = path.join(__dirname, 'pix_database.json');
const dbUsersPath = path.join(__dirname, 'users_mm.json');
const dbGlobalPath = path.join(__dirname, 'proofs_global.json');
const dbTaxasPath = path.join(__dirname, 'taxas_diarias.json');

let globalCounter = 2000;
if (fs.existsSync(dbGlobalPath)) {
    try {
        const savedGlobal = JSON.parse(fs.readFileSync(dbGlobalPath));
        if (typeof savedGlobal === 'number') globalCounter = savedGlobal;
    } catch (e) { console.error("Erro ao carregar globalCounter:", e); }
}

let userData = {};
if (fs.existsSync(dbUsersPath)) {
    try {
        userData = JSON.parse(fs.readFileSync(dbUsersPath)); normalizeUserData();
    } catch (e) { console.error("Erro ao carregar userData:", e); }
}

let taxasDiarias = {};
if (fs.existsSync(dbTaxasPath)) {
    try {
        taxasDiarias = JSON.parse(fs.readFileSync(dbTaxasPath));
    } catch (e) { console.error("Erro ao carregar taxasDiarias:", e); }
}

let pixConfig = new Map();
if (fs.existsSync(dbPixPath)) {
    try {
        pixConfig = new Map(Object.entries(JSON.parse(fs.readFileSync(dbPixPath))));
    } catch (e) { console.error("Erro ao carregar banco de dados PIX:", e); }
}

function saveGlobal() { fs.writeFileSync(dbGlobalPath, JSON.stringify(globalCounter)); }
function saveUsers() { normalizeUserData();  fs.writeFileSync(dbUsersPath, JSON.stringify(userData, null, 2)); }
function saveTaxas() { fs.writeFileSync(dbTaxasPath, JSON.stringify(taxasDiarias, null, 2)); }
function salvarDadosPix() {
    const obj = Object.fromEntries(pixConfig);
    fs.writeFileSync(dbPixPath, JSON.stringify(obj, null, 2));
}

function sanitizarValor(valorStr) {
    if (typeof valorStr !== 'string') return 0;
    let limpo = valorStr.trim();

    if (limpo.includes('.') && limpo.includes(',')) {
        limpo = limpo.replace(/\./g, '').replace(',', '.');
    }
    else if (limpo.includes(',') && limpo.indexOf(',') < limpo.indexOf('.')) {
        limpo = limpo.replace(/,/g, '');
    }
    else if (limpo.includes('.') && !limpo.includes(',')) {
        const partes = limpo.split('.');
        const ultimaParte = partes[partes.length - 1];
        if (ultimaParte.length === 3) {
            limpo = limpo.replace(/\./g, '');
        }
    }
    else if (limpo.includes(',') && !limpo.includes('.')) {
        limpo = limpo.replace(',', '.');
    }

    const num = parseFloat(limpo);
    return isNaN(num) ? 0 : num;
}

const tradeData = new Map();
const pixStorage = new Map();
// Guarda dados temporários de avaliação (resumo, transcript, avaliações já feitas)
// entre o fechamento do ticket e o envio do modal de comentário no PV.
const avaliacoesPendentes = new Map();

function gerarIdAvaliacao() {
    return `AVL${Date.now()}${Math.floor(Math.random() * 900 + 100)}`;
}

// ==========================================================================================
//                                     FUNÇÕES AUXILIARES
// ==========================================================================================

function normalizeUserData() {
  if (userData && typeof userData === "object") {
    if (userData.users && typeof userData.users === "object" && !Array.isArray(userData.users)) {
      for (const [id, uObj] of Object.entries(userData.users)) {
        if (id && id !== "users" && uObj && typeof uObj === "object") {
          userData[id] = { ...userData[id], ...uObj };
        }
      }
      delete userData.users;
    } else if ("users" in userData) {
      delete userData.users;
    }
    for (const [id, user] of Object.entries(userData)) {
      if (!user || typeof user !== "object") {
        delete userData[id];
        continue;
      }
      user.totalTrocas = Number(user.totalTrocas) || 0;
      user.totalValor = Number(user.totalValor) || 0;
      user.maiorTroca = Number(user.maiorTroca) || 0;
      user.totalMes = Number(user.totalMes) || 0;
      user.contador = Number(user.contador) || 0;
      user.pessoasIntermediadas = Number(user.pessoasIntermediadas) || 0;
      user.clienteDesde = Number(user.clienteDesde) || new Date().getFullYear();
    }
  }
}

function registerTrade(userId, valor, contraparteId = null) {
  if (!userData[userId]) userData[userId] = { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
  if (!userData[userId].clienteDesde) userData[userId].clienteDesde = new Date().getFullYear();
  userData[userId].totalTrocas++;
  userData[userId].totalValor += valor;
  userData[userId].totalMes += valor;
  if (valor > userData[userId].maiorTroca) userData[userId].maiorTroca = valor;

  if (contraparteId) {
    if (!userData[userId].listaPessoas) userData[userId].listaPessoas = [];
    if (!userData[userId].listaPessoas.includes(contraparteId)) {
      userData[userId].listaPessoas.push(contraparteId);
      userData[userId].pessoasIntermediadas = userData[userId].listaPessoas.length;
    }
  }

  saveUsers();
}

// Registra a intermediação para o STAFF que mediou o MM: conta 1 troca (não 2),
// soma o valor uma única vez, e ainda assim registra as duas pessoas envolvidas
// na lista de "pessoas intermediadas".
function registerStaffTrade(userId, valor, contraparteIds = []) {
  if (!userData[userId]) userData[userId] = { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
  if (!userData[userId].clienteDesde) userData[userId].clienteDesde = new Date().getFullYear();
  userData[userId].totalTrocas++;
  // O valor da negociação NÃO conta pro staff/MM (nem ranking, nem perfil) — só conta
  // pro enviador e recebedor de fato (via registerTrade). Aqui só contamos a
  // intermediação em si e quem foram as partes.

  if (!userData[userId].listaPessoas) userData[userId].listaPessoas = [];
  for (const cid of contraparteIds) {
    if (cid && !userData[userId].listaPessoas.includes(cid)) {
      userData[userId].listaPessoas.push(cid);
    }
  }
  userData[userId].pessoasIntermediadas = userData[userId].listaPessoas.length;

  saveUsers();
}

async function atualizarCargos(guild, userId) {
  try {
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) return;
    const data = userData[userId];

    // Os cargos de rank (Cliente Nobre, Imperial, etc) NUNCA são removidos automaticamente
    // pelo bot — mesmo que o totalValor calculado fique abaixo do limite daquele cargo
    // (ex: cargo atribuído manualmente por um admin, ou só uma redução pontual de valor).
    // O cliente só sobe de cargo conforme vai atingindo os limites; a remoção, se um dia
    // for necessária, deve ser manual.
    for (const rank of RANK_CARGOS) {
        if (data && data.totalValor >= rank.limite) {
            try {
                if (!member.roles.cache.has(rank.id)) {
                    await member.roles.add(rank.id);
                }
            } catch (e) {
                console.error(`Erro ao adicionar cargo ${rank.nome} para ${userId}:`, e.message);
            }
        }
    }

    const allUsersMonthly = Object.entries(userData).filter(([id, d]) => id !== "users" && d && typeof d === "object").sort(([, a], [, b]) => (Number(b?.totalMes) || 0) - (Number(a?.totalMes) || 0));
    const rolesTop = [CARGO_TOP_1, CARGO_TOP_2, CARGO_TOP_3];

    for (let i = 0; i < 3; i++) {
      if (allUsersMonthly[i]) {
        const topUserId = allUsersMonthly[i][0];
        const topMember = await guild.members.fetch(topUserId).catch(() => null);
        const roleId = rolesTop[i];

        if (topMember) {
          const role = guild.roles.cache.get(roleId);
          if (role) {
            await Promise.all(role.members.map(m => {
                if(m.id !== topUserId) return m.roles.remove(roleId).catch(() => {});
            }));
            if (!topMember.roles.cache.has(roleId)) await topMember.roles.add(roleId).catch(() => {});
          }
        }
      }
    }
  } catch (err) { console.error("Erro ao atualizar cargos:", err); }
}

function calcularTaxa(tipo, valor, enviadorId, recebedorId) {
  let taxaBase = 0;
  if (tipo === "crosstrade") taxaBase = 1.0;
  else if (valor >= 700) taxaBase = valor * 0.01;
  else if (valor >= 400) taxaBase = 6.50;
  else if (valor >= 200) taxaBase = 4.00;
  else if (valor >= 100) taxaBase = 2.00;
  else if (valor >= 8) taxaBase = 0.50;
  if (enviadorId === ID_AFILIADO || recebedorId === ID_AFILIADO) taxaBase /= 2;
  return taxaBase;
}

function crc16(payload) {
    let polinomio = 0x1021;
    let resultado = 0xFFFF;
    for (let i = 0; i < payload.length; i++) {
        resultado ^= payload.charCodeAt(i) << 8;
        for (let j = 0; j < 8; j++) {
            if (resultado & 0x8000) resultado = (resultado << 1) ^ polinomio;
            else resultado <<= 1;
            resultado &= 0xFFFF;
        }
    }
    return resultado.toString(16).toUpperCase().padStart(4, "0");
}

function gerarPix(chave, nome, valor) {
    const nomeF = nome.trim().substring(0, 25).toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    const valorF = parseFloat(valor).toFixed(2);
    const merchantAccount = "0014br.gov.bcb.pix01" + chave.length.toString().padStart(2, "0") + chave;
    let payload = "00020101021126" + merchantAccount.length.toString().padStart(2, "0") + merchantAccount +
        "52040000530398654" + valorF.length.toString().padStart(2, "0") + valorF +
        "5802BR59" + nomeF.length.toString().padStart(2, "0") + nomeF +
        "6009SAO PAULO62070503***6304";
    return payload + crc16(payload);
}

async function getRankingEmbed(guild, tipo, pagina) {
  normalizeUserData();
  const isGeral = tipo === "geral";
  const validEntries = Object.entries(userData).filter(([id, data]) => id !== "users" && data && typeof data === "object");
  const sortedUsers = validEntries.sort(([, a], [, b]) => {
    const valA = isGeral ? (Number(a?.totalValor) || 0) : (Number(a?.totalMes) || 0);
    const valB = isGeral ? (Number(b?.totalValor) || 0) : (Number(b?.totalMes) || 0);
    return valB - valA;
  });

  const itensPorPagina = 10;
  const totalPaginas = Math.ceil(sortedUsers.length / itensPorPagina) || 1;
  if (pagina < 1) pagina = 1;
  if (pagina > totalPaginas) pagina = totalPaginas;

  const indexInicio = (pagina - 1) * itensPorPagina;
  const slice = sortedUsers.slice(indexInicio, indexInicio + itensPorPagina);

  const embedTitulo = new EmbedBuilder()
    .setColor("#FF0000")
    .setTitle(`🏆 Ranking de Movimentação - ${isGeral ? "Geral" : "Mensal"}`)
    .setThumbnail(THUMBNAIL_SPEED);

  const rowMenu = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId("rank_select")
      .setPlaceholder("Alterar tipo de ranking...")
      .addOptions(
        { label: "Ranking Geral", value: "geral", default: isGeral },
        { label: "Ranking Mensal", value: "mensal", default: !isGeral }
      )
  );

  let listaCorpo = "";
  for (let i = 0; i < slice.length; i++) {
    const [id, data] = slice[i];
    const posicao = indexInicio + i + 1;
    const rawVal = isGeral ? data?.totalValor : data?.totalMes;
    const valor = Number(rawVal) || 0;
    const valorFormatado = valor.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
    const totalTrocas = Number(data?.totalTrocas) || 0;
    listaCorpo += `${posicao}. <@${id}> total de R$ \`${valorFormatado}\` gastos e \`${totalTrocas}\` troca(s)\n`;
  }

  const embedLista = new EmbedBuilder()
    .setColor("#FF0000")
    .setDescription(listaCorpo || "Nenhum resultado encontrado.")
    .setFooter({ text: `Página ${pagina} de ${totalPaginas} • ${sortedUsers.length} trader(s)` });

  const rowBotoes = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`rankprev_${tipo}_${pagina}`).setLabel("Anterior").setEmoji("◀️").setStyle(ButtonStyle.Secondary).setDisabled(pagina <= 1),
    new ButtonBuilder().setCustomId(`ranknext_${tipo}_${pagina}`).setLabel("Próximo").setEmoji("▶️").setStyle(ButtonStyle.Secondary).setDisabled(pagina >= totalPaginas)
  );

  return { embeds: [embedTitulo, embedLista], components: [rowMenu, rowBotoes] };
}

// ==========================================================================================
//                                     CLIENT E INICIALIZAÇÃO
// ==========================================================================================
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.DirectMessages
    ]
});

client.once(Events.ClientReady, () => {
    console.log(`✅ Santa MM\'s V2 Integrado Online!`);
    setInterval(checkScheduledTasks, 60 * 1000); // Executa a cada minuto
});

process.on('unhandledRejection', (reason) => console.log(' [ANTI-CRASH] Rejeição:', reason));
process.on('uncaughtException', (err) => console.log(' [ANTI-CRASH] Exceção:', err));

// ==========================================================================================
//                                     FLUXO DE TICKETS V2
// ==========================================================================================
function construirContainerFuncoes(data) {
    const mencoes = data.participantes.map(id => `<@${id}>`).join(' ') || '';

    return new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `${mencoes}\n\n` +
                `# <:parceria:1485054250429054986> ━ Seleção de Funções\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `> Agora vocês vão confirmar a função de vocês, ou seja, quem vai enviar o pix para o MM, e quem depois da troca, irá receber o PIX do MM.\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                `• 🌟 **Vou enviar o pix** — Você vai enviar o PIX para o middleman.\n` +
                `• 📞 **Vou receber** — Você vai receber o PIX do middleman.\n` +
                `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n\n` +
                `**Enviador:** ${data.enviador ? `<@${data.enviador}>` : 'Aguardando...'}\n` +
                `**Recebedor:** ${data.recebedor ? `<@${data.recebedor}>` : 'Aguardando...'}`
            )
        )
        .addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('set_enviador').setLabel('Vou enviar o Pix').setEmoji('🌟').setStyle(ButtonStyle.Secondary).setDisabled(!!data.enviador),
                new ButtonBuilder().setCustomId('set_recebedor').setLabel('Vou Receber').setEmoji('📞').setStyle(ButtonStyle.Secondary).setDisabled(!!data.recebedor),
                new ButtonBuilder().setCustomId('resetar_fluxo').setLabel('Resetar').setEmoji('➡️').setStyle(ButtonStyle.Secondary)
            )
        )
        .addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('btn_fechar').setLabel('Voltar ao início').setEmoji('➡️').setStyle(ButtonStyle.Secondary)
            )
        );
}

async function iniciarFluxoImagens(channel) {
    let data = tradeData.get(channel.id);
    if (!data) {
        data = { enviador: null, recebedor: null, valor: null, item: null, staffReivindicou: null, msgDmId: null, confirmacoes: [], confirmacoesEntrega: [], participantes: [], colValor: null, colItem: null };
        tradeData.set(channel.id, data);
    } else {
        // Se o fluxo estiver sendo reiniciado (ex: botão "Resetar") no meio da etapa
        // de valor/itens, os coletores de mensagem antigos ficavam "vivos" e um novo
        // era criado por cima ao refazer o fluxo — isso duplicava as mensagens de
        // "Itens da negociação" e "Confirmação Final". Agora sempre paramos qualquer
        // coletor pendente antes de resetar.
        data.colValor?.stop();
        data.colItem?.stop();
        data.colValor = null;
        data.colItem = null;
        data.enviador = null; data.recebedor = null; data.valor = null; data.item = null; data.staffReivindicou = null; data.confirmacoes = []; data.confirmacoesEntrega = [];
    }

    const container = construirContainerFuncoes(data);

    await channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(console.error);
}

function enviarLog(guild, embed) {
    const canalLog = guild.channels.cache.get(CANAL_LOGS_ID);
    if (canalLog) canalLog.send({ embeds: [embed] }).catch(() => {});
}

// ==========================================================================================
//                                     INTERAÇÕES
// ==========================================================================================

client.on(Events.InteractionCreate, async (interaction) => {
    // Garante que interaction.member seja um GuildMember completo (com roles.cache).
    // Em cache frio, sweepers de membro ou servidores grandes, o discord.js pode
    // entregar um member parcial/undefined — o que quebrava o "Reivindicar" com
    // "Cannot read properties of undefined (reading 'cache')".
    if (interaction.inGuild() && (!interaction.member || !interaction.member.roles?.cache)) {
        try {
            interaction.member = await interaction.guild.members.fetch(interaction.user.id);
        } catch (e) {
            console.error("Falha ao buscar o member da interação:", e);
        }
    }

    const data = tradeData.get(interaction.channelId);

    if (interaction.isChatInputCommand()) {
        if (interaction.commandName === "configpix") {
            if (!interaction.member?.permissions?.has(PermissionFlagsBits.Administrator)) {
                return interaction.reply({ content: "❌ Apenas administradores podem configurar o PIX de um Middleman.", flags: [MessageFlags.Ephemeral] });
            }
            const modal = new ModalBuilder().setCustomId("modal_config_pix").setTitle("Configurar PIX do Middleman");
            modal.addComponents(
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("pix_id").setLabel("ID do usuário (Middleman)").setPlaceholder("Ex: 123456789012345678").setStyle(TextInputStyle.Short).setRequired(true)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("pix_key").setLabel("Chave PIX").setStyle(TextInputStyle.Short).setRequired(true)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("pix_name").setLabel("Nome Completo (Sem acentos)").setStyle(TextInputStyle.Short).setRequired(true)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("pix_limite").setLabel("Valor máximo que pode mediar (R$)").setPlaceholder("Ex: 500  |  deixe 0 para sem limite").setStyle(TextInputStyle.Short).setRequired(false))
            );
            return interaction.showModal(modal);
        }
        if (interaction.commandName === "ranking") {
            const embedContent = await getRankingEmbed(interaction.guild, "geral", 1);
            return interaction.reply(embedContent);
        }

        if (interaction.commandName === "perfil") {
            await interaction.deferReply();

            const user = interaction.options.getUser("usuario") || interaction.user;
            const dataU = userData[user.id] || { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, clienteDesde: new Date().getFullYear() };

            const allUsersGeral = Object.entries(userData).filter(([id, d]) => id !== "users" && d && typeof d === "object").sort(([, a], [, b]) => (Number(b?.totalValor) || 0) - (Number(a?.totalValor) || 0));
            const rankGeral = allUsersGeral.findIndex(([id]) => id === user.id) + 1;

            const cargoAtual = RANK_CARGOS.find(r => dataU.totalValor >= r.limite) || RANK_CARGOS[RANK_CARGOS.length - 1];
            const indexAtual = RANK_CARGOS.indexOf(cargoAtual);
            const proximoCargo = RANK_CARGOS[indexAtual - 1];

            try {
                const buffer = await gerarCartaoPerfil({
                    username: user.username,
                    avatarURL: user.displayAvatarURL({ extension: "png", size: 256 }),
                    rankNome: cargoAtual.nome,
                    rankCorHex: RANK_COLORS[cargoAtual.id] || "#9B30FF",
                    rankIconType: cargoAtual.iconType,
                    rankPosicao: rankGeral || allUsersGeral.length + 1,
                    rankTotal: allUsersGeral.length,
                    totalMovimentado: dataU.totalValor || 0,
                    intermediacoes: dataU.totalTrocas || 0,
                    maiorTransacao: dataU.maiorTroca || 0,
                    noMes: dataU.totalMes || 0,
                    clienteDesde: dataU.clienteDesde || new Date().getFullYear(),
                    proximoRank: proximoCargo ? { nome: proximoCargo.nome, faltam: Math.max(0, proximoCargo.limite - dataU.totalValor) } : null,
                    progresso: proximoCargo ? (dataU.totalValor - cargoAtual.limite) / (proximoCargo.limite - cargoAtual.limite) : 1,
                    conquistas: [
                        { iconType: "handshake", label: "100 intermédios", desbloqueado: dataU.totalTrocas >= 100 },
                        { iconType: "money", label: "R$ 1k movim.", desbloqueado: dataU.totalValor >= 1000 },
                        { iconType: "money", label: "R$ 10k movim.", desbloqueado: dataU.totalValor >= 10000 },
                        { iconType: "diamond", label: "Trade R$ 500+", desbloqueado: dataU.maiorTroca >= 500 },
                        { iconType: "flame", label: "250 intermédios", desbloqueado: dataU.totalTrocas >= 250 },
                        { iconType: "flame", label: "500 intermédios", desbloqueado: dataU.totalTrocas >= 500 }
                    ]
                });

                const anexo = new AttachmentBuilder(buffer, { name: "perfil.png" });
                return interaction.editReply({ files: [anexo] });
            } catch (e) {
                console.error("Erro ao gerar cartão de perfil:", e);
                return interaction.editReply({ content: "❌ Erro ao gerar o cartão de perfil." });
            }
        }

        if (interaction.commandName === "vouch") {
            if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return interaction.reply({ content: "❌ Sem permissão.", flags: [MessageFlags.Ephemeral] });
            const tipo = interaction.options.getString("tipo");
            const comprador = interaction.options.getUser("comprador");
            const vendedor = interaction.options.getUser("vendedor");
            const valor = sanitizarValor(interaction.options.getString("valor"));
            if (valor <= 0) return interaction.reply({ content: "❌ Valor inválido.", flags: [MessageFlags.Ephemeral] });
            await interaction.deferReply();
            await executarAprovarPagamento(interaction.guild, interaction.user, tipo, comprador, vendedor, valor);
            return interaction.editReply({ content: `✅ Pagamento de R$ ${valor.toFixed(2)} aprovado!` });
        }

        if (interaction.commandName === "aprovar_pagamento") {
            if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return interaction.reply({ content: "❌ Sem permissão.", flags: [MessageFlags.Ephemeral] });
            const tipo = interaction.options.getString("tipo");
            const enviador = interaction.options.getUser("enviador");
            const recebedor = interaction.options.getUser("recebedor");
            const valor = sanitizarValor(interaction.options.getString("valor"));
            if (valor <= 0) return interaction.reply({ content: "❌ Valor inválido.", flags: [MessageFlags.Ephemeral] });
            await interaction.deferReply();
            await executarAprovarPagamento(interaction.guild, interaction.user, tipo, enviador, recebedor, valor);
            return interaction.editReply({ content: `✅ Pagamento de R$ ${valor.toFixed(2)} aprovado!` });
        }
        if (interaction.commandName === "remover_valor") {
            if (!interaction.member?.permissions?.has(PermissionFlagsBits.Administrator)) return interaction.reply({ content: "❌ Sem permissão.", flags: [MessageFlags.Ephemeral] });
            const user = interaction.options.getUser("usuario");
            const valor = sanitizarValor(interaction.options.getString("valor"));
            if (valor <= 0) return interaction.reply({ content: "❌ Valor inválido.", flags: [MessageFlags.Ephemeral] });
            if (userData[user.id]) {
                userData[user.id].totalValor -= valor;
                userData[user.id].totalMes -= valor;
                if (userData[user.id].totalValor < 0) userData[user.id].totalValor = 0;
                if (userData[user.id].totalMes < 0) userData[user.id].totalMes = 0;
                saveUsers();
                await atualizarCargos(interaction.guild, user.id);
                return interaction.reply({ content: `✅ Removido R$ ${valor.toFixed(2)} de <@${user.id}>.` });
            }
            return interaction.reply({ content: "❌ Usuário não encontrado no banco.", flags: [MessageFlags.Ephemeral] });
        }
    }

    // Handlers de interação (Ranking e Avaliação)
    if (interaction.isStringSelectMenu() && interaction.customId === "rank_select") {
        const tipo = interaction.values[0];
        const embedContent = await getRankingEmbed(interaction.guild, tipo, 1);
        return interaction.update(embedContent);
    }

    if (interaction.isButton() && interaction.customId.startsWith("rank")) {
        const parts = interaction.customId.split("_");
        const action = parts[0];
        const tipo = parts[1];
        let pagina = parseInt(parts[2]);
        if (action === "rankprev") pagina--; else pagina++;
        const embedContent = await getRankingEmbed(interaction.guild, tipo, pagina);
        return interaction.update(embedContent);
    }

    // ---- Botão "Abrir Transcript" enviado no PV (resumo do MM) ----
    if (interaction.isButton() && interaction.customId.startsWith("abrir_transcript_")) {
        const pendingId = interaction.customId.replace("abrir_transcript_", "");
        const pend = avaliacoesPendentes.get(pendingId);
        if (!pend || !pend.transcript) return interaction.reply({ content: "❌ Transcript não encontrado ou expirado.", flags: [MessageFlags.Ephemeral] });
        const anexoTranscript = new AttachmentBuilder(Buffer.from(pend.transcript), { name: `transcript-${pendingId}.txt` });
        return interaction.reply({ content: "📄 Aqui está o transcript da sua negociação:", files: [anexoTranscript], flags: [MessageFlags.Ephemeral] });
    }

    // ---- Botões de estrela (1 a 5) enviados no PV — abre modal de comentário ----
    if (interaction.isButton() && interaction.customId.startsWith("av_")) {
        const partesId = interaction.customId.split("_");
        const nota = partesId[1];
        const pendingId = partesId.slice(2).join("_");
        const pend = avaliacoesPendentes.get(pendingId);
        if (!pend) return interaction.reply({ content: "❌ Essa avaliação já expirou ou não foi encontrada.", flags: [MessageFlags.Ephemeral] });
        if (pend.avaliacoes && pend.avaliacoes[interaction.user.id]) return interaction.reply({ content: "✅ Você já avaliou esta mediação, obrigado!", flags: [MessageFlags.Ephemeral] });
        if (interaction.user.id !== pend.enviador && interaction.user.id !== pend.recebedor) return interaction.reply({ content: "❌ Você não faz parte dessa negociação.", flags: [MessageFlags.Ephemeral] });

        const modalAvaliacao = new ModalBuilder()
            .setCustomId(`modal_avaliacao_${nota}_${pendingId}`)
            .setTitle("Deixe seu comentário")
            .addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId("comentario_avaliacao")
                        .setLabel("Como foi sua experiência com o MM?")
                        .setStyle(TextInputStyle.Paragraph)
                        .setPlaceholder("Conte como foi a mediação, o atendimento, a agilidade...")
                        .setMaxLength(300)
                        .setRequired(true)
                )
            );
        return interaction.showModal(modalAvaliacao);
    }

    // Fluxo de Tickets
    if (data && interaction.isButton() && !interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) {
        if (!data.participantes.includes(interaction.user.id)) return interaction.reply({ content: "❌ Você não faz parte desta negociação!", flags: [MessageFlags.Ephemeral] });
    }

    if (interaction.isModalSubmit() && interaction.customId === "modal_config_pix") {
        const idDigitado = interaction.fields.getTextInputValue("pix_id").trim();
        // Validação pra evitar o bug antigo de ID digitado errado: confere se tem o
        // formato de um ID válido do Discord (snowflake) e se a pessoa realmente está
        // no servidor antes de salvar — assim, se o admin digitar errado, o bot avisa
        // na hora em vez do /reivindicar falhar silenciosamente depois.
        if (!/^\d{17,20}$/.test(idDigitado)) {
            return interaction.reply({ content: "❌ ID inválido. Clique com o botão direito no usuário no Discord → **Copiar ID de Usuário** e cole exatamente esse valor.", flags: [MessageFlags.Ephemeral] });
        }
        const membroAlvo = await interaction.guild.members.fetch(idDigitado).catch(() => null);
        if (!membroAlvo) {
            return interaction.reply({ content: "❌ Não encontrei ninguém com esse ID neste servidor. Confira se copiou o ID certo.", flags: [MessageFlags.Ephemeral] });
        }

        const limiteStr = interaction.fields.getTextInputValue("pix_limite");
        const limite = sanitizarValor(limiteStr); // 0 (ou vazio) = sem limite
        pixConfig.set(idDigitado, { chave: interaction.fields.getTextInputValue("pix_key"), nome: interaction.fields.getTextInputValue("pix_name"), limite });
        salvarDadosPix();
        // Recarregar imediatamente para garantir persistência no Map
        if (fs.existsSync(dbPixPath)) {
            try { pixConfig = new Map(Object.entries(JSON.parse(fs.readFileSync(dbPixPath)))); } catch (e) {}
        }
        const limiteTexto = limite > 0 ? `R$ ${limite.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}` : "Sem limite";
        return interaction.reply({ content: `${EMOJI_CHECK} PIX configurado com sucesso para <@${idDigitado}>!\n> Limite de mediação: **${limiteTexto}**`, flags: [MessageFlags.Ephemeral] });
    }

    // ---- Modal de comentário enviado (após clicar nas estrelas no PV) ----
    if (interaction.isModalSubmit() && interaction.customId.startsWith("modal_avaliacao_")) {
        const semPrefixo = interaction.customId.replace("modal_avaliacao_", "");
        const partesModal = semPrefixo.split("_");
        const notaModal = partesModal[0];
        const pendingIdModal = partesModal.slice(1).join("_");
        const pendModal = avaliacoesPendentes.get(pendingIdModal);
        if (!pendModal) return interaction.reply({ content: "❌ Essa avaliação expirou, sinto muito.", flags: [MessageFlags.Ephemeral] });

        const comentarioModal = interaction.fields.getTextInputValue("comentario_avaliacao");
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

        if (!pendModal.avaliacoes) pendModal.avaliacoes = {};
        pendModal.avaliacoes[interaction.user.id] = { nota: notaModal, comentario: comentarioModal };

        // Guarda a nota também no perfil do staff mediador, pra podermos calcular a
        // média (usada no cartão de vouch) sem depender só do canal de avaliações.
        if (pendModal.staffId) {
            if (!userData[pendModal.staffId]) userData[pendModal.staffId] = { totalTrocas: 0, totalValor: 0, maiorTroca: 0, totalMes: 0, contador: 0, pessoasIntermediadas: 0, listaPessoas: [], clienteDesde: new Date().getFullYear() };
            if (!userData[pendModal.staffId].avaliacoes) userData[pendModal.staffId].avaliacoes = [];
            userData[pendModal.staffId].avaliacoes.push(parseInt(notaModal) || 5);
            saveUsers();
        }

        try {
            const guildAvaliacao = client.guilds.cache.get(GUILD_ID);
            const compradorU = await client.users.fetch(pendModal.enviador).catch(() => null);
            const vendedorU = await client.users.fetch(pendModal.recebedor).catch(() => null);
            const mediadorU = pendModal.staffId ? await client.users.fetch(pendModal.staffId).catch(() => null) : null;

            const valorAvaliacaoFormatado = (pendModal.valor || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 });
            const estrelasTexto = "⭐".repeat(Math.max(1, Math.min(5, parseInt(notaModal) || 0)));

            const embedAvaliacao = new EmbedBuilder()
                .setColor(0xF2A20E)
                .setTitle('⭐ Nova avaliação de intermediação')
                .setThumbnail(mediadorU ? mediadorU.displayAvatarURL({ extension: "png", size: 128 }) : THUMBNAIL_SPEED)
                .addFields(
                    { name: 'Nota', value: `${estrelasTexto} ${notaModal}/5` },
                    { name: 'Usuário', value: `<@${interaction.user.id}>` },
                    { name: 'Middleman', value: mediadorU ? `<@${mediadorU.id}>` : "Não informado" },
                    { name: 'Avaliação', value: comentarioModal || "Sem comentário" }
                )
                .setFooter({ text: `Intermediação ${pendModal.transacaoId || pendingIdModal}` })
                .setTimestamp();

            const canalAvaliacoes = guildAvaliacao?.channels.cache.get(CANAL_AVALIACOES);
            if (canalAvaliacoes) await canalAvaliacoes.send({ embeds: [embedAvaliacao] }).catch(() => {});
        } catch (e) {
            console.error("Erro ao gerar/enviar cartão de avaliação:", e);
        }

        await interaction.editReply({ content: "✅ Obrigado pela sua avaliação!" }).catch(() => {});

        // Limpa da memória quando ambas as partes já avaliaram
        if (pendModal.avaliacoes[pendModal.enviador] && pendModal.avaliacoes[pendModal.recebedor]) {
            avaliacoesPendentes.delete(pendingIdModal);
        }
        return;
    }

    if (interaction.isStringSelectMenu() && interaction.customId === 'menu_mm') {
        const tipoMM = interaction.values[0];
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

        const ticketExistente = interaction.guild.channels.cache.find(c => c.name.includes(interaction.user.username) && c.parentId === CATEGORIA_TICKETS);
        if (ticketExistente) {
            const containerAviso = new ContainerBuilder().setAccentColor(0xf23f43).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ❌ Você já possui um ticket de MM aberto!\nSeu ticket em <#${ticketExistente.id}> ainda está aberto.`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setLabel('Ir para o Ticket').setURL(`https://discord.com/channels/${interaction.guild.id}/${ticketExistente.id}`).setStyle(ButtonStyle.Secondary)));
            return interaction.editReply({ components: [containerAviso], flags: MessageFlags.IsComponentsV2 });
        }

        const canalTicket = await interaction.guild.channels.create({
            name: `🛡・middleman-${tipoMM}-${interaction.user.username}`, type: ChannelType.GuildText, parent: CATEGORIA_TICKETS,
            permissionOverwrites: [{ id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] }, { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] }, { id: CARGO_STAFF_ID, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ManageMessages] }]
        });

        tradeData.set(canalTicket.id, { enviador: null, recebedor: null, valor: null, item: null, staffReivindicou: null, msgDmId: null, confirmacoes: [], confirmacoesEntrega: [], participantes: [interaction.user.id], criadorTicketId: interaction.user.id, colValor: null, colItem: null });

        const container1 = new ContainerBuilder().setAccentColor(0xFF0000).addTextDisplayComponents(new TextDisplayBuilder().setContent(`||<@${interaction.user.id}> <@&${CARGO_STAFF_ID}>||\n\n# <:parceria:1485054250429054986> ╺╸ Middleman de PIX criado.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\nSeja bem vindo ao novo ticket **AUTOMÁTICO** de MiddleMan, com segurança e agilidade. É importante que você selecione as opções ao longo do ticket corretamente e responda as perguntas que o bot fizer. Reveja sempre antes de prosseguir qualquer passo para evitar scams e erros.\n\n**Passos:**\n1. Adicione o usuário com quem vai negociar usando o menu ou botão abaixo.\n2. O bot pedirá para ambos descreverem os itens no chat.\n3. Após confirmação, o pix automático é gerado.`));
        const container2 = new ContainerBuilder().setAccentColor(0xFF0000).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Notificação de Segurança\nNossa equipe e nosso bot jamais entram em contato por mensagem direta.\n\nToda comunicação da negociação deve acontecer exclusivamente por este ticket.\n\nIgnorar isso pode te colocar em risco de golpe ou fraude. Não aceitamos pagamentos via Inter ou PicPay.\n\nSolicitações indevidas de reembolso podem gerar medidas cabíveis, inclusive ação judicial.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Quem abriu o ticket** pode encerrar aqui se desistir antes de concluir a configuração.`));
        const container3 = new ContainerBuilder().setAccentColor(0xFF0000).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Com Quem Você Está Negociando?\nSelecione o usuário Discord da outra parte.\nSó quem abriu o ticket pode escolher.\n\nUse o menu abaixo **ou** envie o ID /\n@menção do usuário diretamente no chat.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`))
            .addActionRowComponents(new ActionRowBuilder().addComponents(new UserSelectMenuBuilder().setCustomId('add_user_menu').setPlaceholder('Selecione o outro usuário...')))
            .addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('btn_termos').setLabel('Termos MM').setEmoji('🌙').setStyle(ButtonStyle.Secondary), new ButtonBuilder().setCustomId('btn_fechar').setLabel('Cancelar Ticket').setEmoji('✖️').setStyle(ButtonStyle.Secondary)));

        await canalTicket.send({ components: [container1], flags: MessageFlags.IsComponentsV2 });
        await canalTicket.send({ components: [container2], flags: MessageFlags.IsComponentsV2 });
        await canalTicket.send({ components: [container3], flags: MessageFlags.IsComponentsV2 });

        enviarLog(interaction.guild, new EmbedBuilder().setColor('Red').setTitle('Ticket Aberto').setDescription(`O usuário <@${interaction.user.id}> abriu um ticket de MM (${tipoMM}).\nCanal: ${canalTicket}`));
        await interaction.editReply({ content: `${EMOJI_CHECK} **|** Seu middleman foi criado com sucesso ${canalTicket}` });
    }

    if (interaction.isUserSelectMenu() && interaction.customId === 'add_user_menu') {
        const alvoId = interaction.values[0];
        if (alvoId === interaction.user.id) return interaction.reply({ content: "> ❌ Você não pode adicionar a si mesmo.", flags: [MessageFlags.Ephemeral] });
        const container = new ContainerBuilder().setAccentColor(0xFF0000).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Confirmar Contraparte\nVocê selecionou <@${alvoId}>. Confirme que é a pessoa certa ou escolha outra.\n\nSó quem abriu o ticket pode confirmar.\nEvita convidar o usuário errado.`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`confirm_target_${alvoId}`).setLabel('Confirmar pessoa').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId('escolher_outro').setLabel('Escolher outra pessoa').setStyle(ButtonStyle.Secondary)));
        await interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
    }

    if (interaction.isButton() && interaction.customId.startsWith('confirm_target_')) {
        const alvoId = interaction.customId.split('_')[2];
        if (data) { if (!data.participantes.includes(alvoId)) data.participantes.push(alvoId); }
        await interaction.channel.permissionOverwrites.edit(alvoId, { ViewChannel: true, SendMessages: true });
        const fetched = await interaction.channel.messages.fetch({ limit: 10 }); if (fetched) await interaction.channel.bulkDelete(fetched);
        await interaction.reply({ content: `> ${EMOJI_CHECK} ╺╸ Usuário <@${alvoId}> adicionado!`, flags: [MessageFlags.Ephemeral] });
        await iniciarFluxoImagens(interaction.channel);
    }

    if (interaction.isButton() && interaction.customId === 'escolher_outro') {
        const container = new ContainerBuilder().setAccentColor(0xFF0000).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Com Quem Você Está Negociando?\nSelecione o usuário Discord da outra parte.\nSó quem abriu o ticket pode escolher.\n\nUse o menu abaixo **ou** envie o ID /\n@menção do usuário diretamente no chat.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(new UserSelectMenuBuilder().setCustomId('add_user_menu').setPlaceholder('Selecione o outro usuário...')));
        await interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
    }

    if (interaction.isButton() && (interaction.customId === 'set_enviador' || interaction.customId === 'set_recebedor')) {
        if (!data) return;
        if ((interaction.customId === 'set_enviador' && data.recebedor === interaction.user.id) || (interaction.customId === 'set_recebedor' && data.enviador === interaction.user.id)) return interaction.reply({ content: "❌ Você não pode ocupar as duas vagas!", flags: [MessageFlags.Ephemeral] });
        if (interaction.customId === 'set_enviador' && data.enviador) return interaction.reply({ content: "❌ Essa vaga já foi ocupada!", flags: [MessageFlags.Ephemeral] });
        if (interaction.customId === 'set_recebedor' && data.recebedor) return interaction.reply({ content: "❌ Essa vaga já foi ocupada!", flags: [MessageFlags.Ephemeral] });
        if (interaction.customId === 'set_enviador') data.enviador = interaction.user.id; else data.recebedor = interaction.user.id;

        if (data.enviador && data.recebedor) {
            const containerV = new ContainerBuilder().setAccentColor(0xED4245).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Valor da negociação\n<@${data.enviador}> ou <@${data.recebedor}> — **qualquer um** pode digitar no chat o **valor total** da transação (ex.: \`80,50\` ou \`125.50\`).\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n> Depois, **ambos** devem confirmar na mensagem seguinte (**Confirmar valor**).`));
            await interaction.update({ components: [construirContainerFuncoes(data)], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
            await interaction.channel.send({ components: [containerV], flags: MessageFlags.IsComponentsV2 });

            // Para evitar coletores duplicados de uma tentativa anterior (ex: reset no
            // meio do fluxo), paramos qualquer coletor de valor ainda pendente e guardamos
            // a referência do novo em "data" para poder pará-lo depois se necessário.
            data.colValor?.stop();
            const colV = interaction.channel.createMessageCollector({ filter: m => data.participantes.includes(m.author.id) });
            data.colValor = colV;
            colV.on('collect', async m => {
                // Trava de segurança: se este coletor não for mais o "atual" registrado em
                // data (por exemplo, porque o fluxo foi resetado ou a troca já avançou),
                // ele não deve mais processar nada — evita coletores órfãos reescrevendo
                // uma negociação que já foi confirmada/reivindicada.
                if (data.colValor !== colV) return;
                const valorNumerico = sanitizarValor(m.content);
                if (valorNumerico <= 0) return interaction.channel.send({ content: `<@${m.author.id}> ❌ Valor inválido. Digite novamente o valor (ex: 1.000 ou 50,00).` });
                data.valor = valorNumerico.toString(); colV.stop(); data.colValor = null;
                const containerI = new ContainerBuilder().setAccentColor(0xFF0000).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Itens da negociação\n<@${data.enviador}> ou <@${data.recebedor}> — **qualquer um** pode digitar no chat o **item / produto** que você enviará.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n> Depois, **ambos** devem confirmar na mensagem seguinte (**Confirmar itens**).`));
                await interaction.channel.send({ components: [containerI], flags: MessageFlags.IsComponentsV2 });

                data.colItem?.stop();
                const colI = interaction.channel.createMessageCollector({ filter: m => data.participantes.includes(m.author.id), max: 1 });
                data.colItem = colI;
                colI.on('collect', async m2 => {
                    if (data.colItem !== colI) return;
                    data.item = m2.content; data.colItem = null;
                    const containerF = new ContainerBuilder().setAccentColor(0xFF0000).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:parceria:1485054250429054986> — Confirmação Final\n<@${data.enviador}> <@${data.recebedor}>\nAmbas as partes devem confirmar se os dados abaixo estão corretos.\nApós a confirmação de ambos, o pagamento será gerado.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n<:emoji_165:1499214852990832671> **Enviador:** <@${data.enviador}>\n<:emoji_170:1505047772049702932> **Recebedor:** <@${data.recebedor}>\n<:emoji_165:1499214852990832671>  **Valor PIX:** R$ ${data.valor}\n<:emoji_171:1505047910667259924> **Itens/Serviço:** ${data.item}\n\u200B\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Status:**\n ⏳ <@${data.enviador}> Aguardando...\n⏳ <@${data.recebedor}> Aguardando...`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('confirm_trade').setLabel('Confirmar tudo').setStyle(ButtonStyle.Secondary), new ButtonBuilder().setCustomId('resetar_fluxo').setLabel('Tentar novamente').setStyle(ButtonStyle.Secondary)));
                    await interaction.channel.send({ components: [containerF], flags: MessageFlags.IsComponentsV2 });
                });
            });
        } else {
            await interaction.update({ components: [construirContainerFuncoes(data)], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        }
    }

    if (interaction.isButton() && interaction.customId === 'confirm_trade') {
        if (!data) return; if (data.confirmacoes.includes(interaction.user.id)) return interaction.reply({ content: "Você já confirmou!", flags: [MessageFlags.Ephemeral] });
        data.confirmacoes.push(interaction.user.id);
        const statusE = data.confirmacoes.includes(data.enviador) ? `✅ <@${data.enviador}> Confirmou` : `⏳ <@${data.enviador}> Aguardando...`;
        const statusR = data.confirmacoes.includes(data.recebedor) ? `✅ <@${data.recebedor}> Confirmou` : `⏳ <@${data.recebedor}> Aguardando...`;
        const container = new ContainerBuilder().setAccentColor(0xFF0000).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:parceria:1485054250429054986> — Confirmação Final\n<@${data.enviador}> <@${data.recebedor}>\nAmbas as partes devem confirmar se os dados abaixo estão corretos.\nApós a confirmação de ambos, o pagamento será gerado.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n<:emoji_165:1499214852990832671> **Enviador:** <@${data.enviador}>\n<:emoji_170:1505047772049702932> **Recebedor:** <@${data.recebedor}>\n<:emoji_165:1499214852990832671>  **Valor PIX:** R$ ${data.valor}\n<:emoji_171:1505047910667259924> **Itens/Serviço:** ${data.item}\n\u200B\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Status:**\n${statusE}\n${statusR}`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('confirm_trade').setLabel('Confirmar tudo').setStyle(ButtonStyle.Secondary), new ButtonBuilder().setCustomId('resetar_fluxo').setLabel('Tentar novamente').setStyle(ButtonStyle.Secondary)));
        await interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        if (data.confirmacoes.length === 2) {
            const fetched = await interaction.channel.messages.fetch({ limit: 100 });
            if (fetched) await interaction.channel.bulkDelete(fetched.filter(m => !m.pinned));
            await interaction.channel.send({ content: `${EMOJI_CHECK} — **Ambas as partes confirmaram a negociação!**` });
            setTimeout(async () => {
                const containerRes = new ContainerBuilder().setAccentColor(0x5865F2).addTextDisplayComponents(new TextDisplayBuilder().setContent(`Midldleman imediato aqui!! <@&${CARGO_STAFF_ID}>\n\n# <:parce:1442163891462344798> | Resumo do Middleman\nConsulte este resumo do negócio para quaisquer reafirmações.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Enviador:** <@${data.enviador}>\n**Recebedor:** <@${data.recebedor}>\n**Valor:** R$ ${data.valor}\n**Itens:** ${data.item}\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('btn_reivindicar').setLabel('Reivindicar').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId('btn_fechar').setLabel('Cancelar').setStyle(ButtonStyle.Danger)));
                await interaction.channel.send({ components: [containerRes], flags: MessageFlags.IsComponentsV2 });
            }, 1500);
        }
    }

    if (interaction.isButton() && interaction.customId === 'btn_reivindicar') {
        if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return interaction.reply({ content: "❌ Apenas a staff pode reivindicar!", flags: [MessageFlags.Ephemeral] });
        // Trade em memória perdida (ex: bot reiniciou com o ticket já aberto) — sem essa
        // checagem, o código quebrava mais abaixo ao ler propriedades de "data".
        if (!data) return interaction.reply({ content: "❌ Os dados desse ticket foram perdidos (provavelmente o bot reiniciou). Peça pro cliente clicar em 'Resetar' ou reabrir o fluxo.", flags: [MessageFlags.Ephemeral] });
        if (data.staffReivindicou) return interaction.reply({ content: "❌️ | Esse mm já foi Assumido", flags: [MessageFlags.Ephemeral] });

        const config = pixConfig.get(interaction.user.id);
        if (!config) return interaction.reply({ content: " ❌ Você não configurou seu PIX! Use `/configpix` primeiro.", flags: [MessageFlags.Ephemeral] });

        const vCheck = parseFloat(data.valor) || 0;
        if (config.limite && config.limite > 0 && vCheck > config.limite) {
            const limiteFormatado = config.limite.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
            return interaction.reply({ content: `❌ Essa negociação é de **R$ ${vCheck.toFixed(2)}**, mas seu limite atual de mediação é **R$ ${limiteFormatado}**.\nPeça pra um staff com limite maior assumir, ou fale com um admin pra aumentar seu limite.`, flags: [MessageFlags.Ephemeral] });
        }

        data.staffReivindicou = interaction.user.id;
        const v = parseFloat(data.valor) || 0;
        let taxa = v >= 8 ? (v >= 700 ? v * 0.01 : (v >= 400 ? 6.50 : (v >= 200 ? 4.00 : (v >= 100 ? 2.00 : 0.50)))) : 0;

        const mE = await interaction.guild.members.fetch(data.enviador).catch(() => null);
        const mR = await interaction.guild.members.fetch(data.recebedor).catch(() => null);
        if (mE?.roles.cache.has(CARGO_AFILIADO_ID) || mR?.roles.cache.has(CARGO_AFILIADO_ID)) taxa /= 2;

        const total = (v + taxa).toFixed(2);
        const pixId = Date.now().toString();

        const pixPayload = gerarPix(config.chave, config.nome, total);
        pixStorage.set(pixId, pixPayload);

        const containerOriginal = new ContainerBuilder().setAccentColor(0x5865F2).addTextDisplayComponents(new TextDisplayBuilder().setContent(`Midldleman imediato aqui!! <@&${CARGO_STAFF_ID}>\n\n# <:parce:1442163891462344798> | Resumo do Middleman\nConsulte este resumo do negócio para quaisquer reafirmações.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Enviador:** <@${data.enviador}>\n**Recebedor:** <@${data.recebedor}>\n**Valor:** R$ ${data.valor}\n**Itens:** ${data.item}\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('btn_reivindicar_disabled').setLabel(`Assumido por ${interaction.user.username}`).setStyle(ButtonStyle.Secondary).setDisabled(true), new ButtonBuilder().setCustomId('btn_fechar').setLabel('Cancelar').setStyle(ButtonStyle.Danger)));
        await interaction.update({ components: [containerOriginal], flags: MessageFlags.IsComponentsV2 });
        await interaction.channel.send({ content: `> ${EMOJI_CHECK} ╺╸ Opa! O Middleman <@${interaction.user.id}> assumiu a mediação deste ticket.` });

        setTimeout(async () => {
            const containerPix = new ContainerBuilder().setAccentColor(0xFF0000).addTextDisplayComponents(new TextDisplayBuilder().setContent(`<@${data.enviador}>\n\n## <:parceria:1485054250429054986> ╺╸ MM Automático - Pagamento PIX\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n> ${config.nome} Deve pagar o valor de **R$ ${total}**.\n> A troca é automática sem intervenção humana, caso haja problemas há um botão de disputa.\n\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n* <:emoji_164:1498773852585463929> **Valor da Transação:** R$ ${v.toFixed(2)}\n* <:emoji_151:1487942140037304370> **Taxa da MM:** R$ ${taxa.toFixed(2)}\n* <:emoji_164:1498773734402556095> **Detalhes do Pedido:** ${data.item}\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n\n**Total a Pagar:** R$ ${total}`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`qr_${pixId}`).setLabel('QR Code').setStyle(ButtonStyle.Secondary), new ButtonBuilder().setCustomId(`copy_${pixId}`).setLabel('Copia e Cola').setStyle(ButtonStyle.Secondary), new ButtonBuilder().setCustomId('btn_recebi_valor').setLabel('Confirmei Recebimento (Staff)').setStyle(ButtonStyle.Success)));
            await interaction.channel.send({ components: [containerPix], flags: MessageFlags.IsComponentsV2 });
        }, 2000);
    }

    if (interaction.isButton() && interaction.customId === 'btn_recebi_valor') {
        if (!interaction.member?.roles?.cache?.has(CARGO_STAFF_ID)) return;
        if (!data) return interaction.reply({ content: "❌ Dados desse ticket foram perdidos.", flags: [MessageFlags.Ephemeral] });
        if (data.staffReivindicou !== interaction.user.id) return interaction.reply({ content: "Apenas o staff que reivindicou pode confirmar!", flags: [MessageFlags.Ephemeral] });
        data.pagamentoConfirmado = true;
        await interaction.reply({ content: "✅ Recebimento confirmado pelo staff.", flags: [MessageFlags.Ephemeral] });
        const containerT = new ContainerBuilder().setAccentColor(0xFF0000).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ⚠️ PIX RECEBIDO - INICIAR TROCA\nO Middleman já está com o dinheiro em mãos.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n**Instruções:**\n• O vendedor deve entregar o item agora.\n• Após a entrega, ambos cliquem no botão abaixo.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('confirmar_entrega_user').setLabel('Confirmar Entrega').setEmoji('✅').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId('btn_fechar').setLabel('Fechar Ticket').setStyle(ButtonStyle.Danger)));
        await interaction.channel.send({ components: [containerT], flags: MessageFlags.IsComponentsV2 });
    }

    if (interaction.isButton() && interaction.customId === 'confirmar_entrega_user') {
        if (!data) return; if (interaction.user.id !== data.enviador && interaction.user.id !== data.recebedor) return interaction.reply({ content: "Você não é participante da trade!", flags: [MessageFlags.Ephemeral] });
        if (data.confirmacoesEntrega.includes(interaction.user.id)) return interaction.reply({ content: "Você já confirmou!", flags: [MessageFlags.Ephemeral] });
        data.confirmacoesEntrega.push(interaction.user.id);
        if (data.confirmacoesEntrega.length === 2) {
            const containerM = new ContainerBuilder().setAccentColor(0xFF0000).addTextDisplayComponents(new TextDisplayBuilder().setContent(`<@${data.recebedor}>\n\n# Selecione o tipo de chave PIX\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\nEscolha abaixo o tipo de chave que você deseja utilizar para receber o pagamento do staff.\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`)).addActionRowComponents(new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('selecionar_tipo_pix').setPlaceholder('Clique aqui para selecionar o tipo...').addOptions([{ label: 'Celular', value: 'celular', emoji: '📱' }, { label: 'CPF/CNPJ', value: 'cpf_cnpj', emoji: '👤' }, { label: 'E-mail', value: 'email', emoji: '📧' }, { label: 'Chave Aleatória', value: 'aleatoria', emoji: '🆔' }, { label: 'USDT Wallet', value: 'usdt', emoji: '🪙' }])));
            await interaction.channel.send({ components: [containerM], flags: MessageFlags.IsComponentsV2 });
        } else { await interaction.reply({ content: `${EMOJI_CHECK} — <@${interaction.user.id}> confirmou a entrega. Aguardando a outra parte.` }); }
    }

    if (interaction.isStringSelectMenu() && interaction.customId === 'selecionar_tipo_pix') {
        if (!data || interaction.user.id !== data.recebedor) return interaction.reply({ content: "❌ | Apenas o recebedor pode fornecer a chave pix.", flags: [MessageFlags.Ephemeral] });
        const tipo = interaction.values[0];
        const modal = new ModalBuilder().setCustomId(`modal_chave_final_${tipo}`).setTitle(`Chave PIX: ${tipo.toUpperCase()}`).addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('chave_input').setLabel(`Digite sua chave ${tipo}`).setStyle(TextInputStyle.Short).setRequired(true)));
        await interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith('modal_chave_final_')) {
        if (!data) return interaction.reply({ content: "❌ Dados desse ticket foram perdidos.", flags: [MessageFlags.Ephemeral] });
        const chave = interaction.fields.getTextInputValue('chave_input'); const staff = await client.users.fetch(data.staffReivindicou).catch(() => null);
        if (staff) { await staff.send(`⚠️ **PAGAMENTO PENDENTE**\n**Valor:** R$ ${data.valor}\n**Chave PIX:** \`${chave}\`\n**Ticket:** <#${interaction.channel.id}>`); await interaction.reply({ content: `${EMOJI_CHECK} Chave enviada com sucesso ao Staff!`, flags: [MessageFlags.Ephemeral] }); enviarLog(interaction.guild, new EmbedBuilder().setColor('Blue').setTitle('Chave Pix Fornecida').setDescription(`Vendedor: <@${interaction.user.id}>\nChave: ${chave}\nPara: ${staff.username}`)); }
    }

    if (interaction.isButton() && interaction.customId.startsWith('qr_')) {
        const id = interaction.customId.split('_')[1];
        const payload = pixStorage.get(id);
        if (!payload) return interaction.reply({ content: "❌ QR Code expirado ou não encontrado.", flags: [MessageFlags.Ephemeral] });
        await interaction.reply({ content: "⏳ Gerando QR Code...", flags: [MessageFlags.Ephemeral] });
        const _vQR = data ? (parseFloat(data.valor) || 0) : 0;
        let _taxaQR = _vQR >= 8 ? (_vQR >= 700 ? _vQR * 0.01 : (_vQR >= 400 ? 6.50 : (_vQR >= 200 ? 4.00 : (_vQR >= 100 ? 2.00 : 0.50)))) : 0;
        const _totalQR = (_vQR + _taxaQR).toFixed(2);
        const qrItem = new MediaGalleryItemBuilder();
        qrItem.setUrl(`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(payload)}`);
        const containerQR = new ContainerBuilder().setAccentColor(0xFF0000).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:emoji_164:1498778688886407218> Escaneie o QR Code\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n> 💰 **Valor exato a pagar: R$ ${_totalQR}**`)).addMediaGalleryComponents(new MediaGalleryBuilder().addMediaGalleryItems(qrItem));
        await interaction.editReply({ content: '', components: [containerQR], flags: [MessageFlags.Ephemeral, MessageFlags.IsComponentsV2] });
    }

    if (interaction.isButton() && interaction.customId.startsWith('copy_')) {
        const id = interaction.customId.split('_')[1];
        const payload = pixStorage.get(id);
        if (payload) await interaction.reply({ content: payload, flags: [MessageFlags.Ephemeral] });
    }

    if (interaction.isButton() && interaction.customId === 'btn_termos') {
        const container = new ContainerBuilder().setAccentColor(0xFF0000).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:parceria:1485054250429054986> ╺╸ **Termos e Regras do MM Automático**\n\n**<:discotoolsxyzicon111:1470855659909284104> Segurança em Primeiro Lugar**\nPara garantir a segurança de ambas as partes, siga rigorosamente as instruções abaixo.\n\n**<:discotoolsxyzicon6:1470345157391155301> Para o Vendedor (Quem entrega o item):**\n> **GRAVE TUDO!** Recomendamos fortemente que você grave todo o processo de entrega do produto, desde o momento que inicia a troca até a confirmação de recebimento. Em caso de disputa, essa será sua principal prova.\n\n**<:discotoolsxyzicon28:1470856248122409171> Para o Comprador (Quem paga):**\n> **CONFIRA TUDO!** Verifique se o item recebido é exatamente o combinado antes de confirmar o recebimento no bot. Após confirmado, o dinheiro é liberado automaticamente e não há estorno.\n\n**<:discotoolsxyzicon13:1470342793716174880> Regras Gerais:**\n1. Não tente burlar o sistema de taxas.\n2. Mantenha toda a negociação dentro deste ticket.\n3. O bot não se responsabiliza por erros humanos (ex: enviar item para nick errado).\n4. Em caso de problemas, abra uma **Disputa** imediatamente.`));
        await interaction.reply({ components: [container], flags: [MessageFlags.Ephemeral, MessageFlags.IsComponentsV2] });
    }

    if (interaction.isButton() && interaction.customId === 'resetar_fluxo') {
        const fetched = await interaction.channel.messages.fetch({ limit: 100 }); if (fetched) await interaction.channel.bulkDelete(fetched.filter(m => !m.pinned));
        await iniciarFluxoImagens(interaction.channel);
    }

    if (interaction.isButton() && interaction.customId === 'btn_fechar') {
        // Responde a interação IMEDIATAMENTE (antes de qualquer trabalho pesado).
        // O Discord invalida a interação se não houver resposta em ~3s; como este
        // handler faz várias chamadas assíncronas (fetch de membros, transcript de
        // até 100 mensagens, envio de log com anexo, DM de avaliação), ele estourava
        // esse prazo no primeiro clique — por isso só "funcionava" no segundo clique.
        await interaction.deferReply().catch(() => {});

        const v = parseFloat(data?.valor || 0); let taxa = v >= 8 ? (v >= 700 ? v * 0.01 : (v >= 400 ? 6.50 : (v >= 200 ? 4.00 : (v >= 100 ? 2.00 : 0.50)))) : 0;
        try { const mE = data?.enviador ? await interaction.guild.members.fetch(data.enviador).catch(() => null) : null; const mR = data?.recebedor ? await interaction.guild.members.fetch(data.recebedor).catch(() => null) : null; if (mE?.roles.cache.has(CARGO_AFILIADO_ID) || mR?.roles.cache.has(CARGO_AFILIADO_ID)) taxa /= 2; } catch (err) {}

        // Se o pagamento já foi confirmado pelo Staff, registra a proof automaticamente ao fechar
        let transacaoIdFinal = null;
        if (data && data.pagamentoConfirmado && data.enviador && data.recebedor && data.valor) {
            try {
                const enviadorU = await client.users.fetch(data.enviador).catch(() => null);
                const recebedorU = await client.users.fetch(data.recebedor).catch(() => null);
                // Credita pro staff que REALMENTE reivindicou/mediou o MM, não pra quem clicou em Fechar
                const staffMediadorU = await client.users.fetch(data.staffReivindicou || interaction.user.id).catch(() => null);
                if (enviadorU && recebedorU && staffMediadorU) {
                    transacaoIdFinal = await executarAprovarPagamento(interaction.guild, staffMediadorU, "pix", enviadorU, recebedorU, parseFloat(data.valor));
                }
            } catch (err) { console.error("Erro ao registrar proof automática no fechamento:", err); }
        }

        const messages = await interaction.channel.messages.fetch({ limit: 100 }); const transcript = Array.from(messages.values()).reverse().map(m => `[${m.createdAt.toLocaleString()}] ${m.author.tag}: ${m.content}`).join('\n');
        const canalLog = interaction.guild.channels.cache.get(CANAL_LOGS_ID); if (canalLog) await canalLog.send({ embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('Middle encerrado (Logs)').addFields({ name: 'Administrador', value: `<@${interaction.user.id}>` }, { name: 'Canal', value: `#${interaction.channel.name}` }, { name: 'Valor', value: `R$ ${v.toFixed(2)}`, inline: true }, { name: 'Taxa', value: `R$ ${taxa.toFixed(2)}`, inline: true }).setTimestamp()], files: [new AttachmentBuilder(Buffer.from(transcript), { name: `transcript-${interaction.channel.name}.txt` })] });

        // ---- Envia, no PV de quem enviou e de quem recebeu, o resumo (Components V2 +
        // botão "Abrir Transcript") e, em mensagem separada logo abaixo, os botões de estrela ----
        if (data && data.enviador && data.recebedor) {
            const pendingId = gerarIdAvaliacao();
            avaliacoesPendentes.set(pendingId, {
                enviador: data.enviador,
                recebedor: data.recebedor,
                valor: parseFloat(data.valor) || 0,
                item: data.item,
                staffId: data.staffReivindicou || interaction.user.id,
                transacaoId: transacaoIdFinal || pendingId,
                transcript,
                avaliacoes: {}
            });

            const protocoloResumo = transacaoIdFinal || pendingId;
            const dataFechamentoTxt = new Date().toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" });

            const containerResumo = new ContainerBuilder().setAccentColor(0x5865F2).addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `## 📋 Resumo do Ticket Encerrado\n` +
                    `**Protocolo:** ${protocoloResumo}\n` +
                    `**Valor:** R$ ${data.valor}\n` +
                    `**Servidor:** ${interaction.guild.name}\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `**Comprador:** <@${data.enviador}>\n` +
                    `**Vendedor:** <@${data.recebedor}>\n` +
                    `**Intermediador:** <@${data.staffReivindicou || interaction.user.id}>\n\n` +
                    `✅ Ticket encerrado com sucesso.\n` +
                    `🗓️ ${dataFechamentoTxt}\n` +
                    `-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                    `📄 **Transcrição**\n` +
                    `-# Histórico completo das mensagens deste ticket.`
                )
            ).addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`abrir_transcript_${pendingId}`).setLabel('Abrir transcrição').setEmoji('📄').setStyle(ButtonStyle.Secondary)
                )
            );

            const containerEstrelas = new ContainerBuilder().setAccentColor(0xf2a20e).addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`# ⭐ Avalie o Atendimento ⭐\nPor favor, avalie a mediação que você recebeu!`)
            ).addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`av_1_${pendingId}`).setEmoji('⭐').setLabel('1').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`av_2_${pendingId}`).setEmoji('⭐').setLabel('2').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`av_3_${pendingId}`).setEmoji('⭐').setLabel('3').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`av_4_${pendingId}`).setEmoji('⭐').setLabel('4').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId(`av_5_${pendingId}`).setEmoji('⭐').setLabel('5').setStyle(ButtonStyle.Success)
                )
            );

            for (const uid of [data.enviador, data.recebedor]) {
                const userDM = await client.users.fetch(uid).catch(() => null);
                if (!userDM) continue;
                await userDM.send({ components: [containerResumo], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
                await userDM.send({ components: [containerEstrelas], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
            }
        }

        await interaction.editReply({ content: 'Fechando ticket em 5 segundos...' }).catch(() => {}); setTimeout(() => { interaction.channel.delete().catch(() => {}); tradeData.delete(interaction.channelId); }, 5000);
    }
});

async function executarAprovarPagamento(guild, staffUser, tipo, enviadorUser, recebedorUser, valor) {
    // Para o Staff, conta 1 intermediação (não 2) e registra as duas pessoas envolvidas
    registerStaffTrade(staffUser.id, valor, [enviadorUser.id, recebedorUser.id]);

    // Para os participantes, apenas registra a troca
    registerTrade(enviadorUser.id, valor);
    registerTrade(recebedorUser.id, valor);
    globalCounter++;
    saveGlobal();
    if (userData[enviadorUser.id].contador === undefined) userData[enviadorUser.id].contador = 0;
    userData[enviadorUser.id].contador++;
    saveUsers();
    await atualizarCargos(guild, enviadorUser.id);
    await atualizarCargos(guild, recebedorUser.id);
    await atualizarCargos(guild, staffUser.id);
    const valorFormatado = valor.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
    const taxaTotal = calcularTaxa(tipo, valor, enviadorUser.id, recebedorUser.id);
    if (taxaTotal > 0) {
        taxasDiarias[staffUser.id] = (taxasDiarias[staffUser.id] || 0) + taxaTotal;
        saveTaxas();
    }

    // ---- Vouch em imagem (cartão dourado, estilo do print de referência) ----
    const transacaoId = `MM-${Date.now()}${Math.floor(Math.random() * 900 + 100)}`;
    const vouchCodigo = `#${String(globalCounter).padStart(5, '0')}`;

    // Nota média do staff calculada a partir das avaliações que ele já recebeu
    const avaliacoesStaff = userData[staffUser.id]?.avaliacoes || [];
    const notaMedia = avaliacoesStaff.length
        ? avaliacoesStaff.reduce((a, b) => a + b, 0) / avaliacoesStaff.length
        : 5;

    const canal = guild.channels.cache.get((tipo === "pix_grande") ? CANAL_BIG_TRADE : CANAL_PROOFS);
    if (canal) {
        try {
            const buffer = await gerarCartaoVouch({
                staffNome: staffUser.username,
                staffAvatarURL: staffUser.displayAvatarURL({ extension: "png", size: 128 }),
                staffNota: notaMedia,
                staffIntermediacoes: userData[staffUser.id]?.totalTrocas || 0,
                transacaoId,
                vouchCodigo,
                valor,
                compradorNome: enviadorUser.username,
                compradorAvatarURL: enviadorUser.displayAvatarURL({ extension: "png", size: 128 }),
                vendedorNome: recebedorUser.username,
                vendedorAvatarURL: recebedorUser.displayAvatarURL({ extension: "png", size: 128 }),
                data: new Date().toLocaleDateString("pt-BR")
            });
            const anexoVouch = new AttachmentBuilder(buffer, { name: "vouch.png" });
            await canal.send({ files: [anexoVouch] }).catch(console.error);
        } catch (e) {
            console.error("Erro ao gerar cartão de vouch:", e);
        }
    }
    if (taxaTotal > 0) {
        const canalTaxas = guild.channels.cache.get(CANAL_TAXAS);
        if (canalTaxas) {
            const embedTaxas = new EmbedBuilder().setColor("#2B2D31").setTitle("<:0961:1454624137992474644> — Relatório de Intermediação").setDescription(`**ID da Proof:** \`#${globalCounter}\` | Valor: \`R$ ${valorFormatado}\``).addFields({ name: "💰 Taxa Total", value: `\`R$ ${taxaTotal.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}\`` }, { name: "👑 Parte do Dono (50%)", value: `\`R$ ${(taxaTotal / 2).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}\``, inline: true }, { name: "🤝 Parte do Middleman (50%)", value: `\`R$ ${(taxaTotal / 2).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}\``, inline: true });
            await canalTaxas.send({ content: `🔔 <@${staffUser.id}>`, embeds: [embedTaxas] }).catch(() => {});
        }
    }

    return transacaoId;
}

let lastDailyRun = null;
const dbLastMonthlyPath = path.join(__dirname, 'lastMonthlyRun.json');
let lastMonthlyRun = fs.existsSync(dbLastMonthlyPath) ? JSON.parse(fs.readFileSync(dbLastMonthlyPath)) : null;

function saveLastMonthlyRun() { fs.writeFileSync(dbLastMonthlyPath, JSON.stringify(lastMonthlyRun)); }

function checkScheduledTasks() {
    const now = new Date();
    const options = { timeZone: "America/Sao_Paulo", hour: "numeric", minute: "numeric", day: "numeric" };
    const formatter = new Intl.DateTimeFormat("pt-BR", options);
    const parts = formatter.formatToParts(now);
    const hour = parseInt(parts.find(p => p.type === "hour").value);
    const minute = parseInt(parts.find(p => p.type === "minute").value);
    const day = parseInt(parts.find(p => p.type === "day").value);

    const currentMonthYear = new Date().getMonth() + "-" + new Date().getFullYear();
    if (day === 1 && lastMonthlyRun !== currentMonthYear) {
        console.log("Tentando executar reset mensal...");
        runMonthlyReset();
    }
    if (hour === 23 && minute === 10) runDailyClosure();
}

async function runDailyClosure() {
    const today = new Date().toDateString();
    if (lastDailyRun === today) return;
    lastDailyRun = today;
    try {
        const guild = client.guilds.cache.get(GUILD_ID);
        if (!guild || Object.keys(taxasDiarias).length === 0) return;
        const canalTaxas = guild.channels.cache.get(CANAL_TAXAS);
        for (const [mmId, total] of Object.entries(taxasDiarias)) {
            if (total <= 0) continue;
            const metade = total / 2;
            const embed = new EmbedBuilder().setColor("#2B2D31").setTitle("📊 Fechamento Diário de Taxas").setDescription(`Relatório de <@${mmId}>\nTotal: \`R$ ${total.toFixed(2)}\` | Repasse: \`R$ ${metade.toFixed(2)}\``);
            const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId("copiar_chave_pix_repasse").setLabel("Chave PIX para Repasse").setStyle(ButtonStyle.Primary));
            if (canalTaxas) await canalTaxas.send({ embeds: [embed], components: [row] }).catch(() => {});
        }
        taxasDiarias = {}; saveTaxas();
    } catch (err) { console.error("Erro no fechamento diário:", err); }
}

async function runMonthlyReset() {
    const monthYear = new Date().getMonth() + "-" + new Date().getFullYear();
    if (lastMonthlyRun === monthYear) {
        console.log("Reset mensal já executado para este mês.");
        return;
    }
    lastMonthlyRun = monthYear;
    saveLastMonthlyRun();
    try {
        const guild = client.guilds.cache.get(GUILD_ID);
        if (!guild) return;
        const rolesTop = [CARGO_TOP_1, CARGO_TOP_2, CARGO_TOP_3];
        for (const roleId of rolesTop) {
            const role = guild.roles.cache.get(roleId);
            if (role) {
                for (const [mId, m] of role.members) await m.roles.remove(roleId).catch(() => { });
            }
        }
        for (const id in userData) userData[id].totalMes = 0;
        saveUsers();
        saveLastMonthlyRun(); // Salva a data do último reset mensal
    } catch (err) { console.error("Erro no reset mensal:", err); }
}

const commands = [
    new SlashCommandBuilder().setName("ranking").setDescription("Mostra o ranking de movimentação"),
    new SlashCommandBuilder().setName("perfil").setDescription("Ver perfil financeiro").addUserOption(o => o.setName("usuario").setDescription("Usuário")),
    new SlashCommandBuilder().setName("vouch").setDescription("Aprova um pagamento e gera o vouch de intermediação").addStringOption(o => o.setName("tipo").setDescription("Tipo").setRequired(true).addChoices({ name: "PIX", value: "pix" }, { name: "PIX GRANDE", value: "pix_grande" }, { name: "CROSSTRADE", value: "crosstrade" })).addUserOption(o => o.setName("comprador").setDescription("Comprador").setRequired(true)).addUserOption(o => o.setName("vendedor").setDescription("Vendedor").setRequired(true)).addStringOption(o => o.setName("valor").setDescription("Valor").setRequired(true)),
    new SlashCommandBuilder().setName("aprovar_pagamento").setDescription("Aprova um pagamento").addStringOption(o => o.setName("tipo").setDescription("Tipo").setRequired(true).addChoices({ name: "PIX", value: "pix" }, { name: "PIX GRANDE", value: "pix_grande" }, { name: "CROSSTRADE", value: "crosstrade" })).addUserOption(o => o.setName("enviador").setDescription("Enviador").setRequired(true)).addUserOption(o => o.setName("recebedor").setDescription("Recebedor").setRequired(true)).addStringOption(o => o.setName("valor").setDescription("Valor").setRequired(true)),
    new SlashCommandBuilder().setName("remover_valor").setDescription("Remove um valor do total de um usuário").addUserOption(o => o.setName("usuario").setDescription("Usuário").setRequired(true)).addStringOption(o => o.setName("valor").setDescription("Valor a remover").setRequired(true)),
    new SlashCommandBuilder().setName("configpix").setDescription("Configurar dados de PIX para os Middlemans").setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
];

const rest = new REST({ version: "10" }).setToken(TOKEN);
(async () => {
    try {
        await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body: commands });
        console.log("Comandos registrados.");
    } catch (err) { console.error(err); }
})();

client.on(Events.MessageCreate, async (message) => {
    if (message.content === '!middleman') {
        const container = new ContainerBuilder().setAccentColor(0xFF0000).addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <:parceria:1485054250429054986> ╺╸ Solicitar **MM**\nSelecione, no menu abaixo, a categoria desejada. Oferecemos serviços de intermediação para qualquer tipo de produto ou negociação, sem limitações.\n\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n> **Taxas Normais**\n**R$ 0.50** Acima de R$ 8,00.\n**R$ 2,00** Acima de R$ 100,00.\n**R$ 4,00** Acima de R$ 200,00.\n**R$ 6,50** Acima de R$ 400,00.\n**1%** Acima de R$ 700,00.\n\nEm conta adicionamos **4R$.**\n\n-# ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n> **Taxas Cross Trade**\n**R$ 1,00** - Fixo`)).addActionRowComponents(new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('menu_mm').setPlaceholder('Escolha uma opção...').addOptions({ label: 'PIX', description: 'Faça trocas que envolvam PIX.', value: 'PIX', emoji: { id: '1475258196200521788', name: 'mm_pix' } }, { label: 'Cross Trade', description: 'Faça trocas de ITEM por ITEM.', value: 'Item', emoji: { id: '1475258198410924375', name: 'mm_crosstrade' } })));
        await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(console.error);
    }
});

client.login(TOKEN);
