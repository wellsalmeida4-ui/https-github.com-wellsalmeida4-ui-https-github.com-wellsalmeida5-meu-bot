const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");
const path = require("path");
const fs = require("fs");

/* ------------------------------------------------------------------ *
 *  CARREGAMENTO E REGISTRO DE FONTES CUSTOMIZADAS (Montserrat + NotoCJK)
 * ------------------------------------------------------------------ */
const FONT_FAMILY = "Montserrat";

function getActiveFontFamilies() {
    try {
        if (GlobalFonts && Array.isArray(GlobalFonts.families)) {
            return GlobalFonts.families.map(f => typeof f === "string" ? f : (f && f.family ? f.family : String(f)));
        }
        if (GlobalFonts && typeof GlobalFonts.getFamilies === "function") {
            const raw = GlobalFonts.getFamilies();
            const str = Buffer.isBuffer(raw) ? raw.toString("utf8") : String(raw);
            const parsed = JSON.parse(str);
            if (Array.isArray(parsed)) {
                return parsed.map(f => typeof f === "string" ? f : (f && f.family ? f.family : String(f)));
            }
        }
        if (GlobalFonts && typeof GlobalFonts.has === "function" && GlobalFonts.has("Montserrat")) {
            return ["Montserrat"];
        }
    } catch (e) {
        console.warn("[vouchCard] Aviso ao obter famílias de fontes:", e.message);
    }
    return [];
}

function registerAllFonts() {
    const searchDirs = [
        path.join(__dirname, "fonts"),
        path.join(process.cwd(), "fonts"),
        path.join(__dirname, "..", "fonts"),
        path.join(process.cwd(), "dist", "fonts")
    ];

    const registeredFiles = new Set();
    let montserratCount = 0;
    let notoCount = 0;

    console.log("=================================================");
    console.log("[vouchCard LOG] Iniciando verificação e registro de fontes...");

    for (const fontsDir of searchDirs) {
        console.log(`[vouchCard LOG] Verificando diretório de fontes: ${fontsDir} (existe: ${fs.existsSync(fontsDir)})`);
        if (!fs.existsSync(fontsDir)) continue;
        try {
            const files = fs.readdirSync(fontsDir);
            for (const file of files) {
                if (registeredFiles.has(file)) continue;
                const filePath = path.join(fontsDir, file);
                const exists = fs.existsSync(filePath);
                console.log(`[vouchCard LOG] Arquivo de fonte em disk: ${file} -> existe: ${exists}`);
                if (!exists) continue;

                const lower = file.toLowerCase();
                if (lower.startsWith("montserrat") && (lower.endsWith(".ttf") || lower.endsWith(".otf"))) {
                    // Registra TODOS os pesos (Regular, Medium, SemiBold, Bold,
                    // ExtraBold...) sob a mesma família "Montserrat". O
                    // @napi-rs/canvas escolhe o arquivo certo pelo font-weight
                    // pedido em ctx.font (ex: "800 40px Montserrat"), desde que
                    // cada .ttf tenha o weight correto no seu próprio metadado.
                    try {
                        const fontKey = GlobalFonts.registerFromPath(filePath, FONT_FAMILY);
                        registeredFiles.add(file);
                        montserratCount++;
                        console.log(`[vouchCard LOG] Sucesso ao registrar ${file} como '${FONT_FAMILY}' (Key: ${fontKey ? "OK" : "null"})`);
                    } catch (e) {
                        console.error(`[vouchCard ERRO] Falha ao registrar ${file}:`, e.message);
                    }
                } else if ((lower.includes("noto") || lower.includes("cjk")) && (lower.endsWith(".ttf") || lower.endsWith(".otf"))) {
                    try {
                        const fontKey = GlobalFonts.registerFromPath(filePath, "NotoCJK");
                        registeredFiles.add(file);
                        notoCount++;
                        console.log(`[vouchCard LOG] Sucesso ao registrar ${file} como 'NotoCJK' (Key: ${fontKey ? "OK" : "null"})`);
                    } catch (e) {
                        console.error(`[vouchCard ERRO] Falha ao registrar ${file}:`, e.message);
                    }
                }
            }
        } catch (e) {
            console.error("[vouchCard ERRO] Erro ao ler pasta de fontes:", e.message);
        }
    }

    const activeFamilies = getActiveFontFamilies();
    console.log(`[vouchCard LOG] Resumo do Registro: Montserrat=${montserratCount}, NotoCJK=${notoCount}`);
    console.log(`[vouchCard LOG] Famílias ativas no GlobalFonts: [${activeFamilies.join(", ")}]`);
    console.log("=================================================");

    return { montserratCount, notoCount, activeFamilies };
}

const fontRegStatus = registerAllFonts();

const FONT_STACK = `'${FONT_FAMILY}', 'NotoCJK', 'DejaVu Sans', 'Noto Sans', 'Liberation Sans', sans-serif`;
// Nome do staff/mediador usa a mesma família Montserrat (antes usava
// 'Inter' separado; não é mais necessário, Montserrat cobre tudo).
const NAME_FONT_STACK = FONT_STACK;

function getCardConfig() {
    try {
        const configPath = path.join(process.cwd(), "cardConfig.json");
        if (fs.existsSync(configPath)) {
            return JSON.parse(fs.readFileSync(configPath, "utf8"));
        }
    } catch (e) {}
    return {};
}

/* ------------------------------------------------------------------ *
 *  PALETA ÚNICA: AMARELO DOURADO
 * ------------------------------------------------------------------ *
 *  O cartão usa uma única paleta metálica dourada em todos os elementos:
 *  título, valor intermediado, moldura do perfil, patente e rodapé.
 *  O fundo permanece escuro para preservar o contraste e a legibilidade.
 * ------------------------------------------------------------------ */
const THEMES = {
    golden_yellow: {
        BG: "#15131A",
        GOLD_HIGH: "#FFD080",
        GOLD_1: "#F9A640",
        GOLD_2: "#F0782E",
        GOLD_3: "#C84B32",
        GOLD_4: "#78313A",
        GOLD_SHADOW: "rgba(240,120,46,0.26)",
        GOLD_SOLID: "#E97B32",
        TEXT_MUTED: "#A98595",
        DARK_STAR: "#211821"
    }
};

function getPalette(themeName) {
    // Mantém uma aparência consistente: qualquer tema recebido usa o dourado.
    return THEMES.golden_yellow;
}

/* ------------------------------------------------------------------ *
 *  SISTEMA DE PATENTES (RANK) POR NÚMERO DE INTERMEDIAÇÕES
 * ------------------------------------------------------------------ *
 *  A patente exibida ao lado do nome do staff sobe automaticamente
 *  conforme a quantidade de intermediações feitas (staffIntermediacoes).
 *  Ajuste os limites (min) e nomes abaixo como quiser — dá pra
 *  sobrescrever tudo isso passando `vOpts.rankNome` na hora de chamar
 *  gerarCartaoVouch, se precisar de um caso especial.
 * ------------------------------------------------------------------ */
const RANK_TIERS = [
    { min: 0, nome: "BRONZE" },
    { min: 20, nome: "PRATA" },
    { min: 30, nome: "OURO" },
    { min: 40, nome: "PLATINA" },
    { min: 50, nome: "DIAMANTE" },
    { min: 100, nome: "LENDÁRIO" }
];

function getRankPorIntermediacoes(qtd) {
    let atual = RANK_TIERS[0].nome;
    for (const tier of RANK_TIERS) {
        if (qtd >= tier.min) atual = tier.nome;
    }
    return atual;
}

/* ------------------------------------------------------------------ *
 *  CRIAÇÃO PRECISA DE GRADIENTE E UTILITÁRIOS DE DESENHO
 * ------------------------------------------------------------------ */

function criarGradienteOuro(ctx, y, altura, palette, direcao = "vertical") {
    const p = palette || THEMES.golden_yellow;
    const gHigh = p.GOLD_HIGH || "#FFE885";
    const g1 = p.GOLD_1 || "#F3C84B";
    const g2 = p.GOLD_2 || "#E5A93C";
    const g3 = p.GOLD_3 || "#C48A22";
    const g4 = p.GOLD_4 || "#80520D";

    if (direcao === "horizontal") {
        const grad = ctx.createLinearGradient(y, 0, y + altura, 0);
        grad.addColorStop(0.00, gHigh);
        grad.addColorStop(0.25, g1);
        grad.addColorStop(0.55, g2);
        grad.addColorStop(0.80, g3);
        grad.addColorStop(1.00, g4);
        return grad;
    }

    // Para textos: y é a linha de base (baseline).
    const yTop = y - Math.max(altura * 0.78, 1);
    const yBottom = y + Math.max(altura * 0.12, 1);
    const grad = ctx.createLinearGradient(0, yTop, 0, yBottom);
    grad.addColorStop(0.00, gHigh);
    grad.addColorStop(0.25, g1);
    grad.addColorStop(0.55, g2);
    grad.addColorStop(0.80, g3);
    grad.addColorStop(1.00, g4);
    return grad;
}

/**
 * Desenha texto com efeito de gradiente metálico (5 tons, de cima pra baixo).
 *
 * Técnica: em vez de usar fillStyle=gradiente (que causava texto invisível)
 * ou globalCompositeOperation (que não é suportado nesse ambiente e cobria
 * tudo com retângulo sólido), usamos ctx.clip() com faixas horizontais —
 * isso É suportado (é a mesma técnica usada nos avatares circulares, que
 * sempre recortaram certinho). O texto é desenhado 5 vezes, cada vez
 * recortado numa faixa horizontal diferente com uma cor sólida diferente,
 * criando o efeito de degradê sem depender de gradiente nativo em texto.
 */
function fillTextGradient(ctx, text, x, y, fontSizePx, palette, align = "left", customStops = null) {
    if (!text) return;
    const p = palette || THEMES.golden_yellow;

    // Mais pontos de cor = transição mais suave/realista (menos "faixado").
    // customStops permite um degradê mais simples (ex: 2 tons) para textos específicos.
    const stopColors = customStops || [
        p.GOLD_HIGH || "#FFE885",
        p.GOLD_1 || "#F3C84B",
        p.GOLD_1 || "#F3C84B",
        p.GOLD_2 || "#E5A93C",
        p.GOLD_2 || "#E5A93C",
        p.GOLD_3 || "#C48A22",
        p.GOLD_3 || "#C48A22",
        p.GOLD_4 || "#80520D"
    ];

    ctx.save();
    ctx.textAlign = align;

    let width;
    try {
        const metrics = ctx.measureText(text);
        width = metrics.width || (fontSizePx * text.length * 0.55);
    } catch (e) {
        width = fontSizePx * text.length * 0.55;
    }

    let rectX;
    if (align === "center") rectX = x - width / 2;
    else if (align === "right") rectX = x - width;
    else rectX = x;

    const ascent = fontSizePx * 0.85;
    const descent = fontSizePx * 0.28;
    const top = y - ascent - 2;
    const totalH = ascent + descent + 4;
    const bandH = totalH / stopColors.length;

    for (let i = 0; i < stopColors.length; i++) {
        ctx.save();
        ctx.beginPath();
        ctx.rect(rectX - 6, top + i * bandH - 0.5, width + 12, bandH + 1);
        ctx.clip();
        ctx.fillStyle = stopColors[i];
        ctx.fillText(text, x, y);
        ctx.restore();
    }

    ctx.restore();
}

/**
 * Trunca um texto com "..." no final se ele não couber em maxWidth,
 * usando a fonte já configurada em ctx.font. Usado no nome do staff/
 * mediador, comprador e vendedor pra não bugar o layout com nomes gigantes.
 */
function desenharBrilhoTextoMovel(ctx, text, x, baselineY, fontSize, frame = 0, totalFrames = 12) {
    if (!text) return;
    const font = `800 ${fontSize}px ${FONT_STACK}`;
    const measure = createCanvas(1, 1).getContext("2d");
    measure.font = font;
    const width = Math.max(1, Math.ceil(measure.measureText(text).width) + 4);
    const height = Math.ceil(fontSize * 1.55);
    const baseline = Math.ceil(fontSize * 1.18);

    // Máscara alfa do próprio texto; o reflexo só será criado onde houver glifo.
    const maskCanvas = createCanvas(width, height);
    const maskCtx = maskCanvas.getContext("2d");
    maskCtx.font = font;
    maskCtx.textAlign = "left";
    maskCtx.textBaseline = "alphabetic";
    maskCtx.fillStyle = "#FFFFFF";
    maskCtx.fillText(text, 1, baseline);
    const mask = maskCtx.getImageData(0, 0, width, height).data;

    const layerCanvas = createCanvas(width, height);
    const layerCtx = layerCanvas.getContext("2d");
    const image = layerCtx.createImageData(width, height);
    const frames = Math.max(1, Number(totalFrames) || 1);
    // Começa visível numa imagem estática; em GIF percorre continuamente o texto.
    const phase = ((((Number(frame) || 0) / frames) + 0.40) % 1 + 1) % 1;
    const centerX = -24 + phase * (width + 48);
    const sigma = Math.max(7, fontSize * 0.14);
    for (let py = 0; py < height; py++) {
        for (let px = 0; px < width; px++) {
            const index = (py * width + px) * 4;
            const glyphAlpha = mask[index + 3] / 255;
            if (glyphAlpha <= 0) continue;
            const distance = (px - centerX) / sigma;
            const beamAlpha = Math.exp(-0.5 * distance * distance) * 0.78 * glyphAlpha;
            if (beamAlpha < 0.01) continue;
            image.data[index] = 255;
            image.data[index + 1] = 247;
            image.data[index + 2] = 221;
            image.data[index + 3] = Math.round(beamAlpha * 255);
        }
    }
    layerCtx.putImageData(image, 0, 0);
    ctx.drawImage(layerCanvas, x, baselineY - baseline);
}

function truncarComReticencias(ctx, text, maxWidth) {
    if (!text) return text;
    let t = String(text);
    if (ctx.measureText(t).width <= maxWidth) return t;
    while (t.length > 1 && ctx.measureText(t + "...").width > maxWidth) {
        t = t.slice(0, -1);
    }
    return t + "...";
}

function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
}

/**
 * Moldura com degradê feita só com fillRect em cor HEX sólida (sem stroke e
 * sem gradiente nativo, que saem pretos neste ambiente de canvas).
 * (x, y, w, h) é a caixa EXTERNA da moldura; `espessura` cresce para dentro.
 */
function strokeRectDegrade(ctx, x, y, w, h, stops, espessura, W, H, glowColor = null, glowBlur = 0) {
    const hex2 = n => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0');
    const parsed = stops.map(([pos, hex]) => [pos, [
        parseInt(hex.slice(1, 3), 16), parseInt(hex.slice(3, 5), 16), parseInt(hex.slice(5, 7), 16)
    ]]);
    const cor = (px, py) => {
        const t = Math.min(1, Math.max(0, (px / W + py / H) / 2));
        for (let i = 0; i < parsed.length - 1; i++) {
            const [p1, c1] = parsed[i], [p2, c2] = parsed[i + 1];
            if (t >= p1 && t <= p2) {
                const q = p2 === p1 ? 0 : (t - p1) / (p2 - p1);
                return '#' + hex2(c1[0] + (c2[0] - c1[0]) * q) + hex2(c1[1] + (c2[1] - c1[1]) * q) + hex2(c1[2] + (c2[2] - c1[2]) * q);
            }
        }
        const c = parsed[parsed.length - 1][1];
        return '#' + hex2(c[0]) + hex2(c[1]) + hex2(c[2]);
    };
    const e = espessura;

    if (glowColor && glowBlur > 0) {
        ctx.save();
        ctx.fillStyle = glowColor;
        ctx.shadowColor = glowColor;
        ctx.shadowBlur = glowBlur;
        ctx.fillRect(x, y, w, e);
        ctx.fillRect(x, y + h - e, w, e);
        ctx.fillRect(x, y, e, h);
        ctx.fillRect(x + w - e, y, e, h);
        ctx.restore();
    }

    ctx.save();
    const step = 6;
    for (let px = x; px < x + w; px += step) {
        const sw = Math.min(step + 1, x + w - px);
        ctx.fillStyle = cor(px, y);
        ctx.fillRect(px, y, sw, e);
        ctx.fillStyle = cor(px, y + h);
        ctx.fillRect(px, y + h - e, sw, e);
    }
    for (let py = y; py < y + h; py += step) {
        const sh = Math.min(step + 1, y + h - py);
        ctx.fillStyle = cor(x, py);
        ctx.fillRect(x, py, e, sh);
        ctx.fillStyle = cor(x + w, py);
        ctx.fillRect(x + w - e, py, e, sh);
    }
    ctx.restore();
}

/**
 * Linha fina da moldura (só fillRect em cor HEX, sem stroke).
 * A linha é FIXA (sempre inteira). O brilho passa por cima dela: nasce fraco
 * no topo (canto esquerdo), vai ficando forte no meio da volta, enfraquece
 * até sumir no fim e recomeça lá em cima. Sem animação, só a linha fixa.
 */
function desenharLinhaFinaAnimada(ctx, W, H, frame = 0, totalFrames = 36, animado = true) {
    const hex2 = n => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0');
    const toRgb = h => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
    const mix = (a, b, q) => '#' + [0, 1, 2].map(i => hex2(a[i] + (b[i] - a[i]) * q)).join('');
    const cA = toRgb('#FF8A3D'), cB = toRgb('#FFB36B'), cBrilho = toRgb('#FFF4E6');

    const inset = 16, e = 2, step = 4;
    const x0 = inset, y0 = inset, w = W - inset * 2, h = H - inset * 2;
    const per = 2 * (w + h);
    const frames = Math.max(1, Number(totalFrames) || 1);
    const p = ((frame % frames) + frames) % frames / frames;

    const pos = d => {
        if (d < w) return [x0 + d, y0, true];
        if (d < w + h) return [x0 + w, y0 + (d - w), false];
        if (d < 2 * w + h) return [x0 + w - (d - w - h), y0 + h, true];
        return [x0, y0 + h - (d - 2 * w - h), false];
    };

    ctx.save();
    // 1) linha fixa inteira: fraca no começo, forte no meio, fraca no fim
    for (let d = 0; d < per; d += step) {
        const [x, y, horiz] = pos(d);
        ctx.globalAlpha = 0.22 + 0.78 * Math.sin(Math.PI * d / per);
        ctx.fillStyle = mix(cA, cB, d / per);
        if (horiz) ctx.fillRect(x, y - e / 2, step + 1, e);
        else ctx.fillRect(x - e / 2, y, e, step + 1);
    }

    // 2) brilho que passa pela linha fina
    if (animado) {
        const head = p * per;
        const env = Math.sin(Math.PI * p);      // fraco -> forte -> fraco
        const cauda = 460;
        for (let d = Math.max(0, head - cauda); d <= head; d += step) {
            const f = 1 - (head - d) / cauda;   // 1 na ponta, 0 no fim da cauda
            const a = env * Math.pow(f, 1.4);
            if (a < 0.02) continue;
            const [x, y, horiz] = pos(d);
            const grosso = f > 0.85 ? e + 2 : e + 1;
            ctx.globalAlpha = Math.min(1, a);
            ctx.fillStyle = mix(mix(cA, cB, d / per), cBrilho, 0.35 + 0.65 * f);
            if (horiz) ctx.fillRect(x, y - grosso / 2, step + 1, grosso);
            else ctx.fillRect(x - grosso / 2, y, grosso, step + 1);
        }
    }
    ctx.restore();
}

/**
 * Contorno metálico com brilho reforçado. Ajustado para ficar como UMA linha
 * única, nítida (usa o degradê metálico completo em vez de cor sólida
 * chapada, com um blur bem mais leve para não borrar o traço).
 */
function strokeGlowRoundRect(ctx, x, y, w, h, r, palette, lineWidth = 2.5) {
    // Camada 1: brilho suave e largo por trás da linha (halo)
    ctx.save();
    ctx.shadowColor = palette.GOLD_SHADOW;
    ctx.shadowBlur = 8;
    ctx.strokeStyle = palette.GOLD_SOLID;
    ctx.lineWidth = lineWidth + 2;
    roundRect(ctx, x, y, w, h, r);
    ctx.stroke();
    ctx.restore();

    // Camada 2: linha fina e nítida por cima, em degradê metálico completo
    ctx.save();
    const grad = ctx.createLinearGradient(x, y, x, y + h);
    grad.addColorStop(0.00, palette.GOLD_HIGH || "#FFE885");
    grad.addColorStop(0.30, palette.GOLD_1 || "#F3C84B");
    grad.addColorStop(0.60, palette.GOLD_2 || "#E5A93C");
    grad.addColorStop(0.85, palette.GOLD_3 || "#C48A22");
    grad.addColorStop(1.00, palette.GOLD_4 || "#80520D");
    ctx.strokeStyle = grad;
    ctx.lineWidth = lineWidth;
    roundRect(ctx, x, y, w, h, r);
    ctx.stroke();
    ctx.restore();
}

function strokeGlowCircle(ctx, cx, cy, r, palette, lineWidth = 4) {
    ctx.save();
    ctx.shadowColor = palette.GOLD_SHADOW;
    ctx.shadowBlur = 7;
    ctx.strokeStyle = palette.GOLD_2;
    ctx.lineWidth = lineWidth;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();

    ctx.save();
    const grad = ctx.createLinearGradient(cx, cy - r, cx, cy + r);
    grad.addColorStop(0, palette.GOLD_HIGH);
    grad.addColorStop(0.5, palette.GOLD_2);
    grad.addColorStop(1, palette.GOLD_4);
    ctx.strokeStyle = grad;
    ctx.lineWidth = lineWidth;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
}

function strokeGlowLine(ctx, x1, y1, x2, y2, palette, lineWidth = 1.5) {
    ctx.save();
    ctx.shadowColor = palette.GOLD_SHADOW;
    ctx.shadowBlur = 4;
    ctx.strokeStyle = palette.GOLD_SOLID;
    ctx.lineWidth = lineWidth;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
    ctx.restore();
}

/**
 * Linha "quebrada" (efeito rachadura/raio), usada como decoração
 * discreta nos cantos do cartão. `points` é uma lista de [x, y].
 */
function drawCrackLine(ctx, points, palette, width = 2) {
    ctx.save();
    ctx.shadowColor = palette.GOLD_SHADOW;
    ctx.shadowBlur = 3;
    ctx.strokeStyle = palette.GOLD_SOLID;
    ctx.lineWidth = width;
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(points[0][0], points[0][1]);
    for (let i = 1; i < points.length; i++) ctx.lineTo(points[i][0], points[i][1]);
    ctx.stroke();
    ctx.restore();
}

function desenharRachadurasCanto(ctx, W, H, palette) {
    // Canto superior direito
    drawCrackLine(ctx, [[W - 230, 10], [W - 170, 55], [W - 190, 60], [W - 120, 110], [W - 140, 115], [W - 70, 160]], palette, 2);
    drawCrackLine(ctx, [[W - 110, 15], [W - 80, 45], [W - 95, 50], [W - 40, 90]], palette, 2);
    // Canto inferior esquerdo
    drawCrackLine(ctx, [[20, H - 80], [80, H - 50], [60, H - 45], [120, H - 15]], palette, 2);
    drawCrackLine(ctx, [[15, H - 130], [55, H - 105], [40, H - 100], [90, H - 70]], palette, 2);
}

/**
 * Estrela. Ativa: preenchimento em gradiente metálico com brilho.
 * Inativa: fundo escuro, mas com contorno metálico (em vez de ficar apagada),
 * para que o conjunto de estrelas sempre "leia" como amarelo/dourado.
 */
function drawStar(ctx, cx, cy, outerR, ativa, palette, innerRatio = 0.45) {
    const p = palette || THEMES.golden_yellow;
    const innerR = outerR * innerRatio;
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
        const r = i % 2 === 0 ? outerR : innerR;
        const angle = (Math.PI / 5) * i - Math.PI / 2;
        const x = cx + r * Math.cos(angle);
        const y = cy + r * Math.sin(angle);
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.closePath();
    if (ativa) {
        // Cor sólida e saturada, sem depender de gradiente + sombra: no ambiente
        // de canvas usado aqui, gradiente + shadowBlur em formas pequenas como a
        // estrela renderiza esbranquiçado. Cor sólida garante o dourado visível.
        ctx.save();
        ctx.fillStyle = p.GOLD_SOLID || p.GOLD_2 || "#E5A93C";
        ctx.fill();
        ctx.lineWidth = Math.max(1, outerR * 0.08);
        ctx.strokeStyle = p.GOLD_4 || "#80520D";
        ctx.stroke();
        ctx.restore();
    } else {
        ctx.save();
        ctx.fillStyle = p.DARK_STAR || "#2a2412";
        ctx.fill();
        ctx.lineWidth = Math.max(1, outerR * 0.08);
        ctx.strokeStyle = p.GOLD_4 || "#80520D";
        ctx.stroke();
        ctx.restore();
    }
}

function drawCheckBadge(ctx, cx, cy, r, palette) {
    ctx.save();
    ctx.shadowColor = palette.GOLD_SHADOW;
    ctx.shadowBlur = 4;
    const grad = ctx.createLinearGradient(cx, cy - r, cx, cy + r);
    grad.addColorStop(0, palette.GOLD_1);
    grad.addColorStop(1, palette.GOLD_4);
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.fill();
    ctx.restore();

    ctx.beginPath();
    ctx.moveTo(cx - r * 0.5, cy);
    ctx.lineTo(cx - r * 0.1, cy + r * 0.4);
    ctx.lineTo(cx + r * 0.55, cy - r * 0.4);
    ctx.lineWidth = r * 0.3;
    ctx.strokeStyle = "#1a1206";
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke();
}

function drawCheckOutlineBadge(ctx, cx, cy, r, palette) {
    ctx.save();
    ctx.shadowColor = palette.GOLD_SHADOW;
    ctx.shadowBlur = 4;
    const grad = ctx.createLinearGradient(cx, cy - r, cx, cy + r);
    grad.addColorStop(0, palette.GOLD_1);
    grad.addColorStop(1, palette.GOLD_4);
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.lineWidth = r * 0.16;
    ctx.strokeStyle = grad;
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.5, cy);
    ctx.lineTo(cx - r * 0.1, cy + r * 0.4);
    ctx.lineTo(cx + r * 0.55, cy - r * 0.4);
    ctx.lineWidth = r * 0.24;
    ctx.strokeStyle = grad;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke();
    ctx.restore();
}

function drawCalendar(ctx, cx, cy, size, palette) {
    const w = size * 1.5, h = size * 1.3;
    ctx.strokeStyle = palette.GOLD_SOLID;
    ctx.lineWidth = size * 0.12;
    roundRect(ctx, cx - w / 2, cy - h / 2, w, h, size * 0.18);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx - w / 2, cy - h * 0.15);
    ctx.lineTo(cx + w / 2, cy - h * 0.15);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx - w * 0.25, cy - h / 2 - size * 0.12);
    ctx.lineTo(cx - w * 0.25, cy - h / 2 + size * 0.12);
    ctx.moveTo(cx + w * 0.25, cy - h / 2 - size * 0.12);
    ctx.lineTo(cx + w * 0.25, cy - h / 2 + size * 0.12);
    ctx.stroke();
}

function drawList(ctx, cx, cy, size, cor) {
    const w = size * 1.3, h = size * 1.5;
    ctx.strokeStyle = cor;
    ctx.lineWidth = size * 0.1;
    roundRect(ctx, cx - w / 2, cy - h / 2, w, h, size * 0.15);
    ctx.stroke();
    for (let i = 0; i < 3; i++) {
        const ly = cy - h / 2 + h * 0.28 + i * (h * 0.22);
        ctx.beginPath();
        ctx.moveTo(cx - w / 2 + w * 0.18, ly);
        ctx.lineTo(cx + w / 2 - w * 0.18, ly);
        ctx.stroke();
    }
}

function drawCopyIcon(ctx, cx, cy, size, palette) {
    ctx.strokeStyle = palette.GOLD_SOLID;
    ctx.lineWidth = size * 0.12;
    roundRect(ctx, cx - size * 0.1, cy - size * 0.5, size * 0.75, size * 0.9, size * 0.12);
    ctx.stroke();
    roundRect(ctx, cx - size * 0.5, cy - size * 0.25, size * 0.75, size * 0.9, size * 0.12);
    ctx.fillStyle = palette.BG;
    ctx.fill();
    ctx.stroke();
}

function desenharPontosFundo(ctx, W, H, palette) {
    // Malha pontilhada regular: pequenos quadrados organizados, sem aspecto
    // aleatório, para criar uma textura técnica e discreta no fundo.
    const p = palette || THEMES.golden_yellow;
    const corParticula = p.GOLD_2 || "#D6B86A";
    const espacamento = 22;
    for (let y = 28; y < H - 20; y += espacamento) {
        for (let x = 28; x < W - 20; x += espacamento) {
            ctx.save();
            ctx.globalAlpha = 0.10;
            ctx.fillStyle = corParticula;
            ctx.fillRect(x, y, 2, 2);
            ctx.restore();
        }
    }
}

/**
 * Reduz gradualmente o tamanho da fonte até que o texto caiba dentro de
 * maxWidth, mantendo um tamanho mínimo legível. Mantida disponível para uso
 * futuro (ex: em outros campos), mas não é mais aplicada ao valor
 * intermediado — que agora usa fonte sempre fixa, igual à referência.
 */
function ajustarTamanhoFonteParaLargura(ctx, text, fontWeight, fontSizeInicial, maxWidth, fontSizeMinimo = 40) {
    let fontSize = fontSizeInicial;
    ctx.font = `${fontWeight} ${fontSize}px ${FONT_STACK}`;
    let largura = ctx.measureText(text).width;

    while (largura > maxWidth && fontSize > fontSizeMinimo) {
        fontSize -= 2;
        ctx.font = `${fontWeight} ${fontSize}px ${FONT_STACK}`;
        largura = ctx.measureText(text).width;
    }

    return fontSize;
}

async function desenharAvatarCirculo(ctx, cx, cy, r, urlOuLetra, palette) {
    const anonimato = urlOuLetra === '__ANONYMOUS__';
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();

    if (anonimato) {
        ctx.fillStyle = '#252B32';
        ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
        ctx.fillStyle = palette.GOLD_2 || '#F2B93F';
        ctx.beginPath();
        ctx.arc(cx, cy - r * 0.28, r * 0.27, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(cx, cy + r * 0.48, r * 0.58, Math.PI, 0);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
        return;
    }

    let desenhouImagem = false;
    if (urlOuLetra && String(urlOuLetra).startsWith("http")) {
        try {
            const img = await loadImage(urlOuLetra);
            ctx.drawImage(img, cx - r, cy - r, r * 2, r * 2);
            desenhouImagem = true;
        } catch (e) { /* fallback */ }
    }
    if (!desenhouImagem) {
        ctx.fillStyle = "#161310";
        ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
        ctx.restore();
        ctx.save();
        ctx.fillStyle = criarGradienteOuro(ctx, cy, r * 1.6, palette);
        ctx.font = `bold ${Math.round(r)}px ${FONT_STACK}`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        const letra = (typeof urlOuLetra === "string" && urlOuLetra.length) ? urlOuLetra[0].toUpperCase() : "?";
        ctx.fillText(letra, cx, cy + 4);
        ctx.textAlign = "left";
        ctx.textBaseline = "alphabetic";
        ctx.restore();
        return;
    }
    ctx.restore();
}

/**
 * Gera o cartão de vouch (Buffer PNG) — visual amarelo/dourado, com Montserrat e
 * NotoCJK para caracteres internacionais. Posições e tamanhos calibrados
 * para baterem com a referência pixel a pixel (1729x910): título, ID da
 * transação, caixa do código, valor intermediado (fixo, alinhado à
 * direita), avatar do staff com selo/estrelas/patente, e rodapé com
 * comprador/vendedor/data/marca.
 */
function desenharRastroBorda(ctx, W, H, frame = 0, totalFrames = 36) {
    const edge = [[11, 11], [W - 11, 11], [W - 11, H - 11], [11, H - 11], [11, 11]];
    const perimeter = 2 * (W - 22) + 2 * (H - 22);
    function pointOnEdge(distance) {
        let d = ((distance % perimeter) + perimeter) % perimeter;
        for (let i = 0; i < edge.length - 1; i++) {
            const [x1, y1] = edge[i], [x2, y2] = edge[i + 1];
            const length = Math.hypot(x2 - x1, y2 - y1);
            if (d <= length) {
                const q = d / length;
                return [x1 + (x2 - x1) * q, y1 + (y2 - y1) * q];
            }
            d -= length;
        }
        return edge[0];
    }
    const frames = Math.max(1, Number(totalFrames) || 1);
    const t = ((frame % frames) + frames) % frames / frames;
    ctx.save();
    ctx.lineCap = 'round';

    function drawStreak(head, segments, spacing, segmentLength, strength, widthHot, widthTail, colorHot, colorTail) {
        for (let i = 0; i < segments; i++) {
            const [x1, y1] = pointOnEdge(head - i * spacing);
            const [x2, y2] = pointOnEdge(head - i * spacing - segmentLength);
            const fade = 1 - i / segments;
            ctx.globalAlpha = strength * fade;
            ctx.strokeStyle = i < 5 ? colorHot : colorTail;
            ctx.shadowColor = 'rgba(255, 126, 55, 0.52)';
            ctx.shadowBlur = i < 5 ? 7 : 4;
            ctx.lineWidth = widthTail + (widthHot - widthTail) * fade;
            ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
        }
        const d = ((head % perimeter) + perimeter) % perimeter;
        if (d <= W - 22) {
            const hx = 11 + d;
            ctx.globalAlpha = strength * 0.8;
            ctx.strokeStyle = colorHot;
            ctx.shadowColor = 'rgba(255, 190, 128, 0.68)';
            ctx.shadowBlur = 8;
            ctx.lineWidth = widthHot;
            // Reflexo cruza a borda e a gota de sangue no topo.
            ctx.beginPath(); ctx.moveTo(hx, 10); ctx.lineTo(hx, 12); ctx.stroke();
        }
    }

    // Reflexo claro percorrendo a linha fina da moldura.
    drawStreak(t * perimeter, 26, 7, 7, 0.95, 2, 0.6, '#FFFFFF', '#FFD9B8');
    ctx.restore();
}

function desenharHalloween(ctx, W, H, palette, frame = 0, totalFrames = 12, sombraBase = 0.12, sombraForca = 0.85) {
    const t = ((frame % totalFrames) + totalFrames) % totalFrames / totalFrames;

    // Fundo ameixa quase-preto: preserva o aspecto escuro, mas deixa o vinho visível.
    ctx.save();
    ctx.fillStyle = '#15131A';
    ctx.fillRect(0, 0, W, H);
    // Vaporwave muito discreto por toda a superfície: violeta e ciano escuros.
    const vaporwaveWash = ctx.createLinearGradient(0, 0, W, H);
    vaporwaveWash.addColorStop(0, 'rgba(112, 42, 139, 0.06)');
    vaporwaveWash.addColorStop(0.48, 'rgba(51, 39, 91, 0.04)');
    vaporwaveWash.addColorStop(1, 'rgba(28, 112, 145, 0.05)');
    ctx.fillStyle = vaporwaveWash;
    ctx.fillRect(0, 0, W, H);
    const vaporwaveGlow = ctx.createRadialGradient(W * 0.76, H * 0.53, 8, W * 0.76, H * 0.53, W * 0.58);
    vaporwaveGlow.addColorStop(0, 'rgba(36, 120, 148, 0.06)');
    vaporwaveGlow.addColorStop(1, 'rgba(36, 120, 148, 0)');
    ctx.fillStyle = vaporwaveGlow;
    ctx.fillRect(0, 0, W, H);
    // Quadradinhos pequenos, espaçados e agora um pouco mais visíveis.
    for (let y = 30; y < H - 24; y += 32) {
        for (let x = 30; x < W - 24; x += 32) {
            ctx.fillStyle = ((x / 32 + y / 32) % 2 < 1)
                ? 'rgba(210, 142, 235, 0.08)'
                : 'rgba(112, 202, 228, 0.08)';
            ctx.fillRect(x, y, 3, 3);
        }
    }
    ctx.restore();

    // Sombra difusa vinho atrás da foto: espalha-se a uma distância razoável
    // do avatar e desaparece suavemente antes de alcançar o restante do cartão.
    ctx.save();
    const profileGlow = ctx.createRadialGradient(246, 393, 64, 246, 393, 430);
    profileGlow.addColorStop(0, 'rgba(92, 18, 38, 0.22)');
    profileGlow.addColorStop(0.22, 'rgba(105, 22, 43, 0.24)');
    profileGlow.addColorStop(0.48, 'rgba(82, 18, 36, 0.16)');
    profileGlow.addColorStop(0.78, 'rgba(52, 14, 28, 0.07)');
    profileGlow.addColorStop(1, 'rgba(25, 0, 5, 0)');
    ctx.fillStyle = profileGlow;
    ctx.fillRect(0, 0, W, H);
    ctx.restore();

    // Filete vermelho escuro no topo com gotas escorridas, como na referência.
    ctx.save();
    ctx.globalAlpha = 0.72;
    ctx.strokeStyle = '#8E1825';
    ctx.shadowColor = 'rgba(142, 24, 37, 0.32)';
    ctx.shadowBlur = 5;
    ctx.lineWidth = 15;
    ctx.beginPath(); ctx.moveTo(18, 18); ctx.lineTo(W - 18, 18); ctx.stroke();
    for (const [dx, len, width, phase] of [[52, 58, 21, 0.2], [218, 38, 14, 1.1], [650, 46, 20, 2.2], [1040, 62, 21, 3.0], [1305, 42, 15, 4.1], [W - 88, 68, 21, 5.0]]) {
        const movingLen = len + Math.sin(t * Math.PI * 2 + phase) * 7;
        ctx.lineWidth = width;
        ctx.beginPath(); ctx.moveTo(dx, 18); ctx.lineTo(dx, 18 + movingLen - 7);
        ctx.arc(dx, 18 + movingLen - 7, width / 2, Math.PI, 0); ctx.stroke();
    }
    ctx.restore();

    // Gotas pequenas nos cantos superior direito e inferior esquerdo.
    function drawBloodDrop(x, y, scale, alpha = 0.82, phase = 0) {
        y += Math.sin(t * Math.PI * 2 + phase) * 5;
        ctx.save();
        ctx.globalAlpha = alpha;
        ctx.fillStyle = '#8F1424';
        ctx.shadowColor = 'rgba(95, 8, 20, 0.32)';
        ctx.shadowBlur = 5;
        ctx.beginPath();
        ctx.moveTo(x, y - 17 * scale);
        ctx.bezierCurveTo(x + 3 * scale, y - 10 * scale, x + 10 * scale, y - 2 * scale, x + 9 * scale, y + 4 * scale);
        ctx.bezierCurveTo(x + 8 * scale, y + 14 * scale, x - 8 * scale, y + 14 * scale, x - 9 * scale, y + 4 * scale);
        ctx.bezierCurveTo(x - 10 * scale, y - 2 * scale, x - 3 * scale, y - 10 * scale, x, y - 17 * scale);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
    }
    // Gotas no canto superior direito.
    drawBloodDrop(W - 54, 51, 1.40, 0.78, 0.3);
    drawBloodDrop(W - 86, 78, 1.08, 0.62, 1.4);
    drawBloodDrop(W - 35, 92, 0.90, 0.54, 2.1);
    // Gotas no canto inferior esquerdo.
    drawBloodDrop(54, H - 51, 1.40, 0.78, 2.8);
    drawBloodDrop(86, H - 78, 1.08, 0.62, 3.7);
    drawBloodDrop(35, H - 92, 0.90, 0.54, 5.0);
    // Gotas extras pequenas ao longo das bordas para reforçar a decoração.
    drawBloodDrop(138, 60, 0.88, 0.58, 0.8);
    drawBloodDrop(382, 52, 0.72, 0.55, 1.8);
    drawBloodDrop(824, 58, 0.86, 0.55, 2.6);
    drawBloodDrop(1120, 62, 0.92, 0.58, 3.4);
    drawBloodDrop(1490, 58, 0.88, 0.60, 4.2);
    drawBloodDrop(W - 56, H - 76, 1.00, 0.62, 1.1);
    drawBloodDrop(120, H - 55, 0.94, 0.60, 2.2);
    // Mais gotas nas laterais, mantendo a área central livre para o conteúdo.
    drawBloodDrop(42, 220, 0.92, 0.58, 0.7);
    drawBloodDrop(46, 405, 0.84, 0.56, 1.6);
    drawBloodDrop(44, 590, 0.94, 0.60, 2.5);
    drawBloodDrop(W - 42, 205, 0.90, 0.58, 3.3);
    drawBloodDrop(W - 46, 390, 0.86, 0.56, 4.1);
    drawBloodDrop(W - 43, 575, 0.96, 0.60, 5.0);
    drawBloodDrop(590, 48, 0.88, 0.54, 1.2);
    drawBloodDrop(930, 50, 0.90, 0.56, 2.9);

    // Sombra preta lateral: bem forte na DIREITA e bem fraquinha na ESQUERDA,
    // cobrindo o fundo inteiro. Fica ANTES da abóbora e dos fantasmas, para
    // eles não serem apagados por ela. Faixas verticais em rgba sólido.
    ctx.save();
    for (let x = 0; x < W; x += 4) {
        const q = x / W;
        const a = sombraBase + (sombraForca - sombraBase) * Math.pow(q, 1.6);
        ctx.fillStyle = `rgba(0, 0, 0, ${a.toFixed(3)})`;
        ctx.fillRect(x, 0, 5, H);
    }
    ctx.restore();

    // Abóbora reconstruída com uma silhueta contínua e rosto separado,
    // evitando elipses sobrepostas e caminhos que se cruzavam.
    ctx.save();
    ctx.globalAlpha = 0.55;
    const pumpkinX = W * 0.875, pumpkinY = H * 0.755;
    ctx.fillStyle = '#B75A19';
    ctx.beginPath();
    ctx.moveTo(pumpkinX, pumpkinY - 91);
    ctx.bezierCurveTo(pumpkinX + 36, pumpkinY - 104, pumpkinX + 93, pumpkinY - 80, pumpkinX + 105, pumpkinY - 26);
    ctx.bezierCurveTo(pumpkinX + 124, pumpkinY + 37, pumpkinX + 82, pumpkinY + 91, pumpkinX + 31, pumpkinY + 98);
    ctx.bezierCurveTo(pumpkinX + 10, pumpkinY + 104, pumpkinX - 10, pumpkinY + 104, pumpkinX - 31, pumpkinY + 98);
    ctx.bezierCurveTo(pumpkinX - 82, pumpkinY + 91, pumpkinX - 124, pumpkinY + 37, pumpkinX - 105, pumpkinY - 26);
    ctx.bezierCurveTo(pumpkinX - 93, pumpkinY - 80, pumpkinX - 36, pumpkinY - 104, pumpkinX, pumpkinY - 91);
    ctx.closePath();
    ctx.fill();
    // Sulcos curvos sutis para dar volume sem duplicar a forma da abóbora.
    ctx.strokeStyle = 'rgba(78, 34, 16, 0.38)';
    ctx.lineWidth = 5;
    for (const dx of [-48, -24, 24, 48]) {
        ctx.beginPath();
        ctx.ellipse(pumpkinX + dx, pumpkinY, 35, 78, 0, -1.1, 1.1);
        ctx.stroke();
    }
    ctx.fillStyle = '#554018';
    ctx.beginPath();
    ctx.moveTo(pumpkinX - 7, pumpkinY - 81);
    ctx.quadraticCurveTo(pumpkinX - 9, pumpkinY - 111, pumpkinX + 5, pumpkinY - 121);
    ctx.quadraticCurveTo(pumpkinX + 12, pumpkinY - 104, pumpkinX + 10, pumpkinY - 83);
    ctx.closePath(); ctx.fill();
    // Olhos triangulares, nariz pequeno e sorriso curvo igual ao ícone da imagem.
    ctx.fillStyle = 'rgba(40, 22, 15, 0.72)';
    for (const ex of [-42, 42]) {
        ctx.beginPath();
        ctx.moveTo(pumpkinX + ex - 17, pumpkinY - 25);
        ctx.lineTo(pumpkinX + ex + 17, pumpkinY - 25);
        ctx.lineTo(pumpkinX + ex, pumpkinY + 5);
        ctx.closePath(); ctx.fill();
    }
    // Nariz em triângulo apontado para cima, pequeno e central.
    ctx.beginPath();
    ctx.moveTo(pumpkinX, pumpkinY - 4);
    ctx.lineTo(pumpkinX - 12, pumpkinY + 20);
    ctx.lineTo(pumpkinX + 12, pumpkinY + 20);
    ctx.closePath(); ctx.fill();
    // Boca em sorriso largo e baixo, com duas pequenas entradas de dente.
    ctx.beginPath();
    ctx.moveTo(pumpkinX - 49, pumpkinY + 39);
    ctx.quadraticCurveTo(pumpkinX, pumpkinY + 67, pumpkinX + 49, pumpkinY + 39);
    ctx.quadraticCurveTo(pumpkinX + 38, pumpkinY + 62, pumpkinY + 23, pumpkinY + 52);
    ctx.lineTo(pumpkinX + 12, pumpkinY + 61);
    ctx.lineTo(pumpkinX, pumpkinY + 52);
    ctx.lineTo(pumpkinX - 12, pumpkinY + 61);
    ctx.lineTo(pumpkinX - 23, pumpkinY + 52);
    ctx.quadraticCurveTo(pumpkinX - 38, pumpkinY + 62, pumpkinX - 49, pumpkinY + 39);
    ctx.closePath(); ctx.fill();
    ctx.restore();

    // Cinco fantasminhas sem rosto: dois à esquerda, dois à direita e um
    // pequeno ao centro. Todos sobem e descem em ritmos ligeiramente diferentes.
    function drawGhost(cx, baseY, scale, alpha, phase) {
        const cy = baseY + Math.sin(t * Math.PI * 2 + phase) * 10;
        ctx.save();
        ctx.translate(cx, cy);
        ctx.scale(scale, scale);
        ctx.globalAlpha = alpha * 0.56;
        ctx.shadowColor = 'rgba(111, 91, 128, 0.10)';
        ctx.shadowBlur = 4;
        // Lavanda acinzentado escuro, igual aos fantasmas discretos da referência.
        ctx.fillStyle = '#625B70';
        ctx.beginPath();
        ctx.moveTo(-30, 34);
        ctx.lineTo(-30, -5);
        ctx.bezierCurveTo(-30, -27, -17, -41, 0, -41);
        ctx.bezierCurveTo(17, -41, 30, -27, 30, -5);
        ctx.lineTo(30, 34);
        ctx.quadraticCurveTo(20, 24, 10, 34);
        ctx.quadraticCurveTo(0, 44, -10, 34);
        ctx.quadraticCurveTo(-20, 24, -30, 34);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
    }
    // Fantasmas espalhados pelo fundo, como na referência, sem ocupar a área
    // principal do valor nem cobrir o nome do mediador.
    drawGhost(W * 0.175, H * 0.31, 1.36, 0.48, 0.2);
    drawGhost(W * 0.40, H * 0.22, 1.05, 0.42, 1.7);
    drawGhost(W * 0.52, H * 0.30, 1.08, 0.40, 2.1);
    drawGhost(W * 0.81, H * 0.15, 1.05, 0.43, 3.4);
    drawGhost(W * 0.56, H * 0.83, 0.93, 0.38, 4.5);
    drawGhost(W * 0.71, H * 0.83, 0.93, 0.38, 2.8);

    // Textura pontilhada fina, em tom escuro, por toda a superfície do cartão.
    ctx.save();
    ctx.globalAlpha = 0.10;
    ctx.fillStyle = '#8D6268';
    for (let y = 34; y < H - 20; y += 11) {
        for (let x = 28; x < W - 20; x += 11) ctx.fillRect(x, y, 2, 2);
    }
    ctx.restore();


}
function desenharContornoMMHalloween(ctx, cx, cy, r, frame, totalFrames) {
    const decorScale = r / 133;
    const t = ((frame % totalFrames) + totalFrames) % totalFrames / totalFrames;
    const pulse = 0.55 + 0.45 * Math.sin(t * Math.PI * 2);
    ctx.save();
    ctx.globalAlpha = 0.5 + pulse * 0.35;
    ctx.shadowColor = 'rgba(126, 25, 38, 0.78)';
    ctx.shadowBlur = (28 + pulse * 18) * decorScale;
    ctx.strokeStyle = '#70232F';
    ctx.lineWidth = 8 * decorScale;
    ctx.beginPath(); ctx.arc(cx, cy, r + 8 * decorScale, 0, Math.PI * 2); ctx.stroke();
    ctx.globalAlpha = 0.95;
    ctx.shadowBlur = 10 * decorScale;
    ctx.strokeStyle = '#FFC18A';
    ctx.lineWidth = 3 * decorScale;
    ctx.beginPath(); ctx.arc(cx, cy, r + 13 * decorScale, -Math.PI/2 + t*Math.PI*2, -Math.PI/2 + t*Math.PI*2 + Math.PI*0.72); ctx.stroke();
    ctx.strokeStyle = '#C7652F';
    ctx.beginPath(); ctx.arc(cx, cy, r + 13 * decorScale, Math.PI/2 + t*Math.PI*2, Math.PI/2 + t*Math.PI*2 + Math.PI*0.55); ctx.stroke();
    // Raios/flash ao redor da foto.
    ctx.strokeStyle = '#F4A36C'; ctx.lineWidth = 2 * decorScale; ctx.shadowBlur = 12 * decorScale;
    for (const a of [-2.45, -1.95, -1.45, -0.95, -0.45]) {
        const aa = a + t * 0.5;
        const x1 = cx + Math.cos(aa) * (r + 18 * decorScale), y1 = cy + Math.sin(aa) * (r + 18 * decorScale);
        const x2 = cx + Math.cos(aa) * (r + 30 * decorScale), y2 = cy + Math.sin(aa) * (r + 30 * decorScale);
        ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); ctx.stroke();
    }
    // Coroa limpa, pequena e separada do rosto, sem invadir o avatar.
    const crownY = cy - r - 14 * decorScale;
    ctx.save();
    ctx.fillStyle = '#310D17';
    ctx.strokeStyle = '#FFC18A';
    ctx.lineWidth = 4;
    ctx.shadowColor = 'rgba(126, 25, 38, 0.78)'; ctx.shadowBlur = 14;
    ctx.beginPath();
    ctx.moveTo(cx-r*0.42, crownY);
    ctx.lineTo(cx-r*0.34, crownY-26 * decorScale);
    ctx.lineTo(cx-r*0.12, crownY-10 * decorScale);
    ctx.lineTo(cx, crownY-34 * decorScale);
    ctx.lineTo(cx+r*0.13, crownY-10 * decorScale);
    ctx.lineTo(cx+r*0.35, crownY-26 * decorScale);
    ctx.lineTo(cx+r*0.43, crownY);
    ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#A8492A';
    roundRect(ctx, cx-r*0.46, crownY-2 * decorScale, r*0.92, 11 * decorScale, 4 * decorScale); ctx.fill(); ctx.stroke();
    ctx.restore();
    ctx.restore();
}

async function gerarCartaoVouchGif(opts = {}) {
    const { execFile } = require('child_process');
    const os = require('os');
    const fs = require('fs');
    const frames = Math.max(4, Number(opts.animationFrames || 36));
    const fps = Math.max(4, Number(opts.animationFps || 10));
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vouch-halloween-'));
    try {
        for (let i = 0; i < frames; i++) {
            const png = await gerarCartaoVouch({ ...opts, halloween: true, animationFrame: i, animationFrames: frames });
            fs.writeFileSync(path.join(dir, `frame-${String(i).padStart(3, '0')}.png`), png);
        }
        const out = path.join(dir, 'vouch-halloween.gif');
        await new Promise((resolve, reject) => execFile('ffmpeg', ['-y', '-framerate', String(fps), '-i', path.join(dir, 'frame-%03d.png'), '-vf', `split[s0][s1];[s0]palettegen=max_colors=256:stats_mode=single[p];[s1][p]paletteuse=new=1:dither=sierra2_4a`, out], (err, _stdout, stderr) => err ? reject(new Error(stderr || err.message)) : resolve()));
        return fs.readFileSync(out);
    } finally {
        fs.rmSync(dir, { recursive: true, force: true });
    }
}

async function gerarCartaoVouch(opts = {}) {
    // Verificação estrita de segurança de fonte
    const loadedFamilies = getActiveFontFamilies();
    const montserratLoaded = (fontRegStatus && fontRegStatus.montserratCount > 0) ||
        loadedFamilies.includes("Montserrat") ||
        (GlobalFonts && typeof GlobalFonts.has === "function" && GlobalFonts.has("Montserrat"));

    if (!montserratLoaded) {
        const errMsg = `[vouchCard ERRO CRÍTICO] A fonte 'Montserrat' não foi carregada no GlobalFonts! Famílias ativas: [${loadedFamilies.join(", ")}]. ` +
            `Certifique-se de que os arquivos Montserrat-*.ttf (Regular, Medium, SemiBold, Bold, ExtraBold) estejam presentes na pasta ./fonts/. ` +
            `Geração de card interrompida para evitar texto invisível.`;
        console.error(errMsg);
        throw new Error(errMsg);
    }

    const globalConfig = getCardConfig().vouchOptions || {};
    const vOpts = Object.assign({}, globalConfig, opts);

    // Paleta única: amarelo/dourado, sempre — aplicada ao título, valor,
    // molduras, perfil e patente.
    const palette = getPalette();
    // Amarelo suave para os detalhes; o valor intermediado mantém a paleta original.
    const softAccentPalette = {
        ...palette,
        GOLD_HIGH: '#FFD080', GOLD_1: '#F9A640', GOLD_2: '#F0782E',
        GOLD_3: '#C84B32', GOLD_4: '#78313A', GOLD_SOLID: '#E97B32',
        GOLD_SHADOW: 'rgba(240, 120, 46, 0.22)'
    };
    const whiteIconPalette = { ...palette, GOLD_SOLID: '#FFFFFF', GOLD_SHADOW: 'rgba(255,255,255,0.24)' };
    const halloween = vOpts.halloween === true;
    const animationFrame = Number(vOpts.animationFrame || 0);
    const animationFrames = Math.max(1, Number(vOpts.animationFrames || 36));
    const halloweenAccentColor = vOpts.halloweenTextColor || '#F9A640';
    const itemTexto = String(vOpts.item || '').trim();
    const halloweenTextPalette = { ...palette, GOLD_HIGH: '#FFD080', GOLD_1: '#F9A640', GOLD_2: '#F0782E', GOLD_3: '#C84B32', GOLD_4: '#78313A', GOLD_SOLID: '#E97B32', DARK_STAR: '#211821' };

    const titleText = vOpts.title || vOpts.vouchTitle || "VOUCHER DE INTERMEDIAÇÃO";
    const seloTexto = vOpts.seloTexto || vOpts.vouchSeloTexto || "INTERMEDIADOR VERIFICADO";
    const brandFooter = "NEUX MIDDLE";
    const showStars = vOpts.showStars !== undefined ? vOpts.showStars : (vOpts.vouchShowStars !== undefined ? vOpts.vouchShowStars : true);

    const nameFontSize = vOpts.nameFontSize || vOpts.vouchNameFontSize || 68;
    const titleFontSize = vOpts.titleFontSize || vOpts.vouchTitleFontSize || 56;
    const valorFontSize = vOpts.valorFontSize || vOpts.vouchValorFontSize || Math.round((vOpts.titleFontSize || vOpts.vouchTitleFontSize || 62) * 1.8);
    const valorLabelFontSize = vOpts.valorLabelFontSize || vOpts.vouchValorLabelFontSize || 34;
    const interFontSize = vOpts.interFontSize || vOpts.vouchInterFontSize || 24;
    const codeFontSize = vOpts.codeFontSize || vOpts.vouchCodeFontSize || 58;
    const avatarZoomR = Math.round(vOpts.avatarZoom || vOpts.vouchAvatarZoom || 102);

    const transacaoId = vOpts.transacaoId || "MM-1785439368477803";
    const vouchCodigo = vOpts.vouchCodigo || "#01645";
    const valorNum = typeof vOpts.valor === "number" ? vOpts.valor : (parseFloat(String(vOpts.valor || "1499.90").replace(",", ".")) || 1499.90);

    // Nome exibido no cartão. Por padrão continua sendo `staffNome` (ex: o
    // nome/apelido do Discord). Se você passar `staffNomeCompleto` (o nome
    // real completo da pessoa, tipo "João Silva"), o cartão troca
    // automaticamente e mostra só o SOBRENOME (última palavra) em vez do
    // nome do Discord — é só o bot buscar o nome completo de onde ele
    // estiver guardado (perfil, banco de dados, etc.) e passar aqui.
    let staffNome = vOpts.staffNome || "Seu nome ...";
    if (vOpts.staffNomeCompleto) {
        const partes = String(vOpts.staffNomeCompleto).trim().split(/\s+/).filter(Boolean);
        if (partes.length > 0) staffNome = partes[partes.length - 1];
    }

    const staffAvatarURL = vOpts.staffAvatarURL || "";
    const staffNota = typeof vOpts.staffNota === "number" ? vOpts.staffNota : 5.0;
    const staffIntermediacoes = vOpts.staffIntermediacoes !== undefined ? vOpts.staffIntermediacoes : 128;

    // Patente/rank exibida ao lado do nome. Sobe sozinha conforme
    // staffIntermediacoes (ver RANK_TIERS lá em cima). Dá pra sobrescrever
    // passando vOpts.rankNome, se precisar de um caso manual.
    const rankNome = vOpts.rankNome || vOpts.staffRank || getRankPorIntermediacoes(staffIntermediacoes);

    const compradorNome = vOpts.compradorNome || "Neeux MM Services (2)";
    const compradorAvatarURL = vOpts.compradorAvatarURL || "";
    const vendedorAnonimo = vOpts.vendedorAnonimo === true || vOpts.anonymous === true;
    const vendedorNome = vendedorAnonimo ? "ANÔNIMO" : (vOpts.vendedorNome || "Neeux MM Services (2)");
    const vendedorAvatarURL = vendedorAnonimo ? "__ANONYMOUS__" : (vOpts.vendedorAvatarURL || "");
    const dataStr = vOpts.data || "30/07/2026";

    const W = 1729, H = 910;
    const canvas = createCanvas(W, H);
    const ctx = canvas.getContext("2d");

    // Base ameixa quase-preta para realçar o vermelho-vinho do fundo.
    ctx.fillStyle = "#15131A";
    ctx.fillRect(0, 0, W, H);

    const sombraBase = vOpts.sombraBase !== undefined ? Number(vOpts.sombraBase) : 0.12;
    const sombraForca = vOpts.sombraForca !== undefined ? Number(vOpts.sombraForca) : 0.85;
    desenharHalloween(ctx, W, H, palette, animationFrame, animationFrames, sombraBase, sombraForca);

    // Linha MÉDIA externa (5px, colada na ponta do cartão)
    strokeRectDegrade(ctx, 0, 0, W, H, [
        [0.00, "#FF7A2E"], [0.45, "#F2692F"], [0.78, "#C4587A"], [1.00, "#8A63BC"]
    ], 5, W, H, "rgba(240, 120, 46, 0.45)", 6);

    // Linha FINA interna, mais afastada da média (animada: completa, some e recomeça)
    desenharLinhaFinaAnimada(ctx, W, H, animationFrame, animationFrames, vOpts.animationFrame !== undefined);

    // 1. TÍTULO PRINCIPAL ("VOUCHER DE INTERMEDIAÇÃO")
    ctx.font = `800 ${titleFontSize}px ${FONT_STACK}`;
    ctx.textAlign = "left";
    const titleLetterSpacing = 3;
    let titleCursorX = 65;
    for (const titleChar of Array.from(titleText)) {
        fillTextGradient(ctx, titleChar, titleCursorX, 118, titleFontSize, softAccentPalette, "left");
        titleCursorX += ctx.measureText(titleChar).width + titleLetterSpacing;
    }

    // Linha sob o título, ajustada ao texto com espaçamento entre letras.
    const titleDrawWidth = Math.max(0, titleCursorX - 65 - titleLetterSpacing);
    const titleUnderlineW = Math.max(157, titleDrawWidth * 0.42);
    strokeGlowLine(ctx, 89, 168, 89 + titleUnderlineW, 168, softAccentPalette, 2.5);

    // 2. ID DA TRANSAÇÃO (Canto Superior Direito)
    const rightColX = 1179;
    ctx.textAlign = "left";
    ctx.font = `500 22px ${FONT_STACK}`;
    ctx.fillStyle = palette.TEXT_MUTED;
    ctx.fillText("ID DA TRANSAÇÃO", rightColX, 82);

    ctx.fillStyle = "#FFFFFF";
    ctx.font = `500 26px ${FONT_STACK}`;
    ctx.fillText(transacaoId, rightColX, 122);
    const idValW = ctx.measureText(transacaoId).width;
    drawCopyIcon(ctx, rightColX + idValW + 30, 108, 24, softAccentPalette);

    // 3. CÓDIGO DO VOUCH (Caixa Central Direita — posição original, fixa)
    const boxW = 530, boxH = 94;
    const boxX = 1112, boxY = 215;
    const labelCx = boxX + boxW / 2;

    // Label "CÓDIGO DO VOUCH" em metálico
    ctx.font = `500 20px ${FONT_STACK}`;
    ctx.fillStyle = palette.TEXT_MUTED;
    ctx.textAlign = "center";
    ctx.fillText("CÓDIGO DO VOUCH", labelCx, 210);
    ctx.textAlign = "left";
    const labelW = ctx.measureText("CÓDIGO DO VOUCH").width;
    strokeGlowLine(ctx, boxX, 203, labelCx - labelW / 2 - 20, 203, softAccentPalette, 1.5);
    strokeGlowLine(ctx, labelCx + labelW / 2 + 20, 203, boxX + boxW, 203, softAccentPalette, 1.5);

    strokeGlowRoundRect(ctx, boxX, boxY, boxW, boxH, 12, softAccentPalette, 2.5);
    ctx.font = `800 ${codeFontSize}px ${FONT_STACK}`;
    ctx.fillStyle = "#FFFFFF";
    ctx.textAlign = "center";
    ctx.fillText(vouchCodigo, labelCx, boxY + 64);
    ctx.textAlign = "left";

    // 4. VALOR INTERMEDIADO
    const valorMaxWidth = 640;
    const valorPrefixStr = "R$ ";
    const valorNumeroStr = valorNum.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
    const valorFmt = `${valorPrefixStr}${valorNumeroStr}`;

    const valorFontSizeBase = Math.round(titleFontSize * 1.82);
    const valorFontSizeAjustado = ajustarTamanhoFonteParaLargura(ctx, valorFmt, 800, valorFontSizeBase, valorMaxWidth, 36);
    const valorPrefixFontSize = valorFontSizeAjustado;

    ctx.font = `800 ${valorFontSizeAjustado}px ${FONT_STACK}`;
    const valorNumeroW = ctx.measureText(valorNumeroStr).width;
    const valorPrefixW = ctx.measureText(valorPrefixStr).width;
    const valorTotalW = valorNumeroW + valorPrefixW;

    const labelValorY = 388;
    const valorY = labelValorY + valorFontSizeAjustado + 34;

    const warmValuePalette = {
        ...palette,
        GOLD_HIGH: '#FFD21F', GOLD_1: '#F9A640', GOLD_2: '#F0782E',
        GOLD_3: '#C84B32', GOLD_4: '#78313A'
    };
    ctx.font = `500 ${valorLabelFontSize}px ${FONT_STACK}`;
    ctx.textAlign = "center";
    fillTextGradient(ctx, "VALOR INTERMEDIADO", labelCx, labelValorY, valorLabelFontSize, warmValuePalette, "center");
    ctx.textAlign = "left";

    // Brilho âmbar discreto sob o valor e degradê laranja-dourado igual à referência.
    const valorStartX = labelCx - valorTotalW / 2;
    ctx.save();
    ctx.shadowColor = "rgba(240, 132, 48, 0.30)";
    ctx.shadowBlur = 14;
    ctx.font = `800 ${valorPrefixFontSize}px ${FONT_STACK}`;
    ctx.fillStyle = "#F6A640";
    ctx.fillText(valorPrefixStr, valorStartX, valorY);
    ctx.font = `800 ${valorFontSizeAjustado}px ${FONT_STACK}`;
    ctx.fillText(valorNumeroStr, valorStartX + valorPrefixW, valorY);
    ctx.restore();
    ctx.font = `800 ${valorPrefixFontSize}px ${FONT_STACK}`;
    fillTextGradient(ctx, valorPrefixStr, valorStartX, valorY, valorPrefixFontSize, warmValuePalette, "left");
    ctx.font = `800 ${valorFontSizeAjustado}px ${FONT_STACK}`;
    fillTextGradient(ctx, valorNumeroStr, valorStartX + valorPrefixW, valorY, valorFontSizeAjustado, warmValuePalette, "left");
    desenharBrilhoTextoMovel(ctx, valorPrefixStr, valorStartX, valorY, valorPrefixFontSize, animationFrame, animationFrames);
    desenharBrilhoTextoMovel(ctx, valorNumeroStr, valorStartX + valorPrefixW, valorY, valorFontSizeAjustado, animationFrame, animationFrames);
    if (itemTexto) {
        ctx.font = `500 18px ${FONT_STACK}`;
        fillTextGradient(ctx, 'ITEM', labelCx, 548, 18, softAccentPalette, 'center');
        ctx.fillStyle = halloween ? halloweenAccentColor : '#FFFFFF';
        ctx.font = `600 22px ${FONT_STACK}`;
        const itemExibido = truncarComReticencias(ctx, itemTexto, 540);
        ctx.textAlign = 'center';
        ctx.fillText(itemExibido, labelCx, 583);
        ctx.textAlign = 'left';
    }

    // 5. AVATAR + INFORMAÇÕES DO STAFF / USER (Esquerda)
    const avX = 246, avY = 393, avR = avatarZoomR;
    await desenharAvatarCirculo(ctx, avX, avY, avR, staffAvatarURL || staffNome, palette);
    if (halloween) {
        // Aro de base em vinho e cobre escuro, sem amarelo forte.
        ctx.save();
        ctx.shadowColor = 'rgba(126, 25, 38, 0.70)';
        ctx.shadowBlur = 12;
        ctx.strokeStyle = '#70232F';
        ctx.lineWidth = 5;
        ctx.beginPath(); ctx.arc(avX, avY, avR + 3, 0, Math.PI * 2); ctx.stroke();
        ctx.strokeStyle = '#FFC18A';
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(avX, avY, avR + 7, 0, Math.PI * 2); ctx.stroke();
        ctx.restore();
        desenharContornoMMHalloween(ctx, avX, avY, avR, animationFrame, animationFrames);
    } else {
        strokeGlowCircle(ctx, avX, avY, avR + 3, palette, 5.5);
    }
    const infoX = avX + avR + 58;
    ctx.fillStyle = "#F0D7C8";
    // Nome principal (staff/mediador): Montserrat ExtraBold.
    ctx.font = `800 ${nameFontSize}px ${NAME_FONT_STACK}`;
    // Patente (BRONZE, PRATA...) quase do tamanho do nome. Calculamos a pílula
    // primeiro e deixamos o nome usar só o espaço que sobra até a caixa do
    // código (x ~1090), assim o nome nunca encosta/bugar na patente.
    const rankFontSize = Math.round(nameFontSize * 0.56);
    const rankPillH = Math.round(nameFontSize * 0.92);
    ctx.font = `700 ${rankFontSize}px ${FONT_STACK}`;
    const rankTextW = ctx.measureText(rankNome).width;
    const rankPillW = rankTextW + Math.round(rankFontSize * 1.6);
    const rankGap = 26;
    const limiteDireito = 1090;
    const nomeMaxW = Math.max(150, Math.min(520, limiteDireito - infoX - rankGap - rankPillW));

    ctx.font = `800 ${nameFontSize}px ${NAME_FONT_STACK}`;
    const staffNomeExibido = truncarComReticencias(ctx, staffNome, nomeMaxW);
    ctx.fillStyle = "#F0D7C8";
    ctx.fillText(staffNomeExibido, infoX, 342);
    const nomeW = ctx.measureText(staffNomeExibido).width;

    const capMid = 342 - nameFontSize * 0.36;      // meio das letras do nome
    const rankPillX = infoX + nomeW + rankGap;
    const rankPillY = capMid - rankPillH / 2;
    ctx.save();
    roundRect(ctx, rankPillX, rankPillY, rankPillW, rankPillH, rankPillH / 2);
    ctx.fillStyle = '#0D0B10';
    ctx.fill();
    ctx.strokeStyle = 'rgba(255, 138, 61, 0.90)';
    ctx.lineWidth = 3;
    ctx.shadowColor = 'rgba(255, 138, 61, 0.30)';
    ctx.shadowBlur = 5;
    ctx.stroke();
    ctx.restore();
    ctx.save();
    ctx.fillStyle = '#FF9A4D';
    ctx.font = `700 ${rankFontSize}px ${FONT_STACK}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'alphabetic';
    ctx.fillText(rankNome, rankPillX + rankPillW / 2, capMid + rankFontSize * 0.35);
    ctx.restore();

    // Estrelas + nota ocupam a posição onde ficava o selo removido.
    let nextY = 433;
    if (showStars) {
        const notaArred = Math.max(0, Math.min(5, Math.round(staffNota)));
        let starX = infoX;
        const starY = 407, starR = 18;
        const starPalette = {
            ...softAccentPalette,
            GOLD_HIGH: '#FFE066', GOLD_1: '#FFC133', GOLD_2: '#FFB21A',
            GOLD_3: '#FF9A1A', GOLD_4: '#FF8A00', GOLD_SOLID: '#FFB21A',
            DARK_STAR: '#2A1F24'
        };
        for (let i = 0; i < 5; i++) {
            drawStar(ctx, starX + starR, starY, starR, i < notaArred, starPalette);
            starX += starR * 2 + 14;
        }
        ctx.font = `600 24px ${FONT_STACK}`;
        fillTextGradient(ctx, staffNota.toFixed(1), starX + 14, 419, 24, starPalette, "left");
        nextY = 479;
    }

    // Intermediações: um pouco menores, brancas e alinhadas à direita.
    drawList(ctx, infoX + 24, nextY, 18, "#FFFFFF");
    const interDisplayFontSize = Math.max(16, Math.round(interFontSize * 0.82));
    ctx.font = `500 ${interDisplayFontSize}px ${FONT_STACK}`;
    ctx.fillStyle = "#FFFFFF";
    ctx.textAlign = "left";
    ctx.fillText(`${staffIntermediacoes}  INTERMEDIAÇÕES`, infoX + 48, nextY + 9);

    // 6. BLOCO RODAPÉ (Comprador / Vendedor / Data / Brand)
    const footX = 83, footY = 633, footW = 1563, footH = 194;
    // Conteúdo do rodapé ligeiramente mais baixo e mais compacto.
    const cyCirc = footY + footH / 2 + 36;

    const footLineY = footY + 18;
    ctx.save();
    const footLineGrad = ctx.createLinearGradient(footX, 0, footX + footW, 0);
    footLineGrad.addColorStop(0.00, softAccentPalette.GOLD_4);
    footLineGrad.addColorStop(0.15, softAccentPalette.GOLD_2);
    footLineGrad.addColorStop(0.50, softAccentPalette.GOLD_HIGH);
    footLineGrad.addColorStop(0.85, softAccentPalette.GOLD_2);
    footLineGrad.addColorStop(1.00, softAccentPalette.GOLD_4);
    ctx.strokeStyle = footLineGrad;
    // Linha do rodapé mais suave, mantendo a separação entre as seções.
    ctx.globalAlpha = 0.48;
    ctx.lineWidth = 1.5;
    ctx.lineCap = "butt";
    ctx.beginPath();
    ctx.moveTo(footX, footLineY);
    ctx.lineTo(footX + footW, footLineY);
    ctx.stroke();
    ctx.restore();

    const circR = 38;

    async function desenharParte(cx, letra, avatarURL, label, nome, maxNomeWidth = 300) {
        await desenharAvatarCirculo(ctx, cx, cyCirc, circR, avatarURL || letra, palette);
        const textX = cx + 70;

        ctx.save();
        ctx.globalAlpha = 0.65;
        ctx.fillStyle = palette.TEXT_MUTED;
        ctx.font = `500 16px ${FONT_STACK}`;
        ctx.fillText(label, textX, cyCirc - 4);
        ctx.restore();

        ctx.fillStyle = "#FFFFFF";
        ctx.font = `600 23px ${FONT_STACK}`;
        // Nome truncado com "..." se for grande demais, pra não bugar o
        // alinhamento com o selo de verificado logo depois do nome.
        const nomeExibido = truncarComReticencias(ctx, nome, maxNomeWidth);
        ctx.fillText(nomeExibido, textX, cyCirc + 30);
        const nomeW2 = ctx.measureText(nomeExibido).width;
        drawCheckOutlineBadge(ctx, textX + nomeW2 + 22, cyCirc + 14, 14, softAccentPalette);
    }

    await desenharParte(footX + 82, "C", compradorAvatarURL, "COMPRADOR", compradorNome);
    await desenharParte(footX + footW * 0.330 + 73, "V", vendedorAvatarURL, "VENDEDOR", vendedorNome);

    const dataCx = footX + footW * 0.651 + 63, dataCy = cyCirc;
    drawCalendar(ctx, dataCx, dataCy, 24, whiteIconPalette);

    ctx.save();
    ctx.globalAlpha = 0.65;
    ctx.fillStyle = palette.TEXT_MUTED;
    ctx.font = `500 16px ${FONT_STACK}`;
    ctx.fillText("DATA", dataCx + 42, dataCy - 4);
    ctx.restore();

    ctx.fillStyle = "#FFFFFF";
    ctx.font = `600 23px ${FONT_STACK}`;
    ctx.fillText(dataStr, dataCx + 42, dataCy + 30);

    ctx.font = `500 18px ${FONT_STACK}`;
    ctx.fillStyle = '#FFFFFF';
    ctx.fillText(brandFooter, footX + footW * 0.832 + 6, cyCirc + 8);

    return canvas.toBuffer("image/png");
}

export { gerarCartaoVouch, gerarCartaoVouchGif };
export default { gerarCartaoVouch, gerarCartaoVouchGif };
if (typeof module !== "undefined" && module.exports) {
    module.exports = { gerarCartaoVouch, gerarCartaoVouchGif };
}
