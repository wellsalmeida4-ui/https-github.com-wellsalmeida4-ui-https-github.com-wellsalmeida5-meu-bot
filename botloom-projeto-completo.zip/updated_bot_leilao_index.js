const fs = require("fs");
const { 
    SlashCommandBuilder, ApplicationCommandOptionType, Client, GatewayIntentBits, 
    EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ModalBuilder, 
    TextInputBuilder, TextInputStyle, ChannelType, PermissionsBitField, 
    PermissionFlagsBits, ButtonBuilder, ButtonStyle, MessageFlags 
} = require("discord.js");

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers
    ]
});

const STAFF_ROLE_ID = "1256338006504280084";
const TICKET_CATEGORY_ID = "1283870810334855238";
const AUCTION_CATEGORY_ID = "1343714247548272782";
const LOG_CHANNEL_ID = "1343714247548272782";

const dadosLeilao = new Map();
const lancesAtuais = new Map();
let pixConfig = {};

// Carrega persistência de leilões se existir
try {
    if (fs.existsSync("dados_leilao.json")) {
        const salvos = JSON.parse(fs.readFileSync("dados_leilao.json", "utf8"));
        Object.keys(salvos).forEach(chId => dadosLeilao.set(chId, salvos[chId]));
    }
} catch (e) {}

function salvarDadosLeilao() {
    try {
        const obj = {};
        dadosLeilao.forEach((val, key) => { obj[key] = val; });
        fs.writeFileSync("dados_leilao.json", JSON.stringify(obj, null, 2));
    } catch (e) {}
}

function crc16(payload) {
    let polinomio = 0x1021;
    let resultado = 0xFFFF;
    for (let i = 0; i < payload.length; i++) {
        resultado ^= payload.charCodeAt(i) << 8;
        for (let j = 0; j < 8; j++) {
            if (resultado & 0x8000) resultado = (resultado << 1) ^ polinomio;
            else resultado <<= 1;
            resultado &= 0xFFFF;
        }
    }
    return resultado.toString(16).toUpperCase().padStart(4, "0");
}

function getPixConfig() {
    if (typeof pixConfig !== "undefined" && pixConfig && pixConfig.chave && pixConfig.nome) {
        return pixConfig;
    }
    try {
        if (fs.existsSync("config.json")) {
            const parsed = JSON.parse(fs.readFileSync("config.json", "utf8"));
            if (parsed && parsed.chave) {
                pixConfig = parsed;
                return pixConfig;
            }
        }
    } catch (e) {}
    try {
        if (fs.existsSync("pix_database.json")) {
            const db = JSON.parse(fs.readFileSync("pix_database.json", "utf8"));
            const firstKeyId = Object.keys(db).find(k => k !== "keys" && k !== "activeKey" && db[k] && db[k].chave);
            if (firstKeyId && db[firstKeyId]) {
                pixConfig = { chave: db[firstKeyId].chave, nome: db[firstKeyId].nome || "RECEBEDOR" };
                return pixConfig;
            }
        }
    } catch (e) {}
    pixConfig = { chave: "Kauaantunes310@gmail.com", nome: "Kauã Antunes Martins" };
    return pixConfig;
}

function getPixQR(valor = 1.00) {
    const config = getPixConfig();
    const chave = (config.chave || "Kauaantunes310@gmail.com").trim();
    const nome = (config.nome || "Kauã Antunes Martins").trim().substring(0, 25).toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    const valorF = parseFloat(valor || 1.00).toFixed(2);
    
    const merchantAccount = "0014br.gov.bcb.pix01" + chave.length.toString().padStart(2, "0") + chave;
    const txid = "LEILAO";
    const field62 = "05" + txid.length.toString().padStart(2, "0") + txid;
    
    let payload = "00020101021126" + merchantAccount.length.toString().padStart(2, "0") + merchantAccount +
        "52040000530398654" + valorF.length.toString().padStart(2, "0") + valorF +
        "5802BR59" + nome.length.toString().padStart(2, "0") + nome +
        "6009SAO PAULO62" + field62.length.toString().padStart(2, "0") + field62 + "6304";
    const fullCode = payload + crc16(payload);
    const link = "https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=" + encodeURIComponent(fullCode);
    
    return { link, code: fullCode };
}

function formatarNomeCanal(desc) {
    let limpo = (desc || "").toLowerCase()
        .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
        .replace(/[^a-z0-9\s-]/g, "")
        .replace(/\s+/g, "-");
    return limpo.substring(0, 20) || "pet";
}

function criarPainelEmbedERow() {
    const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle("🔨 Anunciar Leilão")
        .setDescription("# Criar Leilão de Pet / Item\n\nClique no botão abaixo para preencher os dados e iniciar o anúncio do seu pet no leilão!\n\n**Categorias disponíveis:**\n- 💎 **500M PG**\n- 🧠 **Brainrot**\n- 🔮 **Secret**\n- ⚡ **Godly**\n- 👑 **OG**\n- 📦 **Geral**");

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("iniciar_anuncio_leilao")
            .setLabel("Anunciar Leilão")
            .setStyle(ButtonStyle.Success)
            .setEmoji("🔨")
    );
    return { embed, row };
}

client.once("ready", async () => {
    console.log("[DISCORD] Logado como " + client.user.tag);
    try {
        const commands = [
            new SlashCommandBuilder().setName("painelleilao").setDescription("Posta o painel de criação de leilão"),
            new SlashCommandBuilder().setName("setup_leilao").setDescription("Posta o painel de criação de leilão"),
            new SlashCommandBuilder().setName("leilao").setDescription("Posta o painel de criação de leilão"),
            new SlashCommandBuilder()
                .setName("pixleilao")
                .setDescription("Configura a chave Pix para a taxa de leilão")
                .addStringOption(opt => opt.setName("chave").setDescription("Chave Pix (ex: email, CPF)").setRequired(true))
                .addStringOption(opt => opt.setName("nome").setDescription("Nome do titular").setRequired(true))
                .addStringOption(opt => opt.setName("id_atendente").setDescription("ID do atendente no Discord").setRequired(false))
        ];
        await client.application.commands.set(commands);
        console.log("[DISCORD] Comandos Slash registrados com sucesso!");
    } catch (e) {
        console.error("Erro ao registrar comandos Slash:", e);
    }
});

client.on("interactionCreate", async (interaction) => {
    try {
        if (interaction.isChatInputCommand()) {
            const cmd = interaction.commandName.toLowerCase();
            if (cmd === "painelleilao" || cmd === "setup_leilao" || cmd === "leilao") {
                const { embed, row } = criarPainelEmbedERow();
                try {
                    await interaction.reply({ embeds: [embed], components: [row] });
                } catch (eReply) {
                    await interaction.channel.send({ embeds: [embed], components: [row] }).catch(() => {});
                    if (!interaction.replied && !interaction.deferred) {
                        await interaction.reply({ content: "✅ Painel enviado com sucesso!", ephemeral: true }).catch(() => {});
                    }
                }
            } else if (cmd === "pixleilao") {
                await handlePixLeilaoCommand(interaction);
            } else {
                await interaction.reply({ content: `✅ Comando /${cmd} recebido.`, ephemeral: true }).catch(() => {});
            }
        } else if (interaction.isButton()) {
            const cid = interaction.customId;
            if (cid === "iniciar_anuncio_leilao" || cid === "criar_leilao" || cid === "btn_criar_leilao" || cid === "anunciar_leilao" || cid === "setup_leilao") {
                const modal = new ModalBuilder()
                    .setCustomId("modal_anuncio_1")
                    .setTitle("Anunciar Leilão");

                modal.addComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder().setCustomId("desc").setLabel("Descrição do Pet / Item").setStyle(TextInputStyle.Short).setPlaceholder("Ex: 500M PG, Huge Cat, Dragon").setRequired(true)
                    ),
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder().setCustomId("valor").setLabel("Valor In-Game / Estatísticas").setStyle(TextInputStyle.Short).setPlaceholder("Ex: 500M Gems, 10M Dmg").setRequired(true)
                    ),
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder().setCustomId("min").setLabel("Lance Inicial (R$)").setStyle(TextInputStyle.Short).setPlaceholder("Ex: 10.00").setRequired(true)
                    ),
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder().setCustomId("max").setLabel("Auto-Buy / Comprar Já (R$)").setStyle(TextInputStyle.Short).setPlaceholder("Ex: 50.00").setRequired(true)
                    )
                );
                await interaction.showModal(modal);
            } else if (cid === "copy_pix") {
                await copiarCodigoPix(interaction);
            } else if (cid === "aprovar_final") {
                await publicarLeilaoOficial(interaction);
            } else if (cid === "reivindicar_pagamento") {
                await reivindicarPagamento(interaction);
            } else if (cid === "fechar_ticket") {
                await interaction.reply({ content: "🔒 Fechando ticket em 5 segundos..." }).catch(() => {});
                setTimeout(() => {
                    if (interaction.channel) interaction.channel.delete().catch(() => {});
                }, 5000);
            } else if (cid === "btn_dar_lance") {
                await handleLanceButtonModal(interaction);
            } else if (cid === "btn_comprar_ja") {
                const leilao = lancesAtuais.get(interaction.channel.id);
                if (!leilao) return interaction.reply({ content: "Este não é um canal de leilão ativo.", ephemeral: true }).catch(() => {});
                await interaction.reply({ content: "⚡ **COMPRA INSTANTÂNEA (AUTO-BUY)!**\n\n<@" + interaction.user.id + "> comprou o item por **R$ " + leilao.max.toFixed(2) + "**! O leilão foi encerrado com sucesso! 🎉" }).catch(() => {});
            } else {
                if (!interaction.replied && !interaction.deferred) {
                    await interaction.reply({ content: "✅ Ação de botão processada.", ephemeral: true }).catch(() => {});
                }
            }
        } else if (interaction.isStringSelectMenu()) {
            if (interaction.customId === "select_categoria_leilao") {
                await processarSelecaoCategoria(interaction);
            } else {
                if (!interaction.replied && !interaction.deferred) {
                    await interaction.reply({ content: "✅ Categoria selecionada.", ephemeral: true }).catch(() => {});
                }
            }
        } else if (interaction.isModalSubmit()) {
            if (interaction.customId === "modal_anuncio_1") {
                await interaction.deferReply({ ephemeral: true }).catch(() => {});
                const desc = interaction.fields.getTextInputValue("desc");
                const valor = interaction.fields.getTextInputValue("valor");
                const min = interaction.fields.getTextInputValue("min");
                const max = interaction.fields.getTextInputValue("max");

                let canal;
                try {
                    let parentCat = interaction.guild ? interaction.guild.channels.cache.get(TICKET_CATEGORY_ID) : null;
                    if (!parentCat && interaction.guild) {
                        parentCat = interaction.guild.channels.cache.find(c => c.type === ChannelType.GuildCategory && (c.name.toLowerCase().includes("ticket") || c.name.toLowerCase().includes("leilao")));
                    }
                    const channelName = ("ticket-" + interaction.user.username).toLowerCase().replace(/[^a-z0-9_-]/g, "");
                    const permissions = [
                        { id: interaction.guild ? interaction.guild.roles.everyone.id : interaction.user.id, deny: [PermissionsBitField.Flags.ViewChannel] },
                        { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.AttachFiles] }
                    ];
                    if (STAFF_ROLE_ID && interaction.guild && interaction.guild.roles.cache.has(STAFF_ROLE_ID)) {
                        permissions.push({ id: STAFF_ROLE_ID, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] });
                    }
                    const createOpts = {
                        name: channelName,
                        type: ChannelType.GuildText,
                        permissionOverwrites: permissions
                    };
                    if (parentCat) createOpts.parent = parentCat.id;
                    canal = interaction.guild ? await interaction.guild.channels.create(createOpts) : null;
                } catch (eChan) {
                    console.error("Erro ao criar canal no parent:", eChan);
                    canal = interaction.guild ? await interaction.guild.channels.create({
                        name: ("ticket-" + interaction.user.username).toLowerCase().replace(/[^a-z0-9_-]/g, ""),
                        type: ChannelType.GuildText
                    }).catch(() => null) : null;
                }

                if (!canal) {
                    return interaction.editReply({ content: "❌ Erro ao criar o canal do ticket. Verifique permissões do bot ou tente em um servidor." }).catch(() => {});
                }

                dadosLeilao.set(canal.id, {
                    userId: interaction.user.id,
                    username: interaction.user.username,
                    desc, valor, min, max,
                    imagens: [],
                    pixCode: null
                });
                salvarDadosLeilao();

                const embedWelcome = new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle("🔨 Anúncio de Leilão - " + interaction.user.username)
                    .setDescription("# Etapa 1 — Seleção de Categoria\n\n**Item:** " + desc + "\n**Valor in-game:** " + valor + "\n**Lance inicial:** R$ " + min + "\n**Auto-Buy:** R$ " + max + "\n\n📸 **Envie as fotos do seu pet no chat e selecione a categoria abaixo para gerar a taxa Pix.**");

                const menu = new ActionRowBuilder().addComponents(
                    new StringSelectMenuBuilder().setCustomId("select_categoria_leilao").setPlaceholder("Selecione a Categoria").addOptions([
                        { label: "500M PG", value: "1.00_500M PG", description: "Categoria 500M PG (Pet Go)" },
                        { label: "Brainrot", value: "1.00_Brainrot", description: "Pets Brainrot" },
                        { label: "Secret", value: "1.00_Secret", description: "Pets Secret" },
                        { label: "Godly", value: "1.00_Godly", description: "Pets Godly" },
                        { label: "OG", value: "1.00_OG", description: "Pets e Itens OG" },
                        { label: "Geral / Outros", value: "1.00_Geral", description: "Outras categorias de Leilão" }
                    ])
                );

                await canal.send({ content: "<@" + interaction.user.id + ">", embeds: [embedWelcome], components: [menu] }).catch(() => {});
                await interaction.editReply({ content: "✅ Ticket de leilão criado com sucesso: " + canal }).catch(() => {});
            } else if (interaction.customId === "modal_dar_lance") {
                await handleLanceModalSubmit(interaction);
            } else {
                if (!interaction.replied && !interaction.deferred) {
                    await interaction.reply({ content: "✅ Formulário enviado com sucesso!", ephemeral: true }).catch(() => {});
                }
            }
        }

        // Safety fallback to prevent 'Aplicativo não respondeu' on any edge case
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({ content: "✅ Ação concluída com sucesso!", ephemeral: true }).catch(() => {});
        }
    } catch (err) {
        console.error("Erro no manipulador de interações:", err);
        try {
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({ content: "❌ Ocorreu um erro ao processar esta ação. Tente novamente.", ephemeral: true }).catch(() => {});
            } else if (interaction.deferred) {
                await interaction.editReply({ content: "❌ Ocorreu um erro ao processar esta ação. Tente novamente." }).catch(() => {});
            }
        } catch (eErr) {}
    }
});

client.on("messageCreate", async (message) => {
    if (message.author.bot) return;
    const content = message.content.trim().toLowerCase();

    if (content === "!setup_leilao" || content === "!painelleilao" || content === "!leilao" || content === "/setup_leilao" || content === "/painelleilao") {
        const { embed, row } = criarPainelEmbedERow();
        await message.channel.send({ embeds: [embed], components: [row] });
        return;
    }

    await processarAnexosTicket(message);
});

async function copiarCodigoPix(interaction) {
    try {
        let info = dadosLeilao.get(interaction.channel.id);
        let code = info ? info.pixCode : null;
        if (!code) {
            const pix = getPixQR(1.00);
            code = pix.code;
            if (info) info.pixCode = code;
        }
        if (!code) {
            return interaction.reply({ 
                content: "❌ Nenhuma chave Pix configurada no momento. Use /pixleilao para configurar.", 
                ephemeral: true 
            });
        }
        await interaction.reply({ content: "📋 **Código Pix Copia e Cola:**\n```" + code + "```", ephemeral: true });
    } catch (e) {
        console.error("Erro em copiarCodigoPix:", e);
    }
}

async function processarSelecaoCategoria(interaction) {
    try {
        await interaction.deferUpdate();
        const selected = interaction.values[0] || "1.00_Pet";
        const [preco, cat] = selected.split("_");

        let info = dadosLeilao.get(interaction.channel.id);
        if (!info) {
            info = {
                userId: interaction.user.id,
                username: interaction.user.username,
                desc: "Pet Leilão",
                valor: "N/A",
                min: "1.00",
                max: "100.00",
                imagens: []
            };
        }
        info.catPreco = preco;
        info.catNome = cat;

        const pix = getPixQR(preco);
        info.pixCode = pix.code;
        salvarDadosLeilao();

        const embedPix = new EmbedBuilder()
            .setColor(0x22C55E)
            .setTitle("💳 Pagamento da Taxa de Anúncio (" + cat + ")")
            .setDescription("# Pagamento da Taxa Pix\n\n**Valor da Taxa:** R$ " + parseFloat(preco).toFixed(2) + "\n**Categoria Selecionada:** " + cat + "\n**Total de fotos enviadas:** " + (info.imagens ? info.imagens.length : 0) + "\n\n*Escaneie o QR Code abaixo ou clique em **Copiar Pix** para realizar o pagamento.*")
            .setImage(pix.link);

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("copy_pix").setLabel("Copiar Pix").setStyle(ButtonStyle.Secondary).setEmoji("📋"),
            new ButtonBuilder().setCustomId("aprovar_final").setLabel("Postar Leilão").setStyle(ButtonStyle.Success).setEmoji("🚀"),
            new ButtonBuilder().setCustomId("reivindicar_pagamento").setLabel("Reivindicar Pagamento").setStyle(ButtonStyle.Primary).setEmoji("🙋"),
            new ButtonBuilder().setCustomId("fechar_ticket").setLabel("Fechar Ticket").setStyle(ButtonStyle.Danger).setEmoji("🔒")
        );

        await interaction.editReply({ embeds: [embedPix], components: [row] });
    } catch (error) {
        console.error("Erro no processarSelecaoCategoria:", error);
    }
}

async function publicarLeilaoOficial(interaction) {
    const dados = dadosLeilao.get(interaction.channel.id);
    if (!dados) return interaction.reply({ content: "❌ Dados do leilão não encontrados neste canal.", ephemeral: true });

    if (STAFF_ROLE_ID && interaction.member && interaction.member.roles) {
        const isStaff = interaction.member.roles.cache.has(STAFF_ROLE_ID);
        const isAdmin = interaction.member.permissions && interaction.member.permissions.has(PermissionFlagsBits.Administrator);
        const isOwner = dados.userId === interaction.user.id;
        if (!isStaff && !isAdmin && !isOwner) {
            return interaction.reply({ content: "❌ Apenas Staff, Administradores ou o criador do leilão podem postar.", ephemeral: true });
        }
    }

    await interaction.deferReply({ ephemeral: true }).catch(() => {});

    let canalPost;
    try {
        let parentCat = interaction.guild.channels.cache.get(AUCTION_CATEGORY_ID);
        if (!parentCat) {
            parentCat = interaction.guild.channels.cache.find(c => c.type === ChannelType.GuildCategory && (c.name.toLowerCase().includes("leilao") || c.name.toLowerCase().includes("auction")));
        }

        const createOpts = {
            name: "💰-" + formatarNomeCanal(dados.desc),
            type: ChannelType.GuildText,
            permissionOverwrites: [
                { id: interaction.guild.roles.everyone.id, allow: [PermissionsBitField.Flags.ViewChannel], deny: [PermissionsBitField.Flags.SendMessages] },
                { id: dados.userId || interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.AttachFiles] }
            ]
        };
        if (parentCat) createOpts.parent = parentCat.id;
        if (STAFF_ROLE_ID && interaction.guild.roles.cache.has(STAFF_ROLE_ID)) {
            createOpts.permissionOverwrites.push({ id: STAFF_ROLE_ID, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] });
        }
        canalPost = await interaction.guild.channels.create(createOpts);
    } catch (e) {
        canalPost = await interaction.guild.channels.create({
            name: "💰-" + formatarNomeCanal(dados.desc),
            type: ChannelType.GuildText
        }).catch(() => null);
    }

    if (!canalPost) {
        return interaction.editReply({ content: "❌ Erro ao criar canal público de leilão. Verifique permissões do bot." });
    }

    const minVal = parseFloat(String(dados.min).replace(/[R$\s]/g, "").replace(",", ".")) || 50.00;
    const maxVal = parseFloat(String(dados.max).replace(/[R$\s]/g, "").replace(",", ".")) || 150.00;

    const infoLeilao = {
        id: Math.random().toString(16).slice(2, 8).toUpperCase(),
        leiloeiroId: dados.userId || interaction.user.id,
        titulo: dados.desc || "Pet Leilão",
        categoria: dados.catNome || "Geral",
        valorPet: dados.valor || "N/A",
        min: minVal,
        max: maxVal,
        historico: [],
        painelMsgId: null,
        threadId: null
    };

    lancesAtuais.set(canalPost.id, infoLeilao);
    const msgPainel = await atualizarPainelLeilao(canalPost, infoLeilao);

    await interaction.editReply({ content: "✅ Leilão postado com sucesso no canal: " + canalPost });
}

async function processarAnexosTicket(message) {
    const info = dadosLeilao.get(message.channel.id);
    if (info) {
        if (!info.imagens) info.imagens = [];
        if (message.member && message.member.roles && message.member.roles.cache.has(STAFF_ROLE_ID)) {
            if (message.attachments.size > 0 || message.content.startsWith("http")) {
                await message.react("✅").catch(() => {});
            }
            return;
        }
        message.attachments.forEach(att => info.imagens.push(att.url));
        if (message.attachments.size > 0) {
            salvarDadosLeilao();
            await message.react("📸").catch(() => {});
        }
    }
}

async function reivindicarPagamento(interaction) {
    if (interaction.member && interaction.member.roles && !interaction.member.roles.cache.has(STAFF_ROLE_ID) && !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.reply({ content: "❌ Apenas a staff pode reivindicar pagamentos.", ephemeral: true });
    }
    const originalEmbed = interaction.message.embeds[0];
    const newEmbed = EmbedBuilder.from(originalEmbed).setDescription((originalEmbed.description || "") + "\n\n**🙋 Reivindicado por:** <@" + interaction.user.id + ">");

    const updatedComponents = interaction.message.components.map(row => {
        return new ActionRowBuilder().addComponents(row.components.map(component => {
            if (component.customId === "reivindicar_pagamento") {
                return ButtonBuilder.from(component).setDisabled(true).setLabel("Atendido por Staff").setStyle(ButtonStyle.Secondary);
            }
            return component;
        }));
    });

    await interaction.update({ embeds: [newEmbed], components: updatedComponents });
    await interaction.followUp({ content: "✅ Pagamento reivindicado por <@" + interaction.user.id + ">.", ephemeral: true });
}

async function handlePixLeilaoCommand(interaction) {
    if (interaction.member && interaction.member.permissions && !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.reply({ content: "Você não tem permissão para usar este comando.", ephemeral: true });
    }
    const chave = interaction.options.getString("chave");
    const nome = interaction.options.getString("nome");
    const idAtendente = interaction.options.getString("id_atendente");
    pixConfig = { chave, nome, idAtendente };
    try {
        fs.writeFileSync("config.json", JSON.stringify(pixConfig, null, 2));
    } catch (e) {}
    await interaction.reply({ content: "✅ Configurações do Pix para leilão salvas com sucesso!", ephemeral: true });
}

async function atualizarPainelLeilao(canal, info) {
    const ultimoLance = info.historico.length > 0 ? info.historico[0] : null;
    const valorAtual = ultimoLance ? ultimoLance.valor : info.min;

    const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle("🔨 Leilão Ativo - " + info.titulo)
        .addFields(
            { name: "🏷️ Categoria", value: info.categoria || "500M PG", inline: true },
            { name: "👑 Vendedor", value: "<@" + info.leiloeiroId + ">", inline: true },
            { name: "💎 Valor in-game", value: info.valorPet, inline: true },
            { name: "💰 Lance Atual", value: "R$ " + valorAtual.toFixed(2), inline: true },
            { name: "📈 Incremento Mínimo", value: "R$ 1.00", inline: true },
            { name: "⚡ Auto-Buy", value: "R$ " + info.max.toFixed(2), inline: true }
        );

    if (ultimoLance) {
        embed.addFields({ name: "🥇 Maior Lance", value: "<@" + ultimoLance.userId + "> com R$ " + ultimoLance.valor.toFixed(2) });
    }

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("btn_dar_lance").setLabel("Dar Lance").setStyle(ButtonStyle.Success).setEmoji("💸"),
        new ButtonBuilder().setCustomId("btn_comprar_ja").setLabel("Comprar Já").setStyle(ButtonStyle.Primary).setEmoji("⚡")
    );

    if (!info.painelMsgId) {
        const msg = await canal.send({ embeds: [embed], components: [row] });
        info.painelMsgId = msg.id;
        return msg;
    } else {
        const msg = await canal.messages.fetch(info.painelMsgId).catch(() => null);
        if (msg) await msg.edit({ embeds: [embed], components: [row] });
        return msg;
    }
}

async function handleLanceButtonModal(interaction) {
    const modal = new ModalBuilder().setCustomId("modal_dar_lance").setTitle("Dar um Lance");
    modal.addComponents(
        new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId("valor_lance").setLabel("Valor do Lance (R$)").setStyle(TextInputStyle.Short).setRequired(true)
        )
    );
    await interaction.showModal(modal);
}

async function handleLanceModalSubmit(interaction) {
    const leilao = lancesAtuais.get(interaction.channel.id);
    if (!leilao) return interaction.reply({ content: "Este não é um canal de leilão ativo.", ephemeral: true });

    const valorInput = parseFloat(interaction.fields.getTextInputValue("valor_lance").replace(",", "."));
    if (isNaN(valorInput)) return interaction.reply({ content: "Digite um número válido.", ephemeral: true });

    const ultimoLance = leilao.historico.length > 0 ? leilao.historico[0].valor : leilao.min;
    if (valorInput < ultimoLance + 1.00) {
        return interaction.reply({ content: "Seu lance deve ser no mínimo R$ " + (ultimoLance + 1.00).toFixed(2), ephemeral: true });
    }

    leilao.historico.unshift({ userId: interaction.user.id, valor: valorInput, timestamp: Date.now() });
    await atualizarPainelLeilao(interaction.guild.channels.cache.get(interaction.channel.id) || interaction.channel, leilao);
    await interaction.reply({ content: "✅ Lance de R$ " + valorInput.toFixed(2) + " registrado com sucesso!" });
}

client.login(process.env.BOT_TOKEN || process.env.DISCORD_TOKEN);
