const fs = require("fs");
const vm = require("vm");
const http = require("http");

function request(url, options = {}, data = null) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const reqOpts = {
      hostname: u.hostname,
      port: u.port,
      path: u.pathname + u.search,
      method: options.method || "GET",
      headers: options.headers || {}
    };
    if (data) reqOpts.headers["Content-Type"] = "application/json";
    const req = http.request(reqOpts, (res) => {
      let body = "";
      res.on("data", chunk => body += chunk);
      res.on("end", () => {
        try { resolve({ status: res.statusCode, data: JSON.parse(body) }); }
        catch(e) { resolve({ status: res.statusCode, body }); }
      });
    });
    req.on("error", reject);
    if (data) req.write(JSON.stringify(data));
    req.end();
  });
}

(async () => {
  const resDb = await request("http://localhost:3000/api/database");
  const db = resDb.data;
  const botLeilao = (db.bots || []).find(b => b.name.toLowerCase().includes("leilao"));

  if (!botLeilao) return console.log("Bot Leilao not found");

  // Build pristine index.js content for Bot Leilao
  const cleanIndexJs = `const fs = require("fs");
const { 
    SlashCommandBuilder, ApplicationCommandOptionType, Client, GatewayIntentBits, 
    EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ModalBuilder, 
    TextInputBuilder, TextInputStyle, ChannelType, PermissionsBitField, 
    PermissionFlagsBits, ButtonBuilder, ButtonStyle, MessageFlags 
} = require("discord.js");

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers
    ]
});

const STAFF_ROLE_ID = "1256338006504280084";
const TICKET_CATEGORY_ID = "1283870810334855238";
const AUCTION_CATEGORY_ID = "1343714247548272782";
const LOG_CHANNEL_ID = "1343714247548272782";
const MM_CHANNEL_URL = "https://discord.com/channels/1256338005690318959/1283870810334855238";
const MM_CANAL_ID_TEXTO = "1283870810334855238";
const SERVIDOR_ID_TEXTO = "1256338005690318959";

const dadosLeilao = new Map();
const lancesAtuais = new Map();
let pixConfig = {};

function crc16(payload) {
    let polinomio = 0x1021;
    let resultado = 0xFFFF;
    for (let i = 0; i < payload.length; i++) {
        resultado ^= payload.charCodeAt(i) << 8;
        for (let j = 0; j < 8; j++) {
            if (resultado & 0x8000) resultado = (resultado << 1) ^ polinomio;
            else resultado <<= 1;
            resultado &= 0xFFFF;
        }
    }
    return resultado.toString(16).toUpperCase().padStart(4, "0");
}

function getPixConfig() {
    if (typeof pixConfig !== "undefined" && pixConfig && pixConfig.chave && pixConfig.nome) {
        return pixConfig;
    }
    try {
        if (fs.existsSync("config.json")) {
            const parsed = JSON.parse(fs.readFileSync("config.json", "utf8"));
            if (parsed && parsed.chave) {
                pixConfig = parsed;
                return pixConfig;
            }
        }
    } catch (e) {}
    try {
        if (fs.existsSync("data/pix_database.json")) {
            const db = JSON.parse(fs.readFileSync("data/pix_database.json", "utf8"));
            const firstKeyId = Object.keys(db).find(k => k !== "keys" && k !== "activeKey" && db[k] && db[k].chave);
            if (firstKeyId && db[firstKeyId]) {
                pixConfig = { chave: db[firstKeyId].chave, nome: db[firstKeyId].nome || "RECEBEDOR" };
                return pixConfig;
            }
        }
    } catch (e) {}
    return pixConfig || {};
}

function getPixQR(valor = 1.00) {
    const config = getPixConfig();
    if (!config || !config.chave) return { link: "", code: "" };

    const chave = config.chave.trim();
    const nome = (config.nome || "RECEBEDOR").trim().substring(0, 25).toUpperCase().normalize("NFD").replace(/[\\u0300-\\u036f]/g, "");
    const valorF = parseFloat(valor).toFixed(2);
    const merchantAccount = "0014br.gov.bcb.pix01" + chave.length.toString().padStart(2, "0") + chave;
    
    let payload = "00020101021126" + merchantAccount.length.toString().padStart(2, "0") + merchantAccount +
        "52040000530398654" + valorF.length.toString().padStart(2, "0") + valorF +
        "5802BR59" + nome.length.toString().padStart(2, "0") + nome +
        "6009SAO PAULO62070503***6304";

    const fullCode = payload + crc16(payload);
    const link = "https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=" + encodeURIComponent(fullCode);
    
    return { link, code: fullCode };
}

function formatarNomeCanal(desc) {
    let limpo = (desc || "").toLowerCase()
        .normalize("NFD").replace(/[\\u0300-\\u036f]/g, "")
        .replace(/[^a-z0-9\\s-]/g, "")
        .replace(/\\s+/g, "-");
    return limpo.substring(0, 20) || "pet";
}

client.once("ready", async () => {
    console.log("[DISCORD] Logado como " + client.user.tag);
    try {
        const commands = [
            new SlashCommandBuilder().setName("painelleilao").setDescription("Posta o painel de criação de leilão"),
            new SlashCommandBuilder()
                .setName("pixleilao")
                .setDescription("Configura a chave Pix para a taxa de leilão")
                .addStringOption(opt => opt.setName("chave").setDescription("Chave Pix (ex: email, CPF)").setRequired(true))
                .addStringOption(opt => opt.setName("nome").setDescription("Nome do titular").setRequired(true))
                .addStringOption(opt => opt.setName("id_atendente").setDescription("ID do atendente no Discord").setRequired(false))
        ];
        await client.application.commands.set(commands);
        console.log("[DISCORD] Comandos Slash registrados!");
    } catch (e) {
        console.error("Erro ao registrar comandos:", e);
    }
});

client.on("interactionCreate", async (interaction) => {
    try {
        if (interaction.isChatInputCommand()) {
            if (interaction.commandName === "painelleilao") {
                if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
                    return interaction.reply({ content: "Apenas administradores.", flags: [MessageFlags.Ephemeral] });
                }
                const embed = new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle("🔨 Anunciar Leilão")
                    .setDescription("Clique no botão abaixo para iniciar o processo de anúncio do seu pet no leilão.");
                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId("iniciar_anuncio_leilao").setLabel("Anunciar Leilão").setStyle(ButtonStyle.Danger).setEmoji("🔨")
                );
                await interaction.reply({ embeds: [embed], components: [row] });
            } else if (interaction.commandName === "pixleilao") {
                await handlePixLeilaoCommand(interaction);
            }
        } else if (interaction.isButton()) {
            const cid = interaction.customId;
            if (cid === "iniciar_anuncio_leilao") {
                const modal = new ModalBuilder().setCustomId("modal_anuncio_1").setTitle("Anunciar Leilão - Parte 1");
                modal.addComponents(
                    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("desc").setLabel("Descrição do Pet").setStyle(TextInputStyle.Short).setRequired(true)),
                    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("valor").setLabel("Valor In-Game").setStyle(TextInputStyle.Short).setRequired(true)),
                    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("min").setLabel("Lance Inicial (R$)").setStyle(TextInputStyle.Short).setRequired(true)),
                    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("max").setLabel("Auto-Buy / Valor Máximo (R$)").setStyle(TextInputStyle.Short).setRequired(true))
                );
                await interaction.showModal(modal);
            } else if (cid === "copy_pix") {
                await copiarCodigoPix(interaction);
            } else if (cid === "aprovar_final") {
                await publicarLeilaoOficial(interaction);
            } else if (cid === "reivindicar_pagamento") {
                await reivindicarPagamento(interaction);
            } else if (cid === "fechar_ticket") {
                await interaction.channel.delete().catch(() => {});
            } else if (cid === "btn_dar_lance") {
                await handleLanceButtonModal(interaction);
            } else if (cid === "btn_comprar_ja") {
                await interaction.reply({ content: "Para comprar já, entre em contato com a Staff ou envie o valor máximo no chat!", flags: [MessageFlags.Ephemeral] });
            } else if (cid === "discutir_sim" || cid === "discutir_nao") {
                const info = dadosLeilao.get(interaction.channel.id);
                if (info) info.discussaoAtiva = (cid === "discutir_sim");
                await interaction.reply({ content: "Opção de discussão salva! Selecione a categoria abaixo para gerar a taxa Pix.", flags: [MessageFlags.Ephemeral] });
            }
        } else if (interaction.isStringSelectMenu()) {
            if (interaction.customId === "select_categoria_leilao") {
                await processarSelecaoCategoria(interaction);
            }
        } else if (interaction.isModalSubmit()) {
            if (interaction.customId === "modal_anuncio_1") {
                const desc = interaction.fields.getTextInputValue("desc");
                const valor = interaction.fields.getTextInputValue("valor");
                const min = interaction.fields.getTextInputValue("min");
                const max = interaction.fields.getTextInputValue("max");

                const canal = await interaction.guild.channels.create({
                    name: "ticket-" + interaction.user.username,
                    type: ChannelType.GuildText,
                    parent: TICKET_CATEGORY_ID,
                    permissionOverwrites: [
                        { id: interaction.guild.roles.everyone.id, deny: [PermissionsBitField.Flags.ViewChannel] },
                        { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.AttachFiles] },
                        { id: STAFF_ROLE_ID, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] }
                    ]
                });

                dadosLeilao.set(canal.id, {
                    user: interaction.user,
                    desc, valor, min, max,
                    imagens: [],
                    pixCode: null
                });

                const embedWelcome = new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle("🔨 Anúncio de Leilão - " + interaction.user.username)
                    .setDescription("# Etapa 1 — Discussão\\n\\nItem: " + desc + "\\nValor in-game: " + valor + "\\nLance inicial: R$ " + min + "\\n\\n**Envie as fotos do seu pet aqui no chat e selecione a categoria abaixo.**");

                const menu = new ActionRowBuilder().addComponents(
                    new StringSelectMenuBuilder().setCustomId("select_categoria_leilao").setPlaceholder("Selecione a Categoria").addOptions([
                        { label: "Brainrot", value: "1.00_Brainrot" },
                        { label: "Secret", value: "1.00_Secret" },
                        { label: "Godly", value: "1.00_Godly" },
                        { label: "OG", value: "1.00_OG" }
                    ])
                );

                await canal.send({ content: "<@" + interaction.user.id + ">", embeds: [embedWelcome], components: [menu] });
                await interaction.reply({ content: "✅ Ticket criado: " + canal, flags: [MessageFlags.Ephemeral] });
            } else if (interaction.customId === "modal_dar_lance") {
                await handleLanceModalSubmit(interaction);
            }
        }
    } catch (err) {
        console.error("Erro no manipulador de interações:", err);
    }
});

client.on("messageCreate", async (message) => {
    if (message.author.bot) return;
    await processarAnexosTicket(message);
});

async function copiarCodigoPix(interaction) {
    const info = dadosLeilao.get(interaction.channel.id);
    let code = info ? info.pixCode : null;
    if (!code) {
        const pix = getPixQR();
        code = pix.code;
    }
    if (!code) {
        return interaction.reply({ 
            content: "❌ Nenhuma chave Pix configurada no momento. Use /pixleilao para configurar.", 
            flags: [MessageFlags.Ephemeral] 
        });
    }
    await interaction.reply({ content: code, flags: [MessageFlags.Ephemeral] });
}

async function processarSelecaoCategoria(interaction) {
    try {
        await interaction.deferUpdate();
        const [preco, cat] = interaction.values[0].split("_");
        const info = dadosLeilao.get(interaction.channel.id);
        if (!info) return;
        info.catNome = cat;
        const pix = getPixQR();
        info.pixCode = pix.code;

        const embedPix = new EmbedBuilder()
            .setColor(0xFF0000)
            .setDescription("# Pagamento da Taxa\\n\\nValor: R$ 1,00\\nCopie o código pix abaixo.\\n\\nTotal de fotos enviadas: " + info.imagens.length);

        if (pix.link && pix.code) {
            embedPix.setImage(pix.link);
            embedPix.addFields({ name: "🔑 Chave Pix Copia e Cola", value: "\`\`\`" + pix.code + "\`\`\`" });
        } else {
            embedPix.addFields({ name: "⚠️ Atenção", value: "Chave Pix não configurada. Use /pixleilao para configurar." });
        }

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("copy_pix").setLabel("Copiar Pix").setStyle(ButtonStyle.Secondary).setEmoji("📋"),
            new ButtonBuilder().setCustomId("aprovar_final").setLabel("Postar Leilão").setStyle(ButtonStyle.Success).setEmoji("✅"),
            new ButtonBuilder().setCustomId("reivindicar_pagamento").setLabel("Reivindicar Pagamento").setStyle(ButtonStyle.Primary).setEmoji("🙋"),
            new ButtonBuilder().setCustomId("fechar_ticket").setLabel("Fechar Ticket").setStyle(ButtonStyle.Danger)
        );

        await interaction.editReply({ embeds: [embedPix], components: [row] });
    } catch (error) {
        console.error("Erro na seleção de categoria:", error);
    }
}

async function publicarLeilaoOficial(interaction) {
    if (!interaction.member.roles.cache.has(STAFF_ROLE_ID)) {
        return interaction.reply({ content: "❌ Apenas Staff pode postar o leilão.", flags: [MessageFlags.Ephemeral] });
    }
    const dados = dadosLeilao.get(interaction.channel.id);
    if (!dados) return;
    await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

    const canalPost = await interaction.guild.channels.create({
        name: "💰-" + formatarNomeCanal(dados.desc),
        type: ChannelType.GuildText,
        parent: AUCTION_CATEGORY_ID,
        permissionOverwrites: [
            { id: interaction.guild.roles.everyone.id, allow: [PermissionsBitField.Flags.ViewChannel], deny: [PermissionsBitField.Flags.SendMessages] },
            { id: dados.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.AttachFiles] },
            { id: STAFF_ROLE_ID, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] }
        ]
    });

    const minVal = parseFloat(dados.min.replace(/[R$\\s]/g, "").replace(",", ".")) || 50.00;
    const maxVal = parseFloat(dados.max.replace(/[R$\\s]/g, "").replace(",", ".")) || 150.00;

    const infoLeilao = {
        id: Math.random().toString(16).slice(2, 8).toUpperCase(),
        leiloeiroId: dados.user.id,
        titulo: dados.desc,
        valorPet: dados.valor,
        min: minVal,
        max: maxVal,
        historico: [],
        painelMsgId: null,
        threadId: null
    };

    lancesAtuais.set(canalPost.id, infoLeilao);
    const msgPainel = await atualizarPainelLeilao(canalPost, infoLeilao);

    if (msgPainel && dados.discussaoAtiva) {
        const thread = await msgPainel.startThread({ name: "Discussão", autoArchiveDuration: 1440 }).catch(console.error);
        if (thread) {
            infoLeilao.threadId = thread.id;
            lancesAtuais.set(thread.id, infoLeilao);
            await thread.send("🚀 **O leilão começou!**\\n\\n- O preço inicial é **R$ " + minVal.toFixed(2) + "**.\\n- O incremento mínimo é **R$ 1.00**.\\n\\nFaça seus lances usando o botão na mensagem principal ou enviando o valor aqui no chat!");
        }
    }

    await interaction.editReply({ content: "✅ Leilão postado no canal: " + canalPost });
}

async function processarAnexosTicket(message) {
    const info = dadosLeilao.get(message.channel.id);
    if (info) {
        if (message.member.roles.cache.has(STAFF_ROLE_ID)) {
            if (message.attachments.size > 0 || message.content.startsWith("http")) {
                await message.react("✅").catch(() => {});
            }
            return;
        }
        message.attachments.forEach(att => info.imagens.push(att.url));
        if (message.attachments.size > 0) {
            await message.react("📸").catch(() => {});
        }
    }
}

async function reivindicarPagamento(interaction) {
    if (!interaction.member.roles.cache.has(STAFF_ROLE_ID)) {
        return interaction.reply({ content: "❌ Apenas a staff pode reivindicar pagamentos.", flags: [MessageFlags.Ephemeral] });
    }
    const originalEmbed = interaction.message.embeds[0];
    const newEmbed = EmbedBuilder.from(originalEmbed).setDescription(originalEmbed.description + "\\n\\n**Reivindicado por:** <@" + interaction.user.id + ">");
    const updatedComponents = interaction.message.components.map(row => {
        return new ActionRowBuilder().addComponents(row.components.map(component => {
            if (component.customId === "reivindicar_pagamento") {
                return ButtonBuilder.from(component).setDisabled(true).setLabel("Atendido por Staff").setStyle(ButtonStyle.Secondary);
            }
            return component;
        }));
    });
    await interaction.update({ embeds: [newEmbed], components: updatedComponents });
    await interaction.followUp({ content: "✅ Pagamento reivindicado por <@" + interaction.user.id + ">.", flags: [MessageFlags.Ephemeral] });
}

async function handlePixLeilaoCommand(interaction) {
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.reply({ content: "Você não tem permissão para usar este comando.", flags: [MessageFlags.Ephemeral] });
    }
    const chave = interaction.options.getString("chave");
    const nome = interaction.options.getString("nome");
    const idAtendente = interaction.options.getString("id_atendente");

    pixConfig = { chave, nome, idAtendente };
    try {
        fs.writeFileSync("config.json", JSON.stringify(pixConfig, null, 2));
    } catch (e) {}

    await interaction.reply({ content: "✅ Configurações do Pix para leilão salvas com sucesso!", flags: [MessageFlags.Ephemeral] });
}

async function atualizarPainelLeilao(canal, info) {
    const ultimoLance = info.historico.length > 0 ? info.historico[0] : null;
    const valorAtual = ultimoLance ? ultimoLance.valor : info.min;

    const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle("🔨 Leilão Ativo - " + info.titulo)
        .addFields(
            { name: "👑 Vendedor", value: "<@" + info.leiloeiroId + ">", inline: true },
            { name: "💎 Valor in-game", value: info.valorPet, inline: true },
            { name: "💰 Lance Atual", value: "R$ " + valorAtual.toFixed(2), inline: true },
            { name: "📈 Incremento Mínimo", value: "R$ 1.00", inline: true },
            { name: "⚡ Auto-Buy", value: "R$ " + info.max.toFixed(2), inline: true }
        );

    if (ultimoLance) {
        embed.addFields({ name: "🥇 Maior Lance", value: "<@" + ultimoLance.userId + "> com R$ " + ultimoLance.valor.toFixed(2) });
    }

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("btn_dar_lance").setLabel("Dar Lance").setStyle(ButtonStyle.Success).setEmoji("💸"),
        new ButtonBuilder().setCustomId("btn_comprar_ja").setLabel("Comprar Já").setStyle(ButtonStyle.Primary).setEmoji("⚡")
    );

    if (!info.painelMsgId) {
        const msg = await canal.send({ embeds: [embed], components: [row] });
        info.painelMsgId = msg.id;
        return msg;
    } else {
        const msg = await canal.messages.fetch(info.painelMsgId).catch(() => null);
        if (msg) await msg.edit({ embeds: [embed], components: [row] });
        return msg;
    }
}

async function handleLanceButtonModal(interaction) {
    const modal = new ModalBuilder().setCustomId("modal_dar_lance").setTitle("Dar um Lance");
    modal.addComponents(
        new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId("valor_lance").setLabel("Valor do Lance (R$)").setStyle(TextInputStyle.Short).setRequired(true)
        )
    );
    await interaction.showModal(modal);
}

async function handleLanceModalSubmit(interaction) {
    const leilao = lancesAtuais.get(interaction.channel.id);
    if (!leilao) return interaction.reply({ content: "Este não é um canal de leilão ativo.", flags: [MessageFlags.Ephemeral] });

    const valorInput = parseFloat(interaction.fields.getTextInputValue("valor_lance").replace(",", "."));
    if (isNaN(valorInput)) return interaction.reply({ content: "Digite um número válido.", flags: [MessageFlags.Ephemeral] });

    const ultimoLance = leilao.historico.length > 0 ? leilao.historico[0].valor : leilao.min;
    if (valorInput < ultimoLance + 1.00) {
        return interaction.reply({ content: "Seu lance deve ser no mínimo R$ " + (ultimoLance + 1.00).toFixed(2), flags: [MessageFlags.Ephemeral] });
    }

    leilao.historico.unshift({ userId: interaction.user.id, valor: valorInput, timestamp: Date.now() });
    await atualizarPainelLeilao(interaction.guild.channels.cache.get(interaction.channel.id) || interaction.channel, leilao);
    await interaction.reply({ content: "✅ Lance de R$ " + valorInput.toFixed(2) + " registrado com sucesso!" });
}

client.login(process.env.BOT_TOKEN || process.env.DISCORD_TOKEN);
`;

  // Validate script syntax
  try {
    new vm.Script(cleanIndexJs);
    console.log("🎉🎉🎉 ABSOLUTE SUCCESS! Bot Leilao code is 100% PERFECT SYNTAX!");

    // Update Bot Leilao files
    const botLeilaoFiles = botLeilao.files;
    const fileIdx = botLeilaoFiles.find(f => f.name === "index.js");
    fileIdx.content = cleanIndexJs;

    let configJson = botLeilaoFiles.find(f => f.name === "config.json");
    if (!configJson) {
      botLeilaoFiles.push({
        name: "config.json",
        path: "config.json",
        content: JSON.stringify({ chave: "Kauaantunes310@gmail.com", nome: "Kauã Antunes Martins" }, null, 2)
      });
    }

    const putRes = await request(`http://localhost:3000/api/bots/${botLeilao.id}`, { method: "PUT" }, { files: botLeilaoFiles });
    console.log("API PUT Status:", putRes.status);
  } catch (err) {
    console.error("Syntax Error in cleanIndexJs:", err);
  }
})();
