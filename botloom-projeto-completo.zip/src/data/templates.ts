import { BotTemplate } from '../types';

export const BOT_TEMPLATES: BotTemplate[] = [
  {
    id: 'slash-starter',
    name: 'Bot Completo Discord.js v14 (Slash, Buttons, Modals)',
    description: 'Template moderno com suporte a Slash Commands, Botões Interativos, Select Menus e Modals.',
    icon: '⚡',
    dependencies: {
      'discord.js': '^14.14.1',
      'dotenv': '^16.4.5'
    },
    files: [
      {
        name: 'index.js',
        path: 'index.js',
        content: `// BotLoom Hosting - Discord.js v14 Starter Template
const {
  Client,
  GatewayIntentBits,
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  EmbedBuilder,
  StringSelectMenuBuilder,
  ChannelType,
  PermissionFlagsBits
} = require('discord.js');
require('dotenv').config();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ]
});

client.once('ready', () => {
  console.log(\`[DISCORD.JS] Logado com sucesso como \${client.user ? client.user.tag : 'BotLoom#1234'}!\`);
  console.log('[SYSTEM] Bot ativo 24/7 na BotLoom Host!');
});

// Resposta direta a comandos no Chat do Discord
client.on('messageCreate', async message => {
  if (message.author.bot) return;

  const prefix = process.env.PREFIX || '!';
  const content = message.content.trim();
  const lowerContent = content.toLowerCase();

  if (lowerContent === \`\${prefix}ping\` || lowerContent === '!ping') {
    await message.reply(\`🏓 **Pong!** Latência: \\\`\${client.ws.ping}ms\\\` | Host: \\\`BotLoom Engine 24/7\\\`\`);
  } else if (lowerContent === \`\${prefix}ticket\` || lowerContent === '!ticket' || lowerContent === \`\${prefix}painel\` || lowerContent === '!painel') {
    const embed = new EmbedBuilder()
      .setTitle('🎫 Central de Atendimento & Suporte')
      .setDescription('Precisa de ajuda ou deseja tirar dúvidas? Clique no botão abaixo para abrir um Ticket privado com nossa equipe!')
      .setColor('#5865F2')
      .addFields(
        { name: '⏰ Horário de Atendimento', value: '24 horas por dia, 7 dias por semana', inline: true },
        { name: '🔒 Privacidade', value: 'Apenas você e os administradores terão acesso ao seu ticket.', inline: true }
      )
      .setFooter({ text: 'Sistema de Tickets 24/7 • BotLoom Hosting' })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('btn_ticket')
        .setLabel('📩 Abrir Ticket')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('btn_ajuda')
        .setLabel('❓ Ajuda')
        .setStyle(ButtonStyle.Secondary)
    );

    await message.channel.send({ embeds: [embed], components: [row] });
  } else if (lowerContent === \`\${prefix}help\` || lowerContent === '!help' || lowerContent === \`\${prefix}ajuda\` || lowerContent === '!ajuda') {
    const embed = new EmbedBuilder()
      .setTitle(\`🤖 Central de Comandos: \${client.user ? client.user.username : 'Bot'}\`)
      .setDescription(\`Olá **@\${message.author.username}**! Respondo diretamente aos comandos abaixo:\`)
      .setColor('#3B82F6')
      .addFields(
        { name: \`🎫 \${prefix}ticket\`, value: 'Envia o painel de suporte para abertura de tickets.', inline: false },
        { name: \`⚡ \${prefix}ping\`, value: 'Mede a latência real com os servidores do Discord.', inline: true },
        { name: \`📊 \${prefix}status\`, value: 'Exibe o uso de CPU, RAM e tempo online.', inline: true }
      )
      .setFooter({ text: 'BotLoom 24/7 Hosting Engine' })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  } else if (lowerContent === \`\${prefix}status\` || lowerContent === '!status') {
    const embed = new EmbedBuilder()
      .setTitle(\`📊 Status do Bot - Node.js Host\`)
      .addFields(
        { name: '🟢 Status', value: 'Online 24/7 na BotLoom', inline: true },
        { name: '⚡ Latência', value: \`\${client.ws.ping}ms\`, inline: true },
        { name: '🏰 Servidores', value: \`\${client.guilds.cache.size}\`, inline: true }
      )
      .setColor('#22C55E')
      .setTimestamp();
    await message.reply({ embeds: [embed] });
  }
});

// Interações Nativas (Slash Commands, Botões, Select Menus e Modals)
client.on('interactionCreate', async interaction => {
  try {
    // 1. Slash Commands
    if (interaction.isChatInputCommand()) {
      const { commandName } = interaction;

      if (commandName === 'ping') {
        await interaction.reply({ content: \`🏓 Pong! Latência: \${client.ws.ping}ms\`, ephemeral: true });
      } else if (commandName === 'ticket' || commandName === 'painel') {
        const embed = new EmbedBuilder()
          .setTitle('🎫 Central de Atendimento & Suporte')
          .setDescription('Clique no botão abaixo para abrir um Ticket privado com nossa equipe!')
          .setColor('#5865F2')
          .setFooter({ text: 'BotLoom Hosting' });

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('btn_ticket')
            .setLabel('📩 Abrir Ticket')
            .setStyle(ButtonStyle.Success)
        );

        await interaction.reply({ embeds: [embed], components: [row] });
      }
    }

    // 2. Botões Interativos
    if (interaction.isButton()) {
      if (interaction.customId === 'btn_ticket') {
        const modal = new ModalBuilder()
          .setCustomId('modal_ticket')
          .setTitle('🎫 Abrir Ticket de Suporte');

        const titleInput = new TextInputBuilder()
          .setCustomId('ticket_title')
          .setLabel('Assunto do Suporte')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Ex: Dúvida sobre compras / suporte')
          .setRequired(true);

        const descInput = new TextInputBuilder()
          .setCustomId('ticket_desc')
          .setLabel('Descreva seu problema')
          .setStyle(TextInputStyle.Paragraph)
          .setPlaceholder('Detalhe o que você precisa...')
          .setRequired(true);

        modal.addComponents(
          new ActionRowBuilder().addComponents(titleInput),
          new ActionRowBuilder().addComponents(descInput)
        );

        await interaction.showModal(modal);
      } else if (interaction.customId === 'btn_ajuda') {
        await interaction.reply({
          content: 'ℹ️ **Ajuda:** Para abrir um ticket de suporte, basta clicar no botão verde **"Abrir Ticket"** e preencher o formulário.',
          ephemeral: true
        });
      } else if (interaction.customId === 'btn_close_ticket') {
        await interaction.reply({ content: '🔒 **Fechando o ticket em 5 segundos...**' });
        setTimeout(() => {
          interaction.channel?.delete().catch(err => {
            console.error('Erro ao deletar canal de ticket:', err);
          });
        }, 5000);
      }
    }

    // 3. Submissão do Modal (Criação Real do Canal do Ticket)
    if (interaction.isModalSubmit()) {
      if (interaction.customId === 'modal_ticket') {
        // Responde de imediato ao Discord (<100ms) para PREVENIR 'Aplicativo não respondeu a tempo'
        await interaction.deferReply({ ephemeral: true });

        const title = interaction.fields.getTextInputValue('ticket_title');
        const desc = interaction.fields.getTextInputValue('ticket_desc');

        if (!interaction.guild) {
          return await interaction.editReply({
            content: '❌ **Erro:** Os tickets só podem ser criados dentro de um servidor do Discord.'
          });
        }

        const usernameClean = interaction.user.username.toLowerCase().replace(/[^a-z0-9]/g, '');
        const channelName = \`ticket-\${usernameClean || 'usuario'}\`;

        try {
          // Cria o canal de texto privado no Discord real
          const ticketChannel = await interaction.guild.channels.create({
            name: channelName,
            type: ChannelType.GuildText,
            permissionOverwrites: [
              {
                id: interaction.guild.id, // @everyone não pode ver
                deny: [PermissionFlagsBits.ViewChannel]
              },
              {
                id: interaction.user.id, // autor do ticket pode ver e falar
                allow: [
                  PermissionFlagsBits.ViewChannel,
                  PermissionFlagsBits.SendMessages,
                  PermissionFlagsBits.ReadMessageHistory,
                  PermissionFlagsBits.AttachFiles
                ]
              },
              {
                id: client.user.id, // o bot pode ver e gerenciar
                allow: [
                  PermissionFlagsBits.ViewChannel,
                  PermissionFlagsBits.SendMessages,
                  PermissionFlagsBits.ManageChannels
                ]
              }
            ]
          });

          const ticketEmbed = new EmbedBuilder()
            .setTitle(\`🎫 Ticket de Suporte: \${title}\`)
            .setDescription(\`Olá <@\${interaction.user.id}>! Seu ticket foi aberto com sucesso.\\n\\n**Assunto:** \${title}\\n**Descrição:** \${desc}\\n\\n*Aguarde o atendimento de nossa equipe.*\`)
            .setColor('#22C55E')
            .setFooter({ text: 'Para encerrar este atendimento, clique no botão vermelho abaixo.' })
            .setTimestamp();

          const closeRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId('btn_close_ticket')
              .setLabel('🔒 Fechar Ticket')
              .setStyle(ButtonStyle.Danger)
          );

          await ticketChannel.send({
            content: \`👋 <@\${interaction.user.id}> Novo ticket aberto!\`,
            embeds: [ticketEmbed],
            components: [closeRow]
          });

          await interaction.editReply({
            content: \`✅ **Ticket criado com sucesso!** Acesse o seu canal aqui: \${ticketChannel}\`
          });
        } catch (err) {
          console.error('[ERRO TICKET CANAL]', err);
          await interaction.editReply({
            content: \`⚠️ **Erro ao criar o canal do ticket:** \\\`\${err.message}\\\`.\\n*Certifique-se de que o bot possui a permissão "Gerenciar Canais" (Manage Channels) no servidor.*\`.
          });
        }
      }
    }
  } catch (globalErr) {
    console.error('[ERRO INTERACTION]', globalErr);
  }
});

// Inicializa o bot
client.login(process.env.DISCORD_TOKEN || 'BOTLOOM_TOKEN_SIMULATED');
`
      },
      {
        name: 'package.json',
        path: 'package.json',
        content: JSON.stringify(
          {
            name: "botloom-discord-bot",
            version: "1.0.0",
            description: "Bot hospedado na BotLoom Hosting",
            main: "index.js",
            scripts: {
              start: "node index.js"
            },
            dependencies: {
              "discord.js": "^14.14.1",
              "dotenv": "^16.4.5"
            }
          },
          null,
          2
        )
      },
      {
        name: '.env',
        path: '.env',
        content: `DISCORD_TOKEN=seutokenaqui\nPREFIX=!`
      }
    ]
  },
  {
    id: 'moderation-canvas',
    name: 'Bot de Boas-Vindas & Canvas (Geração de Imagens)',
    description: 'Cria banners de entrada personalizados usando Canvas, Embeds coloridos e sistema de boas-vindas.',
    icon: '🎨',
    dependencies: {
      'discord.js': '^14.14.1',
      'canvas': '^2.11.2',
      'dotenv': '^16.4.5'
    },
    files: [
      {
        name: 'index.js',
        path: 'index.js',
        content: `// BotLoom Hosting - Canvas & Welcome Bot
const { Client, GatewayIntentBits, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { createCanvas, loadImage } = require('canvas');
require('dotenv').config();

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildMessages]
});

client.once('ready', () => {
  console.log(\`[CANVAS BOT] Sistema de imagem pronto para \${client.user ? client.user.tag : 'CanvasBot'}!\`);
});

client.on('guildMemberAdd', async member => {
  console.log(\`[EVENTO] Novo membro entrou: \${member.user.username}\`);
  
  // Geração de Banner com Canvas
  const canvas = createCanvas(700, 250);
  const ctx = canvas.getContext('2d');

  // Fundo com Gradiente
  const gradient = ctx.createLinearGradient(0, 0, 700, 250);
  gradient.addColorStop(0, '#5865F2');
  gradient.addColorStop(1, '#7289DA');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 700, 250);

  // Moldura e texto
  ctx.fillStyle = '#FFFFFF';
  ctx.font = '32px sans-serif';
  ctx.fillText('BEM-VINDO AO SERVIDOR!', 200, 100);
  ctx.font = '24px sans-serif';
  ctx.fillText(\`@\${member.user.username}\`, 200, 150);

  const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'welcome-image.png' });
  console.log('[CANVAS] Banner gerado com sucesso.');
});

client.login(process.env.DISCORD_TOKEN || 'BOTLOOM_CANVAS_TOKEN');
`
      },
      {
        name: 'package.json',
        path: 'package.json',
        content: JSON.stringify(
          {
            name: "canvas-welcome-bot",
            version: "1.0.0",
            main: "index.js",
            dependencies: {
              "discord.js": "^14.14.1",
              "canvas": "^2.11.2",
              "dotenv": "^16.4.5"
            }
          },
          null,
          2
        )
      }
    ]
  },
  {
    id: 'ticket-economy',
    name: 'Bot de Tickets, Economia e Moderação',
    description: 'Sistema completo com banco de dados SQLite, sistema de saldo, loja e abertura de tickets.',
    icon: '🛡️',
    dependencies: {
      'discord.js': '^14.14.1',
      'sqlite3': '^5.1.7',
      'dotenv': '^16.4.5'
    },
    files: [
      {
        name: 'index.js',
        path: 'index.js',
        content: `// BotLoom Hosting - Multi-purpose Moderation & Economy Bot
const { Client, GatewayIntentBits, EmbedBuilder } = require('discord.js');
const sqlite3 = require('sqlite3').verbose();
require('dotenv').config();

const db = new sqlite3.Database('./economy.db');

db.serialize(() => {
  db.run("CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, coins INTEGER DEFAULT 0)");
  console.log('[SQLITE] Banco de dados inicializado com sucesso.');
});

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent]
});

client.on('messageCreate', async message => {
  if (message.author.bot) return;

  if (message.content === '!daily') {
    const coins = Math.floor(Math.random() * 500) + 100;
    message.reply(\`💰 Você recebeu seu recompensa diária de \${coins} moedas!\`);
  }
});

client.login(process.env.DISCORD_TOKEN || 'BOTLOOM_ECONOMY_TOKEN');
`
      },
      {
        name: 'package.json',
        path: 'package.json',
        content: JSON.stringify(
          {
            name: "economy-ticket-bot",
            version: "1.0.0",
            main: "index.js",
            dependencies: {
              "discord.js": "^14.14.1",
              "sqlite3": "^5.1.7",
              "dotenv": "^16.4.5"
            }
          },
          null,
          2
        )
      }
    ]
  }
];
