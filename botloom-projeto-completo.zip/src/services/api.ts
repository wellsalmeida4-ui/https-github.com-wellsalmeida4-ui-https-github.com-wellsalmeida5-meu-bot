import { Bot, BotFile } from '../types';
import {
  getPersistedBots,
  savePersistedBots,
  markBotAsDeleted,
  unmarkBotAsDeleted,
  syncedFetch
} from './storageSync';

export async function fetchBots(): Promise<Bot[]> {
  try {
    const res = await syncedFetch('/api/bots');
    if (!res.ok) return getPersistedBots();
    const serverBots = await res.json();
    if (Array.isArray(serverBots) && serverBots.length > 0) {
      return savePersistedBots(serverBots, true);
    }
    return getPersistedBots();
  } catch (err) {
    console.warn('Servidor reconectando, recuperando bots do localStorage...', err);
    return getPersistedBots();
  }
}

export async function createBot(data: {
  name: string;
  botId: string;
  token?: string;
  prefix?: string;
  description?: string;
  files?: BotFile[];
  codeOption?: 'file' | 'code';
}): Promise<Bot> {
  const res = await syncedFetch('/api/bots', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Erro ao criar bot.');
  }
  const newBot: Bot = await res.json();
  unmarkBotAsDeleted(newBot.id);
  const current = getPersistedBots();
  savePersistedBots([newBot, ...current.filter(b => b.id !== newBot.id)], false);
  return newBot;
}

export async function updateBot(id: string, updates: Partial<Bot>): Promise<Bot> {
  const res = await syncedFetch(`/api/bots/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates)
  });
  if (!res.ok) throw new Error('Erro ao atualizar bot.');
  const updated: Bot = await res.json();
  const current = getPersistedBots();
  savePersistedBots(
    current.some(b => b.id === id) ? current.map(b => (b.id === id ? updated : b)) : [updated, ...current],
    false
  );
  return updated;
}

export async function deleteBot(id: string): Promise<void> {
  const res = await syncedFetch(`/api/bots/${id}`, {
    method: 'DELETE'
  });
  if (!res.ok) throw new Error('Erro ao excluir bot.');
  markBotAsDeleted(id);
}

export async function startBot(id: string): Promise<Bot> {
  const res = await syncedFetch(`/api/bots/${id}/start`, {
    method: 'POST'
  });
  if (!res.ok) throw new Error('Erro ao ligar o bot.');
  const updated: Bot = await res.json();
  const current = getPersistedBots();
  savePersistedBots(current.map(b => (b.id === id ? updated : b)), false);
  return updated;
}

export async function stopBot(id: string): Promise<Bot> {
  const res = await syncedFetch(`/api/bots/${id}/stop`, {
    method: 'POST'
  });
  if (!res.ok) throw new Error('Erro ao desligar o bot.');
  const updated: Bot = await res.json();
  const current = getPersistedBots();
  savePersistedBots(current.map(b => (b.id === id ? updated : b)), false);
  return updated;
}

export async function restartBot(id: string): Promise<Bot> {
  const res = await syncedFetch(`/api/bots/${id}/restart`, {
    method: 'POST'
  });
  if (!res.ok) throw new Error('Erro ao reiniciar o bot.');
  const updated: Bot = await res.json();
  const current = getPersistedBots();
  savePersistedBots(current.map(b => (b.id === id ? updated : b)), false);
  return updated;
}

export async function clearBotLogs(id: string): Promise<Bot> {
  const res = await syncedFetch(`/api/bots/${id}/logs/clear`, {
    method: 'POST'
  });
  if (!res.ok) throw new Error('Erro ao limpar logs.');
  const updated: Bot = await res.json();
  const current = getPersistedBots();
  savePersistedBots(current.map(b => (b.id === id ? updated : b)), false);
  return updated;
}

export async function interactWithBot(id: string, payload: {
  command?: string;
  interactionType?: string;
  customId?: string;
  values?: string[];
  inputFields?: Record<string, string>;
}) {
  const res = await syncedFetch(`/api/bots/${id}/interact`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error('Erro na interação com o bot.');
  return res.json();
}

