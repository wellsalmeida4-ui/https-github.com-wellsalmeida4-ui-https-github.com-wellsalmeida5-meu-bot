import { useState, useEffect, useCallback, useRef } from 'react';
import { Bot } from '../types';

export const STORAGE_KEYS = {
  MASTER_STATE: 'botloom_sync_master_v1',
  BOTS: 'botloom_sync_bots_v1',
  PIX_CONFIG: 'botloom_sync_pix_config_v1',
  PROFILE_DATA: 'botloom_sync_profile_data_v1',
  CARD_CONFIG: 'botloom_sync_card_config_v1',
  FULL_DATABASE: 'botloom_sync_full_db_v1',
  DELETED_BOT_IDS: 'botloom_sync_deleted_bots_v1',
  LAST_SYNC_TS: 'botloom_sync_timestamp_v1'
} as const;

export interface ProfileDataState {
  users_mm: Record<string, any>;
  proofs_global: number | { count: number };
  major_trade?: Record<string, any>;
  movements?: Record<string, any>;
  taxas_diarias?: Record<string, any>;
  avaliacoes_pendentes?: Record<string, any>;
  proof_channels?: Record<string, any>;
}

export interface CardConfigState {
  vouchOptions?: Record<string, any>;
  perfilOptions?: Record<string, any>;
}

export interface PersistedAppState {
  version: number;
  updatedAt: number;
  bots: Bot[];
  pixConfig: Record<string, any>;
  profileData: ProfileDataState;
  cardConfig: CardConfigState;
  database: Record<string, any>;
  deletedBotIds: string[];
}

const DEFAULT_SEED_BOT_IDS = new Set(['bot-1', 'bot-2']);

function safeGetItem<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined' || !window.localStorage) return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    return parsed !== null && parsed !== undefined ? parsed : fallback;
  } catch (e) {
    console.warn(`[StorageSync] Erro ao ler chave ${key} do localStorage:`, e);
    return fallback;
  }
}

function safeSetItem(key: string, value: any): boolean {
  if (typeof window === 'undefined' || !window.localStorage) return false;
  try {
    const serialized = JSON.stringify(value);
    window.localStorage.setItem(key, serialized);
    return true;
  } catch (e) {
    console.warn(`[StorageSync] Erro ao gravar chave ${key} no localStorage:`, e);
    // Se exceder quota por logs muito extensos, compacta logs dos bots e tenta novamente
    if (key === STORAGE_KEYS.BOTS || key === STORAGE_KEYS.MASTER_STATE) {
      try {
        if (Array.isArray(value)) {
          const compacted = value.map((b: any) => ({
            ...b,
            logs: Array.isArray(b.logs) ? b.logs.slice(-25) : []
          }));
          window.localStorage.setItem(key, JSON.stringify(compacted));
          return true;
        }
      } catch (retryErr) {
        console.warn('[StorageSync] Falha ao compactar estado para localStorage:', retryErr);
      }
    }
    return false;
  }
}

/**
 * Gerencia IDs de bots explicitamente excluídos pelo usuário para evitar que
 * a reconciliação automática recrie um bot que o usuário deletou intencionalmente.
 */
export function getDeletedBotIds(): string[] {
  return safeGetItem<string[]>(STORAGE_KEYS.DELETED_BOT_IDS, []);
}

export function markBotAsDeleted(botId: string): void {
  const current = new Set(getDeletedBotIds());
  current.add(botId);
  safeSetItem(STORAGE_KEYS.DELETED_BOT_IDS, Array.from(current));

  const existingBots = getPersistedBots();
  const filtered = existingBots.filter(b => b.id !== botId);
  safeSetItem(STORAGE_KEYS.BOTS, filtered);
}

export function unmarkBotAsDeleted(botId: string): void {
  const current = new Set(getDeletedBotIds());
  if (current.has(botId)) {
    current.delete(botId);
    safeSetItem(STORAGE_KEYS.DELETED_BOT_IDS, Array.from(current));
  }
}

/**
 * Mescla de forma inteligente duas listas de bots (local vs servidor),
 * preservando códigos customizados, tokens, arquivos e evitando reset para bots seed.
 */
export function mergeBotsState(localBots: Bot[], serverBots: Bot[]): Bot[] {
  const deletedIds = new Set(getDeletedBotIds());
  const validLocal = Array.isArray(localBots) ? localBots.filter(b => b && b.id && !deletedIds.has(b.id)) : [];
  const validServer = Array.isArray(serverBots) ? serverBots.filter(b => b && b.id && !deletedIds.has(b.id)) : [];

  if (validServer.length === 0 && validLocal.length > 0) {
    return validLocal;
  }
  if (validLocal.length === 0) {
    return validServer;
  }

  // Verifica se o servidor sofreu reset para apenas os bots seed padrão enquanto o local tinha bots reais
  const serverOnlyHasDefaultSeeds =
    validServer.length > 0 &&
    validServer.every(b => DEFAULT_SEED_BOT_IDS.has(b.id));
  const localHasCustomBots = validLocal.some(b => !DEFAULT_SEED_BOT_IDS.has(b.id));

  const mergedMap = new Map<string, Bot>();

  // Se o servidor tiver resetado para seeds mas o local tiver bots customizados e não tinha os seeds,
  // priorizamos os bots locais + fazemos merge seguro
  for (const sBot of validServer) {
    if (serverOnlyHasDefaultSeeds && localHasCustomBots && !validLocal.some(lb => lb.id === sBot.id)) {
      continue;
    }
    mergedMap.set(sBot.id, sBot);
  }

  for (const lBot of validLocal) {
    const existingServerBot = mergedMap.get(lBot.id);
    if (!existingServerBot) {
      mergedMap.set(lBot.id, lBot);
    } else {
      // Mescla arquivos garantindo que nenhum arquivo customizado do bot seja perdido
      const fileMap = new Map<string, { name: string; path: string; content: string; isFolder?: boolean }>();
      for (const sf of existingServerBot.files || []) {
        const key = sf.path || sf.name;
        if (key) fileMap.set(key, sf);
      }
      for (const lf of lBot.files || []) {
        const key = lf.path || lf.name;
        if (!key) continue;
        const sf = fileMap.get(key);
        // Se não existir no servidor ou se o do servidor estiver vazio e o local tiver conteúdo, usa o local
        if (!sf || (!sf.content && lf.content)) {
          fileMap.set(key, lf);
        } else if (lf.content && lf.content.length > sf.content.length && DEFAULT_SEED_BOT_IDS.has(lBot.id)) {
          fileMap.set(key, lf);
        }
      }

      // Preserva token válido caso o servidor tenha voltado para token placeholder
      const isServerTokenPlaceholder =
        !existingServerBot.token ||
        existingServerBot.token.startsWith('BOTLOOM_TOKEN_SECRET_') ||
        existingServerBot.token.includes('SecretKeyDemo');
      const bestToken =
        !isServerTokenPlaceholder
          ? existingServerBot.token
          : lBot.token || existingServerBot.token;

      mergedMap.set(lBot.id, {
        ...lBot,
        ...existingServerBot,
        token: bestToken,
        name: existingServerBot.name || lBot.name,
        prefix: existingServerBot.prefix || lBot.prefix,
        description: existingServerBot.description || lBot.description,
        files: Array.from(fileMap.values()),
        logs:
          existingServerBot.logs && existingServerBot.logs.length > 0
            ? existingServerBot.logs
            : lBot.logs || []
      });
    }
  }

  return Array.from(mergedMap.values());
}

/**
 * Mescla configurações de Pix (pix_database) garantindo que nenhuma chave Pix
 * configurada por intermediadores ou usuários seja perdida após recarregamento.
 */
export function mergePixConfig(
  localPix: Record<string, any> | null | undefined,
  serverPix: Record<string, any> | null | undefined
): Record<string, any> {
  const l = localPix && typeof localPix === 'object' ? localPix : {};
  const s = serverPix && typeof serverPix === 'object' ? serverPix : {};

  const merged: Record<string, any> = {
    keys: Array.isArray(s.keys) && s.keys.length > 0 ? s.keys : Array.isArray(l.keys) ? l.keys : [],
    activeKey: s.activeKey || l.activeKey || '',
    ...l,
    ...s
  };

  // Garante que entradas de usuários/intermediadores (IDs do Discord -> { chave, nome, limite }) nunca sejam apagadas por um objeto vazio
  for (const [key, localVal] of Object.entries(l)) {
    if (key === 'keys' || key === 'activeKey') continue;
    const serverVal = s[key];
    if (!serverVal && localVal && typeof localVal === 'object') {
      merged[key] = localVal;
    } else if (serverVal && typeof serverVal === 'object' && localVal && typeof localVal === 'object') {
      merged[key] = {
        ...localVal,
        ...serverVal,
        chave: serverVal.chave || localVal.chave,
        nome: serverVal.nome || localVal.nome,
        limite:
          serverVal.limite !== undefined && serverVal.limite !== null
            ? serverVal.limite
            : localVal.limite
      };
    }
  }

  return merged;
}

/**
 * Mescla dados de perfil de usuários (users_mm) e contadores globais (proofs_global),
 * protegendo contra qualquer regressão de estatísticas, ranks, avaliações ou valores movimentados.
 */
export function mergeUsersMm(
  localUsers: Record<string, any> | null | undefined,
  serverUsers: Record<string, any> | null | undefined
): Record<string, any> {
  const lRaw = localUsers && typeof localUsers === 'object' ? localUsers : {};
  const sRaw = serverUsers && typeof serverUsers === 'object' ? serverUsers : {};

  // Ignora wrapper acidental { users: {} } vazio se o outro tiver chaves reais de IDs do Discord
  const cleanObj = (obj: Record<string, any>) => {
    const copy = { ...obj };
    if (
      Object.keys(copy).length === 1 &&
      copy.users &&
      typeof copy.users === 'object' &&
      Object.keys(copy.users).length === 0
    ) {
      return {};
    }
    return copy;
  };

  const l = cleanObj(lRaw);
  const s = cleanObj(sRaw);

  const allUserIds = new Set([...Object.keys(l), ...Object.keys(s)]);
  const merged: Record<string, any> = {};

  for (const uid of allUserIds) {
    const lu = l[uid];
    const su = s[uid];

    if (lu && !su) {
      merged[uid] = lu;
    } else if (su && !lu) {
      merged[uid] = su;
    } else if (
      lu &&
      typeof lu === 'object' &&
      su &&
      typeof su === 'object' &&
      !Array.isArray(lu) &&
      !Array.isArray(su)
    ) {
      merged[uid] = {
        ...lu,
        ...su,
        totalTrocas: Math.max(Number(lu.totalTrocas || 0), Number(su.totalTrocas || 0)),
        totalValor: Math.max(Number(lu.totalValor || 0), Number(su.totalValor || 0)),
        maiorTroca: Math.max(Number(lu.maiorTroca || 0), Number(su.maiorTroca || 0)),
        contador: Math.max(Number(lu.contador || 0), Number(su.contador || 0)),
        pessoasIntermediadas: Math.max(
          Number(lu.pessoasIntermediadas || 0),
          Number(su.pessoasIntermediadas || 0)
        ),
        totalMes:
          su.totalMes !== undefined ? Math.max(Number(lu.totalMes || 0), Number(su.totalMes || 0)) : lu.totalMes,
        clienteDesde: su.clienteDesde || lu.clienteDesde || 2026
      };
    } else {
      merged[uid] = su !== undefined ? su : lu;
    }
  }

  return merged;
}

export function extractProofsCount(val: any): number {
  if (typeof val === 'number' && !isNaN(val)) return val;
  if (val && typeof val === 'object' && typeof val.count === 'number') return val.count;
  return 0;
}

export function mergeProfileData(
  localProfile: Partial<ProfileDataState> | null | undefined,
  serverProfile: Partial<ProfileDataState> | null | undefined
): ProfileDataState {
  const lp = localProfile || {};
  const sp = serverProfile || {};

  const mergedUsers = mergeUsersMm(lp.users_mm, sp.users_mm);
  const maxProofs = Math.max(
    2000,
    extractProofsCount(lp.proofs_global),
    extractProofsCount(sp.proofs_global)
  );

  return {
    users_mm: mergedUsers,
    proofs_global: maxProofs,
    major_trade:
      sp.major_trade && Object.keys(sp.major_trade).length > 0
        ? { ...(lp.major_trade || {}), ...sp.major_trade }
        : lp.major_trade || {},
    movements:
      sp.movements && Object.keys(sp.movements).length > 0
        ? { ...(lp.movements || {}), ...sp.movements }
        : lp.movements || {},
    taxas_diarias:
      sp.taxas_diarias && Object.keys(sp.taxas_diarias).length > 0
        ? { ...(lp.taxas_diarias || {}), ...sp.taxas_diarias }
        : lp.taxas_diarias || {},
    avaliacoes_pendentes:
      sp.avaliacoes_pendentes && Object.keys(sp.avaliacoes_pendentes).length > 0
        ? { ...(lp.avaliacoes_pendentes || {}), ...sp.avaliacoes_pendentes }
        : lp.avaliacoes_pendentes || {},
    proof_channels:
      sp.proof_channels && Object.keys(sp.proof_channels).length > 0
        ? { ...(lp.proof_channels || {}), ...sp.proof_channels }
        : lp.proof_channels || {}
  };
}

export function mergeCardConfig(
  localCard: CardConfigState | null | undefined,
  serverCard: CardConfigState | null | undefined
): CardConfigState {
  const lc = localCard || {};
  const sc = serverCard || {};
  return {
    vouchOptions: {
      ...(lc.vouchOptions || {}),
      ...(sc.vouchOptions || {})
    },
    perfilOptions: {
      ...(lc.perfilOptions || {}),
      ...(sc.perfilOptions || {})
    }
  };
}

/**
 * Funções de leitura e gravação direta no localStorage
 */
function cleanBotForStorage(bot: Bot): Bot {
  if (!bot) return bot;
  return {
    ...bot,
    files: Array.isArray(bot.files)
      ? bot.files.filter(f => {
          const name = (f.name || f.path || '').toLowerCase();
          return (
            !name.startsWith('frame-') &&
            !name.endsWith('.png') &&
            !name.endsWith('.tmp') &&
            !name.endsWith('.jpg') &&
            !name.endsWith('.jpeg') &&
            !name.endsWith('.gif') &&
            !name.endsWith('.zip') &&
            name !== 'bot (1).js'
          );
        })
      : [],
    logs: Array.isArray(bot.logs) ? bot.logs.slice(-30) : []
  };
}

export function getPersistedBots(): Bot[] {
  const direct = safeGetItem<Bot[]>(STORAGE_KEYS.BOTS, []);
  if (Array.isArray(direct) && direct.length > 0) {
    const deleted = new Set(getDeletedBotIds());
    return direct
      .filter(b => b && b.id && !deleted.has(b.id))
      .map(cleanBotForStorage);
  }
  const master = safeGetItem<Partial<PersistedAppState>>(STORAGE_KEYS.MASTER_STATE, {});
  if (Array.isArray(master.bots) && master.bots.length > 0) {
    const deleted = new Set(getDeletedBotIds());
    return master.bots
      .filter(b => b && b.id && !deleted.has(b.id))
      .map(cleanBotForStorage);
  }
  return [];
}

export function savePersistedBots(bots: Bot[], mergeWithExisting = true): Bot[] {
  if (!Array.isArray(bots)) return getPersistedBots();
  const existing = mergeWithExisting ? getPersistedBots() : [];
  const merged = mergeWithExisting ? mergeBotsState(existing, bots) : bots;
  const finalBots = merged.map(cleanBotForStorage);

  safeSetItem(STORAGE_KEYS.BOTS, finalBots);
  safeSetItem(STORAGE_KEYS.LAST_SYNC_TS, Date.now());
  updateMasterSnapshot({ bots: finalBots });
  notifySyncListeners();
  return finalBots;
}

export function getPersistedPixConfig(): Record<string, any> {
  const direct = safeGetItem<Record<string, any>>(STORAGE_KEYS.PIX_CONFIG, {});
  if (direct && Object.keys(direct).length > 0) return direct;
  const master = safeGetItem<Partial<PersistedAppState>>(STORAGE_KEYS.MASTER_STATE, {});
  return master.pixConfig || {};
}

export function savePersistedPixConfig(pixConfig: Record<string, any>, mergeWithExisting = true): Record<string, any> {
  const existing = mergeWithExisting ? getPersistedPixConfig() : {};
  const finalPix = mergeWithExisting ? mergePixConfig(existing, pixConfig) : pixConfig;

  safeSetItem(STORAGE_KEYS.PIX_CONFIG, finalPix);
  safeSetItem(STORAGE_KEYS.LAST_SYNC_TS, Date.now());
  updateMasterSnapshot({ pixConfig: finalPix });
  notifySyncListeners();
  return finalPix;
}

export function getPersistedProfileData(): ProfileDataState {
  const fallback: ProfileDataState = {
    users_mm: {},
    proofs_global: 2000,
    major_trade: {},
    movements: {},
    taxas_diarias: {},
    avaliacoes_pendentes: {},
    proof_channels: {}
  };
  const direct = safeGetItem<ProfileDataState>(STORAGE_KEYS.PROFILE_DATA, fallback);
  if (direct && (Object.keys(direct.users_mm || {}).length > 0 || extractProofsCount(direct.proofs_global) > 2000)) {
    return direct;
  }
  const master = safeGetItem<Partial<PersistedAppState>>(STORAGE_KEYS.MASTER_STATE, {});
  return master.profileData || direct;
}

export function savePersistedProfileData(
  profileData: Partial<ProfileDataState>,
  mergeWithExisting = true
): ProfileDataState {
  const existing = mergeWithExisting ? getPersistedProfileData() : undefined;
  const finalProfile = mergeWithExisting
    ? mergeProfileData(existing, profileData)
    : ({
        users_mm: profileData.users_mm || {},
        proofs_global: profileData.proofs_global || 2000,
        major_trade: profileData.major_trade || {},
        movements: profileData.movements || {},
        taxas_diarias: profileData.taxas_diarias || {},
        avaliacoes_pendentes: profileData.avaliacoes_pendentes || {},
        proof_channels: profileData.proof_channels || {}
      } as ProfileDataState);

  safeSetItem(STORAGE_KEYS.PROFILE_DATA, finalProfile);
  safeSetItem(STORAGE_KEYS.LAST_SYNC_TS, Date.now());
  updateMasterSnapshot({ profileData: finalProfile });
  notifySyncListeners();
  return finalProfile;
}

export function getPersistedCardConfig(): CardConfigState {
  const direct = safeGetItem<CardConfigState>(STORAGE_KEYS.CARD_CONFIG, {});
  if (direct && (direct.vouchOptions || direct.perfilOptions)) return direct;
  const master = safeGetItem<Partial<PersistedAppState>>(STORAGE_KEYS.MASTER_STATE, {});
  return master.cardConfig || {};
}

export function savePersistedCardConfig(cardConfig: CardConfigState, mergeWithExisting = true): CardConfigState {
  const existing = mergeWithExisting ? getPersistedCardConfig() : {};
  const finalCard = mergeWithExisting ? mergeCardConfig(existing, cardConfig) : cardConfig;

  safeSetItem(STORAGE_KEYS.CARD_CONFIG, finalCard);
  safeSetItem(STORAGE_KEYS.LAST_SYNC_TS, Date.now());
  updateMasterSnapshot({ cardConfig: finalCard });
  notifySyncListeners();
  return finalCard;
}

export function getPersistedDatabase(): Record<string, any> {
  const direct = safeGetItem<Record<string, any>>(STORAGE_KEYS.FULL_DATABASE, {});
  const pixConfig = getPersistedPixConfig();
  const profileData = getPersistedProfileData();
  const bots = getPersistedBots();

  return {
    ...direct,
    pix_database: mergePixConfig(direct.pix_database, pixConfig),
    users_mm: mergeUsersMm(direct.users_mm, profileData.users_mm),
    proofs_global: Math.max(
      extractProofsCount(direct.proofs_global),
      extractProofsCount(profileData.proofs_global)
    ),
    major_trade: profileData.major_trade || direct.major_trade || {},
    movements: profileData.movements || direct.movements || {},
    taxas_diarias: profileData.taxas_diarias || direct.taxas_diarias || {},
    avaliacoes_pendentes: profileData.avaliacoes_pendentes || direct.avaliacoes_pendentes || {},
    proof_channels: profileData.proof_channels || direct.proof_channels || {},
    bots: bots.length > 0 ? bots : direct.bots || []
  };
}

export function savePersistedDatabase(db: Record<string, any>, mergeWithExisting = true): Record<string, any> {
  if (!db || typeof db !== 'object') return getPersistedDatabase();

  const existingDb = mergeWithExisting ? safeGetItem<Record<string, any>>(STORAGE_KEYS.FULL_DATABASE, {}) : {};

  if (db.pix_database) {
    savePersistedPixConfig(db.pix_database, mergeWithExisting);
  }

  if (
    db.users_mm ||
    db.proofs_global !== undefined ||
    db.major_trade ||
    db.movements ||
    db.taxas_diarias ||
    db.avaliacoes_pendentes ||
    db.proof_channels
  ) {
    savePersistedProfileData(
      {
        users_mm: db.users_mm,
        proofs_global: db.proofs_global,
        major_trade: db.major_trade,
        movements: db.movements,
        taxas_diarias: db.taxas_diarias,
        avaliacoes_pendentes: db.avaliacoes_pendentes,
        proof_channels: db.proof_channels
      },
      mergeWithExisting
    );
  }

  if (Array.isArray(db.bots) && db.bots.length > 0) {
    savePersistedBots(db.bots, mergeWithExisting);
  }

  const mergedDb: Record<string, any> = {
    ...existingDb,
    ...db,
    pix_database: getPersistedPixConfig(),
    users_mm: getPersistedProfileData().users_mm,
    proofs_global: getPersistedProfileData().proofs_global,
    bots: getPersistedBots()
  };

  safeSetItem(STORAGE_KEYS.FULL_DATABASE, mergedDb);
  safeSetItem(STORAGE_KEYS.LAST_SYNC_TS, Date.now());
  updateMasterSnapshot({ database: mergedDb });
  notifySyncListeners();
  return mergedDb;
}

function updateMasterSnapshot(partial: Partial<PersistedAppState>) {
  const current = safeGetItem<Partial<PersistedAppState>>(STORAGE_KEYS.MASTER_STATE, {});
  const updated: PersistedAppState = {
    version: 1,
    updatedAt: Date.now(),
    bots: partial.bots || current.bots || safeGetItem<Bot[]>(STORAGE_KEYS.BOTS, []),
    pixConfig: partial.pixConfig || current.pixConfig || safeGetItem<Record<string, any>>(STORAGE_KEYS.PIX_CONFIG, {}),
    profileData:
      partial.profileData ||
      current.profileData ||
      safeGetItem<ProfileDataState>(STORAGE_KEYS.PROFILE_DATA, {
        users_mm: {},
        proofs_global: 2000
      }),
    cardConfig:
      partial.cardConfig || current.cardConfig || safeGetItem<CardConfigState>(STORAGE_KEYS.CARD_CONFIG, {}),
    database: partial.database || current.database || {},
    deletedBotIds: getDeletedBotIds()
  };
  safeSetItem(STORAGE_KEYS.MASTER_STATE, updated);
}

// Listeners internos para atualizar hooks em tempo real quando o middleware intercepta dados
type SyncListener = () => void;
const syncListeners = new Set<SyncListener>();

export function subscribeToStorageSync(listener: SyncListener): () => void {
  syncListeners.add(listener);
  return () => {
    syncListeners.delete(listener);
  };
}

function notifySyncListeners() {
  syncListeners.forEach(fn => {
    try {
      fn();
    } catch (e) {}
  });
}

/**
 * MIDDLEWARE DE FETCH (Interceptador Automático de API -> localStorage)
 * Garante que qualquer requisição para /api/bots, /api/database ou /api/cards
 * persista automaticamente as alterações no localStorage e forneça fallback offline/reload.
 */
let isMiddlewareInstalled = false;
const nativeFetch: typeof fetch =
  typeof window !== 'undefined' && typeof window.fetch === 'function'
    ? window.fetch.bind(window)
    : fetch;

export async function syncedFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const urlStr = typeof input === 'string' ? input : input instanceof URL ? input.toString() : input.url;
  const method = (init?.method || 'GET').toUpperCase();

  // Captura mutações otimistas enviadas no body antes mesmo da resposta
  if ((method === 'PUT' || method === 'POST') && init?.body && typeof init.body === 'string') {
    try {
      if (urlStr.includes('/api/database/pix_database')) {
        const parsedBody = JSON.parse(init.body);
        savePersistedPixConfig(parsedBody, false);
      } else if (urlStr.includes('/api/database/users_mm')) {
        const parsedBody = JSON.parse(init.body);
        savePersistedProfileData({ users_mm: parsedBody }, false);
      } else if (urlStr.includes('/api/database/proofs_global')) {
        const parsedBody = JSON.parse(init.body);
        savePersistedProfileData({ proofs_global: parsedBody }, true);
      } else if (urlStr.includes('/api/database/')) {
        const tableMatch = urlStr.match(/\/api\/database\/([a-zA-Z0-9_]+)/);
        if (tableMatch && tableMatch[1]) {
          const tableName = tableMatch[1];
          const parsedBody = JSON.parse(init.body);
          savePersistedDatabase({ [tableName]: parsedBody }, true);
        }
      } else if (urlStr.includes('/api/cards/apply')) {
        const parsedBody = JSON.parse(init.body);
        if (parsedBody.vouchOptions || parsedBody.perfilOptions) {
          savePersistedCardConfig({
            vouchOptions: parsedBody.vouchOptions,
            perfilOptions: parsedBody.perfilOptions
          });
        }
      }
    } catch (e) {}
  }

  try {
    const response = await nativeFetch(input, init);

    // Clona a resposta para inspecionar o JSON e persistir no localStorage sem consumir o stream original
    if (response.ok && urlStr.includes('/api/')) {
      const cloned = response.clone();
      cloned
        .json()
        .then(data => {
          // 1. Rotas de Bots (/api/bots)
          if (urlStr.endsWith('/api/bots') && method === 'GET' && Array.isArray(data)) {
            savePersistedBots(data, true);
          } else if (urlStr.endsWith('/api/bots') && method === 'POST' && data && data.id) {
            unmarkBotAsDeleted(data.id);
            const current = getPersistedBots();
            savePersistedBots([data, ...current.filter(b => b.id !== data.id)], false);
          } else if (urlStr.match(/\/api\/bots\/[^/]+$/) && method === 'DELETE') {
            const idMatch = urlStr.match(/\/api\/bots\/([^/?]+)/);
            if (idMatch && idMatch[1]) {
              markBotAsDeleted(idMatch[1]);
            }
          } else if (
            urlStr.match(/\/api\/bots\/[^/]+(\/start|\/stop|\/restart|\/logs\/clear)?$/) &&
            (method === 'PUT' || method === 'POST') &&
            data &&
            data.id
          ) {
            const current = getPersistedBots();
            const updatedList = current.some(b => b.id === data.id)
              ? current.map(b => (b.id === data.id ? data : b))
              : [data, ...current];
            savePersistedBots(updatedList, false);

            // Se os arquivos do bot contiverem pix_database.json ou users_mm.json, também sincroniza!
            if (Array.isArray(data.files)) {
              for (const f of data.files) {
                const fname = (f.name || f.path || '').toLowerCase();
                if (fname === 'pix_database.json' && f.content) {
                  try {
                    savePersistedPixConfig(JSON.parse(f.content), true);
                  } catch {}
                } else if (fname === 'users_mm.json' && f.content) {
                  try {
                    savePersistedProfileData({ users_mm: JSON.parse(f.content) }, true);
                  } catch {}
                }
              }
            }
          }

          // 2. Rotas de Banco de Dados (/api/database)
          else if (urlStr.endsWith('/api/database') && method === 'GET' && data && typeof data === 'object') {
            savePersistedDatabase(data, true);
          } else if (urlStr.includes('/api/backups/restore/') && method === 'POST' && data?.success) {
            // Após restaurar um snapshot, busca o banco atualizado
            nativeFetch('/api/database')
              .then(r => r.json())
              .then(freshDb => savePersistedDatabase(freshDb, false))
              .catch(() => {});
          }

          // 3. Rotas de Configuração de Cartões e Perfil (/api/cards/config)
          else if (urlStr.includes('/api/cards/config') && method === 'GET' && data) {
            savePersistedCardConfig(data, true);
          }
        })
        .catch(() => {});
    }

    return response;
  } catch (networkError) {
    // FALLBACK ROBUSTO PÓS-RECARREGAMENTO:
    // Se o servidor estiver reiniciando no exato momento do reload, retorna os dados do localStorage!
    if (method === 'GET') {
      if (urlStr.endsWith('/api/bots')) {
        const cachedBots = getPersistedBots();
        if (cachedBots.length > 0) {
          return new Response(JSON.stringify(cachedBots), {
            status: 200,
            headers: { 'Content-Type': 'application/json', 'X-Storage-Sync': 'local-fallback' }
          });
        }
      } else if (urlStr.endsWith('/api/database')) {
        const cachedDb = getPersistedDatabase();
        return new Response(JSON.stringify(cachedDb), {
          status: 200,
          headers: { 'Content-Type': 'application/json', 'X-Storage-Sync': 'local-fallback' }
        });
      } else if (urlStr.includes('/api/cards/config')) {
        const cachedCards = getPersistedCardConfig();
        return new Response(JSON.stringify(cachedCards), {
          status: 200,
          headers: { 'Content-Type': 'application/json', 'X-Storage-Sync': 'local-fallback' }
        });
      }
    }
    throw networkError;
  }
}

export function installStorageSyncMiddleware(): void {
  if (typeof window === 'undefined' || isMiddlewareInstalled) return;
  isMiddlewareInstalled = true;

  try {
    const desc = Object.getOwnPropertyDescriptor(window, 'fetch');
    if (!desc || desc.writable) {
      window.fetch = syncedFetch;
    } else if (desc.configurable) {
      Object.defineProperty(window, 'fetch', {
        value: syncedFetch,
        configurable: true,
        writable: true
      });
    }
  } catch {
    // Ambiente com window.fetch somente leitura (getter-only); syncedFetch continua ativo diretamente nos serviços
  }
}

/**
 * Executa reconciliação bidirecional completa entre localStorage e o servidor backend.
 * Garante que se o servidor tiver reiniciado ou perdido dados em memória, o estado do
 * localStorage (bots, chaves Pix, dados de perfil e cartões) restaura o servidor imediatamente,
 * e se o servidor tiver novas transações do Discord, atualiza o localStorage.
 */
export async function reconcileWithServer(): Promise<{
  bots: Bot[];
  pixConfig: Record<string, any>;
  profileData: ProfileDataState;
  cardConfig: CardConfigState;
  syncedAt: number;
}> {
  const localBots = getPersistedBots();
  const localPix = getPersistedPixConfig();
  const localProfile = getPersistedProfileData();
  const localCards = getPersistedCardConfig();
  const localDb = safeGetItem<Record<string, any>>(STORAGE_KEYS.FULL_DATABASE, {});
  const deletedBotIds = getDeletedBotIds();

  try {
    const res = await fetch('/api/sync/reconcile', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        bots: localBots,
        pix_database: localPix,
        users_mm: localProfile.users_mm,
        proofs_global: localProfile.proofs_global,
        cardConfig: localCards,
        database: {
          ...localDb,
          pix_database: localPix,
          users_mm: localProfile.users_mm,
          proofs_global: localProfile.proofs_global,
          major_trade: localProfile.major_trade,
          movements: localProfile.movements,
          taxas_diarias: localProfile.taxas_diarias,
          avaliacoes_pendentes: localProfile.avaliacoes_pendentes,
          proof_channels: localProfile.proof_channels
        },
        deletedBotIds
      })
    });

    if (res.ok) {
      const payload = await res.json();
      const mergedBots = savePersistedBots(payload.bots || localBots, true);
      const mergedDb = savePersistedDatabase(payload.database || {}, true);
      const mergedCards = savePersistedCardConfig(payload.cardConfig || localCards, true);
      const now = Date.now();
      safeSetItem(STORAGE_KEYS.LAST_SYNC_TS, now);

      return {
        bots: mergedBots,
        pixConfig: mergedDb.pix_database || getPersistedPixConfig(),
        profileData: getPersistedProfileData(),
        cardConfig: mergedCards,
        syncedAt: now
      };
    }
  } catch (e) {
    console.warn('[StorageSync] Reconciliação offline, mantendo estado seguro do localStorage:', e);
  }

  return {
    bots: localBots,
    pixConfig: localPix,
    profileData: localProfile,
    cardConfig: localCards,
    syncedAt: safeGetItem<number>(STORAGE_KEYS.LAST_SYNC_TS, Date.now())
  };
}

/**
 * HOOK DE SINCRONIZAÇÃO ROBUSTO (`useStorageSync`)
 * Recupera instantaneamente o estado completo de bots, configurações de Pix e dados de perfil
 * na inicialização da aplicação e mantém sincronização contínua com localStorage + Backend.
 */
export function useStorageSync() {
  const [bots, setBotsState] = useState<Bot[]>(() => getPersistedBots());
  const [pixConfig, setPixConfigState] = useState<Record<string, any>>(() => getPersistedPixConfig());
  const [profileData, setProfileDataState] = useState<ProfileDataState>(() => getPersistedProfileData());
  const [cardConfig, setCardConfigState] = useState<CardConfigState>(() => getPersistedCardConfig());
  const [isHydrated, setIsHydrated] = useState<boolean>(() => getPersistedBots().length > 0);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [lastSyncedAt, setLastSyncedAt] = useState<number>(() =>
    safeGetItem<number>(STORAGE_KEYS.LAST_SYNC_TS, Date.now())
  );

  const botsRef = useRef<Bot[]>(bots);
  botsRef.current = bots;

  // Wrapper para atualizar bots no React state e persistir imediatamente no localStorage
  const setBots = useCallback((updater: Bot[] | ((prev: Bot[]) => Bot[])) => {
    setBotsState(prev => {
      const next = typeof updater === 'function' ? updater(prev) : updater;
      if (Array.isArray(next)) {
        safeSetItem(STORAGE_KEYS.BOTS, next);
        safeSetItem(STORAGE_KEYS.LAST_SYNC_TS, Date.now());
        updateMasterSnapshot({ bots: next });
      }
      return next;
    });
  }, []);

  // Sincroniza estado completo com o servidor na inicialização e sob demanda
  const syncNow = useCallback(async () => {
    setIsSyncing(true);
    try {
      const result = await reconcileWithServer();
      if (Array.isArray(result.bots) && result.bots.length > 0) {
        setBotsState(result.bots);
      }
      setPixConfigState(result.pixConfig);
      setProfileDataState(result.profileData);
      setCardConfigState(result.cardConfig);
      setLastSyncedAt(result.syncedAt);
    } finally {
      setIsHydrated(true);
      setIsSyncing(false);
    }
  }, []);

  useEffect(() => {
    installStorageSyncMiddleware();

    // Reconcilia na inicialização da aplicação
    syncNow();

    // Escuta atualizações disparadas pelo middleware de fetch
    const unsubscribe = subscribeToStorageSync(() => {
      setPixConfigState(getPersistedPixConfig());
      setProfileDataState(getPersistedProfileData());
      setCardConfigState(getPersistedCardConfig());
      setLastSyncedAt(safeGetItem<number>(STORAGE_KEYS.LAST_SYNC_TS, Date.now()));
    });

    // Escuta eventos de storage entre abas (cross-tab sync)
    const handleStorageEvent = (event: StorageEvent) => {
      if (!event.key) return;
      if (event.key === STORAGE_KEYS.BOTS) {
        const updatedBots = getPersistedBots();
        if (updatedBots.length > 0) setBotsState(updatedBots);
      } else if (event.key === STORAGE_KEYS.PIX_CONFIG) {
        setPixConfigState(getPersistedPixConfig());
      } else if (event.key === STORAGE_KEYS.PROFILE_DATA) {
        setProfileDataState(getPersistedProfileData());
      } else if (event.key === STORAGE_KEYS.CARD_CONFIG) {
        setCardConfigState(getPersistedCardConfig());
      }
    };

    // Garante flush final antes de fechar ou recarregar a página
    const handleBeforeUnload = () => {
      if (botsRef.current && botsRef.current.length > 0) {
        safeSetItem(STORAGE_KEYS.BOTS, botsRef.current);
        updateMasterSnapshot({ bots: botsRef.current });
      }
    };

    window.addEventListener('storage', handleStorageEvent);
    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      unsubscribe();
      window.removeEventListener('storage', handleStorageEvent);
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [syncNow]);

  const pixKeysCount = Object.keys(pixConfig || {}).filter(
    k => k !== 'keys' && k !== 'activeKey' && pixConfig[k] && typeof pixConfig[k] === 'object'
  ).length + (Array.isArray(pixConfig?.keys) ? pixConfig.keys.length : 0);

  const profilesCount = Object.keys(profileData?.users_mm || {}).length;
  const proofsCount = extractProofsCount(profileData?.proofs_global);

  return {
    bots,
    setBots,
    pixConfig,
    profileData,
    cardConfig,
    isHydrated,
    isSyncing,
    lastSyncedAt,
    syncNow,
    syncStats: {
      botsCount: bots.length,
      pixKeysCount,
      profilesCount,
      proofsCount
    }
  };
}
