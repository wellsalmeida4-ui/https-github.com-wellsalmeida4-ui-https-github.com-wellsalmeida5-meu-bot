import React, { useState } from 'react';
import {
  X,
  Download,
  UploadCloud,
  ExternalLink,
  Check,
  Copy,
  FileArchive,
  Layers,
  Terminal,
  ShieldAlert,
  Sparkles,
  HelpCircle,
  FolderArchive
} from 'lucide-react';

interface ExportNetlifyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportNetlifyModal: React.FC<ExportNetlifyModalProps> = ({
  isOpen,
  onClose
}) => {
  const [downloadingDist, setDownloadingDist] = useState(false);
  const [downloadingProject, setDownloadingProject] = useState(false);
  const [copiedGit, setCopiedGit] = useState(false);
  const [activeTab, setActiveTab] = useState<'drop' | 'github' | 'bots'>('drop');

  if (!isOpen) return null;

  const handleDownloadDist = () => {
    setDownloadingDist(true);
    const link = document.createElement('a');
    link.href = '/api/export/dist';
    link.download = 'botloom-netlify-dist.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => setDownloadingDist(false), 2500);
  };

  const handleDownloadProject = () => {
    setDownloadingProject(true);
    const link = document.createElement('a');
    link.href = '/api/export/project';
    link.download = 'botloom-projeto-completo.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => setDownloadingProject(false), 3000);
  };

  const gitCode = `git init
git add .
git commit -m "Meu BotLoom Hosting"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
git push -u origin main`;

  const handleCopyGit = () => {
    navigator.clipboard.writeText(gitCode);
    setCopiedGit(true);
    setTimeout(() => setCopiedGit(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-slate-900 via-cyan-950/20 to-slate-900">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 ring-1 ring-white/20">
              <UploadCloud className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-lg font-bold text-white tracking-tight">
                  Exportar Projeto & Hospedar no Netlify
                </h3>
                <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                  Pronto para Download
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Baixe os arquivos direto para o seu computador e coloque seu site no ar
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-slate-200">
          
          {/* Main Action Download Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Card 1: Dist for Netlify Drop */}
            <div className="relative bg-gradient-to-b from-cyan-950/30 to-slate-950 p-5 rounded-xl border border-cyan-500/30 shadow-lg flex flex-col justify-between group hover:border-cyan-400/60 transition-all">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                    RECOMENDADO PARA O SITE
                  </span>
                  <FileArchive className="w-5 h-5 text-cyan-400" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors">
                    1. Site Pronto para Netlify (dist.zip)
                  </h4>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Contém o site já compilado em HTML, CSS e JavaScript otimizados, com o arquivo <code className="text-cyan-300 font-mono">_redirects</code> configurado para não dar erro 404 ao atualizar páginas.
                  </p>
                </div>
                <div className="text-[11px] text-cyan-400/80 bg-cyan-950/40 p-2.5 rounded-lg border border-cyan-900/50">
                  ✨ <strong>Ideal para:</strong> Arrastar direto no Netlify Drop sem precisar compilar nada.
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center gap-2">
                <button
                  onClick={handleDownloadDist}
                  disabled={downloadingDist}
                  className="w-full flex items-center justify-center space-x-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-2.5 px-4 rounded-xl text-xs shadow-lg shadow-cyan-600/30 transition-all active:scale-95 disabled:opacity-50"
                >
                  <Download className={`w-4 h-4 ${downloadingDist ? 'animate-bounce' : ''}`} />
                  <span>{downloadingDist ? 'Gerando ZIP...' : 'Baixar Site para Netlify (.ZIP)'}</span>
                </button>
              </div>
            </div>

            {/* Card 2: Full Source Code */}
            <div className="relative bg-gradient-to-b from-indigo-950/30 to-slate-950 p-5 rounded-xl border border-indigo-500/30 shadow-lg flex flex-col justify-between group hover:border-indigo-400/60 transition-all">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                    CÓDIGO COMPLETO
                  </span>
                  <FolderArchive className="w-5 h-5 text-indigo-400" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-white group-hover:text-indigo-300 transition-colors">
                    2. Projeto Completo (.ZIP)
                  </h4>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Contém todos os códigos-fonte, arquivos dos bots Discord (<code className="text-indigo-300 font-mono">Middleman</code>, <code className="text-indigo-300 font-mono">Leilão</code>), bancos JSON (<code className="text-indigo-300 font-mono">users_mm.json</code>), servidor Node.js e configurações.
                  </p>
                </div>
                <div className="text-[11px] text-indigo-400/80 bg-indigo-950/40 p-2.5 rounded-lg border border-indigo-900/50">
                  📁 <strong>Ideal para:</strong> Subir para o GitHub, editar no VS Code ou rodar na sua máquina com <code className="font-mono">npm run dev</code>.
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center gap-2">
                <button
                  onClick={handleDownloadProject}
                  disabled={downloadingProject}
                  className="w-full flex items-center justify-center space-x-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2.5 px-4 rounded-xl text-xs shadow-lg shadow-indigo-600/30 transition-all active:scale-95 disabled:opacity-50"
                >
                  <Download className={`w-4 h-4 ${downloadingProject ? 'animate-bounce' : ''}`} />
                  <span>{downloadingProject ? 'Compactando...' : 'Baixar Projeto Completo (.ZIP)'}</span>
                </button>
              </div>
            </div>

          </div>

          {/* Navigation Tabs */}
          <div className="border-b border-slate-800 flex space-x-4">
            <button
              onClick={() => setActiveTab('drop')}
              className={`pb-2.5 text-xs font-bold transition-all relative flex items-center space-x-1.5 ${
                activeTab === 'drop'
                  ? 'text-cyan-400 border-b-2 border-cyan-400'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Passo a Passo: Netlify Drop (Mais Fácil)</span>
            </button>
            <button
              onClick={() => setActiveTab('github')}
              className={`pb-2.5 text-xs font-bold transition-all relative flex items-center space-x-1.5 ${
                activeTab === 'github'
                  ? 'text-cyan-400 border-b-2 border-cyan-400'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Conectar com GitHub</span>
            </button>
            <button
              onClick={() => setActiveTab('bots')}
              className={`pb-2.5 text-xs font-bold transition-all relative flex items-center space-x-1.5 ${
                activeTab === 'bots'
                  ? 'text-amber-400 border-b-2 border-amber-400'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Como funcionam os Bots 24/7?</span>
            </button>
          </div>

          {/* Tab 1: Netlify Drop */}
          {activeTab === 'drop' && (
            <div className="bg-slate-950/80 p-5 rounded-xl border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <h5 className="text-sm font-bold text-white flex items-center space-x-2">
                  <span>Como colocar no ar em menos de 1 minuto:</span>
                </h5>
                <a
                  href="https://app.netlify.com/drop"
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center space-x-1 text-xs text-cyan-400 hover:text-cyan-300 font-semibold underline"
                >
                  <span>Abrir Netlify Drop</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              <ol className="space-y-3 text-xs text-slate-300 list-decimal list-inside leading-relaxed">
                <li>
                  Clique no botão <strong>"Baixar Site para Netlify (.ZIP)"</strong> no card acima.
                </li>
                <li>
                  Extraia o arquivo zip baixado no seu computador (ele terá a pasta <code className="bg-slate-800 px-1.5 py-0.5 rounded text-cyan-300 font-mono">dist</code>).
                </li>
                <li>
                  Abra o site <a href="https://app.netlify.com/drop" target="_blank" rel="noreferrer" className="text-cyan-400 font-bold underline">app.netlify.com/drop</a> e faça login (com GitHub, Google ou e-mail).
                </li>
                <li>
                  Arraste a pasta <code className="bg-slate-800 px-1.5 py-0.5 rounded text-cyan-300 font-mono">dist</code> diretamente para o centro da tela do Netlify.
                </li>
                <li>
                  Pronto! O Netlify criará automaticamente seu link oficial (exemplo: <code className="bg-slate-800 px-1.5 py-0.5 rounded text-emerald-400 font-mono">seu-site.netlify.app</code>) com certificado SSL HTTPS grátis.
                </li>
              </ol>

              <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-xs text-emerald-300 flex items-start space-x-2">
                <Check className="w-4 h-4 flex-shrink-0 mt-0.5 text-emerald-400" />
                <span>
                  <strong>Configuração automática inclusa:</strong> O arquivo de rotas <code className="font-mono">_redirects</code> já está dentro da pasta para que qualquer página do seu painel abra diretamente sem dar tela em branco.
                </span>
              </div>
            </div>
          )}

          {/* Tab 2: GitHub + Netlify */}
          {activeTab === 'github' && (
            <div className="bg-slate-950/80 p-5 rounded-xl border border-slate-800 space-y-4">
              <h5 className="text-sm font-bold text-white">
                Como subir para o GitHub e conectar ao Netlify:
              </h5>
              <p className="text-xs text-slate-400 leading-relaxed">
                Usando o GitHub, toda vez que você fizer alterações no código, o Netlify atualiza o site automaticamente em segundos.
              </p>

              <div className="relative bg-slate-900 border border-slate-800 rounded-lg p-3 font-mono text-xs text-slate-200">
                <button
                  onClick={handleCopyGit}
                  className="absolute top-2 right-2 flex items-center space-x-1 bg-slate-800 hover:bg-slate-700 px-2 py-1 rounded text-[11px] text-slate-300 transition-colors"
                >
                  {copiedGit ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedGit ? 'Copiado!' : 'Copiar'}</span>
                </button>
                <pre className="overflow-x-auto whitespace-pre">{gitCode}</pre>
              </div>

              <div className="text-xs text-slate-300 space-y-2">
                <p>
                  No Netlify:
                </p>
                <ul className="list-disc list-inside space-y-1 text-slate-400 pl-2">
                  <li>Clique em <strong>Add new site</strong> &gt; <strong>Import an existing project</strong>.</li>
                  <li>Escolha o <strong>GitHub</strong> e selecione o repositório que você acabou de criar.</li>
                  <li>O Netlify usará o arquivo <code className="text-cyan-300 font-mono">netlify.toml</code> que já deixamos configurado (<code className="text-slate-300 font-mono">npm run build</code> e pasta <code className="text-slate-300 font-mono">dist</code>).</li>
                </ul>
              </div>
            </div>
          )}

          {/* Tab 3: Bots Discord 24/7 Explanation */}
          {activeTab === 'bots' && (
            <div className="bg-slate-950/80 p-5 rounded-xl border border-amber-500/30 space-y-3">
              <div className="flex items-center space-x-2 text-amber-400">
                <ShieldAlert className="w-5 h-5 flex-shrink-0" />
                <h5 className="text-sm font-bold text-white">
                  Entendendo: Frontend no Netlify vs Bots Discord 24/7
                </h5>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                O <strong>Netlify</strong> é uma plataforma especializada em hospedar <strong>sites visuais estáticos (HTML/React)</strong>. Ele não mantém servidores Node.js ligados continuamente com conexão de WebSocket aberta.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-1.5">
                  <span className="font-bold text-cyan-400 flex items-center space-x-1">
                    <Layers className="w-3.5 h-3.5" />
                    <span>Site no Netlify</span>
                  </span>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    Hospeda a interface visual do painel, visualização dos cards e configurações com carregamento ultrarrápido globalmente.
                  </p>
                </div>
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-1.5">
                  <span className="font-bold text-emerald-400 flex items-center space-x-1">
                    <Terminal className="w-3.5 h-3.5" />
                    <span>Bots do Discord (24/7)</span>
                  </span>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    Podem continuar rodando aqui mesmo no <strong>BotLoom Cloud</strong> (com UptimeRobot), ou na sua própria VPS/computador usando <code className="font-mono text-white">node server.cjs</code>!
                  </p>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Arquivos prontos com suporte a SPA e SSL gratuito no Netlify
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-colors"
          >
            Fechar
          </button>
        </div>

      </div>
    </div>
  );
};
