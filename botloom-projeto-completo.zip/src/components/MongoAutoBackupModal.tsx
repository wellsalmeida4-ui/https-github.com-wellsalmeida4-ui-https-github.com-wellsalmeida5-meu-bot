import React, { useState, useEffect } from 'react';
import {
  X,
  Database,
  Clock,
  Calendar,
  Save,
  Play,
  RotateCcw,
  Trash2,
  CheckCircle,
  AlertCircle,
  ShieldCheck,
  RefreshCw,
  FolderArchive,
  Layers,
  ChevronRight,
  ExternalLink
} from 'lucide-react';
import { Bot } from '../types';

interface MongoAutoBackupModalProps {
  isOpen: boolean;
  onClose: () => void;
  bots: Bot[];
  onOpenDatabaseModal?: () => void;
}

interface BackupHistoryItem {
  id: string;
  createdAt: string;
  trigger: 'manual' | 'daily' | 'weekly' | 'hourly';
  label: string;
  totalBots: number;
  totalFiles: number;
  totalBytes: number;
  sizeKb: number;
  botNames: string[];
}

interface AutoBackupConfig {
  enabled: boolean;
  frequency: 'daily' | 'weekly' | 'every_6h' | 'every_12h';
  executionTime: string;
  dayOfWeek: number;
  selectedBotIds: string[];
  includeDatabaseFiles: boolean;
  retentionCopies: number;
  lastRun?: {
    timestamp: string;
    status: 'success' | 'error';
    backupId?: string;
    message?: string;
    totalBots?: number;
    totalFiles?: number;
    sizeKb?: number;
  };
}

const DAYS_OF_WEEK = [
  { value: 0, label: 'Domingo' },
  { value: 1, label: 'Segunda-feira' },
  { value: 2, label: 'Terça-feira' },
  { value: 3, label: 'Quarta-feira' },
  { value: 4, label: 'Quinta-feira' },
  { value: 5, label: 'Sexta-feira' },
  { value: 6, label: 'Sábado' },
];

const PRESET_TIMES = ['00:00', '03:00', '06:00', '12:00', '18:00', '23:00'];

export const MongoAutoBackupModal: React.FC<MongoAutoBackupModalProps> = ({
  isOpen,
  onClose,
  bots,
  onOpenDatabaseModal
}) => {
  const [config, setConfig] = useState<AutoBackupConfig>({
    enabled: true,
    frequency: 'daily',
    executionTime: '03:00',
    dayOfWeek: 1,
    selectedBotIds: [],
    includeDatabaseFiles: true,
    retentionCopies: 15
  });

  const [history, setHistory] = useState<BackupHistoryItem[]>([]);
  const [loadingConfig, setLoadingConfig] = useState<boolean>(false);
  const [loadingHistory, setLoadingHistory] = useState<boolean>(false);
  const [savingConfig, setSavingConfig] = useState<boolean>(false);
  const [runningBackup, setRunningBackup] = useState<boolean>(false);
  const [restoringId, setRestoringId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [mongoStatus, setMongoStatus] = useState<{ configured: boolean; connected: boolean; error: string | null; maskedUri?: string | null; database?: string | null }>({
    configured: false,
    connected: false,
    error: null,
    database: null
  });

  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [activeTab, setActiveTab] = useState<'schedule' | 'history'>('schedule');

  const showFeedback = (type: 'success' | 'error', message: string) => {
    setFeedback({ type, message });
    setTimeout(() => setFeedback(null), 5000);
  };

  const loadConfig = async () => {
    setLoadingConfig(true);
    try {
      const res = await fetch('/api/mongodb/backup-config');
      if (res.ok) {
        const data = await res.json();
        if (data.config) setConfig(data.config);
        if (data.mongoStatus) setMongoStatus(data.mongoStatus);
      }
    } catch (e) {
      console.error('Erro ao carregar configurações de backup:', e);
    } finally {
      setLoadingConfig(false);
    }
  };

  const loadHistory = async () => {
    setLoadingHistory(true);
    try {
      const res = await fetch('/api/mongodb/backup-history');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.backups)) setHistory(data.backups);
        if (data.mongoStatus) setMongoStatus(data.mongoStatus);
      }
    } catch (e) {
      console.error('Erro ao listar histórico de backups:', e);
    } finally {
      setLoadingHistory(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadConfig();
      loadHistory();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSaveConfig = async () => {
    setSavingConfig(true);
    try {
      const res = await fetch('/api/mongodb/backup-config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });
      const data = await res.json();
      if (res.ok && data.success) {
        showFeedback('success', 'Configurações de agendamento salvas com sucesso!');
      } else {
        showFeedback('error', data.error || 'Erro ao salvar configurações.');
      }
    } catch (err: any) {
      showFeedback('error', err?.message || 'Falha de conexão com o servidor.');
    } finally {
      setSavingConfig(false);
    }
  };

  const handleRunBackupNow = async () => {
    setRunningBackup(true);
    try {
      const res = await fetch('/api/mongodb/backup-now', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          label: `Backup Manual (${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })})`,
          selectedBotIds: config.selectedBotIds,
          includeDatabases: config.includeDatabaseFiles
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        showFeedback('success', `Backup salvo no MongoDB! ${data.stats?.totalFiles || 0} arquivos salvos (${data.stats?.sizeKb || 0} KB).`);
        loadHistory();
        loadConfig();
      } else {
        showFeedback('error', data.error || 'Falha ao executar backup.');
      }
    } catch (err: any) {
      showFeedback('error', err?.message || 'Falha de conexão.');
    } finally {
      setRunningBackup(false);
    }
  };

  const handleRestoreBackup = async (id: string) => {
    if (!window.confirm('Deseja realmente restaurar os arquivos deste backup? Os arquivos atuais dos bots serão mesclados com o estado deste snapshot.')) {
      return;
    }
    setRestoringId(id);
    try {
      const res = await fetch(`/api/mongodb/restore-backup/${id}`, { method: 'POST' });
      const data = await res.json();
      if (res.ok && data.success) {
        showFeedback('success', data.message || 'Arquivos restaurados com sucesso!');
      } else {
        showFeedback('error', data.error || 'Falha ao restaurar backup.');
      }
    } catch (err: any) {
      showFeedback('error', err?.message || 'Erro ao restaurar.');
    } finally {
      setRestoringId(null);
    }
  };

  const handleDeleteBackup = async (id: string) => {
    if (!window.confirm('Excluir este snapshot do MongoDB?')) return;
    setDeletingId(id);
    try {
      const res = await fetch(`/api/mongodb/backup/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (res.ok && data.success) {
        setHistory(prev => prev.filter(item => item.id !== id));
        showFeedback('success', 'Backup excluído do MongoDB com sucesso.');
      } else {
        showFeedback('error', data.error || 'Falha ao excluir backup.');
      }
    } catch (err: any) {
      showFeedback('error', err?.message || 'Erro ao excluir.');
    } finally {
      setDeletingId(null);
    }
  };

  const toggleBotSelection = (botId: string) => {
    setConfig(prev => {
      const current = prev.selectedBotIds || [];
      if (current.includes(botId)) {
        return { ...prev, selectedBotIds: current.filter(id => id !== botId) };
      } else {
        return { ...prev, selectedBotIds: [...current, botId] };
      }
    });
  };

  const selectAllBots = () => {
    setConfig(prev => ({ ...prev, selectedBotIds: [] }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center shadow-inner">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base font-bold text-white tracking-tight">
                  Backups Automáticos para o MongoDB
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-medium">
                  Nuvem Atlas
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Agendamento de segurança para salvar todos os códigos (.js) e bancos (.json) no MongoDB
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* MongoDB Status Warning if not connected */}
        {!mongoStatus.connected && (
          <div className="px-6 py-3 bg-amber-950/40 border-b border-amber-800/40 flex items-center justify-between text-xs text-amber-300">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                O MongoDB Atlas ainda não está conectado. Configure suas credenciais na aba MongoDB para ativar a replicação automática em nuvem.
              </span>
            </div>
            {onOpenDatabaseModal && (
              <button
                onClick={() => {
                  onClose();
                  onOpenDatabaseModal();
                }}
                className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 rounded text-[11px] font-medium border border-amber-500/30 flex items-center space-x-1 shrink-0 transition"
              >
                <span>Conectar MongoDB</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            )}
          </div>
        )}

        {/* Feedback Alert */}
        {feedback && (
          <div className={`px-6 py-2.5 text-xs flex items-center space-x-2 border-b ${
            feedback.type === 'success'
              ? 'bg-emerald-950/40 border-emerald-800/40 text-emerald-300'
              : 'bg-red-950/40 border-red-800/40 text-red-300'
          }`}>
            {feedback.type === 'success' ? <CheckCircle className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
            <span className="font-medium">{feedback.message}</span>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="flex items-center px-6 border-b border-slate-800 bg-slate-950/40">
          <button
            onClick={() => setActiveTab('schedule')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 flex items-center space-x-2 transition ${
              activeTab === 'schedule'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Configuração do Agendamento</span>
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 flex items-center space-x-2 transition ${
              activeTab === 'history'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FolderArchive className="w-3.5 h-3.5" />
            <span>Histórico de Backups ({history.length})</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">

          {activeTab === 'schedule' ? (
            <div className="space-y-6">
              
              {/* Card 1: Toggle Principal de Ativação */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`p-2.5 rounded-xl border ${config.enabled ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-slate-800 border-slate-700 text-slate-500'}`}>
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-white">
                      Rotina de Backup Automático
                    </h4>
                    <p className="text-xs text-slate-400">
                      Dispara automaticamente no horário e na frequência programada salvando os arquivos na nuvem MongoDB Atlas.
                    </p>
                  </div>
                </div>

                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.enabled}
                    onChange={(e) => setConfig({ ...config, enabled: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              {/* Card 2: Frequência & Horário de Execução */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Frequência */}
                <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-5 space-y-3">
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-4 h-4 text-indigo-400" />
                    <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                      Frequência de Execução
                    </h4>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setConfig({ ...config, frequency: 'daily' })}
                      className={`p-3 rounded-xl border text-left text-xs transition ${
                        config.frequency === 'daily'
                          ? 'bg-indigo-600/20 border-indigo-500/50 text-white font-semibold'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800/60'
                      }`}
                    >
                      <div className="font-bold text-slate-200">Diária</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">Todos os dias</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setConfig({ ...config, frequency: 'weekly' })}
                      className={`p-3 rounded-xl border text-left text-xs transition ${
                        config.frequency === 'weekly'
                          ? 'bg-indigo-600/20 border-indigo-500/50 text-white font-semibold'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800/60'
                      }`}
                    >
                      <div className="font-bold text-slate-200">Semanal</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">1 vez por semana</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setConfig({ ...config, frequency: 'every_6h' })}
                      className={`p-3 rounded-xl border text-left text-xs transition ${
                        config.frequency === 'every_6h'
                          ? 'bg-indigo-600/20 border-indigo-500/50 text-white font-semibold'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800/60'
                      }`}
                    >
                      <div className="font-bold text-slate-200">A cada 6 horas</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">4 vezes ao dia</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setConfig({ ...config, frequency: 'every_12h' })}
                      className={`p-3 rounded-xl border text-left text-xs transition ${
                        config.frequency === 'every_12h'
                          ? 'bg-indigo-600/20 border-indigo-500/50 text-white font-semibold'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800/60'
                      }`}
                    >
                      <div className="font-bold text-slate-200">A cada 12 horas</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">2 vezes ao dia</div>
                    </button>
                  </div>

                  {/* Seletor de dia da semana para semanal */}
                  {config.frequency === 'weekly' && (
                    <div className="pt-2">
                      <label className="text-[11px] text-slate-400 block mb-1 font-medium">
                        Dia da Semana para Execução:
                      </label>
                      <select
                        value={config.dayOfWeek}
                        onChange={(e) => setConfig({ ...config, dayOfWeek: Number(e.target.value) })}
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                      >
                        {DAYS_OF_WEEK.map(d => (
                          <option key={d.value} value={d.value}>{d.label}</option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>

                {/* Horário de Execução */}
                <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-5 space-y-3">
                  <div className="flex items-center space-x-2">
                    <Clock className="w-4 h-4 text-emerald-400" />
                    <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                      Horário de Execução (Brasília / UTC)
                    </h4>
                  </div>

                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1 font-medium">
                      Horário programado (HH:MM):
                    </label>
                    <input
                      type="time"
                      value={config.executionTime}
                      onChange={(e) => setConfig({ ...config, executionTime: e.target.value })}
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-sm font-mono text-white focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-500 block mb-1.5 uppercase font-bold tracking-wider">
                      Horários Rápidos Sugeridos:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {PRESET_TIMES.map(t => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => setConfig({ ...config, executionTime: t })}
                          className={`px-2.5 py-1 rounded-lg text-xs font-mono border transition ${
                            config.executionTime === t
                              ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300 font-bold'
                              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="pt-2">
                    <label className="flex items-center space-x-2 text-xs text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={config.includeDatabaseFiles}
                        onChange={(e) => setConfig({ ...config, includeDatabaseFiles: e.target.checked })}
                        className="rounded border-slate-700 bg-slate-900 text-emerald-600 focus:ring-0"
                      />
                      <span>Incluir tabelas financeiras (users_mm, pix, proofs)</span>
                    </label>
                  </div>
                </div>

              </div>

              {/* Card 3: Seleção dos Bots */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Layers className="w-4 h-4 text-purple-400" />
                    <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                      Bots Incluídos no Backup ({config.selectedBotIds.length === 0 ? 'Todos' : `${config.selectedBotIds.length} selecionado(s)`})
                    </h4>
                  </div>
                  <button
                    type="button"
                    onClick={selectAllBots}
                    className={`text-xs px-2.5 py-1 rounded-lg border transition ${
                      config.selectedBotIds.length === 0
                        ? 'bg-purple-500/20 text-purple-300 border-purple-500/40 font-bold'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    Incluir Todos os Bots
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 pt-1">
                  {bots.map(bot => {
                    const isSelected = config.selectedBotIds.length === 0 || config.selectedBotIds.includes(bot.id);
                    return (
                      <div
                        key={bot.id}
                        onClick={() => toggleBotSelection(bot.id)}
                        className={`p-3 rounded-xl border cursor-pointer transition flex items-center justify-between ${
                          isSelected
                            ? 'bg-purple-950/20 border-purple-500/40 text-purple-200'
                            : 'bg-slate-900/40 border-slate-800/80 text-slate-500 opacity-60 hover:opacity-100'
                        }`}
                      >
                        <div className="overflow-hidden pr-2">
                          <div className="text-xs font-bold truncate text-slate-200">{bot.name}</div>
                          <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                            {bot.files?.length || 0} arquivos • {bot.status}
                          </div>
                        </div>
                        <input
                          type="checkbox"
                          checked={isSelected}
                          readOnly
                          className="rounded border-slate-700 bg-slate-900 text-purple-600 focus:ring-0 shrink-0 pointer-events-none"
                        />
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Card 4: Resumo do Último Backup Executado */}
              {config.lastRun && (
                <div className="bg-slate-950/40 border border-slate-800/60 rounded-2xl p-4 flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${config.lastRun.status === 'success' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>
                      {config.lastRun.status === 'success' ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                    </div>
                    <div>
                      <span className="font-semibold text-slate-200 block">
                        Última Execução Automática: {new Date(config.lastRun.timestamp).toLocaleString('pt-BR')}
                      </span>
                      <span className="text-slate-400 text-[11px]">
                        {config.lastRun.message} • {config.lastRun.totalFiles || 0} arquivos ({config.lastRun.sizeKb || 0} KB)
                      </span>
                    </div>
                  </div>
                </div>
              )}

            </div>
          ) : (
            /* Tab: Histórico de Backups */
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <div>
                  <h4 className="text-sm font-bold text-white">
                    Snapshots de Arquivos no MongoDB Atlas
                  </h4>
                  <p className="text-xs text-slate-400">
                    Restaure ou gerencie os backups completos dos códigos e tabelas dos seus bots.
                  </p>
                </div>
                <button
                  onClick={loadHistory}
                  disabled={loadingHistory}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium border border-slate-700 transition flex items-center space-x-1.5"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingHistory ? 'animate-spin' : ''}`} />
                  <span>Atualizar Lista</span>
                </button>
              </div>

              {history.length === 0 ? (
                <div className="text-center py-12 bg-slate-950/40 border border-dashed border-slate-800 rounded-2xl">
                  <FolderArchive className="w-10 h-10 text-slate-600 mx-auto mb-2" />
                  <p className="text-xs text-slate-400 font-medium">Nenhum backup encontrado no MongoDB Atlas ainda.</p>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Clique em "Fazer Backup Agora" para criar o primeiro snapshot dos arquivos.
                  </p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {history.map(item => (
                    <div
                      key={item.id}
                      className="bg-slate-950/60 border border-slate-800 hover:border-slate-700/80 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 transition"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                            item.trigger === 'daily'
                              ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                              : item.trigger === 'weekly'
                              ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                              : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          }`}>
                            {item.trigger === 'daily' ? 'Diário' : item.trigger === 'weekly' ? 'Semanal' : 'Manual'}
                          </span>
                          <span className="text-sm font-semibold text-white">
                            {item.label}
                          </span>
                        </div>
                        <div className="text-xs text-slate-400 flex flex-wrap items-center gap-x-3 gap-y-1">
                          <span>📅 {new Date(item.createdAt).toLocaleString('pt-BR')}</span>
                          <span>•</span>
                          <span>🤖 {item.totalBots} bot(s)</span>
                          <span>•</span>
                          <span>📄 {item.totalFiles} arquivos</span>
                          <span>•</span>
                          <span className="text-emerald-400 font-mono font-medium">{item.sizeKb} KB</span>
                        </div>
                        {item.botNames && item.botNames.length > 0 && (
                          <div className="text-[10px] text-slate-500 truncate max-w-lg">
                            Bots: {item.botNames.join(', ')}
                          </div>
                        )}
                      </div>

                      <div className="flex items-center space-x-2 shrink-0">
                        <button
                          onClick={() => handleRestoreBackup(item.id)}
                          disabled={restoringId === item.id}
                          className="px-3.5 py-1.5 bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 hover:text-white border border-indigo-500/30 rounded-xl text-xs font-semibold transition flex items-center space-x-1.5"
                          title="Restaurar arquivos para os bots"
                        >
                          <RotateCcw className={`w-3.5 h-3.5 ${restoringId === item.id ? 'animate-spin' : ''}`} />
                          <span>{restoringId === item.id ? 'Restaurando...' : 'Restaurar'}</span>
                        </button>
                        <button
                          onClick={() => handleDeleteBackup(item.id)}
                          disabled={deletingId === item.id}
                          className="p-1.5 text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition"
                          title="Excluir este backup do MongoDB"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-900/90 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center space-x-2 text-xs text-slate-400">
            <span className={`w-2 h-2 rounded-full ${mongoStatus.connected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
            <span>
              {mongoStatus.connected
                ? `MongoDB Atlas: Conectado (${mongoStatus.database || 'neuxmm'})`
                : 'MongoDB Atlas: Não Conectado'}
            </span>
          </div>

          <div className="flex items-center space-x-2 w-full sm:w-auto justify-end">
            <button
              onClick={handleRunBackupNow}
              disabled={runningBackup || !mongoStatus.connected}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-white rounded-xl text-xs font-semibold border border-slate-700 transition flex items-center space-x-1.5"
              title="Disparar um backup imediato dos arquivos agora"
            >
              <Play className={`w-3.5 h-3.5 text-emerald-400 ${runningBackup ? 'animate-spin' : ''}`} />
              <span>{runningBackup ? 'Criando Backup...' : 'Fazer Backup Agora'}</span>
            </button>

            <button
              onClick={handleSaveConfig}
              disabled={savingConfig}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-lg shadow-emerald-600/20 active:scale-95"
            >
              <Save className={`w-3.5 h-3.5 ${savingConfig ? 'animate-spin' : ''}`} />
              <span>{savingConfig ? 'Salvando...' : 'Salvar Configuração'}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
