import React, { useState, useEffect } from 'react';
import { Radio, Copy, Check, ExternalLink, Zap, ShieldCheck, Clock, Cpu, AlertTriangle, Activity } from 'lucide-react';

interface UptimeRobotModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UptimeRobotModal: React.FC<UptimeRobotModalProps> = ({ isOpen, onClose }) => {
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [copiedSseUrl, setCopiedSseUrl] = useState(false);
  const [pingStatus, setPingStatus] = useState<string | null>(null);
  const [isTestingPing, setIsTestingPing] = useState(false);
  const [serverKeepAlive, setServerKeepAlive] = useState<{ publicPingUrl?: string; uptimeSeconds?: number } | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    fetch('/api/keepalive-info')
      .then(res => res.json())
      .then(data => setServerKeepAlive(data))
      .catch(() => {});
  }, [isOpen]);

  if (!isOpen) return null;

  // Calculate the truly public URL (in AI Studio, ais-dev- requires Google login; ais-pre- is 100% public without login)
  const computePublicPingUrl = () => {
    if (serverKeepAlive?.publicPingUrl) return serverKeepAlive.publicPingUrl;
    if (typeof window === 'undefined') return 'https://botloom.app/ping';
    const origin = window.location.origin;
    if (origin.includes('ais-dev-')) {
      return origin.replace('ais-dev-', 'ais-pre-') + '/ping';
    }
    return `${origin}/ping`;
  };

  const publicPingUrl = computePublicPingUrl();
  const publicSseUrl = publicPingUrl.replace(/\/ping$/, '/api/stream');
  const keepAliveKey = 'botloom_keepalive_247_active';

  const handleCopy = (text: string, type: 'key' | 'url' | 'sse') => {
    navigator.clipboard.writeText(text);
    if (type === 'key') {
      setCopiedKey(true);
      setTimeout(() => setCopiedKey(false), 2000);
    } else if (type === 'url') {
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2000);
    } else {
      setCopiedSseUrl(true);
      setTimeout(() => setCopiedSseUrl(false), 2000);
    }
  };

  const handleTestPing = async () => {
    setIsTestingPing(true);
    setPingStatus(null);
    try {
      const res = await fetch('/ping');
      const data = await res.json();
      if (res.ok) {
        setPingStatus(`🟢 PING OK! Servidor e Gateway 24/7 Ativos | Uptime: ${data.uptimeSeconds || 0}s | Bots Online: ${data.botsOnline || 0}`);
      } else {
        setPingStatus('🔴 Erro ao testar ping.');
      }
    } catch (err: any) {
      setPingStatus(`🔴 Falha: ${err?.message || 'Servidor indisponível'}`);
    } finally {
      setIsTestingPing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl text-slate-100 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                UptimeRobot 24/7 & Proteção Anti-Queda
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-mono uppercase">
                  Proteção 24/7 Ativa
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Evite que o servidor ou os bots do Discord entrem em hibernação ou caiam!
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-slate-800 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-300">
          
          {/* Key Info Banner */}
          <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-xl p-4 flex items-start space-x-3">
            <ShieldCheck className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h3 className="font-bold text-emerald-200 text-sm">
                Proteções Anti-Queda Aplicadas no Servidor
              </h3>
              <p className="text-emerald-300/80 leading-relaxed text-[11px]">
                ✅ <strong>Self-Ping HTTPS a cada 25s:</strong> O servidor pinga sua própria URL pública pela internet impedindo a hibernação por inatividade.<br />
                ✅ <strong>Canal Streaming SSE Persistente:</strong> Mantém conexões ativas contínuas para a CPU nunca ser congelada.<br />
                ✅ <strong>Auto-Resume no Discord:</strong> O bot reconecta sua sessão de forma suave no WebSocket sem tempestades de reconexão.
              </p>
            </div>
          </div>

          {/* Attention Banner on Why It Was Falling */}
          <div className="bg-amber-950/30 border border-amber-500/30 rounded-xl p-3.5 flex items-start space-x-3 text-amber-200">
            <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
            <div className="space-y-1 text-[11px] leading-relaxed">
              <strong className="text-amber-300 font-semibold">⚠️ Por que o site caía antes mesmo com ping?</strong>
              <p className="text-amber-200/90">
                Se você colocou no UptimeRobot o link contendo <code className="bg-amber-900/40 px-1 py-0.5 rounded text-amber-300">ais-dev-</code>, esse link exige <strong>login com conta Google</strong>, bloqueando o UptimeRobot com erro 403 Forbidden!
                <br />
                <strong>A solução é usar a URL Pública Direta abaixo (<code className="bg-emerald-900/40 px-1 py-0.5 rounded text-emerald-300">ais-pre-</code>)</strong>, que é 100% pública e responde 24 horas por dia sem login.
              </p>
            </div>
          </div>

          {/* UptimeRobot Public Ping URL */}
          <div className="space-y-2">
            <label className="font-bold text-slate-200 text-xs flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-emerald-400" />
                URL PÚBLICA PARA UPTIMEROBOT (Sem exigência de login):
              </span>
              <span className="text-[10px] text-emerald-400 font-mono font-bold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                Recomendada • Intervalo 5 min
              </span>
            </label>
            <div className="flex items-center space-x-2">
              <input
                type="text"
                readOnly
                value={publicPingUrl}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 font-mono text-xs text-emerald-300 focus:outline-none select-all"
              />
              <button
                onClick={() => handleCopy(publicPingUrl, 'url')}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold flex items-center space-x-1.5 transition-all flex-shrink-0 shadow-lg shadow-emerald-600/20"
              >
                {copiedUrl ? <Check className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4" />}
                <span>{copiedUrl ? 'Copiado!' : 'Copiar URL Pública'}</span>
              </button>
            </div>
          </div>

          {/* SSE Stream URL */}
          <div className="space-y-2">
            <label className="font-bold text-slate-200 text-xs flex items-center justify-between">
              <span>CANAL STREAMING KEEPALIVE (SSE):</span>
              <span className="text-[10px] text-indigo-400 font-mono">Conexão Contínua</span>
            </label>
            <div className="flex items-center space-x-2">
              <input
                type="text"
                readOnly
                value={publicSseUrl}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 font-mono text-xs text-indigo-300 focus:outline-none select-all"
              />
              <button
                onClick={() => handleCopy(publicSseUrl, 'sse')}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold flex items-center space-x-1.5 transition-all flex-shrink-0 border border-slate-700"
              >
                {copiedSseUrl ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copiedSseUrl ? 'Copiado!' : 'Copiar Stream'}</span>
              </button>
            </div>
          </div>

          {/* Test Ping Button & Status */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div>
              <div className="font-bold text-slate-200 flex items-center space-x-2">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Testar Resposta de Ping Imediato</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Dispara um ping imediato para validar se o servidor e os bots estão ativos.
              </p>
            </div>
            <button
              onClick={handleTestPing}
              disabled={isTestingPing}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs transition-all flex items-center space-x-1.5 shadow-md flex-shrink-0 disabled:opacity-50"
            >
              <Clock className="w-4 h-4" />
              <span>{isTestingPing ? 'Testando...' : 'Testar Ping Agora'}</span>
            </button>
          </div>

          {pingStatus && (
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl font-mono text-xs text-emerald-400 animate-fade-in">
              {pingStatus}
            </div>
          )}

          {/* Step-by-step UptimeRobot guide */}
          <div className="border-t border-slate-800 pt-4 space-y-3">
            <h4 className="font-bold text-slate-200 flex items-center space-x-2">
              <ExternalLink className="w-4 h-4 text-indigo-400" />
              <span>Como configurar no UptimeRobot (Passo a Passo Corrigido):</span>
            </h4>
            <ol className="list-decimal list-inside space-y-1.5 text-slate-300 leading-relaxed pl-1 text-[11px]">
              <li>Acesse <a href="https://uptimerobot.com" target="_blank" rel="noreferrer" className="text-indigo-400 underline font-semibold">UptimeRobot.com</a> e faça login.</li>
              <li>Clique no botão <strong>+ Add New Monitor</strong>.</li>
              <li>Em <strong>Monitor Type</strong>, selecione <strong>HTTP(s)</strong>.</li>
              <li>Em <strong>Friendly Name</strong>, digite <code className="bg-slate-950 px-1 py-0.5 rounded text-indigo-300">BotLoom 24/7</code>.</li>
              <li>Em <strong>URL or IP</strong>, cole a URL Pública copiada acima (<code className="bg-slate-950 px-1 py-0.5 rounded text-emerald-300">{publicPingUrl}</code>).</li>
              <li>Em <strong>Monitoring Interval</strong>, defina <strong>5 minutos</strong>.</li>
              <li>Clique em <strong>Create Monitor</strong>. O UptimeRobot enviará pings contínuos sem bloqueios!</li>
            </ol>
          </div>

        </div>

        {/* Footer */}
        <div className="bg-slate-950 px-6 py-3 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl text-xs transition-all"
          >
            Fechar
          </button>
        </div>

      </div>
    </div>
  );
};
