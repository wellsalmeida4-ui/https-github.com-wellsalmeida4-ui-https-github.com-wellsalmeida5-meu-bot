import React from 'react';
import { Bot } from '../types';
import { AlertTriangle, X, Trash2 } from 'lucide-react';

interface DeleteConfirmModalProps {
  bot: Bot | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirmDelete: (botId: string) => Promise<void>;
  isDeleting: boolean;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  bot,
  isOpen,
  onClose,
  onConfirmDelete,
  isDeleting
}) => {
  if (!isOpen || !bot) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl">
        <div className="flex items-center space-x-3 text-rose-400 mb-3">
          <div className="w-10 h-10 rounded-xl bg-rose-950/60 border border-rose-800/80 flex items-center justify-center">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Excluir Bot</h3>
            <p className="text-xs text-slate-400">Esta ação não poderá ser desfeita.</p>
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed mb-5 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
          Tem certeza de que deseja excluir o bot <strong>"{bot.name}"</strong> (ID: {bot.botId})? Todos os arquivos do projeto e histórico de logs serão removidos da plataforma.
        </p>

        <div className="flex items-center justify-end space-x-3">
          <button
            onClick={onClose}
            disabled={isDeleting}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
          >
            Cancelar
          </button>
          <button
            onClick={() => onConfirmDelete(bot.id)}
            disabled={isDeleting}
            className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all shadow-lg shadow-rose-900/30"
          >
            <Trash2 className="w-4 h-4" />
            <span>{isDeleting ? 'Excluindo...' : 'Excluir Definitivamente'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
