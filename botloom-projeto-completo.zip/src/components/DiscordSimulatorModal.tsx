import React, { useState } from 'react';
import { Bot, DiscordMessage, DiscordEmbed, DiscordComponent } from '../types';
import {
  X,
  Send,
  Bot as BotIcon,
  Smile,
  Hash,
  Sparkles,
  Command,
  Image as ImageIcon,
  CheckCircle2,
  ExternalLink,
  MessageSquare
} from 'lucide-react';

interface DiscordSimulatorModalProps {
  bot: Bot | null;
  isOpen: boolean;
  onClose: () => void;
  onStartBot?: (botId: string) => void;
  onInteract: (payload: {
    command?: string;
    interactionType?: string;
    customId?: string;
    values?: string[];
    inputFields?: Record<string, string>;
  }) => Promise<{
    message?: DiscordMessage;
    showModal?: boolean;
    modalData?: {
      title: string;
      customId: string;
      fields: { customId: string; label: string; placeholder?: string }[];
    };
  }>;
}

export const DiscordSimulatorModal: React.FC<DiscordSimulatorModalProps> = ({
  bot,
  isOpen,
  onClose,
  onStartBot,
  onInteract
}) => {
  const [inputCommand, setInputCommand] = useState('');
  const [messages, setMessages] = useState<DiscordMessage[]>([]);

  const [activeModalData, setActiveModalData] = useState<{
    title: string;
    customId: string;
    fields: { customId: string; label: string; placeholder?: string }[];
  } | null>(null);

  const [modalInputValues, setModalInputValues] = useState<Record<string, string>>({});
  const [isSending, setIsSending] = useState(false);

  const isOnline = bot?.status === 'online';

  // Initialize or reset greeting message when bot changes
  React.useEffect(() => {
    if (isOpen && bot) {
      const isBotOnline = bot.status === 'online';
      setMessages([
        {
          id: 'm-init',
          author: {
            username: bot.name,
            bot: true,
            avatar: bot.icon || '🤖'
          },
          content: isBotOnline
            ? `👋 **Simulador do Discord BotLoom**: Digite um comando slash (ex: \`/ping\`, \`/help\`, \`/ticket\`, \`/welcome\`) ou envie uma mensagem com o prefixo \`${bot.prefix}\` para testar as respostas em tempo real!`
            : `🔴 **[BOT DESLIGADO]** O bot **${bot.name}** está atualmente **OFFLINE**. Ligue-o para poder enviar comandos e interagir no simulador.`,
          timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  }, [isOpen, bot?.id, bot?.status]);

  if (!isOpen || !bot) return null;

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputCommand.trim() || isSending) return;

    const userText = inputCommand.trim();
    const timeNow = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

    // Append user message
    const userMsg: DiscordMessage = {
      id: 'usr-' + Date.now(),
      author: {
        username: 'UsuárioTeste',
        bot: false,
        avatar: '👤'
      },
      content: userText,
      timestamp: timeNow
    };

    setMessages(prev => [...prev, userMsg]);
    setInputCommand('');

    if (bot.status !== 'online') {
      setMessages(prev => [
        ...prev,
        {
          id: 'off-' + Date.now(),
          author: {
            username: bot.name,
            bot: true,
            avatar: bot.icon || '🤖'
          },
          content: `🔴 **[BOT DESLIGADO]** O bot **${bot.name}** está **OFFLINE**. Ligue-o no painel ou no botão no topo para enviar e responder comandos.`,
          timestamp: timeNow
        }
      ]);
      return;
    }

    try {
      setIsSending(true);
      const res = await onInteract({ command: userText });

      if (res.showModal && res.modalData) {
        setActiveModalData(res.modalData);
      } else if (res.message) {
        setMessages(prev => [...prev, res.message!]);
      }
    } catch (err: any) {
      console.error(err);
      setMessages(prev => [
        ...prev,
        {
          id: 'err-' + Date.now(),
          author: {
            username: bot.name,
            bot: true,
            avatar: bot.icon || '🤖'
          },
          content: `⚠️ **Aviso:** ${err?.message || 'O bot está desligado ou não respondeu.'}`,
          timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setIsSending(false);
    }
  };

  const handleComponentClick = async (comp: DiscordComponent) => {
    if (bot.status !== 'online') {
      setMessages(prev => [
        ...prev,
        {
          id: 'off-' + Date.now(),
          author: {
            username: bot.name,
            bot: true,
            avatar: bot.icon || '🤖'
          },
          content: `🔴 **[BOT DESLIGADO]** O bot está OFFLINE. Ligue-o para interagir com botões e menus.`,
          timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
      return;
    }

    try {
      const res = await onInteract({
        interactionType: 'button',
        customId: comp.customId
      });

      if (res.showModal && res.modalData) {
        setActiveModalData(res.modalData);
      } else if (res.message) {
        setMessages(prev => [...prev, res.message!]);
      }
    } catch (err) {
      console.error(err);
      setMessages(prev => [
        ...prev,
        {
          id: 'err-' + Date.now(),
          author: {
            username: bot.name,
            bot: true,
            avatar: bot.icon || '🤖'
          },
          content: `⚠️ **Esta interação falhou:** O bot não respondeu a tempo (3s) ou ocorreu um erro.`,
          timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  };

  const handleSelectChange = async (comp: any, selectedVal: string) => {
    if (!selectedVal) return;
    if (bot.status !== 'online') {
      setMessages(prev => [
        ...prev,
        {
          id: 'off-' + Date.now(),
          author: {
            username: bot.name,
            bot: true,
            avatar: bot.icon || '🤖'
          },
          content: `🔴 **[BOT DESLIGADO]** O bot está OFFLINE. Ligue-o para usar os menus de seleção.`,
          timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
      return;
    }

    try {
      const res = await onInteract({
        interactionType: 'select_menu',
        customId: comp.customId || 'select_menu',
        values: [selectedVal]
      });

      if (res.showModal && res.modalData) {
        setActiveModalData(res.modalData);
      } else if (res.message) {
        setMessages(prev => [...prev, res.message!]);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleModalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeModalData) return;

    if (bot.status !== 'online') {
      setActiveModalData(null);
      setModalInputValues({});
      return;
    }

    try {
      const res = await onInteract({
        interactionType: 'modal_submit',
        customId: activeModalData.customId,
        inputFields: modalInputValues
      });

      setActiveModalData(null);
      setModalInputValues({});

      if (res.message) {
        setMessages(prev => [...prev, res.message!]);
      }
    } catch (err) {
      console.error(err);
      setActiveModalData(null);
      setModalInputValues({});
      setMessages(prev => [
        ...prev,
        {
          id: 'err-' + Date.now(),
          author: {
            username: bot.name,
            bot: true,
            avatar: bot.icon || '🤖'
          },
          content: `⚠️ **Erro no envio do formulário:** O bot não processou a resposta.`,
          timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-950/85 backdrop-blur-md">
      <div className="bg-[#313338] border border-slate-700 rounded-2xl w-full max-w-4xl h-[85vh] shadow-2xl flex flex-col overflow-hidden text-slate-200">
        
        {/* Discord Header Bar */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#2b2d31] border-b border-[#1e1f22]">
          <div className="flex items-center space-x-2">
            <Hash className="w-5 h-5 text-slate-400" />
            <h2 className="text-sm font-bold text-white font-sans">comandos-bot</h2>
            <span className="text-xs text-slate-400 border-l border-slate-700 pl-2 hidden sm:inline">
              Simulador em Tempo Real para <strong>{bot.name}</strong>
            </span>
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
              isOnline
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
            }`}>
              {isOnline ? '🟢 ONLINE' : '🔴 DESLIGADO'}
            </span>
          </div>

          <div className="flex items-center space-x-2">
            {!isOnline && onStartBot && (
              <button
                onClick={() => onStartBot(bot.id)}
                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold transition-colors flex items-center space-x-1 shadow-md"
              >
                <span>⚡ Ligar Bot</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Offline Status Warning Bar */}
        {!isOnline && (
          <div className="bg-rose-950/90 border-b border-rose-800/80 px-4 py-2.5 flex items-center justify-between text-xs text-rose-200">
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
              <span>
                <strong>ATENÇÃO:</strong> O bot <strong>{bot.name}</strong> está <strong>DESLIGADO (OFFLINE)</strong> no painel. Ele não responderá a comandos no simulador nem no Discord.
              </span>
            </div>
            {onStartBot && (
              <button
                onClick={() => onStartBot(bot.id)}
                className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold text-xs transition-all shadow active:scale-95 flex-shrink-0"
              >
                LIGAR BOT
              </button>
            )}
          </div>
        )}

        {/* Discord Chat Messages View */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-[#313338]">
          {messages.map(msg => (
            <div key={msg.id} className="flex items-start space-x-3 group hover:bg-[#2e3035] p-2 rounded-xl transition-colors">
              
              {/* Avatar */}
              <div className="w-10 h-10 rounded-full bg-blurple flex items-center justify-center text-lg font-bold flex-shrink-0 text-white shadow">
                {msg.author.avatar || '🤖'}
              </div>

              {/* Content Box */}
              <div className="flex-1 overflow-hidden">
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-bold text-white">{msg.author.username}</span>
                  {msg.author.bot && (
                    <span className="bg-[#5865f2] text-[10px] font-bold text-white px-1.5 py-0.2 rounded uppercase">
                      BOT
                    </span>
                  )}
                  <span className="text-[11px] text-slate-400">{msg.timestamp}</span>
                </div>

                {msg.content && (
                  <p className="text-sm text-slate-200 mt-1 whitespace-pre-wrap leading-relaxed">
                    {msg.content}
                  </p>
                )}

                {/* Embeds Rendering */}
                {msg.embeds && msg.embeds.map((embed, idx) => (
                  <div
                    key={idx}
                    className="mt-2.5 p-3.5 rounded-lg bg-[#2b2d31] border-l-4 max-w-lg shadow-md"
                    style={{ borderColor: embed.color || '#5865F2' }}
                  >
                    {embed.title && (
                      <h4 className="text-sm font-bold text-white mb-1">{embed.title}</h4>
                    )}
                    {embed.description && (
                      <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-wrap mb-2">
                        {embed.description}
                      </p>
                    )}

                    {/* Author */}
                    {embed.author && (
                      <div className="flex items-center space-x-2 mb-2">
                        {embed.author.iconUrl && (
                          <img src={embed.author.iconUrl} alt="Author icon" className="w-5 h-5 rounded-full" />
                        )}
                        <span className="text-xs font-bold text-white">{embed.author.name}</span>
                      </div>
                    )}

                    {/* Thumbnail */}
                    {(embed.thumbnailUrl || (embed as any).thumbnail?.url) && (
                      <div className="float-right ml-3 mb-2 w-16 h-16 rounded-lg overflow-hidden border border-slate-700/60 bg-[#1e1f22]">
                        <img
                          src={embed.thumbnailUrl || (embed as any).thumbnail?.url}
                          alt="Thumbnail"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}

                    {embed.title && (
                      <h4 className="text-sm font-bold text-white mb-1">{embed.title}</h4>
                    )}
                    {embed.description && (
                      <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-wrap mb-2">
                        {embed.description}
                      </p>
                    )}

                    {embed.fields && embed.fields.length > 0 && (
                      <div className="grid grid-cols-2 gap-2 my-2 text-xs">
                        {embed.fields.map((field, fIdx) => (
                          <div key={fIdx} className={field.inline ? '' : 'col-span-2'}>
                            <p className="font-bold text-white">{field.name}</p>
                            <p className="text-slate-300">{field.value}</p>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Embed Image - Full Aspect Ratio Formatting */}
                    {(embed.imageUrl || (embed as any).image?.url) && (
                      <div className="mt-2.5 rounded-lg overflow-hidden border border-slate-700/80 bg-[#1e1f22] max-w-full flex items-center justify-center p-1">
                        <img
                          src={embed.imageUrl || (embed as any).image?.url}
                          alt="Embed image"
                          className="w-full h-auto max-h-[420px] object-contain rounded-md"
                        />
                      </div>
                    )}

                    {embed.footer && (
                      <div className="mt-2 pt-2 border-t border-slate-700/60 text-[10px] text-slate-400 flex items-center justify-between">
                        <span>{embed.footer.text}</span>
                        {embed.timestamp && <span>{msg.timestamp}</span>}
                      </div>
                    )}
                  </div>
                ))}

                {/* Attachments Rendering */}
                {msg.attachments && msg.attachments.length > 0 && (
                  <div className="mt-2.5 space-y-2">
                    {msg.attachments.map((att: any, aIdx: number) => {
                      const url = typeof att === 'string' ? att : (att.url || att.attachment);
                      if (!url) return null;
                      const isImg = /\.(png|jpe?g|gif|webp)(\?.*)?$/i.test(url) || url.startsWith('data:image/');
                      if (isImg) {
                        return (
                          <div key={aIdx} className="rounded-xl overflow-hidden border border-slate-700/80 bg-[#1e1f22] max-w-lg shadow-md p-1">
                            <img src={url} alt="Attachment" className="w-full h-auto max-h-[450px] object-contain rounded-lg" />
                          </div>
                        );
                      }
                      return (
                        <a key={aIdx} href={url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center space-x-2 text-xs text-indigo-400 hover:underline bg-[#2b2d31] p-2 rounded-lg border border-slate-700">
                          <ImageIcon className="w-3.5 h-3.5" />
                          <span>Anexo {aIdx + 1}</span>
                        </a>
                      );
                    })}
                  </div>
                )}

                {/* Component Buttons & Select Menus Rendering */}
                {msg.components && msg.components.length > 0 && (
                  <div className="flex flex-wrap items-center gap-2 mt-3">
                    {msg.components.map((comp: any, cIdx: number) => {
                      if (comp.type === 'select' || comp.type === 'string_select' || comp.options) {
                        return (
                          <select
                            key={cIdx}
                            onChange={e => handleSelectChange(comp, e.target.value)}
                            className="bg-[#2b2d31] border border-slate-600 text-xs text-white rounded-lg px-3 py-1.5 focus:outline-none cursor-pointer hover:border-slate-500"
                          >
                            <option value="">{comp.placeholder || 'Selecione uma opção...'}</option>
                            {comp.options?.map((opt: any, oIdx: number) => (
                              <option key={oIdx} value={opt.value}>
                                {opt.label} {opt.description ? `- ${opt.description}` : ''}
                              </option>
                            ))}
                          </select>
                        );
                      }

                      const isApprove = comp.style === 'success' || comp.style === 3 || /aprovar|approve|confirmar|aceitar/i.test(comp.label || '');
                      const isReject = comp.style === 'danger' || comp.style === 4 || /rejeitar|reject|cancelar|recusar/i.test(comp.label || '');
                      const isSecondary = comp.style === 'secondary' || comp.style === 2;

                      let btnStyleClass = 'bg-[#5865f2] hover:bg-[#4752c4] text-white';
                      if (isApprove) {
                        btnStyleClass = 'bg-emerald-600 hover:bg-emerald-500 text-white font-bold shadow-md shadow-emerald-950/40';
                      } else if (isReject) {
                        btnStyleClass = 'bg-rose-600 hover:bg-rose-500 text-white font-bold shadow-md shadow-rose-950/40';
                      } else if (isSecondary) {
                        btnStyleClass = 'bg-slate-700 hover:bg-slate-600 text-slate-200';
                      }

                      return (
                        <button
                          key={cIdx}
                          onClick={() => handleComponentClick(comp)}
                          className={`px-3 py-1.5 rounded text-xs font-semibold shadow transition-all active:scale-95 flex items-center space-x-1.5 ${btnStyleClass}`}
                        >
                          {isApprove && <CheckCircle2 className="w-3.5 h-3.5 mr-1 text-emerald-200" />}
                          <span>{comp.label}</span>
                        </button>
                      );
                    })}
                  </div>
                )}

              </div>
            </div>
          ))}
        </div>

        {/* Discord Chat Input Box */}
        <div className="p-4 bg-[#2b2d31] border-t border-[#1e1f22]">
          <form onSubmit={handleSendMessage} className="flex items-center bg-[#383a40] rounded-lg px-3 py-2">
            <span className="text-slate-400 text-xs font-mono mr-2">/</span>
            <input
              type="text"
              value={inputCommand}
              onChange={e => setInputCommand(e.target.value)}
              placeholder="Digite /ping, /help, /ticket, /welcome ou qualquer comando..."
              className="flex-1 bg-transparent text-sm text-white placeholder-slate-500 focus:outline-none font-sans"
            />
            <button
              type="submit"
              disabled={isSending}
              className="ml-2 p-1.5 rounded-md bg-[#5865f2] text-white hover:bg-[#4752c4] transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 px-1">
            <div className="flex items-center space-x-2">
              <span className="bg-[#1e1f22] px-1.5 py-0.5 rounded text-slate-300">Sugestões:</span>
              <button onClick={() => setInputCommand('/ping')} className="hover:text-white">/ping</button>
              <button onClick={() => setInputCommand('/help')} className="hover:text-white">/help</button>
              <button onClick={() => setInputCommand('/ticket')} className="hover:text-white">/ticket</button>
              <button onClick={() => setInputCommand('/welcome')} className="hover:text-white">/welcome</button>
            </div>
            <span>BotLoom Gateway Simulator</span>
          </div>
        </div>

        {/* Modal Popup Overlay if triggered */}
        {activeModalData && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <div className="bg-[#313338] border border-slate-700 rounded-xl w-full max-w-md p-5 text-slate-200 shadow-2xl">
              <h3 className="text-base font-bold text-white mb-3">{activeModalData.title}</h3>
              <form onSubmit={handleModalSubmit} className="space-y-4">
                {activeModalData.fields.map(field => (
                  <div key={field.customId}>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      {field.label}
                    </label>
                    <input
                      type="text"
                      placeholder={field.placeholder}
                      onChange={e => setModalInputValues({ ...modalInputValues, [field.customId]: e.target.value })}
                      className="w-full bg-[#1e1f22] border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-[#5865f2]"
                      required
                    />
                  </div>
                ))}
                <div className="flex justify-end space-x-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setActiveModalData(null)}
                    className="px-3 py-1.5 rounded text-xs bg-slate-700 hover:bg-slate-600 text-white"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded text-xs bg-[#5865f2] hover:bg-[#4752c4] text-white font-bold"
                  >
                    Enviar Formulário
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
