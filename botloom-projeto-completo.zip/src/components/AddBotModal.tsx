import React, { useState } from 'react';
import { BotFile, BotTemplate } from '../types';
import { BOT_TEMPLATES } from '../data/templates';
import JSZip from 'jszip';
import {
  X,
  Upload,
  Code,
  FileCode,
  Bot as BotIcon,
  Check,
  AlertCircle,
  Sparkles,
  FileArchive,
  FolderPlus
} from 'lucide-react';

interface AddBotModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: {
    name: string;
    botId: string;
    token?: string;
    prefix?: string;
    description?: string;
    files: BotFile[];
    codeOption: 'file' | 'code';
  }) => Promise<void>;
}

export const AddBotModal: React.FC<AddBotModalProps> = ({
  isOpen,
  onClose,
  onSubmit
}) => {
  const [name, setName] = useState('');
  const [botId, setBotId] = useState('');
  const [token, setToken] = useState('');
  const [prefix, setPrefix] = useState('!');
  const [description, setDescription] = useState('');

  const [codeOption, setCodeOption] = useState<'code' | 'file'>('code');
  const [selectedTemplateId, setSelectedTemplateId] = useState('slash-starter');

  // Code option custom code
  const [writtenCode, setWrittenCode] = useState(
    BOT_TEMPLATES[0].files.find(f => f.name === 'index.js')?.content || ''
  );

  // Uploaded files
  const [uploadedFiles, setUploadedFiles] = useState<BotFile[]>([]);
  const [uploadedZipName, setUploadedZipName] = useState<string | null>(null);

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const folderInputRef = React.useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    if (folderInputRef.current) {
      folderInputRef.current.setAttribute('webkitdirectory', '');
      folderInputRef.current.setAttribute('directory', '');
    }
  }, []);

  if (!isOpen) return null;

  // Handle template switch
  const handleSelectTemplate = (template: BotTemplate) => {
    setSelectedTemplateId(template.id);
    const mainFile = template.files.find(f => f.name === 'index.js');
    if (mainFile) {
      setWrittenCode(mainFile.content);
    }
  };

  // Helper to recursively read dropped folders
  const readEntriesFromItems = async (items: DataTransferItemList): Promise<{ file: File; relativePath: string }[]> => {
    const results: { file: File; relativePath: string }[] = [];

    const readEntry = async (entry: any, currentPath: string): Promise<void> => {
      if (!entry) return;
      if (entry.isFile) {
        await new Promise<void>((resolve) => {
          entry.file(
            (f: File) => {
              const relPath = currentPath ? `${currentPath}/${f.name}` : f.name;
              results.push({ file: f, relativePath: relPath });
              resolve();
            },
            () => resolve()
          );
        });
      } else if (entry.isDirectory) {
        const dirReader = entry.createReader();
        const readBatch = (): Promise<any[]> => {
          return new Promise((resolve) => {
            dirReader.readEntries(
              (entries: any[]) => resolve(entries),
              () => resolve([])
            );
          });
        };

        let entries: any[] = [];
        let batch: any[] = [];
        do {
          batch = await readBatch();
          entries = entries.concat(batch);
        } while (batch.length > 0);

        const newPath = currentPath ? `${currentPath}/${entry.name}` : entry.name;
        for (const child of entries) {
          await readEntry(child, newPath);
        }
      }
    };

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (item.webkitGetAsEntry) {
        const entry = item.webkitGetAsEntry();
        if (entry) {
          await readEntry(entry, '');
        }
      }
    }

    return results;
  };

  // Handle ZIP or File Upload
  const processFiles = async (filesList: FileList | File[]) => {
    if (!filesList || filesList.length === 0) return;

    setErrorMessage('');
    const filesArray = Array.from(filesList);
    const parsedFiles: BotFile[] = [];
    let primaryName = '';

    for (const file of filesArray) {
      const lowerName = file.name.toLowerCase();

      // Check for unsupported archives
      if (
        lowerName.endsWith('.rar') ||
        lowerName.endsWith('.7z') ||
        lowerName.endsWith('.tar') ||
        lowerName.endsWith('.gz') ||
        lowerName.endsWith('.bz2')
      ) {
        setErrorMessage(
          `Arquivos .${lowerName.split('.').pop()} não são arquivos ZIP válidos. Por favor, descompacte o arquivo e envie como .ZIP ou arraste a pasta descompactada.`
        );
        return;
      }

      if (lowerName.endsWith('.zip')) {
        try {
          primaryName = file.name;
          const zip = new JSZip();
          const zipContent = await zip.loadAsync(file);

          const rawEntries: { path: string; zipObj: JSZip.JSZipObject }[] = [];

          // 1. Filter out directory entries and ignored metadata/node_modules
          for (const rawFilename of Object.keys(zipContent.files)) {
            const zipObj = zipContent.files[rawFilename];
            if (zipObj.dir) continue;

            const lower = rawFilename.toLowerCase();
            if (
              lower.includes('__macosx') ||
              lower.includes('.ds_store') ||
              lower.includes('node_modules/') ||
              lower.includes('.git/') ||
              lower.includes('.next/') ||
              lower.includes('dist/') ||
              lower.includes('build/')
            ) {
              continue;
            }

            rawEntries.push({ path: rawFilename, zipObj });
          }

          if (rawEntries.length === 0) {
            throw new Error('O arquivo ZIP não contém arquivos válidos de código.');
          }

          // 2. Detect common top-level prefix if present (e.g., 'my-bot-master/')
          const paths = rawEntries.map(e => e.path);
          let commonPrefix = '';
          const firstPathParts = paths[0].split('/');
          if (firstPathParts.length > 1) {
            const possiblePrefix = firstPathParts[0] + '/';
            if (paths.every(p => p.startsWith(possiblePrefix))) {
              commonPrefix = possiblePrefix;
            }
          }

          // 3. Read files asynchronously
          for (const entry of rawEntries) {
            const cleanPath = commonPrefix ? entry.path.replace(commonPrefix, '') : entry.path;
            if (!cleanPath) continue;

            const lower = cleanPath.toLowerCase();
            // Skip binary extensions from text parsing
            if (
              lower.endsWith('.png') ||
              lower.endsWith('.jpg') ||
              lower.endsWith('.jpeg') ||
              lower.endsWith('.gif') ||
              lower.endsWith('.ico') ||
              lower.endsWith('.sqlite') ||
              lower.endsWith('.db') ||
              lower.endsWith('.node') ||
              lower.endsWith('.exe') ||
              lower.endsWith('.zip')
            ) {
              parsedFiles.push({
                name: cleanPath,
                path: cleanPath,
                content: `// [Arquivo Binário: ${cleanPath}]`
              });
              continue;
            }

            try {
              const content = await entry.zipObj.async('string');
              parsedFiles.push({
                name: cleanPath,
                path: cleanPath,
                content
              });
            } catch (fileErr) {
              console.warn('Erro ao ler arquivo do zip:', cleanPath, fileErr);
              parsedFiles.push({
                name: cleanPath,
                path: cleanPath,
                content: `// Não foi possível ler o arquivo ${cleanPath}`
              });
            }
          }
        } catch (err: any) {
          console.error(err);
          setErrorMessage('Erro ao extrair arquivo ZIP: ' + (err.message || 'Verifique se o arquivo não está corrompido.'));
          return;
        }
      } else {
        // Non-ZIP file (JS, JSON, TS, TXT, ENV, etc.)
        try {
          const cleanPath = (file as any).customPath || file.webkitRelativePath || file.name;
          const lower = cleanPath.toLowerCase();

          // Skip node_modules or system files
          if (
            lower.includes('__macosx') ||
            lower.includes('.ds_store') ||
            lower.includes('node_modules/') ||
            lower.includes('.git/') ||
            lower.includes('.next/') ||
            lower.includes('dist/')
          ) {
            continue;
          }

          const text = await file.text();
          if (!primaryName) primaryName = file.name;

          parsedFiles.push({
            name: cleanPath,
            path: cleanPath,
            content: text
          });
        } catch (err) {
          console.warn('Erro ao ler arquivo individual:', file.name, err);
        }
      }
    }

    if (parsedFiles.length === 0) {
      setErrorMessage('Nenhum arquivo válido pôde ser extraído. Verifique o formato do arquivo.');
      return;
    }

    setUploadedFiles(prev => {
      const existingPaths = new Set(prev.map(p => p.path));
      const filteredNew = parsedFiles.filter(p => !existingPaths.has(p.path));
      return [...prev, ...filteredNew];
    });

    if (primaryName) {
      setUploadedZipName(primaryName);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      await processFiles(e.target.files);
    }
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();

    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) {
      const items = e.dataTransfer.items;
      let hasDirectory = false;

      for (let i = 0; i < items.length; i++) {
        const entry = items[i].webkitGetAsEntry?.();
        if (entry?.isDirectory) {
          hasDirectory = true;
          break;
        }
      }

      if (hasDirectory) {
        const folderFiles = await readEntriesFromItems(items);
        const fileObjects = folderFiles.map(item => {
          return Object.defineProperty(item.file, 'customPath', {
            value: item.relativePath,
            writable: false
          });
        });
        await processFiles(fileObjects);
        return;
      }
    }

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      await processFiles(e.dataTransfer.files);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!name.trim()) {
      setErrorMessage('Por favor, informe o Nome do bot.');
      return;
    }

    if (!botId.trim()) {
      setErrorMessage('Por favor, informe o ID do bot.');
      return;
    }

    let finalFiles: BotFile[] = [];

    if (codeOption === 'code') {
      const currentTemplate = BOT_TEMPLATES.find(t => t.id === selectedTemplateId) || BOT_TEMPLATES[0];
      finalFiles = currentTemplate.files.map(f => {
        if (f.name === 'index.js') {
          return { ...f, content: writtenCode };
        }
        return f;
      });
    } else {
      if (uploadedFiles.length === 0) {
        setErrorMessage('Por favor, faça o upload do projeto em ZIP ou insira arquivos.');
        return;
      }
      finalFiles = uploadedFiles;
    }

    try {
      setIsLoading(true);
      await onSubmit({
        name,
        botId,
        token: token || undefined,
        prefix: prefix || '!',
        description: description || 'Bot do Discord hospedado na BotLoom Hosting.',
        files: finalFiles,
        codeOption
      });
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Erro ao cadastrar bot.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl shadow-2xl overflow-hidden my-8 my-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <BotIcon className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">Adicionar Novo Bot</h2>
              <p className="text-xs text-slate-400">Cadastre um bot do Discord para hospedar e executar 24/7</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          
          {errorMessage && (
            <div className="p-3.5 bg-rose-950/60 border border-rose-800/80 rounded-xl text-rose-300 text-xs flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Basic Fields Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Nome do bot */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Nome do Bot <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Ex: BotLoom Moderador"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                required
              />
            </div>

            {/* ID do bot */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                ID do Bot (Client ID) <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={botId}
                onChange={e => setBotId(e.target.value)}
                placeholder="Ex: 128475920184710293"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                required
              />
            </div>

            {/* Bot Token */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Token do Bot <span className="text-slate-500 font-normal">(Opcional para testes)</span>
              </label>
              <input
                type="password"
                value={token}
                onChange={e => setToken(e.target.value)}
                placeholder="MTI4NDc1OTI..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Prefix */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Prefixo Padrão
              </label>
              <input
                type="text"
                value={prefix}
                onChange={e => setPrefix(e.target.value)}
                placeholder="Ex: ! ou /"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:border-indigo-500"
              />
            </div>

          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Descrição do Bot
            </label>
            <input
              type="text"
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Descreva brevemente a finalidade e comandos do seu bot..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Código do Bot Section */}
          <div className="pt-3 border-t border-slate-800">
            <label className="block text-xs font-bold text-white mb-2">
              Opção do Código do Bot
            </label>

            {/* Option Tabs */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              
              <button
                type="button"
                onClick={() => setCodeOption('code')}
                className={`flex items-center justify-center space-x-2 py-3 px-4 rounded-xl border text-xs font-semibold transition-all ${
                  codeOption === 'code'
                    ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300 ring-1 ring-indigo-500/50'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <Code className="w-4 h-4" />
                <span>Código escrito</span>
              </button>

              <button
                type="button"
                onClick={() => setCodeOption('file')}
                className={`flex items-center justify-center space-x-2 py-3 px-4 rounded-xl border text-xs font-semibold transition-all ${
                  codeOption === 'file'
                    ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300 ring-1 ring-indigo-500/50'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <Upload className="w-4 h-4" />
                <span>Enviar arquivo (ZIP / Pasta)</span>
              </button>

            </div>

            {/* Code Written View */}
            {codeOption === 'code' && (
              <div className="space-y-3">
                
                {/* Template Selector */}
                <div>
                  <span className="block text-[11px] font-semibold text-slate-400 mb-1.5 flex items-center space-x-1">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Selecione um Template Starter (discord.js v14):</span>
                  </span>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                    {BOT_TEMPLATES.map(tmpl => (
                      <button
                        key={tmpl.id}
                        type="button"
                        onClick={() => handleSelectTemplate(tmpl)}
                        className={`p-2.5 rounded-xl border text-left transition-all flex items-start space-x-2 ${
                          selectedTemplateId === tmpl.id
                            ? 'bg-slate-800 border-indigo-500 text-white'
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                        }`}
                      >
                        <span className="text-lg">{tmpl.icon}</span>
                        <div>
                          <p className="text-xs font-bold text-slate-200 leading-tight">{tmpl.name}</p>
                          <p className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">{tmpl.description}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Integrated Editor */}
                <div className="rounded-xl border border-slate-800 bg-slate-950 overflow-hidden">
                  <div className="flex items-center justify-between px-3 py-1.5 bg-slate-900 border-b border-slate-800 text-[11px] text-slate-400 font-mono">
                    <span className="flex items-center space-x-1.5">
                      <FileCode className="w-3.5 h-3.5 text-indigo-400" />
                      <span>index.js (Destaque de sintaxe & Salvamento Automático)</span>
                    </span>
                    <span className="text-[10px] text-emerald-400 font-semibold">Ready</span>
                  </div>

                  <div className="relative flex font-mono text-xs">
                    {/* Line Numbers */}
                    <div className="select-none bg-slate-900/60 text-slate-600 p-3 text-right pr-2 border-r border-slate-800/80 font-mono leading-relaxed text-[11px] min-w-[36px]">
                      {writtenCode.split('\n').map((_, idx) => (
                        <div key={idx}>{idx + 1}</div>
                      ))}
                    </div>

                    {/* Textarea Code Input */}
                    <textarea
                      value={writtenCode}
                      onChange={e => setWrittenCode(e.target.value)}
                      rows={10}
                      className="w-full bg-slate-950 text-slate-200 p-3 font-mono text-xs leading-relaxed focus:outline-none resize-none"
                      spellCheck={false}
                    ></textarea>
                  </div>
                </div>

              </div>
            )}

            {/* File Upload View */}
            {codeOption === 'file' && (
              <div
                onDragOver={e => e.preventDefault()}
                onDrop={handleDrop}
                className="p-6 border-2 border-dashed border-slate-800 hover:border-indigo-500/50 rounded-2xl bg-slate-950 text-center transition-all group"
              >
                <input
                  type="file"
                  id="bot-file-upload"
                  accept=".zip,.js,.json,.ts,.cjs,.mjs,.txt,.env"
                  multiple
                  onChange={handleFileUpload}
                  className="hidden"
                />

                <input
                  ref={folderInputRef}
                  type="file"
                  id="bot-folder-upload"
                  multiple
                  onChange={handleFileUpload}
                  className="hidden"
                />

                <div className="flex flex-col items-center justify-center">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-600/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                    <FileArchive className="w-6 h-6" />
                  </div>

                  <p className="text-xs font-bold text-white mb-1">
                    Arraste sua pasta descompactada ou selecione um ZIP / múltiplos arquivos
                  </p>
                  <p className="text-[11px] text-slate-400 mb-4 max-w-md mx-auto leading-relaxed">
                    Suporta bots Discord com qualquer estrutura de pastas (commands, events, package.json).
                    <br />
                    <span className="text-amber-400/90 font-medium">Nota: Se tiver em .RAR ou .7z, envie a pasta descompactada diretamente.</span>
                  </p>

                  <div className="flex flex-wrap items-center justify-center gap-3">
                    <label
                      htmlFor="bot-file-upload"
                      className="cursor-pointer px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition-all flex items-center space-x-1.5"
                    >
                      <FileArchive className="w-4 h-4" />
                      <span>Selecionar Arquivo .ZIP</span>
                    </label>

                    <label
                      htmlFor="bot-folder-upload"
                      className="cursor-pointer px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all flex items-center space-x-1.5"
                    >
                      <FolderPlus className="w-4 h-4 text-indigo-400" />
                      <span>Selecionar Pasta Inteira</span>
                    </label>
                  </div>
                </div>

                {uploadedZipName && (
                  <div className="mt-4 p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-xl text-emerald-300 text-xs flex items-center justify-center space-x-2">
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>Carregado: <strong>{uploadedZipName}</strong> ({uploadedFiles.length} arquivos detectados)</span>
                  </div>
                )}
              </div>
            )}

          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
            >
              Cancelar
            </button>

            <button
              type="submit"
              disabled={isLoading}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/30 transition-all"
            >
              {isLoading ? 'Cadastrando Bot...' : 'Cadastrar e Salvar Bot'}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
