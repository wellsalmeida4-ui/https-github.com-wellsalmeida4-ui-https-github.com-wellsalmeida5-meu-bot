import React, { useState, useEffect } from 'react';
import { Bot } from '../types';
import { Key, Eye, EyeOff, Save, Check, X, ExternalLink, ShieldCheck } from 'lucide-react';

interface TokenConfigModalProps {
  bot: Bot | null;
  isOpen: boolean;
  onClose: () => void;
  onSaveToken: (botId: string, newToken: string) => Promise<void>;
}

export const TokenConfigModal: React.FC<TokenConfigModalProps> = ({
  bot,
  isOpen,
  onClose,
  onSaveToken
}) => {
  const [token, setToken] = useState('');
  const [showToken, setShowToken] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (isOpen && bot) {
      setToken(bot.token || '');
      setShowToken(false);
      setSuccess(false);
    }
  }, [isOpen, bot?.id]);

  if (!isOpen || !bot) return null;

  const handleSave = async () => {
    if (!token.trim()) {
      alert('Por favor, informe um Token válido do Discord.');
      return;
    }
    try {
      setIsSaving(true);
      await onSaveToken(bot.id, token.trim());
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 1200);
    } catch (e: any) {
      alert(e.message || 'Erro ao atualizar o token do bot.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/50">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <span>Alterar Token (.env)</span>
              </h3>
              <p className="text-xs text-slate-400">
                Bot: <span className="font-semibold text-slate-200">{bot.name}</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4">
          
          <div className="bg-indigo-950/30 border border-indigo-800/40 rounded-xl p-3.5 text-xs text-slate-300 leading-relaxed flex items-start space-x-2.5">
            <ShieldCheck className="w-5 h-5 text-indigo-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-indigo-300 mb-1">Isolamento Individual do Bot</p>
              <p className="text-slate-400">
                O token inserido abaixo pertence unicamente ao bot <strong className="text-white">{bot.name}</strong> e atualizará o arquivo <code className="bg-slate-900 px-1 py-0.5 rounded text-indigo-300 font-mono">.env</code> de forma individual sem afetar outros bots.
              </p>
            </div>
          </div>

          {/* Input Field */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
              <span>Discord Bot Token (DISCORD_TOKEN)</span>
              <a
                href="https://discord.com/developers/applications"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[11px] text-indigo-400 hover:text-indigo-300 flex items-center space-x-1"
              >
                <span>Obter no Discord Developer Portal</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </label>

            <div className="relative">
              <input
                type={showToken ? 'text' : 'password'}
                value={token}
                onChange={e => setToken(e.target.value)}
                placeholder="Ex: MTQzOD...GSMRUV...uyhxwOOumn"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white font-mono placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all pr-10"
              />
              <button
                type="button"
                onClick={() => setShowToken(!showToken)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1"
                title={showToken ? 'Ocultar Token' : 'Mostrar Token'}
              >
                {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="text-[11px] text-slate-500 space-y-1 bg-slate-950/60 p-3 rounded-xl border border-slate-800/60 font-mono">
            <p className="text-slate-400 font-sans font-semibold">📍 Como pegar o Token:</p>
            <p>1. Acesse https://discord.com/developers/applications</p>
            <p>2. Clique na sua aplicação do Bot</p>
            <p>3. Vá no menu lateral "Bot" -&gt; clique em "Reset Token"</p>
            <p>4. Copie a chave gerada e cole no campo acima.</p>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-950 border-t border-slate-800 flex justify-end space-x-3">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-xl text-xs transition-colors"
          >
            Cancelar
          </button>
          
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="flex items-center space-x-2 px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs transition-all shadow-lg shadow-indigo-600/30 active:scale-95 disabled:opacity-50"
          >
            {success ? (
              <>
                <Check className="w-4 h-4 text-emerald-300" />
                <span>Token Atualizado!</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'Salvando...' : 'Salvar e Reconectar'}</span>
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
};
