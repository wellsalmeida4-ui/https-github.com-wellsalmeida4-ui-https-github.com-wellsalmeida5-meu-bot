import React from 'react';
import { Server, Plus, Shield, Cpu, Search, RefreshCw, Database, Sparkles, Radio, Clock, UploadCloud } from 'lucide-react';

interface HeaderProps {
  totalBots: number;
  onlineBots: number;
  onAddBotClick: () => void;
  onOpenDatabaseClick: () => void;
  onOpenAutoBackupClick?: () => void;
  onOpenCardConfiguratorClick: () => void;
  onOpenUptimeRobotClick: () => void;
  onOpenExportClick?: () => void;
  searchTerm: string;
  onSearchChange: (value: string) => void;
  onRefresh: () => void;
  isRefreshing: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  totalBots,
  onlineBots,
  onAddBotClick,
  onOpenDatabaseClick,
  onOpenAutoBackupClick,
  onOpenCardConfiguratorClick,
  onOpenUptimeRobotClick,
  onOpenExportClick,
  searchTerm,
  onSearchChange,
  onRefresh,
  isRefreshing,
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-30 shadow-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between py-4 gap-4">
          
          {/* Logo and Tagline */}
          <div className="flex items-center space-x-3 w-full md:w-auto justify-between md:justify-start">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-blurple to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20 ring-1 ring-white/20">
                <Server className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h1 className="text-xl font-black tracking-tight text-white font-mono">
                    BotLoom<span className="text-indigo-400">.Hosting</span>
                  </h1>
                  <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                    Node v20.12 (24/7)
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  Painel de Hospedagem & Execução de Bots do Discord
                </p>
              </div>
            </div>

            {/* Mobile Actions */}
            <div className="md:hidden flex items-center space-x-2">
              {onOpenExportClick && (
                <button
                  onClick={onOpenExportClick}
                  className="p-2 bg-cyan-500/20 text-cyan-400 rounded-lg text-sm border border-cyan-500/30"
                  title="Exportar / Netlify"
                >
                  <UploadCloud className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={onOpenUptimeRobotClick}
                className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg text-sm border border-emerald-500/30"
                title="UptimeRobot 24/7 Ping"
              >
                <Radio className="w-4 h-4 animate-pulse" />
              </button>
              <button
                onClick={onAddBotClick}
                className="flex items-center space-x-1 bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-2 rounded-lg text-sm font-medium transition-all shadow-md shadow-indigo-600/30"
              >
                <Plus className="w-4 h-4" />
                <span>Adicionar</span>
              </button>
            </div>
          </div>

          {/* Quick Metrics & Search */}
          <div className="flex items-center space-x-3 w-full md:w-auto justify-between md:justify-end">
            
            {/* Server Health Pills */}
            <div className="hidden lg:flex items-center space-x-3 bg-slate-950/60 px-3.5 py-1.5 rounded-xl border border-slate-800/80 text-xs text-slate-300">
              <div className="flex items-center space-x-2">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span className="font-medium text-slate-200">
                  <strong className="text-emerald-400">{onlineBots}</strong>/{totalBots} Bots Online
                </span>
              </div>
              <span className="text-slate-700">|</span>
              <div className="flex items-center space-x-1.5 text-slate-400">
                <Cpu className="w-3.5 h-3.5 text-indigo-400" />
                <span>Cluster Node: <strong>Normal</strong></span>
              </div>
            </div>

            {/* Search Input */}
            <div className="relative flex-1 md:flex-initial md:w-48">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Buscar bot..."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
              />
            </div>

            {/* Refresh Button */}
            <button
              onClick={onRefresh}
              disabled={isRefreshing}
              title="Atualizar status"
              className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition-colors border border-slate-700/60"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-indigo-400' : ''}`} />
            </button>

            {/* UptimeRobot 24/7 Button */}
            <button
              onClick={onOpenUptimeRobotClick}
              className="hidden lg:flex items-center space-x-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 hover:text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-all border border-emerald-500/30 shadow-md shadow-emerald-500/10"
              title="Configurar UptimeRobot para manter site e bots 24/7 ativos"
            >
              <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
              <span>UptimeRobot 24/7</span>
            </button>

            {/* Auto-Backup MongoDB Modal Button */}
            {onOpenAutoBackupClick && (
              <button
                onClick={onOpenAutoBackupClick}
                className="hidden sm:flex items-center space-x-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 hover:text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-all border border-emerald-500/30 shadow-md shadow-emerald-500/10"
                title="Configurar Backups Automáticos dos Arquivos dos Bots para o MongoDB"
              >
                <Clock className="w-4 h-4 text-emerald-400" />
                <span>Backup MongoDB</span>
              </button>
            )}

            {/* Banco de Dados / MongoDB Modal Button */}
            <button
              onClick={onOpenDatabaseClick}
              className="hidden md:flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-all border border-slate-700 shadow-md"
              title="Abrir Banco de Dados e MongoDB Atlas"
            >
              <Database className="w-4 h-4 text-indigo-400" />
              <span>Banco & Tabelas</span>
            </button>

            {/* Vouchcard & Perfilcard Customizer Button */}
            <button
              onClick={onOpenCardConfiguratorClick}
              className="flex items-center space-x-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 hover:text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-all border border-amber-500/40 shadow-md shadow-amber-500/10"
              title="Personalizar Vouchcard, Perfilcard e Colocar Imagem de Fundo"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Personalizar Cards & Fundo</span>
            </button>

            {/* Exportar / Netlify Modal Button */}
            {onOpenExportClick && (
              <button
                onClick={onOpenExportClick}
                className="flex items-center space-x-1.5 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 hover:text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-all border border-cyan-500/30 shadow-md shadow-cyan-500/10 hover:scale-105 active:scale-95"
                title="Baixar arquivos do projeto (.zip) e hospedar no Netlify"
              >
                <UploadCloud className="w-4 h-4 text-cyan-400" />
                <span>Exportar / Netlify</span>
              </button>
            )}

            {/* Primary Desktop Add Bot Button */}
            <button
              onClick={onAddBotClick}
              className="hidden md:flex items-center space-x-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-lg shadow-indigo-600/30 hover:scale-105 active:scale-95 border border-indigo-400/30"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Bot</span>
            </button>

          </div>

        </div>
      </div>
    </header>
  );
};

