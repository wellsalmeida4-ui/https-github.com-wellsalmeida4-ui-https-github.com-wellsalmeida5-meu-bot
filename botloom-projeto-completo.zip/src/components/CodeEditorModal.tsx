import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Bot, BotFile } from '../types';
import {
  X,
  FileCode,
  Plus,
  Trash2,
  Save,
  Check,
  Folder,
  File,
  Package,
  Sparkles,
  Download,
  Code,
  Upload
} from 'lucide-react';

interface CodeEditorModalProps {
  bot: Bot | null;
  isOpen: boolean;
  onClose: () => void;
  onSaveFiles: (botId: string, files: BotFile[]) => Promise<void>;
}

export const CodeEditorModal: React.FC<CodeEditorModalProps> = ({
  bot,
  isOpen,
  onClose,
  onSaveFiles
}) => {
  const [files, setFiles] = useState<BotFile[]>(bot?.files || []);
  const [activeFileName, setActiveFileName] = useState<string>(
    bot?.files?.[0]?.name || bot?.files?.[0]?.path || 'index.js'
  );

  const [activeContent, setActiveContent] = useState<string>(
    bot?.files?.[0]?.content || ''
  );

  const [newFileName, setNewFileName] = useState('');
  const [showNewFileForm, setShowNewFileForm] = useState(false);

  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const lineNumbersRef = useRef<HTMLDivElement>(null);

  // Sync internal state whenever bot or isOpen changes
  useEffect(() => {
    if (isOpen && bot) {
      let currentFiles = bot.files ? [...bot.files] : [];
      let envFile = currentFiles.find(f => f.name === '.env' || f.path === '.env');
      if (!envFile) {
        envFile = {
          name: '.env',
          path: '.env',
          content: `DISCORD_TOKEN=${bot.token || ''}\nTOKEN=${bot.token || ''}\nPREFIX=${bot.prefix || '!'}\nCLIENT_ID=${bot.botId || ''}`
        };
        currentFiles.push(envFile);
      }
      setFiles(currentFiles);
      if (currentFiles.length > 0) {
        const found = currentFiles.find(
          f => f.name === activeFileName || f.path === activeFileName
        ) || currentFiles.find(
          f => f.name === 'bot.js' || f.name === 'index.js'
        ) || currentFiles[0];
        const fname = found.name || found.path || 'bot.js';
        setActiveFileName(fname);
        setActiveContent(found.content || '');
      }
    }
  }, [isOpen, bot?.id]);

  // Keyboard shortcut Ctrl+S / Cmd+S to save
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        handleSave();
      }
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    }
  }, [isOpen, activeFileName, activeContent, files, bot?.id]);

  // High-performance line numbers generation
  const lineNumbersText = useMemo(() => {
    if (!activeContent) return '1';
    let count = 1;
    for (let i = 0; i < activeContent.length; i++) {
      if (activeContent[i] === '\n') count++;
    }
    const arr = new Array(count);
    for (let i = 0; i < count; i++) {
      arr[i] = String(i + 1);
    }
    return arr.join('\n');
  }, [activeContent]);

  if (!isOpen || !bot) return null;

  const handleScroll = () => {
    if (textareaRef.current && lineNumbersRef.current) {
      lineNumbersRef.current.scrollTop = textareaRef.current.scrollTop;
    }
  };

  // Handle content change in editor
  const handleContentChange = (newText: string) => {
    setActiveContent(newText);
    const targetName = activeFileName;
    setFiles(prev =>
      prev.map(f => (f.name === targetName || f.path === targetName ? { ...f, content: newText } : f))
    );
  };

  // Switch file tab
  const handleSelectFile = (targetFileName: string) => {
    const currentName = activeFileName;
    const currentText = activeContent;
    setFiles(prev => {
      const updated = prev.map(f =>
        f.name === currentName || f.path === currentName ? { ...f, content: currentText } : f
      );
      const target = updated.find(f => f.name === targetFileName || f.path === targetFileName);
      if (target) {
        setActiveContent(target.content || '');
      }
      return updated;
    });
    setActiveFileName(targetFileName);
  };

  // Create new file
  const handleCreateFile = () => {
    if (!newFileName.trim()) return;

    const fileNameClean = newFileName.trim();
    if (files.some(f => f.name === fileNameClean || f.path === fileNameClean)) {
      alert('Já existe um arquivo com esse nome.');
      return;
    }

    const newFile: BotFile = {
      name: fileNameClean,
      path: fileNameClean,
      content: fileNameClean.endsWith('.json')
        ? '{\n  "name": "novo-arquivo"\n}'
        : `// Arquivo ${fileNameClean}\n`
    };

    const updatedFiles = [...files, newFile];
    setFiles(updatedFiles);
    setActiveFileName(fileNameClean);
    setActiveContent(newFile.content);
    setNewFileName('');
    setShowNewFileForm(false);
  };

  // Delete file
  const handleDeleteFile = (fileNameToDelete: string) => {
    if (files.length <= 1) {
      alert('O projeto precisa ter pelo menos 1 arquivo.');
      return;
    }

    if (confirm(`Tem certeza que deseja apagar o arquivo "${fileNameToDelete}"?`)) {
      const updated = files.filter(f => f.name !== fileNameToDelete && f.path !== fileNameToDelete);
      setFiles(updated);
      if (activeFileName === fileNameToDelete) {
        const next = updated[0];
        const nextName = next.name || next.path;
        setActiveFileName(nextName);
        setActiveContent(next.content || '');
      }
    }
  };

  // Save all changes
  const handleSave = async () => {
    try {
      setIsSaving(true);
      const currentName = activeFileName;
      const currentText = activeContent;
      let finalFiles = files.map(f =>
        f.name === currentName || f.path === currentName ? { ...f, content: currentText } : f
      );
      if (!finalFiles.some(f => f.name === currentName || f.path === currentName)) {
        finalFiles = [...finalFiles, { name: currentName, path: currentName, content: currentText }];
      }

      await onSaveFiles(bot.id, finalFiles);
      setFiles(finalFiles);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2500);
    } catch (err) {
      alert('Erro ao salvar arquivos do bot.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-950/85 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-5xl h-[88vh] shadow-2xl flex flex-col overflow-hidden">
        
        {/* Top Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-slate-900 border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Code className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-sm font-bold text-white font-mono">{bot.name}</h2>
                <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-mono">
                  IDE BotLoom
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Editor Online com Destaque e Salvamento Direto
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md shadow-indigo-600/30 transition-all active:scale-95"
            >
              {savedSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-300" />
                  <span>Salvo!</span>
                </>
              ) : (
                <>
                  <Save className="w-3.5 h-3.5" />
                  <span>{isSaving ? 'Salvando...' : 'Salvar Alterações'}</span>
                </>
              )}
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Main Workspace Body */}
        <div className="flex-1 flex overflow-hidden">
          
          {/* File Explorer Sidebar */}
          <div className="w-60 bg-slate-950 border-r border-slate-800/80 flex flex-col justify-between select-none">
            
            <div>
              {/* Files Title & New File Trigger */}
              <div className="flex items-center justify-between px-3 py-2 bg-slate-900/60 border-b border-slate-800/80 text-xs font-semibold text-slate-400">
                <span className="flex items-center space-x-1.5 font-mono">
                  <Folder className="w-3.5 h-3.5 text-indigo-400" />
                  <span>ARQUIVOS</span>
                </span>

                <div className="flex items-center space-x-1">
                  <label
                    className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded transition-colors cursor-pointer"
                    title="Carregar Arquivo"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <input
                      type="file"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        const reader = new FileReader();
                        reader.onload = (event) => {
                          const content = (event.target?.result as string) || '';
                          const fname = file.name;
                          const updated = files.filter(f => f.name !== fname && f.path !== fname);
                          const newFile: BotFile = { name: fname, path: fname, content };
                          updated.push(newFile);
                          setFiles(updated);
                          setActiveFileName(fname);
                          setActiveContent(content);
                        };
                        reader.readAsText(file);
                      }}
                      className="hidden"
                    />
                  </label>

                  <button
                    onClick={() => setShowNewFileForm(!showNewFileForm)}
                    className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded transition-colors"
                    title="Novo Arquivo"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* New File Form */}
              {showNewFileForm && (
                <div className="p-2 border-b border-slate-800 bg-slate-900/40">
                  <input
                    type="text"
                    value={newFileName}
                    onChange={e => setNewFileName(e.target.value)}
                    placeholder="Ex: commands/moderation.js"
                    className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:border-indigo-500 mb-1.5"
                  />
                  <div className="flex space-x-1">
                    <button
                      onClick={handleCreateFile}
                      className="flex-1 bg-indigo-600 text-white text-[10px] font-bold py-1 rounded"
                    >
                      Criar
                    </button>
                    <button
                      onClick={() => setShowNewFileForm(false)}
                      className="px-2 bg-slate-800 text-slate-300 text-[10px] rounded"
                    >
                      Cancelar
                    </button>
                  </div>
                </div>
              )}

              {/* File List */}
              <div className="p-1.5 space-y-0.5 overflow-y-auto max-h-[50vh]">
                {files.map(file => {
                  const fname = file.name || file.path;
                  const isActive = fname === activeFileName;
                  return (
                    <div
                      key={fname}
                      onClick={() => handleSelectFile(fname)}
                      className={`group flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-mono cursor-pointer transition-colors ${
                        isActive
                          ? 'bg-indigo-600/20 text-indigo-300 font-semibold border border-indigo-500/30'
                          : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                      }`}
                    >
                      <div className="flex items-center space-x-2 truncate">
                        <FileCode className={`w-3.5 h-3.5 flex-shrink-0 ${isActive ? 'text-indigo-400' : 'text-slate-500'}`} />
                        <span className="truncate">{fname}</span>
                      </div>

                      <button
                        onClick={e => {
                          e.stopPropagation();
                          handleDeleteFile(fname);
                        }}
                        className="opacity-0 group-hover:opacity-100 p-0.5 hover:text-rose-400 transition-opacity"
                        title="Excluir arquivo"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Installed Dependencies Section */}
            <div className="p-3 bg-slate-900/80 border-t border-slate-800 text-[11px] font-mono">
              <div className="flex items-center space-x-1.5 text-indigo-400 font-bold mb-2">
                <Package className="w-3.5 h-3.5" />
                <span>Dependências Auto-Instaladas</span>
              </div>
              <div className="space-y-1 text-[10px] text-slate-400">
                <div className="flex justify-between">
                  <span>discord.js</span>
                  <span className="text-emerald-400 font-semibold">^14.14.1</span>
                </div>
                <div className="flex justify-between">
                  <span>canvas</span>
                  <span className="text-emerald-400 font-semibold">^2.11.2</span>
                </div>
                <div className="flex justify-between">
                  <span>dotenv</span>
                  <span className="text-emerald-400 font-semibold">^16.4.5</span>
                </div>
                <div className="flex justify-between">
                  <span>axios</span>
                  <span className="text-emerald-400 font-semibold">^1.6.8</span>
                </div>
              </div>
            </div>

          </div>

          {/* Code Editor Main Canvas */}
          <div className="flex-1 flex flex-col bg-slate-950 overflow-hidden">
            
            {/* Editor Tab Bar */}
            <div className="flex items-center justify-between px-4 py-2 bg-slate-900/80 border-b border-slate-800/80 text-xs font-mono text-slate-300">
              <span className="flex items-center space-x-2">
                <FileCode className="w-4 h-4 text-indigo-400" />
                <span className="font-bold text-white">{activeFileName}</span>
              </span>

              <span className="text-[10px] text-slate-500">
                Salva automaticamente ao rodar ou clicar em Salvar
              </span>
            </div>

            {/* Editor Textarea with Line Numbers */}
            <div className="flex-1 relative flex overflow-hidden font-mono text-xs">
              
              {/* Line Numbers Column (Synced Scroll) */}
              <div
                ref={lineNumbersRef}
                className="select-none bg-slate-900/60 text-slate-500 p-3 text-right pr-3 border-r border-slate-800/80 font-mono leading-relaxed text-[11px] min-w-[50px] overflow-hidden pointer-events-none"
              >
                <pre className="font-mono text-right">{lineNumbersText}</pre>
              </div>

              {/* Editable Area */}
              <div className="flex-1 relative overflow-hidden bg-slate-950">
                <textarea
                  ref={textareaRef}
                  value={activeContent}
                  onScroll={handleScroll}
                  onChange={e => handleContentChange(e.target.value)}
                  className="w-full h-full bg-transparent text-slate-100 caret-indigo-400 p-3 font-mono text-xs leading-relaxed focus:outline-none resize-none whitespace-pre overflow-auto selection:bg-indigo-600 selection:text-white"
                  spellCheck={false}
                ></textarea>
              </div>

            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
