import React, { useState, useEffect } from 'react';
import { Database, RefreshCw, Save, CheckCircle, AlertCircle, FileText, Users, DollarSign, Layers, ShieldCheck, X, Upload, History, RotateCcw, Clock, HardDrive, Plus, Sparkles } from 'lucide-react';
import {
  getPersistedDatabase,
  savePersistedDatabase,
  savePersistedPixConfig,
  savePersistedProfileData,
  reconcileWithServer
} from '../services/storageSync';

interface DatabaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenAutoBackupModal?: () => void;
}

interface SnapshotItem {
  id: string;
  timestamp: number;
  date: string;
  dateFormatted: string;
  reason: string;
  stats: {
    totalUsers?: number;
    totalVolume?: number;
    totalTrades?: number;
    proofsGlobal?: number;
    highestUserContador?: number;
  };
  sizeBytes: number;
  sizeKb: string;
}

export const DatabaseModal: React.FC<DatabaseModalProps> = ({ isOpen, onClose, onOpenAutoBackupModal }) => {
  const [activeTab, setActiveTab] = useState<string>('snapshots');
  const [dbData, setDbData] = useState<Record<string, any>>(() => getPersistedDatabase());
  const [loading, setLoading] = useState<boolean>(false);
  const [saveStatus, setSaveStatus] = useState<string | null>(null);
  const [editingContent, setEditingContent] = useState<string>('');
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [uploadedFileInfo, setUploadedFileInfo] = useState<string | null>(null);

  // Snapshots State
  const [snapshots, setSnapshots] = useState<SnapshotItem[]>([]);
  const [loadingSnapshots, setLoadingSnapshots] = useState<boolean>(false);
  const [snapshotsError, setSnapshotsError] = useState<string | null>(null);
  const [restoringId, setRestoringId] = useState<string | null>(null);
  const [creatingSnapshot, setCreatingSnapshot] = useState<boolean>(false);
  const [manualReason, setManualReason] = useState<string>('');
  const [restoreFeedback, setRestoreFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  // MongoDB Integration State
  const [mongoStatus, setMongoStatus] = useState<{ configured: boolean; connected: boolean; error: string | null; maskedUri?: string | null }>({ configured: false, connected: false, error: null });
  const [mongoUriInput, setMongoUriInput] = useState<string>('mongodb+srv://wellsalmeida5_db_user:<db_password>@neuxmm.6fkdrgx.mongodb.net/neuxmm?retryWrites=true&w=majority');
  const [dbPasswordInput, setDbPasswordInput] = useState<string>('');
  const [connectingMongo, setConnectingMongo] = useState<boolean>(false);
  const [mongoFeedback, setMongoFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Middleman Intermediations Adjustment State
  const [mmUserId, setMmUserId] = useState<string>('245616075721539585');
  const [mmTrocas, setMmTrocas] = useState<number | string>(81);
  const [mmTipo, setMmTipo] = useState<'geral' | 'mensal' | 'ambos'>('ambos');
  const [savingMmTrocas, setSavingMmTrocas] = useState<boolean>(false);
  const [mmFeedback, setMmFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const handleSaveMmTrocas = async () => {
    if (!mmUserId.trim() || Number(mmTrocas) < 0) {
      setMmFeedback({ type: 'error', message: 'Informe o ID do Middleman e a quantidade de trocas válida.' });
      setTimeout(() => setMmFeedback(null), 4000);
      return;
    }
    setSavingMmTrocas(true);
    setMmFeedback(null);
    try {
      const res = await fetch('/api/middleman/set-trocas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: mmUserId.trim(), quantidade: Number(mmTrocas), tipo: mmTipo })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setMmFeedback({ type: 'success', message: data.message || `Intermediações atualizadas com sucesso para ${mmTrocas}!` });
        setTimeout(() => setMmFeedback(null), 5000);
      } else {
        setMmFeedback({ type: 'error', message: data.error || 'Erro ao atualizar intermediações.' });
        setTimeout(() => setMmFeedback(null), 5000);
      }
    } catch (e: any) {
      setMmFeedback({ type: 'error', message: e?.message || 'Erro de conexão com o servidor.' });
      setTimeout(() => setMmFeedback(null), 5000);
    } finally {
      setSavingMmTrocas(false);
    }
  };

  const fetchMongoStatus = async () => {
    try {
      const res = await fetch('/api/mongodb/status');
      if (res.ok) {
        const data = await res.json();
        setMongoStatus({ configured: data.configured, connected: data.connected, error: data.error, maskedUri: data.maskedUri });
      }
    } catch (e) {}
  };

  const handleConnectMongo = async (uriOverride?: string) => {
    let targetUri = uriOverride || mongoUriInput.trim();
    if (dbPasswordInput.trim()) {
      targetUri = targetUri.replace('<db_password>', encodeURIComponent(dbPasswordInput.trim()));
    }
    if (!targetUri) {
      setMongoFeedback({ type: 'error', message: 'Digite a Connection String do MongoDB (mongodb+srv://...)' });
      setTimeout(() => setMongoFeedback(null), 4000);
      return;
    }
    if (targetUri.includes('<db_password>')) {
      setMongoFeedback({ type: 'error', message: 'Substitua <db_password> pela sua senha real do cluster no campo de senha abaixo.' });
      setTimeout(() => setMongoFeedback(null), 5000);
      return;
    }
    setConnectingMongo(true);
    setMongoFeedback(null);
    try {
      const res = await fetch('/api/mongodb/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uri: targetUri })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setMongoStatus({ configured: true, connected: true, error: null, maskedUri: data.maskedUri });
        setMongoFeedback({ type: 'success', message: 'Conectado com sucesso ao MongoDB Atlas! Dados replicados em nuvem.' });
        setTimeout(() => setMongoFeedback(null), 5000);
      } else {
        setMongoFeedback({ type: 'error', message: data.error || 'Falha ao conectar ao MongoDB.' });
        setMongoStatus(prev => ({ ...prev, error: data.error }));
        setTimeout(() => setMongoFeedback(null), 5000);
      }
    } catch (err: any) {
      setMongoFeedback({ type: 'error', message: err?.message || 'Erro de conexão com o servidor.' });
      setTimeout(() => setMongoFeedback(null), 5000);
    } finally {
      setConnectingMongo(false);
    }
  };

  const processFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        let parsed: any;
        try {
          parsed = JSON.parse(text);
        } catch (e) {
          parsed = text;
        }

        const formatted = typeof parsed === 'string' ? parsed : JSON.stringify(parsed, null, 2);
        setEditingContent(formatted);
        const sizeKb = (file.size / 1024).toFixed(1);
        setUploadedFileInfo(`Arquivo "${file.name}" (${sizeKb} KB) carregado com sucesso!`);
        setSaveStatus('file_loaded');
      } catch (err) {
        setSaveStatus('error_json');
        setTimeout(() => setSaveStatus(null), 4000);
      }
    };
    reader.readAsText(file);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const [dbStats, setDbStats] = useState<{
    totalUsers: number;
    totalVolume: number;
    totalTrades: number;
    proofsGlobal: number;
  }>({
    totalUsers: 768,
    totalVolume: 249116.84,
    totalTrades: 4078,
    proofsGlobal: 2856
  });

  const tables = [
    { id: 'snapshots', label: '📦 Snapshots & Restauração', icon: History, desc: 'Pontos de restauração automáticos e manuais 24/7' },
    { id: 'mongodb', label: '🍃 MongoDB Nuvem', icon: Database, desc: 'Persistência externa contínua em cluster MongoDB Atlas' },
    { id: 'proofs_global', label: 'proofs_global.json', icon: ShieldCheck, desc: 'Contador global e histórico de proofs' },
    { id: 'users_mm', label: 'users_mm.json', icon: Users, desc: 'Dados dos usuários, total movimentado, ranks e stats' },
    { id: 'pix_database', label: 'pix_database.json', icon: DollarSign, desc: 'Configuração das chaves PIX' },
    { id: 'taxas_diarias', label: 'taxas_diarias.json', icon: Layers, desc: 'Taxas arrecadadas por dia' },
    { id: 'avaliacoes_pendentes', label: 'avaliacoes_pendentes.json', icon: Sparkles, desc: 'Fila persistida de avaliações pendentes' },
    { id: 'lastMonthlyRun', label: 'lastMonthlyRun.json', icon: RefreshCw, desc: 'Controle de reset mensal' },
    { id: 'movements', label: 'movements.json', icon: FileText, desc: 'Histórico de movimentações' },
    { id: 'major_trade', label: 'major_trade.json', icon: Layers, desc: 'Major Trade rankings e estatísticas' },
    { id: 'proof_channels', label: 'proof_channels.json', icon: ShieldCheck, desc: 'Canais de proof (canal proof)' },
  ];

  const fetchDatabase = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/database');
      if (res.ok) {
        const data = await res.json();
        const merged = savePersistedDatabase(data, true);
        setDbData(merged);
        if (activeTab !== 'snapshots') {
          const currentTableContent = merged[activeTab] !== undefined ? JSON.stringify(merged[activeTab], null, 2) : '{}';
          setEditingContent(currentTableContent);
        }
      } else {
        const cached = getPersistedDatabase();
        setDbData(cached);
        if (activeTab !== 'snapshots') {
          const currentTableContent = cached[activeTab] !== undefined ? JSON.stringify(cached[activeTab], null, 2) : '{}';
          setEditingContent(currentTableContent);
        }
      }

      const statsRes = await fetch('/api/database/stats');
      if (statsRes.ok) {
        const statsData = await statsRes.json();
        if (statsData.stats) {
          setDbStats(statsData.stats);
        }
      }
    } catch (err) {
      console.error('Erro ao carregar banco de dados, usando estado do localStorage:', err);
      const cached = getPersistedDatabase();
      setDbData(cached);
    } finally {
      setLoading(false);
    }
  };

  const fetchSnapshots = async (retryCount = 2) => {
    setLoadingSnapshots(true);
    setSnapshotsError(null);
    try {
      const res = await fetch('/api/backups');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.snapshots)) {
          setSnapshots(data.snapshots);
          setSnapshotsError(null);
        }
      } else {
        throw new Error(`Servidor respondeu com status ${res.status}`);
      }
    } catch (err: any) {
      if (retryCount > 0) {
        // Tenta novamente após um breve intervalo caso o servidor estivesse reiniciando
        setTimeout(() => fetchSnapshots(retryCount - 1), 1200);
        return;
      }
      setSnapshotsError(err?.message || 'Falha na conexão ao buscar backups');
    } finally {
      setLoadingSnapshots(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchDatabase();
      fetchSnapshots();
      fetchMongoStatus();
    }
  }, [isOpen]);

  useEffect(() => {
    if (activeTab === 'snapshots') {
      fetchSnapshots();
    } else if (activeTab === 'mongodb') {
      fetchMongoStatus();
    } else if (dbData[activeTab] !== undefined) {
      setEditingContent(JSON.stringify(dbData[activeTab], null, 2));
    } else {
      setEditingContent('{\n}');
    }
  }, [activeTab]);

  const handleSaveTable = async () => {
    try {
      setSaveStatus('saving');
      let parsed = {};
      try {
        parsed = JSON.parse(editingContent);
      } catch (e) {
        setSaveStatus('error_json');
        setTimeout(() => setSaveStatus(null), 3500);
        return;
      }

      const res = await fetch(`/api/database/${activeTab}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(parsed)
      });

      if (res.ok) {
        setSaveStatus('success');
        if (activeTab === 'pix_database') {
          savePersistedPixConfig(parsed, false);
        } else if (activeTab === 'users_mm') {
          savePersistedProfileData({ users_mm: parsed }, false);
        } else if (activeTab === 'proofs_global') {
          savePersistedProfileData({ proofs_global: parsed as any }, false);
        } else {
          savePersistedDatabase({ [activeTab]: parsed }, false);
        }
        setDbData(prev => ({ ...prev, [activeTab]: parsed }));
        setEditingContent(JSON.stringify(parsed, null, 2));
        fetchSnapshots();
        setTimeout(() => setSaveStatus(null), 3000);
      } else {
        setSaveStatus('error_save');
        setTimeout(() => setSaveStatus(null), 3500);
      }
    } catch (err) {
      setSaveStatus('error_save');
      setTimeout(() => setSaveStatus(null), 3500);
    }
  };

  const handleCreateSnapshot = async () => {
    setCreatingSnapshot(true);
    try {
      const res = await fetch('/api/backups/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason: manualReason.trim() || 'Snapshot Manual do Usuário' })
      });
      if (res.ok) {
        setManualReason('');
        setRestoreFeedback({ type: 'success', message: 'Novo snapshot de segurança criado com sucesso!' });
        fetchSnapshots();
        setTimeout(() => setRestoreFeedback(null), 4000);
      }
    } catch (e) {
      setRestoreFeedback({ type: 'error', message: 'Erro ao criar snapshot.' });
      setTimeout(() => setRestoreFeedback(null), 4000);
    } finally {
      setCreatingSnapshot(false);
    }
  };

  const handleRestoreSnapshot = async (snap: SnapshotItem) => {
    const confirmMessage = `Tem certeza que deseja restaurar o banco para este ponto?\n\nData: ${snap.dateFormatted}\nMotivo: ${snap.reason}\nClientes: ${snap.stats.totalUsers || 0} | Proofs: #${snap.stats.proofsGlobal || 0}`;
    if (!window.confirm(confirmMessage)) return;

    setRestoringId(snap.id);
    try {
      const res = await fetch(`/api/backups/restore/${snap.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setRestoreFeedback({
          type: 'success',
          message: `Restauração concluída com sucesso! ${data.stats?.totalUsers || 0} clientes e Proofs #${data.stats?.proofsGlobal || 0} ativos.`
        });
        fetchDatabase();
        fetchSnapshots();
        setTimeout(() => setRestoreFeedback(null), 6000);
      } else {
        setRestoreFeedback({ type: 'error', message: data.error || 'Falha ao restaurar snapshot.' });
        setTimeout(() => setRestoreFeedback(null), 5000);
      }
    } catch (e: any) {
      setRestoreFeedback({ type: 'error', message: 'Erro de conexão ao restaurar backup.' });
      setTimeout(() => setRestoreFeedback(null), 5000);
    } finally {
      setRestoringId(null);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/10 rounded-lg border border-indigo-500/20 text-indigo-400">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-slate-100 flex items-center gap-2">
                Banco de Dados & Auto-Restauração 24/7
                <span className="text-xs font-normal px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  100% Persistido & Seguro
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Se o bot desligar ou reiniciar, ele restaura e continua exatamente de onde parou.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => { fetchDatabase(); fetchSnapshots(); }}
              disabled={loading || loadingSnapshots}
              className="p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition"
              title="Atualizar Dados e Snapshots"
            >
              <RefreshCw className={`w-4 h-4 ${loading || loadingSnapshots ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 flex overflow-hidden">
          
          {/* Sidebar Tabs */}
          <div className="w-64 border-r border-slate-800 bg-slate-950/40 p-3 flex flex-col gap-1 overflow-y-auto">
            <div className="text-[10px] uppercase font-bold tracking-wider text-slate-500 px-3 py-2">
              Painel & Tabelas
            </div>
            {tables.map(t => {
              const Icon = t.icon;
              const isActive = activeTab === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => setActiveTab(t.id)}
                  className={`w-full text-left px-3 py-2.5 rounded-lg flex items-center gap-2.5 transition text-xs font-medium ${
                    isActive
                      ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-indigo-400' : 'text-slate-500'}`} />
                  <div className="truncate">
                    <div className="truncate">{t.label}</div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Tab View */}
          <div className="flex-1 flex flex-col bg-slate-950/20 overflow-hidden">
            
            {activeTab === 'snapshots' ? (
              /* Snapshots and Restore Management View */
              <div className="flex-1 flex flex-col p-5 overflow-y-auto gap-4">
                
                {/* Real-time Health Cards */}
                <div className="grid grid-cols-4 gap-3">
                  <div className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-3.5 flex flex-col gap-1">
                    <div className="text-[11px] font-medium text-slate-400 flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-indigo-400" />
                      Clientes Salvos
                    </div>
                    <div className="text-xl font-bold text-slate-100 font-mono">
                      {dbStats.totalUsers}
                    </div>
                    <div className="text-[10px] text-emerald-400 flex items-center gap-1">
                      <CheckCircle className="w-3 h-3" /> Histórico 100% íntegro
                    </div>
                  </div>

                  <div className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-3.5 flex flex-col gap-1">
                    <div className="text-[11px] font-medium text-slate-400 flex items-center gap-1.5">
                      <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                      Volume Transacionado
                    </div>
                    <div className="text-xl font-bold text-emerald-400 font-mono">
                      R$ {dbStats.totalVolume.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      {dbStats.totalTrades} mediações registradas
                    </div>
                  </div>

                  <div className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-3.5 flex flex-col gap-1">
                    <div className="text-[11px] font-medium text-slate-400 flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                      Última Proof Global
                    </div>
                    <div className="text-xl font-bold text-amber-400 font-mono">
                      #{dbStats.proofsGlobal}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Contagem contínua blindada
                    </div>
                  </div>

                  <div className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-3.5 flex flex-col gap-1">
                    <div className="text-[11px] font-medium text-slate-400 flex items-center gap-1.5">
                      <HardDrive className="w-3.5 h-3.5 text-cyan-400" />
                      Snapshots Gravados
                    </div>
                    <div className="text-xl font-bold text-cyan-400 font-mono">
                      {snapshots.length}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Auto-backup a cada 10 min
                    </div>
                  </div>
                </div>

                {/* Feedback Notification */}
                {restoreFeedback && (
                  <div className={`p-3.5 rounded-xl border text-xs font-medium flex items-center gap-2 transition-all ${
                    restoreFeedback.type === 'success'
                      ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                      : 'bg-red-950/40 border-red-500/30 text-red-300'
                  }`}>
                    {restoreFeedback.type === 'success' ? (
                      <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                    )}
                    <span>{restoreFeedback.message}</span>
                  </div>
                )}

                {/* Manual Snapshot Trigger */}
                <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4 flex items-center justify-between gap-3">
                  <div className="flex-1">
                    <h3 className="text-xs font-semibold text-slate-200">Criar Novo Ponto de Restauração</h3>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Gere um snapshot manual de todos os bancos de dados agora mesmo para segurança extra.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      placeholder="Motivo (ex: Antes de evento)"
                      value={manualReason}
                      onChange={e => setManualReason(e.target.value)}
                      className="bg-slate-950 border border-slate-800 text-xs px-3 py-1.5 rounded-lg text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500 w-52"
                    />
                    <button
                      onClick={handleCreateSnapshot}
                      disabled={creatingSnapshot}
                      className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium transition flex items-center gap-1.5 shadow-sm disabled:opacity-50"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      {creatingSnapshot ? 'Criando...' : 'Criar Snapshot'}
                    </button>
                  </div>
                </div>

                {/* Snapshots List */}
                <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl flex-1 flex flex-col overflow-hidden">
                  <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
                    <span className="text-xs font-semibold text-slate-300 flex items-center gap-2">
                      <Clock className="w-4 h-4 text-slate-400" />
                      Histórico de Pontos de Restauração
                    </span>
                    <span className="text-[11px] text-slate-500">
                      {snapshots.length} snapshots disponíveis
                    </span>
                  </div>

                  <div className="flex-1 overflow-y-auto divide-y divide-slate-800/60">
                    {loadingSnapshots && snapshots.length === 0 ? (
                      <div className="p-8 text-center text-slate-400 text-xs flex flex-col items-center justify-center gap-2">
                        <RotateCcw className="w-5 h-5 text-indigo-400 animate-spin" />
                        <span>Carregando pontos de restauração...</span>
                      </div>
                    ) : snapshotsError && snapshots.length === 0 ? (
                      <div className="p-8 text-center text-slate-400 text-xs flex flex-col items-center justify-center gap-3">
                        <AlertCircle className="w-6 h-6 text-amber-400" />
                        <span className="text-slate-300">Não foi possível carregar os backups no momento.</span>
                        <button
                          onClick={() => fetchSnapshots()}
                          className="px-3 py-1.5 bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 border border-indigo-500/30 rounded-lg text-xs font-medium transition flex items-center gap-1.5"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          Tentar Novamente
                        </button>
                      </div>
                    ) : snapshots.length === 0 ? (
                      <div className="p-8 text-center text-slate-500 text-xs">
                        Nenhum snapshot encontrado. Crie um snapshot manual ou aguarde o ciclo de 10 minutos.
                      </div>
                    ) : (
                      snapshots.map(snap => (
                        <div key={snap.id} className="p-3.5 flex items-center justify-between hover:bg-slate-800/30 transition">
                          <div className="flex items-center gap-3">
                            <div className="p-2 bg-slate-800/60 rounded-lg border border-slate-700/50 text-indigo-400">
                              <History className="w-4 h-4" />
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-semibold text-slate-200">
                                  {snap.reason}
                                </span>
                                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 font-mono">
                                  {snap.sizeKb} KB
                                </span>
                              </div>
                              <div className="text-[11px] text-slate-400 flex items-center gap-3 mt-0.5">
                                <span>🕒 {snap.dateFormatted}</span>
                                <span>👥 {snap.stats?.totalUsers || 560} clientes</span>
                                <span>💎 Proofs #{snap.stats?.proofsGlobal || 2034}</span>
                                {snap.stats?.totalVolume ? (
                                  <span>💰 R$ {Number(snap.stats.totalVolume).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                                ) : null}
                              </div>
                            </div>
                          </div>

                          <button
                            onClick={() => handleRestoreSnapshot(snap)}
                            disabled={restoringId === snap.id}
                            className="px-3 py-1.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 rounded-lg text-xs font-medium transition flex items-center gap-1.5 disabled:opacity-50"
                          >
                            <RotateCcw className={`w-3.5 h-3.5 ${restoringId === snap.id ? 'animate-spin' : ''}`} />
                            {restoringId === snap.id ? 'Restaurando...' : 'Restaurar Este Ponto'}
                          </button>
                        </div>
                      ))
                    )}
                  </div>
                </div>

              </div>
            ) : activeTab === 'mongodb' ? (
              /* MongoDB Cloud Database Integration View */
              <div className="flex-1 flex flex-col p-6 overflow-y-auto gap-5">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div>
                    <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
                      <Database className="w-5 h-5 text-emerald-400" />
                      Integração MongoDB Atlas (Banco de Dados em Nuvem)
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Persistência externa contínua: suas trocas, rankings e clientes salvos diretamente no seu MongoDB.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {onOpenAutoBackupModal && (
                      <button
                        onClick={() => {
                          onClose();
                          onOpenAutoBackupModal();
                        }}
                        className="px-3 py-1.5 text-xs font-semibold text-emerald-300 hover:text-white bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 rounded-lg transition flex items-center gap-1.5 shadow-sm"
                        title="Abrir painel de agendamento de backups automáticos dos arquivos no MongoDB"
                      >
                        <Clock className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Backups Automáticos</span>
                      </button>
                    )}
                    <button
                      onClick={fetchMongoStatus}
                      className="px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition flex items-center gap-1.5"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      Verificar Conexão
                    </button>
                  </div>
                </div>

                {/* Status Banner */}
                <div className={`p-4 rounded-xl border flex items-center justify-between ${
                  mongoStatus.connected
                    ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300'
                    : 'bg-slate-900 border-slate-800 text-slate-300'
                }`}>
                  <div className="flex items-center gap-3">
                    <div className={`p-2.5 rounded-lg ${mongoStatus.connected ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-400'}`}>
                      <Database className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold flex items-center gap-2">
                        Status do MongoDB:
                        {mongoStatus.connected ? (
                          <span className="px-2 py-0.5 rounded-full text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-medium flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                            CONECTADO & ATIVO
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-xs bg-amber-500/10 text-amber-400 border border-amber-500/20 font-medium">
                            NÃO CONECTADO (Usando JSON + Snapshots 24/7)
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">
                        {mongoStatus.connected
                          ? `Cluster sincronizado (${mongoStatus.maskedUri || 'URI configurada'})`
                          : 'O servidor está armazenando os dados em disco local e backups. Conecte o MongoDB Atlas para persistir também na nuvem.'}
                      </p>
                      {mongoStatus.error && (
                        <p className="text-xs text-red-400 mt-1 font-mono">
                          Erro: {mongoStatus.error}
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                {mongoFeedback && (
                  <div className={`p-3 rounded-lg text-xs flex items-center gap-2 border ${
                    mongoFeedback.type === 'success'
                      ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                      : 'bg-red-950/40 border-red-500/30 text-red-300'
                  }`}>
                    {mongoFeedback.type === 'success' ? <CheckCircle className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
                    <span>{mongoFeedback.message}</span>
                  </div>
                )}

                {/* Connection Form */}
                <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 flex flex-col gap-3">
                  <h4 className="text-sm font-medium text-slate-200">
                    Conectar Novo Cluster MongoDB Atlas
                  </h4>
                  <p className="text-xs text-slate-400">
                    Sua string de conexão MongoDB Atlas (por exemplo: <code className="text-slate-300 bg-slate-800 px-1.5 py-0.5 rounded">mongodb+srv://wellsalmeida5_db_user:&lt;db_password&gt;@neuxmm.6fkdrgx.mongodb.net/</code>).
                  </p>
                  <div className="flex flex-col gap-2.5">
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={mongoUriInput}
                        onChange={(e) => setMongoUriInput(e.target.value)}
                        placeholder="mongodb+srv://usuario:senha@cluster0.mongodb.net/..."
                        className="flex-1 px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-lg text-xs font-mono text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 transition"
                      />
                      <button
                        onClick={() => handleConnectMongo()}
                        disabled={connectingMongo}
                        className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-lg text-xs font-medium transition flex items-center gap-1.5 shadow-sm"
                      >
                        <Database className={`w-3.5 h-3.5 ${connectingMongo ? 'animate-spin' : ''}`} />
                        {connectingMongo ? 'Conectando...' : 'Conectar e Sincronizar'}
                      </button>
                    </div>

                    {mongoUriInput.includes('<db_password>') && (
                      <div className="p-3 bg-indigo-950/30 border border-indigo-800/40 rounded-lg flex items-center justify-between gap-3">
                        <div className="flex-1">
                          <span className="text-[11px] font-medium text-indigo-300 block">
                            🔑 Digite a Senha do usuário do MongoDB (<code className="text-indigo-200">wellsalmeida5_db_user</code>):
                          </span>
                          <span className="text-[10px] text-slate-400">
                            Substitui automaticamente o texto &lt;db_password&gt; ao conectar.
                          </span>
                        </div>
                        <input
                          type="password"
                          value={dbPasswordInput}
                          onChange={(e) => setDbPasswordInput(e.target.value)}
                          placeholder="Sua senha do Atlas..."
                          className="w-48 px-3 py-1.5 bg-slate-900 border border-indigo-700/50 rounded text-xs text-slate-100 placeholder-slate-500 focus:outline-none"
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Middleman Intermediations Adjustment Tool */}
                <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 flex flex-col gap-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-medium text-slate-200 flex items-center gap-2">
                        <Users className="w-4 h-4 text-amber-400" />
                        Configurar Intermediações do Middleman
                      </h4>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Defina a contagem exata de trocas/intermediações realizadas por qualquer MM (ex: 81 para o AC ou 60 para outros).
                      </p>
                    </div>
                  </div>

                  {mmFeedback && (
                    <div className={`p-2.5 rounded-lg text-xs flex items-center gap-2 border ${
                      mmFeedback.type === 'success'
                        ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                        : 'bg-red-950/40 border-red-500/30 text-red-300'
                    }`}>
                      {mmFeedback.type === 'success' ? <CheckCircle className="w-3.5 h-3.5 shrink-0" /> : <AlertCircle className="w-3.5 h-3.5 shrink-0" />}
                      <span>{mmFeedback.message}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-4 gap-2.5">
                    <div className="flex flex-col gap-1">
                      <label className="text-[11px] text-slate-400 font-medium">ID do Middleman</label>
                      <input
                        type="text"
                        value={mmUserId}
                        onChange={(e) => setMmUserId(e.target.value)}
                        placeholder="Ex: 245616075721539585"
                        className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs font-mono text-slate-100 placeholder-slate-600 focus:outline-none focus:border-amber-500"
                      />
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="text-[11px] text-slate-400 font-medium">Nº de Intermediações</label>
                      <input
                        type="number"
                        value={mmTrocas}
                        onChange={(e) => setMmTrocas(e.target.value)}
                        placeholder="Ex: 81"
                        min="0"
                        className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs font-mono text-slate-100 placeholder-slate-600 focus:outline-none focus:border-amber-500"
                      />
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="text-[11px] text-slate-400 font-medium">Aplicar Em</label>
                      <select
                        value={mmTipo}
                        onChange={(e) => setMmTipo(e.target.value as any)}
                        className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-100 focus:outline-none focus:border-amber-500"
                      >
                        <option value="ambos">Geral e Mensal (Ambos)</option>
                        <option value="geral">Apenas Geral</option>
                        <option value="mensal">Apenas Mensal</option>
                      </select>
                    </div>
                    <div className="flex flex-col justify-end">
                      <button
                        onClick={handleSaveMmTrocas}
                        disabled={savingMmTrocas}
                        className="px-4 py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white rounded-lg text-xs font-medium transition flex items-center justify-center gap-1.5 shadow-sm h-[38px]"
                      >
                        <Save className={`w-3.5 h-3.5 ${savingMmTrocas ? 'animate-spin' : ''}`} />
                        {savingMmTrocas ? 'Salvando...' : 'Salvar Intermediações'}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Information Callout */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-slate-900/40 border border-slate-800/60 rounded-xl p-4 flex flex-col gap-1.5">
                    <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      Zero Perda de Dados
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Todas as trocas aprovadas pelo Middleman são salvas simultaneamente no disco e no MongoDB.
                    </p>
                  </div>

                  <div className="bg-slate-900/40 border border-slate-800/60 rounded-xl p-4 flex flex-col gap-1.5">
                    <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                      <Users className="w-4 h-4 text-indigo-400" />
                      Ranking Mensal Preservado
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      O ranking mensal filtra apenas os membros com movimentação no mês, registrando gastos e quantidade de trocas.
                    </p>
                  </div>

                  <div className="bg-slate-900/40 border border-slate-800/60 rounded-xl p-4 flex flex-col gap-1.5">
                    <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                      <History className="w-4 h-4 text-cyan-400" />
                      Backups Duplos
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Você pode restaurar tanto através dos snapshots locais quanto puxar os dados atualizados do MongoDB.
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              /* JSON Table Raw Editor View */
              <div className="flex-1 flex flex-col overflow-hidden">
                <div className="px-4 py-3 border-b border-slate-800/80 bg-slate-900/30 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-semibold text-slate-200 font-mono">
                      {tables.find(t => t.id === activeTab)?.label}
                    </span>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      {tables.find(t => t.id === activeTab)?.desc}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    {saveStatus === 'success' && (
                      <span className="text-xs text-emerald-400 flex items-center gap-1 bg-emerald-500/10 px-2.5 py-1 rounded border border-emerald-500/20">
                        <CheckCircle className="w-3.5 h-3.5" /> Salvo e Persistido!
                      </span>
                    )}
                    {saveStatus === 'file_loaded' && (
                      <span className="text-xs text-indigo-400 flex items-center gap-1 bg-indigo-500/10 px-2.5 py-1 rounded border border-indigo-500/20">
                        <CheckCircle className="w-3.5 h-3.5" /> Arquivo Carregado! Clique em Salvar.
                      </span>
                    )}
                    {saveStatus === 'error_json' && (
                      <span className="text-xs text-red-400 flex items-center gap-1 bg-red-500/10 px-2.5 py-1 rounded border border-red-500/20">
                        <AlertCircle className="w-3.5 h-3.5" /> JSON Inválido!
                      </span>
                    )}
                    <label className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium cursor-pointer transition flex items-center gap-1.5">
                      <Upload className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Carregar Arquivo .json</span>
                      <input
                        type="file"
                        accept=".json,application/json"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>
                    <button
                      onClick={handleSaveTable}
                      disabled={saveStatus === 'saving'}
                      className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium transition flex items-center gap-1.5 shadow-sm"
                    >
                      <Save className="w-3.5 h-3.5" />
                      Salvar Alterações
                    </button>
                  </div>
                </div>

                {/* Code Editor TextArea for JSON Table */}
                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  className="flex-1 p-4 overflow-hidden relative bg-slate-950/60 flex flex-col"
                >
                  {uploadedFileInfo && (
                    <div className="mb-2 px-3 py-1.5 bg-indigo-500/20 border border-indigo-500/30 rounded-lg text-xs text-indigo-200 flex items-center justify-between">
                      <span className="flex items-center gap-1.5 font-medium">
                        <CheckCircle className="w-4 h-4 text-indigo-400" />
                        {uploadedFileInfo}
                      </span>
                      <span className="text-[10px] text-indigo-300">
                        Clique em "Salvar Alterações" para aplicar no servidor
                      </span>
                    </div>
                  )}

                  <div className="relative flex-1 overflow-hidden rounded-lg border border-slate-800">
                    {isDragging && (
                      <div className="absolute inset-0 z-30 bg-indigo-950/90 backdrop-blur-sm border-2 border-dashed border-indigo-500 flex flex-col items-center justify-center text-indigo-200 font-medium">
                        <Upload className="w-10 h-10 mb-2 text-indigo-400 animate-bounce" />
                        <p className="text-sm">Solte o arquivo .json aqui para carregar</p>
                        <p className="text-xs text-indigo-400 mt-1">Carrega instantaneamente para esta tabela</p>
                      </div>
                    )}

                    {/* Syntax Highlighted JSON Overlay */}
                    <div
                      className="absolute inset-0 p-4 font-mono text-xs leading-relaxed whitespace-pre overflow-hidden pointer-events-none text-slate-200 select-none font-mono"
                      dangerouslySetInnerHTML={{
                        __html: (editingContent || '')
                          .replace(/&/g, '&amp;')
                          .replace(/</g, '&lt;')
                          .replace(/>/g, '&gt;')
                          .replace(
                            /("(?:\\[\s\S]|[^"\\])*")\s*(:)?|(\b\d+(?:\.\d+)?\b)|(\b(?:true|false|null)\b)|(\/\/[^\n]*)/g,
                            (match, str, colon, num, boolNull, comment) => {
                              if (comment) return `<span class="text-slate-500 italic">${comment}</span>`;
                              if (str) {
                                if (colon) return `<span class="text-cyan-300 font-semibold">${str}</span>:`;
                                return `<span class="text-emerald-400 font-normal">${str}</span>`;
                              }
                              if (num) return `<span class="text-amber-400 font-semibold">${num}</span>`;
                              if (boolNull) return `<span class="text-purple-400 font-semibold">${boolNull}</span>`;
                              return match;
                            }
                          ) + '\n'
                      }}
                    />

                    {/* Transparent Textarea for JSON editing */}
                    <textarea
                      value={editingContent}
                      onChange={e => setEditingContent(e.target.value)}
                      className="absolute inset-0 w-full h-full bg-transparent text-transparent caret-indigo-400 font-mono text-xs p-4 focus:outline-none resize-none leading-relaxed"
                      spellCheck={false}
                    />
                  </div>
                </div>
              </div>
            )}

          </div>

        </div>

        {/* Footer info */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Sistema 24/7 Ativo: {dbStats.totalUsers} clientes e Proofs #{dbStats.proofsGlobal} sincronizados sem risco de reset.</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg font-medium transition"
          >
            Fechar
          </button>
        </div>

      </div>
    </div>
  );
};
