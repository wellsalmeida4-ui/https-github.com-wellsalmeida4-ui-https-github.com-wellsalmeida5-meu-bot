import React from 'react';
import { Bot } from '../types';
import {
  Play,
  Square,
  RotateCw,
  Code2,
  Terminal,
  Trash2,
  MessageSquareCode,
  Cpu,
  HardDrive,
  Clock,
  Loader2,
  Key
} from 'lucide-react';

interface BotCardProps {
  bot: Bot;
  onStart: (botId: string) => void;
  onStop: (botId: string) => void;
  onRestart: (botId: string) => void;
  onEditCode: (bot: Bot) => void;
  onEditToken?: (bot: Bot) => void;
  onViewLogs: (bot: Bot) => void;
  onSimulate: (bot: Bot) => void;
  onDelete: (bot: Bot) => void;
  isActionLoading: boolean;
}

export const BotCard: React.FC<BotCardProps> = React.memo(({
  bot,
  onStart,
  onStop,
  onRestart,
  onEditCode,
  onEditToken,
  onViewLogs,
  onSimulate,
  onDelete,
  isActionLoading
}) => {
  const isOnline = bot.status === 'online';
  const isStarting = bot.status === 'starting';
  const isInstalling = bot.status === 'installing';
  const isError = bot.status === 'error';
  const isRunning = isOnline || isStarting;

  // Format last run date safely
  const formattedLastRun = bot.lastRunAt
    ? new Date(bot.lastRunAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) + ' - ' + new Date(bot.lastRunAt).toLocaleDateString('pt-BR')
    : 'Nunca executado';

  const memoryPercent = Math.min(100, Math.round((bot.stats.memoryUsage / (bot.stats.maxMemory || 512)) * 100));

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg hover:border-slate-700/80 transition-colors flex flex-col justify-between relative group">
      
      {/* Top Header Row */}
      <div>
        <div className="flex items-start justify-between gap-3 mb-3">
          
          <div className="flex items-center space-x-3">
            {/* Discord Bot Avatar with Status Dot */}
            <div className="relative">
              <div className="w-12 h-12 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-center text-2xl font-mono select-none">
                {bot.icon || '🤖'}
              </div>
              <span
                className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full border-2 border-slate-900 flex items-center justify-center ${
                  isOnline
                    ? 'bg-emerald-500'
                    : isStarting
                    ? 'bg-indigo-500 animate-pulse'
                    : isInstalling
                    ? 'bg-amber-500 animate-pulse'
                    : isError
                    ? 'bg-rose-500'
                    : 'bg-slate-600'
                }`}
                title={`Status: ${bot.status}`}
              />
            </div>

            {/* Name and Discord ID */}
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base font-bold text-white tracking-tight leading-tight group-hover:text-indigo-400 transition-colors truncate max-w-[150px] sm:max-w-[200px]">
                  {bot.name}
                </h3>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                  {bot.prefix}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                ID: {bot.botId}
              </p>
            </div>
          </div>

          {/* Status Badge */}
          <div>
            {isOnline && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5"></span>
                ONLINE 24/7
              </span>
            )}
            {isStarting && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                <Loader2 className="w-3 h-3 mr-1.5 animate-spin text-indigo-400" />
                Iniciando...
              </span>
            )}
            {isInstalling && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                <Loader2 className="w-3 h-3 mr-1.5 animate-spin text-amber-400" />
                Instalando...
              </span>
            )}
            {isError && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mr-1.5"></span>
                ERRO
              </span>
            )}
            {!isOnline && !isStarting && !isInstalling && !isError && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-800 text-slate-400 border border-slate-700">
                OFFLINE
              </span>
            )}
          </div>

        </div>

        {/* Bot Description */}
        <p className="text-xs text-slate-400 line-clamp-2 mb-3 bg-slate-950/40 p-2 rounded-lg border border-slate-800/60">
          {bot.description}
        </p>

        {/* Real-time Hardware Metrics (CPU / RAM) */}
        <div className="grid grid-cols-2 gap-3 mb-3 bg-slate-950/80 p-2.5 rounded-xl border border-slate-800/80">
          
          {/* CPU Metric */}
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span className="flex items-center space-x-1 font-mono">
                <Cpu className="w-3.5 h-3.5 text-emerald-400" />
                <span>CPU Turbo</span>
              </span>
              <span className="font-mono font-bold text-emerald-400">
                {isOnline ? '100% [Max]' : '0%'}
              </span>
            </div>
            <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-emerald-500 transition-all duration-300"
                style={{ width: `${isOnline ? 100 : 0}%` }}
              ></div>
            </div>
          </div>

          {/* RAM Metric */}
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span className="flex items-center space-x-1 font-mono">
                <HardDrive className="w-3.5 h-3.5 text-purple-400" />
                <span>RAM</span>
              </span>
              <span className="font-mono font-bold text-slate-200">
                {isOnline ? `${bot.stats.memoryUsage} MB` : '0 MB'}
              </span>
            </div>
            <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-purple-500 transition-all duration-300"
                style={{ width: `${isOnline ? memoryPercent : 0}%` }}
              ></div>
            </div>
          </div>

        </div>

        {/* Last Execution Info & Discord Invite Link */}
        <div className="flex items-center justify-between text-[11px] text-slate-500 mb-3 px-1">
          <span className="flex items-center space-x-1 truncate max-w-[60%]">
            <Clock className="w-3.5 h-3.5 flex-shrink-0" />
            <span className="font-mono text-slate-400 truncate">{formattedLastRun}</span>
          </span>

          <a
            href={`https://discord.com/api/oauth2/authorize?client_id=${bot.botId}&permissions=8&scope=bot%20applications.commands`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center space-x-1 text-indigo-400 hover:text-indigo-300 font-medium hover:underline bg-indigo-950/40 px-2 py-0.5 rounded border border-indigo-800/50 flex-shrink-0"
            title="Convidar este Bot para o seu Servidor do Discord"
          >
            <span>🔗 Convidar</span>
          </a>
        </div>
      </div>

      {/* Action Buttons Grid */}
      <div className="pt-3 border-t border-slate-800/80 flex flex-col gap-2">
        
        {/* Row 1: Start / Stop / Restart Control Buttons */}
        <div className="grid grid-cols-3 gap-2">
          
          {/* Ligar Bot */}
          <button
            onClick={() => onStart(bot.id)}
            disabled={isRunning || isInstalling || isActionLoading}
            className={`flex items-center justify-center space-x-1.5 py-2 px-2 rounded-xl text-xs font-semibold transition-all border ${
              isRunning || isActionLoading
                ? 'bg-slate-800/50 text-slate-500 border-slate-800 cursor-not-allowed'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-500/40 shadow-sm active:scale-95'
            }`}
          >
            {isStarting || isActionLoading ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin text-slate-400" />
                <span>Iniciando...</span>
              </>
            ) : isOnline ? (
              <>
                <Play className="w-3.5 h-3.5 fill-current opacity-40" />
                <span>Ligado</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Ligar</span>
              </>
            )}
          </button>

          {/* Desligar Bot */}
          <button
            onClick={() => onStop(bot.id)}
            disabled={!isRunning || isActionLoading}
            className={`flex items-center justify-center space-x-1.5 py-2 px-2 rounded-xl text-xs font-semibold transition-all border ${
              !isRunning || isActionLoading
                ? 'bg-slate-800/50 text-slate-500 border-slate-800 cursor-not-allowed'
                : 'bg-amber-600 hover:bg-amber-500 text-white border-amber-500/40 shadow-sm active:scale-95'
            }`}
          >
            <Square className="w-3.5 h-3.5 fill-current" />
            <span>Desligar</span>
          </button>

          {/* Reiniciar Bot */}
          <button
            onClick={() => onRestart(bot.id)}
            disabled={isActionLoading}
            className="flex items-center justify-center space-x-1.5 py-2 px-2 rounded-xl text-xs font-semibold bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/30 transition-all active:scale-95"
          >
            <RotateCw className="w-3.5 h-3.5" />
            <span>Reiniciar</span>
          </button>

        </div>

        {/* Row 2: Secondary Tools (Editar Código, Editar Token, Ver Logs, Testar Simulador, Excluir) */}
        <div className="grid grid-cols-5 gap-1.5 mt-0.5">
          
          {/* Editar Código */}
          <button
            onClick={() => onEditCode(bot)}
            className="flex flex-col items-center justify-center py-2 px-1 rounded-lg text-[11px] font-medium bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700/60 transition-colors"
            title="Abrir Editor de Código Integrado"
          >
            <Code2 className="w-3.5 h-3.5 text-indigo-400 mb-0.5" />
            <span>Código</span>
          </button>

          {/* Editar Token (.env) */}
          <button
            onClick={() => onEditToken && onEditToken(bot)}
            className="flex flex-col items-center justify-center py-2 px-1 rounded-lg text-[11px] font-medium bg-amber-950/40 hover:bg-amber-900/60 text-amber-300 border border-amber-800/50 transition-colors"
            title="Alterar Token do Bot no .env"
          >
            <Key className="w-3.5 h-3.5 text-amber-400 mb-0.5" />
            <span>Token</span>
          </button>

          {/* Ver Logs */}
          <button
            onClick={() => onViewLogs(bot)}
            className="flex flex-col items-center justify-center py-2 px-1 rounded-lg text-[11px] font-medium bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700/60 transition-colors"
            title="Ver Console e Logs em Tempo Real"
          >
            <Terminal className="w-3.5 h-3.5 text-emerald-400 mb-0.5" />
            <span>Logs</span>
          </button>

          {/* Testar / Simulador Discord */}
          <button
            onClick={() => onSimulate(bot)}
            className="flex flex-col items-center justify-center py-2 px-1 rounded-lg text-[11px] font-medium bg-indigo-950/60 hover:bg-indigo-900/80 text-indigo-300 border border-indigo-800/60 transition-colors"
            title="Simular Comandos e Interações no Discord"
          >
            <MessageSquareCode className="w-3.5 h-3.5 text-indigo-400 mb-0.5" />
            <span>Simular</span>
          </button>

          {/* Excluir Bot */}
          <button
            onClick={() => onDelete(bot)}
            className="flex flex-col items-center justify-center py-2 px-1 rounded-lg text-[11px] font-medium bg-rose-950/30 hover:bg-rose-900/50 text-rose-400 border border-rose-900/40 transition-colors"
            title="Excluir Bot do Painel"
          >
            <Trash2 className="w-3.5 h-3.5 text-rose-400 mb-0.5" />
            <span>Excluir</span>
          </button>

        </div>

      </div>

    </div>
  );
});
