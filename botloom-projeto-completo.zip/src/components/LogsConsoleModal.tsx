import React, { useState, useEffect, useRef } from 'react';
import { Bot, BotLog } from '../types';
import {
  X,
  Terminal,
  Trash2,
  Download,
  Filter,
  Send,
  Play,
  CheckCircle2,
  AlertTriangle,
  RotateCcw
} from 'lucide-react';

interface LogsConsoleModalProps {
  bot: Bot | null;
  isOpen: boolean;
  onClose: () => void;
  onClearLogs: (botId: string) => Promise<void>;
  onSendTerminalCommand?: (botId: string, cmd: string) => void;
}

export const LogsConsoleModal: React.FC<LogsConsoleModalProps> = ({
  bot,
  isOpen,
  onClose,
  onClearLogs,
  onSendTerminalCommand
}) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'discord' | 'system' | 'error' | 'stdout'>('all');
  const [terminalInput, setTerminalInput] = useState('');
  const [autoScroll, setAutoScroll] = useState(true);

  const consoleEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new logs arrive
  useEffect(() => {
    if (autoScroll && isOpen && bot) {
      consoleEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [bot?.logs, autoScroll, isOpen]);

  if (!isOpen || !bot) return null;

  // Filter and slice logs to latest 150 entries for maximum DOM performance
  const filteredLogs = (bot.logs || [])
    .filter(log => {
      if (activeFilter === 'all') return true;
      if (activeFilter === 'discord') return log.type === 'discord';
      if (activeFilter === 'system') return log.type === 'system';
      if (activeFilter === 'error') return log.type === 'error' || log.type === 'stderr';
      if (activeFilter === 'stdout') return log.type === 'stdout';
      return true;
    })
    .slice(-150);

  // Download log output file
  const handleExportLogs = () => {
    const textContent = (bot.logs || [])
      .map(l => `[${l.timestamp}] [${l.type.toUpperCase()}] ${l.message}`)
      .join('\n');

    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `logs-${bot.name.toLowerCase().replace(/\s+/g, '-')}-${Date.now()}.log`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSendInput = (e: React.FormEvent) => {
    e.preventDefault();
    if (!terminalInput.trim()) return;

    if (onSendTerminalCommand) {
      onSendTerminalCommand(bot.id, terminalInput.trim());
    }
    setTerminalInput('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-950/85 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl h-[82vh] shadow-2xl flex flex-col overflow-hidden">
        
        {/* Terminal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-slate-900 border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-600/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Terminal className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-sm font-bold text-white font-mono">{bot.name}</h2>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                  bot.status === 'online' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-slate-800 text-slate-400'
                }`}>
                  {bot.status}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Console Integrado & Logs de Execução em Tempo Real
              </p>
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center space-x-2">
            
            <button
              onClick={() => setAutoScroll(!autoScroll)}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono border transition-colors ${
                autoScroll ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300' : 'bg-slate-800 border-slate-700 text-slate-400'
              }`}
            >
              Auto-Scroll: {autoScroll ? 'ON' : 'OFF'}
            </button>

            <button
              onClick={handleExportLogs}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
              title="Baixar Logs (.log)"
            >
              <Download className="w-4 h-4" />
            </button>

            <button
              onClick={() => onClearLogs(bot.id)}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
              title="Limpar Console"
            >
              <Trash2 className="w-4 h-4 text-rose-400" />
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Navigation Bar */}
        <div className="flex items-center space-x-2 px-4 py-2 bg-slate-950 border-b border-slate-800/80 text-xs font-mono">
          <Filter className="w-3.5 h-3.5 text-slate-500 mr-1" />
          
          {(['all', 'discord', 'system', 'stdout', 'error'] as const).map(tabKey => (
            <button
              key={tabKey}
              onClick={() => setActiveFilter(tabKey)}
              className={`px-2.5 py-1 rounded-md capitalize transition-colors ${
                activeFilter === tabKey
                  ? 'bg-indigo-600 text-white font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              {tabKey === 'all' ? 'Todos' : tabKey}
            </button>
          ))}
        </div>

        {/* Console Screen Body */}
        <div className="flex-1 bg-black/95 p-4 font-mono text-xs overflow-y-auto space-y-1.5 leading-relaxed selection:bg-indigo-500 selection:text-white">
          {filteredLogs.length === 0 ? (
            <div className="text-slate-600 text-center py-12 italic">
              Nenhum log registrado para este filtro.
            </div>
          ) : (
            filteredLogs.map(log => {
              let tagColor = 'text-slate-400';
              if (log.type === 'discord') tagColor = 'text-blurple font-bold';
              if (log.type === 'system') tagColor = 'text-indigo-400';
              if (log.type === 'error' || log.type === 'stderr') tagColor = 'text-rose-400 font-bold';
              if (log.type === 'stdout') tagColor = 'text-emerald-400';

              return (
                <div key={log.id} className="flex items-start space-x-2 hover:bg-slate-900/60 p-0.5 rounded">
                  <span className="text-slate-600 select-none">[{log.timestamp}]</span>
                  <span className={`${tagColor} select-none`}>[{log.type.toUpperCase()}]</span>
                  <span className="text-slate-200 break-all">{log.message}</span>
                </div>
              );
            })
          )}
          <div ref={consoleEndRef} />
        </div>

        {/* Console Interactive Input Bar */}
        <form onSubmit={handleSendInput} className="flex items-center px-4 py-2 bg-slate-950 border-t border-slate-800">
          <span className="text-emerald-400 font-mono text-xs font-bold mr-2 select-none">$</span>
          <input
            type="text"
            value={terminalInput}
            onChange={e => setTerminalInput(e.target.value)}
            placeholder="Enviar comando direto ou sinal para a instância do bot (Ex: npm run check, node index.js)..."
            className="flex-1 bg-transparent text-xs text-white font-mono placeholder-slate-600 focus:outline-none"
          />
          <button
            type="submit"
            className="p-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors"
            title="Enviar"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>

      </div>
    </div>
  );
};
