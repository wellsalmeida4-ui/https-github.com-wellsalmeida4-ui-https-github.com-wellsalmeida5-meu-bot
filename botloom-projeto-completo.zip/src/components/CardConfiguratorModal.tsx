import React, { useState, useEffect, useRef } from 'react';
import { Bot, BotFile } from '../types';
import {
  getPersistedCardConfig,
  savePersistedCardConfig
} from '../services/storageSync';
import {
  X,
  Sparkles,
  Palette,
  Check,
  Zap,
  Sliders,
  FileCode,
  CheckCircle2,
  RefreshCw,
  Eye,
  Save,
  Award,
  CircleDollarSign,
  UserCheck,
  Layers,
  Star,
  Upload,
  Image as ImageIcon,
  Trash2
} from 'lucide-react';

interface CardConfiguratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  bots: Bot[];
  selectedBotId?: string | null;
  onBotsUpdated: () => void;
}

export const CardConfiguratorModal: React.FC<CardConfiguratorModalProps> = ({
  isOpen,
  onClose,
  bots,
  selectedBotId,
  onBotsUpdated
}) => {
  const [activeTab, setActiveTab] = useState<'vouch' | 'perfil' | 'code'>('vouch');
  const [targetBotId, setTargetBotId] = useState<string>(selectedBotId || (bots[0]?.id || ''));
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);

  // Vouchcard State
  const [vouchTitle, setVouchTitle] = useState<string>('VOUCH DE INTERMEDIAÇÃO');
  const [vouchTheme, setVouchTheme] = useState<string>('platinum_silver');
  const [vouchAvatarZoom, setVouchAvatarZoom] = useState<number>(155);
  const [vouchNameFontSize, setVouchNameFontSize] = useState<number>(58);
  const [vouchSeloTexto, setVouchSeloTexto] = useState<string>('INTERMEDIADOR VERIFICADO');
  const [vouchValorFontSize, setVouchValorFontSize] = useState<number>(74);
  const [vouchInterFontSize, setVouchInterFontSize] = useState<number>(32);
  const [vouchBrandFooter, setVouchBrandFooter] = useState<string>('NEUX MIDDLE');
  const [vouchShowStars, setVouchShowStars] = useState<boolean>(true);

  // Vouchcard Custom Background Image State
  const [vouchUseCustomBg, setVouchUseCustomBg] = useState<boolean>(false);
  const [vouchCustomBgUrl, setVouchCustomBgUrl] = useState<string>('');
  const [vouchCustomBgOpacity, setVouchCustomBgOpacity] = useState<number>(100);
  const [vouchHideDefaultBorders, setVouchHideDefaultBorders] = useState<boolean>(false);
  const [vouchHideDefaultDots, setVouchHideDefaultDots] = useState<boolean>(false);
  const [isUploadingBg, setIsUploadingBg] = useState<boolean>(false);
  const [uploadBgSuccess, setUploadBgSuccess] = useState<string | null>(null);
  const customBgImgRef = useRef<HTMLImageElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Vouchcard Code Box Customization State
  const [vouchShowCodeBox, setVouchShowCodeBox] = useState<boolean>(true);
  const [vouchCodeLabel, setVouchCodeLabel] = useState<string>('CÓDIGO DO VOUCH');
  const [vouchCodeType, setVouchCodeType] = useState<string>('auto_vouch');
  const [vouchCodePrefix, setVouchCodePrefix] = useState<string>('#');
  const [vouchCodeCustomValue, setVouchCodeCustomValue] = useState<string>('#01645');
  const [vouchCodeFontSize, setVouchCodeFontSize] = useState<number>(48);

  // Perfilcard State
  const [perfilTitle, setPerfilTitle] = useState<string>('PERFIL DE ATENDIMENTO');
  const [perfilTheme, setPerfilTheme] = useState<string>('bicolor_gold');
  const [perfilAvatarZoom, setPerfilAvatarZoom] = useState<number>(160);
  const [perfilRankBadge, setPerfilRankBadge] = useState<string>('TOP #1 MIDDLEMAN');
  const [perfilBrandFooter, setPerfilBrandFooter] = useState<string>('NEUX MIDDLE MEDIAÇÕES');
  const [perfilStatsSize, setPerfilStatsSize] = useState<number>(36);

  // Canvas Refs for Live Preview
  const vouchCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const perfilCanvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (selectedBotId) setTargetBotId(selectedBotId);
    else if (bots.length > 0 && !targetBotId) setTargetBotId(bots[0].id);
  }, [selectedBotId, bots]);

  // Load existing card configuration from localStorage immediately, then reconcile with server on modal open
  useEffect(() => {
    if (!isOpen) return;

    const applyConfigObj = (cfg: any) => {
      if (cfg?.vouchOptions) {
        const v = cfg.vouchOptions;
        if (v.title) setVouchTitle(v.title);
        if (v.theme) setVouchTheme(v.theme);
        if (v.avatarZoom) setVouchAvatarZoom(Number(v.avatarZoom));
        if (v.nameFontSize) setVouchNameFontSize(Number(v.nameFontSize));
        if (v.seloTexto) setVouchSeloTexto(v.seloTexto);
        if (v.valorFontSize) setVouchValorFontSize(Number(v.valorFontSize));
        if (v.interFontSize) setVouchInterFontSize(Number(v.interFontSize));
        if (v.brandFooter) setVouchBrandFooter(v.brandFooter);
        if (v.showStars !== undefined) setVouchShowStars(v.showStars === true || v.showStars === 'true');
        if (v.showCodeBox !== undefined) setVouchShowCodeBox(v.showCodeBox === true || v.showCodeBox === 'true');
        if (v.codeLabel) setVouchCodeLabel(v.codeLabel);
        if (v.codeType) setVouchCodeType(v.codeType);
        if (v.codePrefix !== undefined) setVouchCodePrefix(v.codePrefix);
        if (v.codeCustomValue) setVouchCodeCustomValue(v.codeCustomValue);
        if (v.codeFontSize) setVouchCodeFontSize(Number(v.codeFontSize));
        if (v.useCustomBg !== undefined) setVouchUseCustomBg(v.useCustomBg === true || v.useCustomBg === 'true');
        if (v.customBgUrl || v.customBgImage) {
          const bgUrl = v.customBgUrl || '/api/cards/custom_vouch_bg.png';
          setVouchCustomBgUrl(bgUrl);
          const img = new Image();
          img.crossOrigin = 'anonymous';
          img.src = bgUrl;
          img.onload = () => { customBgImgRef.current = img; };
        }
        if (v.customBgOpacity !== undefined) {
          const op = Number(v.customBgOpacity);
          setVouchCustomBgOpacity(op <= 1.0 ? Math.round(op * 100) : op);
        }
        if (v.hideDefaultBorders !== undefined) setVouchHideDefaultBorders(v.hideDefaultBorders === true || v.hideDefaultBorders === 'true');
        if (v.hideDefaultDots !== undefined) setVouchHideDefaultDots(v.hideDefaultDots === true || v.hideDefaultDots === 'true');
      }
      if (cfg?.perfilOptions) {
        const p = cfg.perfilOptions;
        if (p.title) setPerfilTitle(p.title);
        if (p.theme) setPerfilTheme(p.theme);
        if (p.avatarZoom) setPerfilAvatarZoom(Number(p.avatarZoom));
        if (p.rankBadge) setPerfilRankBadge(p.rankBadge);
        if (p.brandFooter) setPerfilBrandFooter(p.brandFooter);
        if (p.statsSize) setPerfilStatsSize(Number(p.statsSize));
      }
    };

    const cachedCfg = getPersistedCardConfig();
    if (cachedCfg && (cachedCfg.vouchOptions || cachedCfg.perfilOptions)) {
      applyConfigObj(cachedCfg);
    }

    fetch('/api/cards/config')
      .then(res => res.json())
      .then(cfg => {
        const merged = savePersistedCardConfig(cfg, true);
        applyConfigObj(merged);
      })
      .catch(err => console.error('Erro ao carregar cardConfig:', err));
  }, [isOpen]);

  // Preload custom background image when URL changes
  useEffect(() => {
    if (vouchCustomBgUrl) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.src = vouchCustomBgUrl;
      img.onload = () => {
        customBgImgRef.current = img;
      };
    } else {
      customBgImgRef.current = null;
    }
  }, [vouchCustomBgUrl]);

  // Upload handler for custom background template
  const handleUploadBgFile = async (file: File) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      alert('Por favor selecione um arquivo de imagem válido (PNG, JPG, WEBP).');
      return;
    }

    try {
      setIsUploadingBg(true);
      setUploadBgSuccess(null);

      // Read as base64
      const reader = new FileReader();
      reader.onload = async (e) => {
        const base64Data = e.target?.result as string;
        if (!base64Data) return;

        // Instant local preview
        const localImg = new Image();
        localImg.src = base64Data;
        localImg.onload = () => {
          customBgImgRef.current = localImg;
        };

        // Send to backend
        const res = await fetch('/api/cards/upload-image', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: base64Data,
            type: 'vouch'
          })
        });

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.error || 'Falha ao importar imagem.');
        }

        const data = await res.json();
        setVouchCustomBgUrl(data.url);
        setVouchUseCustomBg(true);
        setUploadBgSuccess('✨ Imagem importada e configurada diretamente no código do Vouchcard com sucesso!');
        setGifTimestamp(Date.now());
        onBotsUpdated();
        setTimeout(() => setUploadBgSuccess(null), 5000);
      };
      reader.readAsDataURL(file);
    } catch (err: any) {
      alert(err.message || 'Erro ao importar imagem.');
    } finally {
      setIsUploadingBg(false);
    }
  };

  const handleRemoveCustomBg = async () => {
    if (!confirm('Deseja remover a imagem de fundo personalizada e voltar ao gradiente padrão?')) return;
    try {
      await fetch('/api/cards/custom_vouch_bg.png', { method: 'DELETE' });
      setVouchCustomBgUrl('');
      setVouchUseCustomBg(false);
      customBgImgRef.current = null;
      setGifTimestamp(Date.now());
      onBotsUpdated();
    } catch (err: any) {
      alert('Erro ao remover imagem.');
    }
  };

  // Preview view mode for vouch
  const [vouchPreviewMode, setVouchPreviewMode] = useState<'canvas' | 'gif'>('canvas');
  const [gifTimestamp, setGifTimestamp] = useState<number>(Date.now());

  // Render Vouchcard Live Animated Preview
  useEffect(() => {
    if (!isOpen || activeTab !== 'vouch' || !vouchCanvasRef.current) return;
    const canvas = vouchCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = 1729, H = 910;
    canvas.width = W;
    canvas.height = H;

    let animFrameId: number;
    const startTime = performance.now();

    // Paleta Platina / Prata High-Tech Dark Luxury
    let colorStart = '#FFFFFF', colorMid = '#E5E4E2', colorDark = '#708090';
    if (vouchTheme === 'bicolor_gold') {
      // Se selecionado ouro, mantém os tons de ouro
      colorStart = '#FFF0B8'; colorMid = '#E8B923'; colorDark = '#8C650C';
    } else if (vouchTheme === 'emerald_gold') {
      colorStart = '#A7F3D0'; colorMid = '#10B981'; colorDark = '#065F46';
    } else if (vouchTheme === 'ruby_gold') {
      colorStart = '#FECDD3'; colorMid = '#F43F5E'; colorDark = '#881337';
    } else if (vouchTheme === 'diamond_blue') {
      colorStart = '#BAE6FD'; colorMid = '#0EA5E9'; colorDark = '#0369A1';
    }

    const SPARKLES = [
      { x: 140, y: 110, r: 8, phase: 0.0 },
      { x: 420, y: 140, r: 6, phase: 0.35 },
      { x: 1250, y: 75, r: 7, phase: 0.7 },
      { x: 1620, y: 110, r: 9, phase: 0.15 },
      { x: 1120, y: 220, r: 8, phase: 0.5 },
      { x: 1610, y: 260, r: 10, phase: 0.85 },
      { x: 1350, y: 440, r: 12, phase: 0.4 },
      { x: 1580, y: 480, r: 7, phase: 0.65 },
      { x: 222, y: 215, r: 9, phase: 0.2 },
      { x: 370, y: 480, r: 8, phase: 0.75 },
      { x: 740, y: 345, r: 7, phase: 0.1 },
      { x: 180, y: 730, r: 6, phase: 0.9 },
      { x: 800, y: 645, r: 8, phase: 0.45 },
      { x: 1380, y: 740, r: 7, phase: 0.3 },
      { x: 1620, y: 810, r: 8, phase: 0.6 }
    ];

    // Static geometric grid points for high-tech dot matrix
    const DOT_ROWS = 18;
    const DOT_COLS = 34;

    const render = (now: number) => {
      const elapsed = (now - startTime) / 1000;
      const loopDuration = 6.5; // 6.5 segundos de ciclo cinematográfico
      const progress = (elapsed % loopDuration) / loopDuration;

      // 1. FUNDO PRETO / CINZA CHUMBO ESCURO COM VINHETA PROFUNDA
      const bgGrad = ctx.createRadialGradient(W / 2, H / 2, 50, W / 2, H / 2, Math.max(W, H) * 0.75);
      bgGrad.addColorStop(0, '#090b0e');
      bgGrad.addColorStop(0.65, '#05070a');
      bgGrad.addColorStop(1, '#000000');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, W, H);

      // Custom Background Image (if imported and enabled)
      if (vouchUseCustomBg && customBgImgRef.current && customBgImgRef.current.complete) {
        ctx.save();
        ctx.globalAlpha = Math.max(0.1, Math.min(1.0, vouchCustomBgOpacity / 100));
        ctx.drawImage(customBgImgRef.current, 0, 0, W, H);
        ctx.restore();
      }

      // 2. TEXTURA DE PEQUENOS PONTOS (DOT MATRIX TECNOLÓGICA)
      if (!vouchHideDefaultDots) {
        ctx.save();
        for (let r = 0; r < DOT_ROWS; r++) {
          for (let c = 0; c < DOT_COLS; c++) {
            const dx = 40 + c * ((W - 80) / (DOT_COLS - 1));
            const dy = 40 + r * ((H - 80) / (DOT_ROWS - 1));
            // Pulso sutil ondulante
            const wave = Math.sin((c * 0.25 + r * 0.25) - progress * Math.PI * 4);
            const alpha = 0.08 + 0.07 * wave;
            ctx.fillStyle = `rgba(200, 215, 230, ${Math.max(0.02, alpha)})`;
            ctx.fillRect(dx - 1, dy - 1, 2, 2);
          }
        }
        ctx.restore();
      }

      // Gradiente da Moldura e dos Elementos Metálicos Prateados
      const frameGrad = ctx.createLinearGradient(0, 0, W, H);
      frameGrad.addColorStop(0.00, colorStart);
      frameGrad.addColorStop(0.25, colorMid);
      frameGrad.addColorStop(0.50, colorDark);
      frameGrad.addColorStop(0.75, colorMid);
      frameGrad.addColorStop(1.00, colorStart);

      // 3. MOLDURA DUPLA FINA PRATEADA AO REDOR DO CARD
      if (!vouchHideDefaultBorders) {
        ctx.save();
        // Glow sutil na borda
        ctx.shadowColor = 'rgba(225, 235, 250, 0.35)';
        ctx.shadowBlur = 8;
        ctx.strokeStyle = frameGrad;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.roundRect(14, 14, W - 28, H - 28, 16);
        ctx.stroke();

        // Borda interna fina metálica
        ctx.shadowBlur = 0;
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.22)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(22, 22, W - 44, H - 44, 12);
        ctx.stroke();
        ctx.restore();

        // Cantoneiras geométricas / suportes futuristas nos 4 cantos
        const corners = [
          { x: 14, y: 14, dx: 1, dy: 1 },
          { x: W - 14, y: 14, dx: -1, dy: 1 },
          { x: 14, y: H - 14, dx: 1, dy: -1 },
          { x: W - 14, y: H - 14, dx: -1, dy: -1 }
        ];
        ctx.save();
        ctx.strokeStyle = colorStart;
        ctx.lineWidth = 2.5;
        for (const c of corners) {
          ctx.beginPath();
          ctx.moveTo(c.x, c.y + c.dy * 28);
          ctx.lineTo(c.x, c.y);
          ctx.lineTo(c.x + c.dx * 28, c.y);
          ctx.stroke();
        }
        ctx.restore();
      }

      // 4. DETALHES DE LINHAS GEOMÉTRICAS E RAIOS NOS CANTOS
      ctx.save();
      const drawCrack = (pts: number[][], alpha = 0.55) => {
        ctx.strokeStyle = `rgba(220, 235, 255, ${alpha})`;
        ctx.lineWidth = 1.8;
        ctx.beginPath();
        ctx.moveTo(pts[0][0], pts[0][1]);
        for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
        ctx.stroke();
      };
      // Pulso elétrico sutil nos raios dos cantos
      const electricPulse = 0.5 + 0.4 * Math.sin(progress * Math.PI * 8);
      drawCrack([[W - 240, 20], [W - 180, 65], [W - 198, 72], [W - 130, 120], [W - 148, 126], [W - 75, 175]], electricPulse);
      drawCrack([[W - 120, 22], [W - 88, 52], [W - 102, 58], [W - 45, 100]], electricPulse * 0.7);
      drawCrack([[22, H - 90], [85, H - 60], [68, H - 54], [130, H - 22]], electricPulse);
      drawCrack([[20, H - 140], [60, H - 115], [46, H - 110], [98, H - 78]], electricPulse * 0.7);
      ctx.restore();

      // Função de Texto com Gradiente Metálico e Brilho Prateado
      const drawGradientText = (text: string, x: number, y: number, font: string, align: 'left' | 'right' | 'center' = 'left', customPaletteGrad?: any) => {
        ctx.font = font;
        const textW = ctx.measureText(text).width;
        let startX = x;
        if (align === 'right') startX = x - textW;
        else if (align === 'center') startX = x - textW / 2;

        const grad = customPaletteGrad || ctx.createLinearGradient(startX, y - 40, startX + textW, y);
        if (!customPaletteGrad) {
          grad.addColorStop(0.0, colorStart);
          grad.addColorStop(0.35, colorMid);
          grad.addColorStop(0.70, colorDark);
          grad.addColorStop(1.0, colorStart);
        }

        ctx.save();
        ctx.textAlign = align;
        ctx.fillStyle = grad;
        ctx.fillText(text, x, y);
        ctx.restore();
      };

      // 5. TÍTULO "VOUCH DE INTERMEDIAÇÃO" EM ESTILO MONTSERRAT EXTRABOLD PRATEADO METÁLICO
      drawGradientText(vouchTitle, 65, 118, `800 58px 'Montserrat', sans-serif`, 'left');
      
      // Linha geométrica abaixo do título com ponta futurista
      ctx.strokeStyle = frameGrad;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(68, 150);
      ctx.lineTo(290, 150);
      ctx.stroke();
      ctx.fillStyle = colorStart;
      ctx.fillRect(290, 148, 6, 6);

      // 6. ID DA TRANSAÇÃO NO CANTO SUPERIOR DIREITO
      const rightX = W - 105;
      ctx.textAlign = 'right';
      ctx.fillStyle = colorMid;
      ctx.font = `600 20px 'Montserrat', sans-serif`;
      ctx.fillText('ID DA TRANSAÇÃO', rightX, 82);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = `600 25px 'Montserrat', monospace`;
      ctx.fillText('MM-1785439368477803', rightX, 120);

      // Ícone de cópia sutil
      ctx.strokeStyle = colorMid;
      ctx.lineWidth = 2;
      const icX = rightX - 295, icY = 104;
      ctx.strokeRect(icX, icY, 14, 18);
      ctx.strokeRect(icX - 4, icY + 4, 14, 18);

      // 7. CÓDIGO DO VOUCH DENTRO DE CAIXA COM BORDA ARREDONDADA
      if (vouchShowCodeBox) {
        let previewCodeText = '#01645';
        if (vouchCodeType === 'custom_text') {
          previewCodeText = vouchCodeCustomValue || '#01645';
        } else if (vouchCodeType === 'ticket_id') {
          previewCodeText = `${vouchCodePrefix || ''}ticket-042`.replace(/^##/, '#');
        } else if (vouchCodeType === 'pix_id') {
          previewCodeText = `${vouchCodePrefix || ''}PIX-9874`.replace(/^##/, '#');
        } else if (vouchCodeType === 'protocol_id') {
          previewCodeText = `${vouchCodePrefix || ''}MM-9482X`.replace(/^##/, '#');
        } else {
          if (vouchCodePrefix && !previewCodeText.startsWith(vouchCodePrefix) && !previewCodeText.startsWith('#')) {
            previewCodeText = `${vouchCodePrefix}${previewCodeText}`;
          } else if (vouchCodePrefix === '' && previewCodeText.startsWith('#')) {
            previewCodeText = previewCodeText.replace(/^#+/, '');
          }
        }

        const boxW = 510, boxH = 92;
        const boxX = W - 105 - boxW, boxY = 210;
        const centerBoxX = boxX + boxW / 2;

        // Label do código
        ctx.textAlign = 'center';
        ctx.fillStyle = '#a8b4c0';
        ctx.font = `600 19px 'Montserrat', sans-serif`;
        ctx.fillText(vouchCodeLabel.toUpperCase() || 'CÓDIGO DO VOUCH', centerBoxX, 196);

        // Caixa com borda arredondada prateada
        ctx.strokeStyle = frameGrad;
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        ctx.roundRect(boxX, boxY, boxW, boxH, 12);
        ctx.stroke();

        // Fundo sutil translúcido
        ctx.fillStyle = 'rgba(255, 255, 255, 0.02)';
        ctx.fill();

        // Código grande em destaque
        drawGradientText(previewCodeText, centerBoxX, boxY + 63, `800 ${vouchCodeFontSize}px 'Montserrat', sans-serif`, 'center');
      }

      // 8. VALOR DA INTERMEDIAÇÃO EM DESTAQUE GRANDE
      ctx.textAlign = 'right';
      ctx.fillStyle = '#94a3b8';
      ctx.font = `600 24px 'Montserrat', sans-serif`;
      ctx.fillText('VALOR INTERMEDIADO', rightX, 395);
      
      // Valor com gradiente de alta reflexão prateada
      const valGrad = ctx.createLinearGradient(rightX - 450, 440, rightX, 490);
      valGrad.addColorStop(0.0, '#FFFFFF');
      valGrad.addColorStop(0.3, '#E2E8F0');
      valGrad.addColorStop(0.65, '#94A3B8');
      valGrad.addColorStop(1.0, '#CBD5E1');
      drawGradientText('R$ 1.499,90', rightX, 480, `800 ${vouchValorFontSize}px 'Montserrat', sans-serif`, 'right', valGrad);

      // 9. FOTO DO INTERMEDIADOR DENTRO DE CÍRCULO COM BORDA PRATEADA
      const avX = 222, avY = 350, avR = vouchAvatarZoom;
      ctx.save();
      ctx.beginPath();
      ctx.arc(avX, avY, avR, 0, Math.PI * 2);
      ctx.clip();
      
      const avBg = ctx.createRadialGradient(avX, avY, 15, avX, avY, avR);
      avBg.addColorStop(0, '#1a222d');
      avBg.addColorStop(1, '#080b0f');
      ctx.fillStyle = avBg;
      ctx.fillRect(avX - avR, avY - avR, avR * 2, avR * 2);

      // Letra central com reflexo metálico
      drawGradientText('S', avX, avY + Math.round(avR * 0.32), `800 ${Math.round(avR * 1.15)}px 'Montserrat', sans-serif`, 'center');
      ctx.restore();

      // Moldura circular prateada elegante
      ctx.save();
      ctx.strokeStyle = frameGrad;
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.arc(avX, avY, avR + 3, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      // Anel halo pulsante e rotativo tecnológico ao redor do avatar
      const haloAlpha = 0.25 + 0.25 * Math.sin(progress * Math.PI * 2);
      ctx.save();
      ctx.strokeStyle = 'rgba(225, 240, 255, ' + haloAlpha + ')';
      ctx.lineWidth = 2;
      ctx.setLineDash([12, 16]);
      ctx.beginPath();
      ctx.arc(avX, avY, avR + 10, progress * Math.PI * 2, progress * Math.PI * 2 + Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      // 10. NOME DO INTERMEDIADOR, CARGO BRONZE, SELO, ESTRELAS E INTERMEDIAÇÕES
      const infoX = avX + avR + 52;
      drawGradientText('Yoga Intermediações', infoX, 300, `800 ${vouchNameFontSize}px 'Montserrat', sans-serif`, 'left');

      // Cargo BRONZE em pill metálica prateada ao lado do nome
      const nomeTextWidth = 520;
      const rankPillX = infoX + Math.min(nomeTextWidth, 420);
      const rankPillY = 300 - vouchNameFontSize * 0.72;
      ctx.strokeStyle = frameGrad;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(rankPillX, rankPillY, 120, 38, 19);
      ctx.stroke();
      drawGradientText('BRONZE', rankPillX + 60, rankPillY + 26, `700 20px 'Montserrat', sans-serif`, 'center');

      // Selo de Intermediador Verificado
      const seloY = 345;
      ctx.strokeStyle = frameGrad;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(infoX, seloY, 392, 46, 12);
      ctx.stroke();

      // Checkmark estilizado no selo
      ctx.save();
      ctx.strokeStyle = colorStart;
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.arc(infoX + 28, seloY + 23, 12, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(infoX + 22, seloY + 23);
      ctx.lineTo(infoX + 26, seloY + 28);
      ctx.lineTo(infoX + 34, seloY + 18);
      ctx.stroke();
      ctx.restore();

      drawGradientText(vouchSeloTexto, infoX + 48, seloY + 30, `600 20px 'Montserrat', sans-serif`, 'left');

      // Estrelas + Avaliação
      let nextY = 440;
      if (vouchShowStars) {
        let starX = infoX;
        for (let i = 0; i < 5; i++) {
          ctx.fillStyle = colorMid;
          ctx.beginPath();
          // Estrela desenhada
          const cx = starX + 15, cy = 436, outerR = 14, innerR = 6.5;
          for (let st = 0; st < 10; st++) {
            const r = st % 2 === 0 ? outerR : innerR;
            const angle = (Math.PI / 5) * st - Math.PI / 2;
            const px = cx + r * Math.cos(angle);
            const py = cy + r * Math.sin(angle);
            if (st === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
          }
          ctx.closePath();
          ctx.fill();
          starX += 36;
        }
        drawGradientText('5.0', starX + 10, 447, `700 28px 'Montserrat', sans-serif`, 'left');
        nextY = 505;
      }

      // Quantidade de Intermediações
      // Ícone lista
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 2;
      ctx.strokeRect(infoX + 6, nextY - 18, 16, 20);
      ctx.beginPath();
      ctx.moveTo(infoX + 10, nextY - 12); ctx.lineTo(infoX + 18, nextY - 12);
      ctx.moveTo(infoX + 10, nextY - 6); ctx.lineTo(infoX + 18, nextY - 6);
      ctx.stroke();

      ctx.fillStyle = '#94a3b8';
      ctx.font = `600 ${vouchInterFontSize}px 'Montserrat', sans-serif`;
      ctx.fillText('1284 INTERMEDIAÇÕES', infoX + 34, nextY);

      // 11. RODAPÉ: COMPRADOR, VENDEDOR, DATA E NOME DA PLATAFORMA
      const footX = 75, footW = W - 150, footY = 645;
      
      // Linha divisória horizontal prateada com gradiente elegante
      ctx.save();
      const footLineGrad = ctx.createLinearGradient(footX, 0, footX + footW, 0);
      footLineGrad.addColorStop(0.00, 'rgba(75, 85, 96, 0.4)');
      footLineGrad.addColorStop(0.20, colorMid);
      footLineGrad.addColorStop(0.50, colorStart);
      footLineGrad.addColorStop(0.80, colorMid);
      footLineGrad.addColorStop(1.00, 'rgba(75, 85, 96, 0.4)');
      ctx.strokeStyle = footLineGrad;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(footX, footY + 16);
      ctx.lineTo(footX + footW, footY + 16);
      ctx.stroke();
      ctx.restore();

      const cyParty = footY + 88;

      const drawParty = (x: number, letter: string, label: string, name: string) => {
        ctx.save();
        // Círculo com borda prateada
        ctx.beginPath();
        ctx.arc(x, cyParty, 36, 0, Math.PI * 2);
        ctx.fillStyle = '#10141a';
        ctx.fill();
        ctx.strokeStyle = frameGrad;
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.fillStyle = '#F8FAFC';
        ctx.font = `700 28px 'Montserrat', sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(letter, x, cyParty + 2);

        const textX = x + 54;
        ctx.textAlign = 'left';
        ctx.fillStyle = '#94a3b8';
        ctx.font = `600 17px 'Montserrat', sans-serif`;
        ctx.fillText(label, textX, cyParty - 10);

        ctx.fillStyle = '#FFFFFF';
        ctx.font = `700 24px 'Montserrat', sans-serif`;
        ctx.fillText(name, textX, cyParty + 18);

        // Selo verificado pequeno
        const nw = ctx.measureText(name).width;
        ctx.beginPath();
        ctx.arc(textX + nw + 18, cyParty + 12, 9, 0, Math.PI * 2);
        ctx.fillStyle = colorMid;
        ctx.fill();
        ctx.restore();
      };

      drawParty(footX + 50, 'C', 'COMPRADOR', 'Neeux MM Services');
      drawParty(footX + footW * 0.34, 'V', 'VENDEDOR', 'Neeux MM Services');

      // Coluna da Data
      const dataX = footX + footW * 0.65;
      ctx.save();
      // Ícone calendário
      ctx.strokeStyle = colorMid;
      ctx.lineWidth = 2;
      ctx.strokeRect(dataX, cyParty - 18, 26, 24);
      ctx.beginPath();
      ctx.moveTo(dataX, cyParty - 10); ctx.lineTo(dataX + 26, cyParty - 10);
      ctx.moveTo(dataX + 6, cyParty - 22); ctx.lineTo(dataX + 6, cyParty - 18);
      ctx.moveTo(dataX + 20, cyParty - 22); ctx.lineTo(dataX + 20, cyParty - 18);
      ctx.stroke();

      ctx.fillStyle = '#94a3b8';
      ctx.font = `600 17px 'Montserrat', sans-serif`;
      ctx.fillText('DATA', dataX + 38, cyParty - 8);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = `700 24px 'Montserrat', sans-serif`;
      ctx.fillText('30/07/2026', dataX + 38, cyParty + 18);
      ctx.restore();

      // Nome da Plataforma no canto direito
      drawGradientText(vouchBrandFooter, footX + footW - 20, cyParty + 8, `700 22px 'Montserrat', sans-serif`, 'right');

      // 12. ANIMAÇÃO: FEIXE DE LUZ PRATEADO / METÁLICO (LIGHT SWEEP SHIMMER)
      ctx.save();
      // Varredura suave diagonal ao longo de todo o voucher
      const sweepPos = ((progress * 1.4) % 1.4) - 0.2; // ciclo com pausa elegante
      const sweepX = sweepPos * (W + 800) - 400;
      const beamW = 280;

      ctx.translate(sweepX, H / 2);
      ctx.rotate(-25 * Math.PI / 180);

      const shimmerGrad = ctx.createLinearGradient(-beamW, 0, beamW, 0);
      shimmerGrad.addColorStop(0.00, 'rgba(255, 255, 255, 0)');
      shimmerGrad.addColorStop(0.35, 'rgba(220, 235, 255, 0.05)');
      shimmerGrad.addColorStop(0.50, 'rgba(255, 255, 255, 0.32)');
      shimmerGrad.addColorStop(0.65, 'rgba(220, 235, 255, 0.05)');
      shimmerGrad.addColorStop(1.00, 'rgba(255, 255, 255, 0)');

      ctx.fillStyle = shimmerGrad;
      ctx.fillRect(-beamW, -H * 2, beamW * 2, H * 4);
      ctx.restore();

      // 13. ANIMAÇÃO: LINHA DE ESCANEAMENTO HUD CIBERNÉTICA
      ctx.save();
      const scanY = (progress * H * 1.1) % H;
      const scanGrad = ctx.createLinearGradient(0, scanY - 8, 0, scanY + 8);
      scanGrad.addColorStop(0, 'rgba(180, 215, 255, 0)');
      scanGrad.addColorStop(0.5, 'rgba(220, 240, 255, 0.28)');
      scanGrad.addColorStop(1, 'rgba(180, 215, 255, 0)');
      ctx.fillStyle = scanGrad;
      ctx.fillRect(14, scanY - 8, W - 28, 16);
      ctx.restore();

      // 14. ANIMAÇÃO: BRILHOS METÁLICOS / SPARKLES ESTILIZADOS
      for (const s of SPARKLES) {
        const sparkleCycle = (progress * 2 + s.phase) % 1;
        const alpha = Math.sin(sparkleCycle * Math.PI);
        if (alpha > 0.05) {
          const curR = s.r * (0.6 + 0.6 * alpha);
          ctx.save();
          ctx.globalAlpha = Math.min(1, alpha * 0.95);

          const coreGrad = ctx.createRadialGradient(s.x, s.y, 0, s.x, s.y, curR * 2.2);
          coreGrad.addColorStop(0, '#FFFFFF');
          coreGrad.addColorStop(0.3, colorStart);
          coreGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
          ctx.fillStyle = coreGrad;
          ctx.beginPath();
          ctx.arc(s.x, s.y, curR * 2.2, 0, Math.PI * 2);
          ctx.fill();

          // Cruz estelar com flare fino prateado
          ctx.fillStyle = '#FFFFFF';
          ctx.beginPath();
          ctx.moveTo(s.x, s.y - curR * 2.5);
          ctx.quadraticCurveTo(s.x, s.y, s.x + curR * 0.35, s.y);
          ctx.quadraticCurveTo(s.x, s.y, s.x, s.y + curR * 2.5);
          ctx.quadraticCurveTo(s.x, s.y, s.x - curR * 0.35, s.y);
          ctx.quadraticCurveTo(s.x, s.y, s.x, s.y - curR * 2.5);
          ctx.fill();

          ctx.beginPath();
          ctx.moveTo(s.x - curR * 2.5, s.y);
          ctx.quadraticCurveTo(s.x, s.y, s.x, s.y + curR * 0.35);
          ctx.quadraticCurveTo(s.x, s.y, s.x + curR * 2.5, s.y);
          ctx.quadraticCurveTo(s.x, s.y, s.x, s.y - curR * 0.35);
          ctx.quadraticCurveTo(s.x, s.y, s.x - curR * 2.5, s.y);
          ctx.fill();

          ctx.restore();
        }
      }

      animFrameId = requestAnimationFrame(render);
    };

    animFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animFrameId);
    };
  }, [
    isOpen,
    activeTab,
    vouchTitle,
    vouchTheme,
    vouchAvatarZoom,
    vouchNameFontSize,
    vouchSeloTexto,
    vouchValorFontSize,
    vouchInterFontSize,
    vouchBrandFooter,
    vouchShowStars,
    vouchShowCodeBox,
    vouchCodeLabel,
    vouchCodeType,
    vouchCodePrefix,
    vouchCodeCustomValue,
    vouchCodeFontSize,
    vouchUseCustomBg,
    vouchCustomBgOpacity,
    vouchHideDefaultBorders,
    vouchHideDefaultDots
  ]);

  // Render Perfilcard Live Preview
  useEffect(() => {
    if (!isOpen || activeTab !== 'perfil' || !perfilCanvasRef.current) return;
    const canvas = perfilCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = 1740, H = 920;
    canvas.width = W;
    canvas.height = H;

    ctx.fillStyle = '#080808';
    ctx.fillRect(0, 0, W, H);

    let colorStart = '#FFF0B8', colorMid = '#E8B923', colorDark = '#8C650C';
    if (perfilTheme === 'platinum_silver') {
      colorStart = '#FFFFFF'; colorMid = '#E5E4E2'; colorDark = '#708090';
    } else if (perfilTheme === 'emerald_gold') {
      colorStart = '#A7F3D0'; colorMid = '#10B981'; colorDark = '#065F46';
    } else if (perfilTheme === 'ruby_gold') {
      colorStart = '#FECDD3'; colorMid = '#F43F5E'; colorDark = '#881337';
    } else if (perfilTheme === 'diamond_blue') {
      colorStart = '#BAE6FD'; colorMid = '#0EA5E9'; colorDark = '#0369A1';
    }

    const frameGrad = ctx.createLinearGradient(0, 0, W, H);
    frameGrad.addColorStop(0, colorStart);
    frameGrad.addColorStop(0.3, colorMid);
    frameGrad.addColorStop(0.7, colorDark);
    frameGrad.addColorStop(1, colorStart);

    ctx.strokeStyle = frameGrad;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.roundRect(18, 18, W - 36, H - 36, 24);
    ctx.stroke();

    const drawGradientText = (text: string, x: number, y: number, font: string, align: 'left' | 'right' | 'center' = 'left') => {
      ctx.font = font;
      const textW = ctx.measureText(text).width;
      let startX = x;
      if (align === 'right') startX = x - textW;
      else if (align === 'center') startX = x - textW / 2;

      const grad = ctx.createLinearGradient(startX, y - 40, startX + textW, y);
      grad.addColorStop(0, colorStart);
      grad.addColorStop(0.4, colorMid);
      grad.addColorStop(0.8, colorDark);
      grad.addColorStop(1, colorStart);

      ctx.save();
      ctx.textAlign = align;
      ctx.fillStyle = grad;
      ctx.fillText(text, x, y);
      ctx.restore();
    };

    drawGradientText(perfilTitle, 65, 100, `bold 48px sans-serif`, 'left');

    const avX = 220, avY = 350, avR = perfilAvatarZoom;
    ctx.save();
    ctx.beginPath();
    ctx.arc(avX, avY, avR, 0, Math.PI * 2);
    ctx.clip();
    const bgGrad = ctx.createRadialGradient(avX, avY, 10, avX, avY, avR);
    bgGrad.addColorStop(0, '#262012');
    bgGrad.addColorStop(1, '#0f0d07');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(avX - avR, avY - avR, avR * 2, avR * 2);
    drawGradientText('S', avX, avY + Math.round(avR * 0.3), `bold ${Math.round(avR * 1.15)}px sans-serif`, 'center');
    ctx.restore();

    ctx.strokeStyle = frameGrad;
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.arc(avX, avY, avR + 4, 0, Math.PI * 2);
    ctx.stroke();

    const infoX = avX + avR + 45;
    drawGradientText('Yoga Staff Oficial', infoX, 285, `bold 58px sans-serif`, 'left');

    ctx.strokeStyle = frameGrad;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(infoX, 315, 340, 48, 24);
    ctx.stroke();
    drawGradientText(perfilRankBadge, infoX + 30, 347, 'bold 22px sans-serif', 'left');

    // Stats Grid
    ctx.fillStyle = '#FFFFFF';
    ctx.font = `bold ${perfilStatsSize}px sans-serif`;
    ctx.fillText('R$ 248.500,00', infoX, 430);
    ctx.fillStyle = '#9c9c9c';
    ctx.font = '22px sans-serif';
    ctx.fillText('TOTAL MOVIMENTADO GERAL', infoX, 460);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = `bold ${perfilStatsSize}px sans-serif`;
    ctx.fillText('148 INTERMEDIAÇÕES ESTE MÊS', infoX, 520);

    drawGradientText(perfilBrandFooter, W - 100, H - 70, 'bold 26px sans-serif', 'right');

  }, [
    isOpen,
    activeTab,
    perfilTitle,
    perfilTheme,
    perfilAvatarZoom,
    perfilRankBadge,
    perfilBrandFooter,
    perfilStatsSize
  ]);

  const handleSaveAndApply = async () => {
    try {
      setIsSaving(true);
      setSaveSuccess(null);

      const payload = {
        botId: targetBotId,
        vouchOptions: {
          title: vouchTitle,
          theme: vouchTheme,
          avatarZoom: vouchAvatarZoom,
          nameFontSize: vouchNameFontSize,
          seloTexto: vouchSeloTexto,
          valorFontSize: vouchValorFontSize,
          interFontSize: vouchInterFontSize,
          brandFooter: vouchBrandFooter,
          showStars: vouchShowStars,
          useCustomBg: vouchUseCustomBg,
          customBgUrl: vouchCustomBgUrl,
          customBgOpacity: vouchCustomBgOpacity,
          hideDefaultBorders: vouchHideDefaultBorders,
          hideDefaultDots: vouchHideDefaultDots,
          showCodeBox: vouchShowCodeBox,
          codeLabel: vouchCodeLabel,
          codeType: vouchCodeType,
          codePrefix: vouchCodePrefix,
          codeCustomValue: vouchCodeCustomValue,
          codeFontSize: vouchCodeFontSize
        },
        perfilOptions: {
          title: perfilTitle,
          theme: perfilTheme,
          avatarZoom: perfilAvatarZoom,
          rankBadge: perfilRankBadge,
          brandFooter: perfilBrandFooter,
          statsSize: perfilStatsSize
        }
      };

      const res = await fetch('/api/cards/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        throw new Error('Erro ao salvar configurações dos cartões.');
      }

      setSaveSuccess('✅ Sucesso! As opções do Vouchcard e Perfilcard foram aplicadas automaticamente no código (vouchCard.js e perfilCard.js) e nos comandos /aprovar_pagamento, /vouch e /perfil!');
      onBotsUpdated();
      setTimeout(() => setSaveSuccess(null), 6000);
    } catch (err: any) {
      alert(err.message || 'Erro ao aplicar alterações.');
    } finally {
      setIsSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-6xl shadow-2xl overflow-hidden my-8 flex flex-col max-h-[90vh]">
        
        {/* Header Bar */}
        <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-yellow-500 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/20 text-slate-950 font-bold">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center space-x-2">
                <span>Estúdio de Cartões: Vouchcard & Perfilcard</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                  Auto-Sync nos Comandos
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Altere títulos, gradientes metálicos, tamanhos de letra, zoom do intermediador e formatos. Tudo é sincronizado automaticamente no código e no Discord.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="bg-slate-950/60 border-b border-slate-800/80 px-6 py-2 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setActiveTab('vouch')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'vouch'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <CircleDollarSign className="w-4 h-4" />
              <span>🎟️ Vouchcard (/aprovar_pagamento & /vouch)</span>
            </button>

            <button
              onClick={() => setActiveTab('perfil')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'perfil'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <UserCheck className="w-4 h-4" />
              <span>👤 Perfilcard (/perfil)</span>
            </button>

            <button
              onClick={() => setActiveTab('code')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'code'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <FileCode className="w-4 h-4" />
              <span>⚡ Código Sincronizado</span>
            </button>
          </div>

          {/* Bot Target Selector */}
          <div className="flex items-center space-x-2 text-xs">
            <span className="text-slate-400 font-medium">Aplicar no Bot:</span>
            <select
              value={targetBotId}
              onChange={(e) => setTargetBotId(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1 text-slate-200 text-xs font-bold focus:outline-none focus:border-amber-500"
            >
              {bots.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name} ({b.status})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Success Toast */}
        {saveSuccess && (
          <div className="bg-emerald-500/10 border-b border-emerald-500/30 px-6 py-3 text-emerald-400 text-xs font-medium flex items-center space-x-2 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>{saveSuccess}</span>
          </div>
        )}

        {/* Main Content Body */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Controls Column (5 cols) */}
          <div className="lg:col-span-5 space-y-5 bg-slate-950/40 p-4 rounded-2xl border border-slate-800/80">
            
            {activeTab === 'vouch' && (
              <>
                <h3 className="text-sm font-bold text-amber-400 flex items-center space-x-2 pb-2 border-b border-slate-800">
                  <Sliders className="w-4 h-4" />
                  <span>Opções do Vouchcard</span>
                </h3>

                {/* Importar Imagem de Fundo / Template Customizado */}
                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-amber-500/40 space-y-3 shadow-lg shadow-amber-950/20">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <ImageIcon className="w-4 h-4 text-amber-400" />
                      <span className="text-xs font-bold text-amber-300">
                        🖼️ Imagem de Fundo / Template Personalizado
                      </span>
                    </div>
                    {vouchCustomBgUrl && (
                      <label className="inline-flex items-center cursor-pointer space-x-1.5 text-[11px] font-medium text-slate-300">
                        <input
                          type="checkbox"
                          checked={vouchUseCustomBg}
                          onChange={(e) => {
                            setVouchUseCustomBg(e.target.checked);
                            setGifTimestamp(Date.now());
                          }}
                          className="rounded border-slate-700 text-amber-500 focus:ring-amber-500 bg-slate-950"
                        />
                        <span>Ativar no Card</span>
                      </label>
                    )}
                  </div>

                  {uploadBgSuccess && (
                    <div className="bg-emerald-500/20 border border-emerald-500/40 rounded-lg p-2 text-emerald-300 text-[11px] font-medium flex items-center space-x-2">
                      <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0" />
                      <span>{uploadBgSuccess}</span>
                    </div>
                  )}

                  {/* Upload Box (Drag & Drop + Click + Explicit Button) */}
                  <div
                    onDragOver={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                    }}
                    onDrop={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                        handleUploadBgFile(e.dataTransfer.files[0]);
                      }
                    }}
                    className={`border-2 border-dashed rounded-xl p-4 text-center transition-all ${
                      vouchCustomBgUrl
                        ? 'border-amber-500/50 bg-amber-950/20'
                        : 'border-amber-500/40 bg-slate-950/80 hover:border-amber-400'
                    }`}
                  >
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          handleUploadBgFile(e.target.files[0]);
                        }
                      }}
                      accept="image/png,image/jpeg,image/webp,image/jpg"
                      className="hidden"
                    />

                    {isUploadingBg ? (
                      <div className="flex flex-col items-center justify-center space-y-2 py-3 text-amber-400">
                        <RefreshCw className="w-7 h-7 animate-spin" />
                        <span className="text-xs font-bold">Importando e salvando imagem no código...</span>
                      </div>
                    ) : vouchCustomBgUrl ? (
                      <div className="space-y-3">
                        <div className="flex items-center space-x-3 text-left">
                          <img
                            src={vouchCustomBgUrl}
                            alt="Custom Background Preview"
                            className="w-20 h-12 object-cover rounded-lg border-2 border-amber-500/60 shadow-md"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center space-x-1.5">
                              <span className="text-xs font-bold text-white truncate">Imagem Importada Ativa</span>
                              <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                                1729x910
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-400 mt-0.5">
                              O Vouchcard utilizará este fundo na renderização.
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleRemoveCustomBg();
                            }}
                            className="p-2 rounded-lg bg-red-950/60 hover:bg-red-900 text-red-400 hover:text-red-200 border border-red-800/60 transition-colors shadow"
                            title="Remover Imagem de Fundo"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>

                        {/* Botão de Trocar Imagem */}
                        <div className="flex items-center gap-2 pt-1 border-t border-slate-800/80">
                          <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            className="flex-1 flex items-center justify-center space-x-2 py-2 px-3 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 hover:text-white rounded-lg text-xs font-bold border border-amber-500/40 transition-all cursor-pointer shadow-sm active:scale-95"
                          >
                            <Upload className="w-3.5 h-3.5" />
                            <span>Clique aqui para Trocar Imagem</span>
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center space-y-3 py-3">
                        <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-inner">
                          <ImageIcon className="w-6 h-6" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-100">
                            Adicione uma imagem de fundo para o Vouchcard
                          </p>
                          <p className="text-[11px] text-slate-400 mt-0.5">
                            Formato ideal: PNG, JPG ou WEBP (Resolução recomendada: 1729x910)
                          </p>
                        </div>

                        {/* Botão Bem Visível e Destacado de Upload */}
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="flex items-center space-x-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 px-5 py-2.5 rounded-xl text-xs font-black transition-all shadow-lg shadow-amber-500/20 hover:scale-105 active:scale-95 cursor-pointer"
                        >
                          <Upload className="w-4 h-4 text-slate-950" />
                          <span>SELECIONAR IMAGEM DO SEU COMPUTADOR</span>
                        </button>
                        <span className="text-[10px] text-slate-500">ou simplesmente arraste e solte o arquivo aqui</span>
                      </div>
                    )}
                  </div>

                  {/* Controles adicionais da Imagem Importada */}
                  {vouchCustomBgUrl && (
                    <div className="space-y-2.5 pt-2 border-t border-slate-800/80">
                      {/* Opacidade do Fundo Personalizado */}
                      <div>
                        <div className="flex justify-between items-center text-[11px] mb-1">
                          <span className="font-semibold text-slate-300">Opacidade do Fundo Personalizado</span>
                          <span className="font-mono text-amber-400 font-bold">{vouchCustomBgOpacity}%</span>
                        </div>
                        <input
                          type="range"
                          min="20"
                          max="100"
                          value={vouchCustomBgOpacity}
                          onChange={(e) => setVouchCustomBgOpacity(Number(e.target.value))}
                          className="w-full accent-amber-500 cursor-pointer"
                        />
                      </div>

                      {/* Toggles de Moldura e Partículas */}
                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <label className="flex items-center space-x-2 text-[11px] text-slate-300 cursor-pointer bg-slate-950/60 p-2 rounded-lg border border-slate-800">
                          <input
                            type="checkbox"
                            checked={vouchHideDefaultBorders}
                            onChange={(e) => setVouchHideDefaultBorders(e.target.checked)}
                            className="rounded border-slate-700 text-amber-500 focus:ring-amber-500 bg-slate-950"
                          />
                          <span>Ocultar Moldura Dourada</span>
                        </label>
                        <label className="flex items-center space-x-2 text-[11px] text-slate-300 cursor-pointer bg-slate-950/60 p-2 rounded-lg border border-slate-800">
                          <input
                            type="checkbox"
                            checked={vouchHideDefaultDots}
                            onChange={(e) => setVouchHideDefaultDots(e.target.checked)}
                            className="rounded border-slate-700 text-amber-500 focus:ring-amber-500 bg-slate-950"
                          />
                          <span>Ocultar Partículas</span>
                        </label>
                      </div>
                    </div>
                  )}
                </div>

                {/* Título do Cartão */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Título do Cartão
                  </label>
                  <input
                    type="text"
                    value={vouchTitle}
                    onChange={(e) => setVouchTitle(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-500 focus:outline-none font-bold"
                  />
                </div>

                {/* Tema / Gradiente Metálico */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Tema / Gradiente Metálico
                  </label>
                  <select
                    value={vouchTheme}
                    onChange={(e) => setVouchTheme(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-500 focus:outline-none font-bold"
                  >
                    <option value="bicolor_gold">✨ Ouro Metálico Bicolor Luxo (#E8B923)</option>
                    <option value="platinum_silver">🥈 Platina & Prata Premium (#E5E4E2)</option>
                    <option value="emerald_gold">🟢 Esmeralda & Ouro (#10B981)</option>
                    <option value="ruby_gold">🔴 Rubi Imaterial (#F43F5E)</option>
                    <option value="diamond_blue">💎 Diamante Azul (#0EA5E9)</option>
                  </select>
                </div>

                {/* Zoom e Tamanho do Avatar do Intermediador */}
                <div>
                  <div className="flex justify-between items-center text-xs mb-1">
                    <span className="font-semibold text-slate-300">Zoom do Avatar do Intermediador</span>
                    <span className="font-mono text-amber-400 font-bold">{vouchAvatarZoom}px (Ampliado)</span>
                  </div>
                  <input
                    type="range"
                    min="110"
                    max="180"
                    value={vouchAvatarZoom}
                    onChange={(e) => setVouchAvatarZoom(Number(e.target.value))}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                {/* Tamanho da Fonte do Nome do Intermediador */}
                <div>
                  <div className="flex justify-between items-center text-xs mb-1">
                    <span className="font-semibold text-slate-300">Tamanho da Fonte do Nome</span>
                    <span className="font-mono text-amber-400 font-bold">{vouchNameFontSize}px Bold</span>
                  </div>
                  <input
                    type="range"
                    min="40"
                    max="72"
                    value={vouchNameFontSize}
                    onChange={(e) => setVouchNameFontSize(Number(e.target.value))}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                {/* Texto do Selo */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Texto do Selo de Verificação
                  </label>
                  <input
                    type="text"
                    value={vouchSeloTexto}
                    onChange={(e) => setVouchSeloTexto(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-500 focus:outline-none"
                  />
                </div>

                {/* Bloco de Configuração do CÓDIGO */}
                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-amber-500/30 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                      <span className="text-xs font-bold text-amber-300">
                        🎯 Seção "CÓDIGO" (Identificador)
                      </span>
                    </div>
                    <label className="inline-flex items-center cursor-pointer space-x-1.5 text-[11px] font-medium text-slate-300">
                      <input
                        type="checkbox"
                        checked={vouchShowCodeBox}
                        onChange={(e) => setVouchShowCodeBox(e.target.checked)}
                        className="rounded border-slate-700 text-amber-500 focus:ring-amber-500 bg-slate-950"
                      />
                      <span>Exibir no Cartão</span>
                    </label>
                  </div>

                  {vouchShowCodeBox && (
                    <div className="space-y-3 pt-1">
                      {/* O que mostrar no campo de Código */}
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          Tipo de Dado / O que Mostrar no Código
                        </label>
                        <select
                          value={vouchCodeType}
                          onChange={(e) => setVouchCodeType(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-500 focus:outline-none font-bold"
                        >
                          <option value="auto_vouch">🔢 Sequencial Automático (ex: #01645)</option>
                          <option value="ticket_id">🎫 ID / Número do Ticket (ex: #ticket-042)</option>
                          <option value="pix_id">⚡ Chave / Hash PIX (ex: #PIX-9874)</option>
                          <option value="protocol_id">🔒 Protocolo Criptográfico (ex: #MM-9482X)</option>
                          <option value="custom_text">✍️ Texto / Código Fixo Personalizado</option>
                        </select>
                      </div>

                      {/* Se for texto fixo personalizado */}
                      {vouchCodeType === 'custom_text' && (
                        <div>
                          <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                            Texto / Valor Personalizado do Código
                          </label>
                          <input
                            type="text"
                            value={vouchCodeCustomValue}
                            onChange={(e) => setVouchCodeCustomValue(e.target.value)}
                            placeholder="Ex: #01645, VOUCH-VIP, #NEUX-1"
                            className="w-full bg-slate-950 border border-amber-500/40 rounded-xl px-3 py-2 text-xs text-amber-200 focus:border-amber-500 focus:outline-none font-mono font-bold"
                          />
                        </div>
                      )}

                      {/* Rótulo / Título Superior da Caixa */}
                      <div>
                        <div className="flex justify-between items-center mb-1">
                          <label className="text-[11px] font-semibold text-slate-300">
                            Rótulo / Título Superior da Caixa
                          </label>
                        </div>
                        <input
                          type="text"
                          value={vouchCodeLabel}
                          onChange={(e) => setVouchCodeLabel(e.target.value)}
                          placeholder="Ex: CÓDIGO DO VOUCH"
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-500 focus:outline-none font-bold mb-1.5"
                        />
                        {/* Botões de Predefinição Rápida */}
                        <div className="flex flex-wrap gap-1">
                          {[
                            'CÓDIGO DO VOUCH',
                            'CÓDIGO DO TICKET',
                            'CHAVE PIX',
                            'PROTOCOLO',
                            'ID DO LEILÃO',
                            'ID DA TROCA'
                          ].map((preset) => (
                            <button
                              key={preset}
                              type="button"
                              onClick={() => setVouchCodeLabel(preset)}
                              className={`text-[9px] px-2 py-0.5 rounded-md border transition-all ${
                                vouchCodeLabel.toUpperCase() === preset
                                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 font-bold'
                                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                              }`}
                            >
                              {preset}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Prefixo do Código */}
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                            Prefixo
                          </label>
                          <select
                            value={vouchCodePrefix}
                            onChange={(e) => setVouchCodePrefix(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-white focus:border-amber-500 focus:outline-none font-bold"
                          >
                            <option value="#"># (Hashtag)</option>
                            <option value="ID-">ID-</option>
                            <option value="VOUCH-">VOUCH-</option>
                            <option value="TK-">TK-</option>
                            <option value="">Nenhum (Sem Prefixo)</option>
                          </select>
                        </div>

                        {/* Tamanho da Fonte do Código */}
                        <div>
                          <div className="flex justify-between items-center text-[11px] mb-1">
                            <span className="font-semibold text-slate-300">Tamanho Fonte</span>
                            <span className="font-mono text-amber-400 font-bold">{vouchCodeFontSize}px</span>
                          </div>
                          <input
                            type="range"
                            min="28"
                            max="64"
                            value={vouchCodeFontSize}
                            onChange={(e) => setVouchCodeFontSize(Number(e.target.value))}
                            className="w-full accent-amber-500 cursor-pointer mt-1"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Tamanho do Valor Intermediado */}
                <div>
                  <div className="flex justify-between items-center text-xs mb-1">
                    <span className="font-semibold text-slate-300">Tamanho do Valor Intermediado</span>
                    <span className="font-mono text-amber-400 font-bold">{vouchValorFontSize}px Destaque</span>
                  </div>
                  <input
                    type="range"
                    min="50"
                    max="92"
                    value={vouchValorFontSize}
                    onChange={(e) => setVouchValorFontSize(Number(e.target.value))}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                {/* Tamanho do Número de Intermediações */}
                <div>
                  <div className="flex justify-between items-center text-xs mb-1">
                    <span className="font-semibold text-slate-300">Tamanho do Número de Intermediações</span>
                    <span className="font-mono text-amber-400 font-bold">{vouchInterFontSize}px</span>
                  </div>
                  <input
                    type="range"
                    min="22"
                    max="44"
                    value={vouchInterFontSize}
                    onChange={(e) => setVouchInterFontSize(Number(e.target.value))}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                {/* Marca no Rodapé */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Marca / Texto no Rodapé
                  </label>
                  <input
                    type="text"
                    value={vouchBrandFooter}
                    onChange={(e) => setVouchBrandFooter(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </>
            )}

            {activeTab === 'perfil' && (
              <>
                <h3 className="text-sm font-bold text-amber-400 flex items-center space-x-2 pb-2 border-b border-slate-800">
                  <Sliders className="w-4 h-4" />
                  <span>Opções do Perfilcard</span>
                </h3>

                {/* Título do Perfil */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Título do Perfil
                  </label>
                  <input
                    type="text"
                    value={perfilTitle}
                    onChange={(e) => setPerfilTitle(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-500 focus:outline-none font-bold"
                  />
                </div>

                {/* Tema Metálico */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Tema Metálico Bicolor
                  </label>
                  <select
                    value={perfilTheme}
                    onChange={(e) => setPerfilTheme(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-500 focus:outline-none font-bold"
                  >
                    <option value="bicolor_gold">✨ Ouro Metálico Bicolor Luxo (#E8B923)</option>
                    <option value="platinum_silver">🥈 Platina & Prata Premium (#E5E4E2)</option>
                    <option value="emerald_gold">🟢 Esmeralda & Ouro (#10B981)</option>
                    <option value="ruby_gold">🔴 Rubi Imaterial (#F43F5E)</option>
                    <option value="diamond_blue">💎 Diamante Azul (#0EA5E9)</option>
                  </select>
                </div>

                {/* Badge de Rank */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Badge de Rank / Titulação
                  </label>
                  <input
                    type="text"
                    value={perfilRankBadge}
                    onChange={(e) => setPerfilRankBadge(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-500 focus:outline-none"
                  />
                </div>

                {/* Zoom Avatar Perfil */}
                <div>
                  <div className="flex justify-between items-center text-xs mb-1">
                    <span className="font-semibold text-slate-300">Zoom do Avatar</span>
                    <span className="font-mono text-amber-400 font-bold">{perfilAvatarZoom}px</span>
                  </div>
                  <input
                    type="range"
                    min="120"
                    max="190"
                    value={perfilAvatarZoom}
                    onChange={(e) => setPerfilAvatarZoom(Number(e.target.value))}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                {/* Tamanho dos Números das Métricas */}
                <div>
                  <div className="flex justify-between items-center text-xs mb-1">
                    <span className="font-semibold text-slate-300">Tamanho das Métricas Financeiras</span>
                    <span className="font-mono text-amber-400 font-bold">{perfilStatsSize}px</span>
                  </div>
                  <input
                    type="range"
                    min="24"
                    max="48"
                    value={perfilStatsSize}
                    onChange={(e) => setPerfilStatsSize(Number(e.target.value))}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                {/* Marca no Rodapé */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Marca do Rodapé
                  </label>
                  <input
                    type="text"
                    value={perfilBrandFooter}
                    onChange={(e) => setPerfilBrandFooter(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </>
            )}

            {activeTab === 'code' && (
              <div className="space-y-3 text-xs text-slate-300">
                <h3 className="text-sm font-bold text-indigo-400 flex items-center space-x-2 pb-2 border-b border-slate-800">
                  <FileCode className="w-4 h-4" />
                  <span>Sincronização nos Comandos</span>
                </h3>

                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-2">
                  <p className="font-semibold text-amber-400">⚡ Sincronização Automática com:</p>
                  <ul className="list-disc list-inside space-y-1 text-slate-400 font-mono text-[11px]">
                    <li>/aprovar_pagamento (Gera Vouchcard)</li>
                    <li>/vouch (Gera Vouchcard)</li>
                    <li>/perfil (Gera Perfilcard)</li>
                  </ul>
                </div>

                <p className="text-slate-400 text-[11px] leading-relaxed">
                  Ao clicar em <strong>"Salvar e Aplicar"</strong>, as variáveis visualmente configuradas acima são compiladas e injetadas diretamente nos arquivos <code className="text-amber-300">vouchCard.js</code> e <code className="text-amber-300">perfilCard.js</code> do seu Bot do Discord.
                </p>
              </div>
            )}

          </div>

          {/* Preview Column (7 cols) */}
          <div className="lg:col-span-7 flex flex-col justify-between space-y-4 bg-slate-950/80 p-4 rounded-2xl border border-slate-800/80">
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <h4 className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
                    <Eye className="w-4 h-4 text-amber-400" />
                    <span>Pré-visualização em Tempo Real ({activeTab === 'vouch' ? 'Vouchcard Animado' : 'Perfilcard'})</span>
                  </h4>
                  {activeTab === 'vouch' && (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                      GIF Animado (Shimmer + Partículas)
                    </span>
                  )}
                </div>

                <div className="flex items-center space-x-2">
                  {activeTab === 'vouch' && (
                    <div className="flex rounded-lg bg-slate-900 p-0.5 border border-slate-800 text-[10px]">
                      <button
                        type="button"
                        onClick={() => setVouchPreviewMode('canvas')}
                        className={`px-2 py-1 rounded-md font-bold transition-all ${
                          vouchPreviewMode === 'canvas'
                            ? 'bg-amber-500 text-slate-950 shadow'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        ⚡ Canvas 60 FPS
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setVouchPreviewMode('gif');
                          setGifTimestamp(Date.now());
                        }}
                        className={`px-2 py-1 rounded-md font-bold transition-all ${
                          vouchPreviewMode === 'gif'
                            ? 'bg-amber-500 text-slate-950 shadow'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        🎞️ Arquivo GIF
                      </button>
                    </div>
                  )}

                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
                    1740 x 920 Canvas
                  </span>
                </div>
              </div>

              <div className="bg-slate-950 p-2 rounded-xl border border-slate-800/80 shadow-inner flex items-center justify-center overflow-hidden min-h-[320px] relative">
                {activeTab === 'vouch' ? (
                  vouchPreviewMode === 'canvas' ? (
                    <canvas ref={vouchCanvasRef} className="w-full h-auto rounded-lg shadow-2xl" />
                  ) : (
                    <div className="w-full flex flex-col items-center justify-center space-y-2">
                      <img
                        key={gifTimestamp}
                        src={`/api/cards/vouch-preview.gif?theme=${vouchTheme}&title=${encodeURIComponent(vouchTitle)}&seloTexto=${encodeURIComponent(vouchSeloTexto)}&valorFontSize=${vouchValorFontSize}&avatarZoom=${vouchAvatarZoom}&nameFontSize=${vouchNameFontSize}&interFontSize=${vouchInterFontSize}&showStars=${vouchShowStars}&showCodeBox=${vouchShowCodeBox}&codeLabel=${encodeURIComponent(vouchCodeLabel)}&codeType=${vouchCodeType}&codePrefix=${encodeURIComponent(vouchCodePrefix)}&codeCustomValue=${encodeURIComponent(vouchCodeCustomValue)}&codeFontSize=${vouchCodeFontSize}&t=${gifTimestamp}`}
                        alt="Preview GIF Vouch"
                        className="w-full h-auto rounded-lg shadow-2xl border border-amber-500/20"
                      />
                      <div className="flex items-center space-x-3 text-[11px] text-slate-400 pt-1">
                        <span>Arquivo GIF real renderizado pelo backend do Bot.</span>
                        <button
                          type="button"
                          onClick={() => setGifTimestamp(Date.now())}
                          className="text-amber-400 hover:underline font-bold"
                        >
                          🔄 Recarregar GIF
                        </button>
                        <a
                          href={`/api/cards/vouch-preview.gif?t=${gifTimestamp}`}
                          target="_blank"
                          rel="noreferrer"
                          className="text-indigo-400 hover:underline font-bold"
                        >
                          ↗️ Abrir GIF direto
                        </a>
                      </div>
                    </div>
                  )
                ) : activeTab === 'perfil' ? (
                  <canvas ref={perfilCanvasRef} className="w-full h-auto rounded-lg shadow-2xl" />
                ) : (
                  <div className="p-8 text-center text-slate-400 space-y-2">
                    <FileCode className="w-12 h-12 text-indigo-400 mx-auto opacity-80" />
                    <p className="font-bold text-white text-sm">Código Pronto para Sincronização</p>
                    <p className="text-xs text-slate-400">
                      Ao clicar em Salvar abaixo, o bot irá recompilar e reiniciar instantaneamente com as novas personalizações!
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Save & Apply Action Button */}
            <div className="pt-4 border-t border-slate-800/80 flex items-center justify-end space-x-3">
              <button
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              >
                Cancelar
              </button>

              <button
                onClick={handleSaveAndApply}
                disabled={isSaving}
                className="flex items-center space-x-2 bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 px-6 py-2.5 rounded-xl text-xs font-extrabold transition-all shadow-lg shadow-amber-500/25 active:scale-95 border border-amber-300/40"
              >
                {isSaving ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                    <span>Injetando no Código & Reiniciando...</span>
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 fill-current" />
                    <span>Salvar e Aplicar Automaticamente no Código & Comandos</span>
                  </>
                )}
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
