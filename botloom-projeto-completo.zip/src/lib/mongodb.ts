import { MongoClient, Db, ObjectId } from 'mongodb';

let client: MongoClient | null = null;
let db: Db | null = null;
let isConnecting = false;
let connectionError: string | null = null;
let configuredUri: string | null = process.env.MONGODB_URI || process.env.MONGO_URI || null;

export interface MongoAutoBackupConfig {
  enabled: boolean;
  frequency: 'daily' | 'weekly' | 'every_6h' | 'every_12h';
  executionTime: string; // HH:MM, e.g. "03:00"
  dayOfWeek: number; // 0 (Domingo) a 6 (Sábado)
  selectedBotIds: string[]; // vazio = todos os bots
  includeDatabaseFiles: boolean;
  retentionCopies: number;
  lastRun?: {
    timestamp: string;
    status: 'success' | 'error';
    backupId?: string;
    message?: string;
    totalBots?: number;
    totalFiles?: number;
    sizeKb?: number;
  };
}

export const DEFAULT_BACKUP_CONFIG: MongoAutoBackupConfig = {
  enabled: true,
  frequency: 'daily',
  executionTime: '03:00',
  dayOfWeek: 1, // Segunda-feira
  selectedBotIds: [], // Todos
  includeDatabaseFiles: true,
  retentionCopies: 15
};

export const ATLAS_URI = "mongodb+srv://wellsalmeida5_db_user:<db_password>@neuxmm.6fkdrgx.mongodb.net/";

export { client };

export async function connectToMongoDB() {
  try {
    const database = await getMongoDb();
    if (database && client) {
      console.log("You successfully connected to MongoDB!");
      return client;
    }
    const targetUri = configuredUri || process.env.MONGODB_URI || ATLAS_URI;
    if (!client) {
      client = new MongoClient(targetUri);
    }
    await client.connect();
    console.log("You successfully connected to MongoDB!");
    return client;
  } catch (err) {
    console.dir(err);
    return null;
  }
}

// Call this only when your application terminates
export async function disconnectFromMongoDB() {
  if (client) {
    try {
      await client.close();
    } catch (e) {}
    client = null;
    db = null;
  }
}

export function setMongoUri(uri: string) {
  configuredUri = uri;
  if (client) {
    try {
      client.close().catch(() => {});
    } catch (e) {}
    client = null;
    db = null;
  }
}

export async function getMongoDb(customUri?: string): Promise<Db | null> {
  const uri = customUri || configuredUri || process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!uri) return null;

  if (db && client) return db;

  if (isConnecting) {
    await new Promise(res => setTimeout(res, 500));
    if (db) return db;
  }

  isConnecting = true;
  connectionError = null;

  try {
    const cleanUri = uri.trim();
    let targetDbName = 'neuxmm';
    try {
      const matchDb = cleanUri.match(/mongodb(?:\+srv)?:\/\/[^\/]+\/([^?]+)/i);
      if (matchDb && matchDb[1] && matchDb[1].trim()) {
        targetDbName = matchDb[1].trim();
      }
    } catch (e) {}

    client = new MongoClient(cleanUri, {
      connectTimeoutMS: 10000,
      serverSelectionTimeoutMS: 10000,
    });
    await client.connect();
    db = client.db(targetDbName);
    console.log(`🍃 [MONGODB] Conectado com sucesso ao MongoDB Atlas (Banco: ${targetDbName})!`);
    return db;
  } catch (err: any) {
    const rawMsg = err?.message || String(err);
    if (rawMsg.includes('alert number 80') || rawMsg.includes('tlsv1 alert internal error')) {
      connectionError = 'Erro SSL (Alert 80): Verifique no painel do MongoDB Atlas em "Network Access" se o IP está liberado (adicione 0.0.0.0/0) e confira suas credenciais de usuário/senha.';
    } else if (rawMsg.includes('Authentication failed') || rawMsg.includes('auth failed')) {
      connectionError = 'Falha de Autenticação: Usuário ou senha incorretos no MongoDB Atlas.';
    } else {
      connectionError = rawMsg;
    }
    console.error('❌ [MONGODB ERRO DE CONEXÃO]', connectionError);
    client = null;
    db = null;
    return null;
  } finally {
    isConnecting = false;
  }
}

export function getMongoStatus() {
  const uri = configuredUri || process.env.MONGODB_URI || process.env.MONGO_URI;
  return {
    configured: Boolean(uri),
    connected: Boolean(db && client),
    error: connectionError,
    database: db ? db.databaseName : null,
    maskedUri: uri ? uri.replace(/\/\/([^:]+):([^@]+)@/, '//***:***@') : null
  };
}

export async function syncDatabaseToMongo(appDatabase: any): Promise<boolean> {
  try {
    const database = await getMongoDb();
    if (!database) return false;

    const collectionsToSync = [
      'users_mm',
      'pix_database',
      'taxas_diarias',
      'lastMonthlyRun',
      'movements',
      'major_trade',
      'trade_data',
      'avaliacoes_pendentes'
    ];

    for (const key of collectionsToSync) {
      if (appDatabase[key] !== undefined) {
        const col = database.collection(key);
        await col.replaceOne(
          { _id: 'current_state' as any },
          { _id: 'current_state' as any, data: appDatabase[key], updatedAt: new Date() },
          { upsert: true }
        );
      }
    }

    console.log('🍃 [MONGODB] Sincronização de tabelas concluída com sucesso no MongoDB!');
    return true;
  } catch (err) {
    console.error('❌ [MONGODB ERRO AO SINCRONIZAR]', err);
    return false;
  }
}

export async function loadDatabaseFromMongo(): Promise<any | null> {
  try {
    const database = await getMongoDb();
    if (!database) return null;

    const result: any = {};
    const collectionsToSync = [
      'users_mm',
      'pix_database',
      'taxas_diarias',
      'lastMonthlyRun',
      'movements',
      'major_trade',
      'trade_data',
      'avaliacoes_pendentes'
    ];

    for (const key of collectionsToSync) {
      const col = database.collection(key);
      const doc = await col.findOne({ _id: 'current_state' as any });
      if (doc && (doc as any).data !== undefined) {
        result[key] = (doc as any).data;
      }
    }

    if (Object.keys(result).length > 0) {
      console.log('🍃 [MONGODB] Dados carregados do MongoDB com sucesso!');
      return result;
    }
    return null;
  } catch (err) {
    console.error('❌ [MONGODB ERRO AO CARREGAR]', err);
    return null;
  }
}

/* ========================================================================= */
/*  BACKUP AUTOMÁTICO DE ARQUIVOS DOS BOTS PARA O MONGODB                   */
/* ========================================================================= */

export interface BotBackupDocument {
  _id?: any;
  id: string;
  createdAt: string;
  trigger: 'manual' | 'daily' | 'weekly' | 'hourly';
  label: string;
  totalBots: number;
  totalFiles: number;
  totalBytes: number;
  bots: Array<{
    id: string;
    name: string;
    status: string;
    files: Array<{ name: string; path?: string; size: number; content: string }>;
  }>;
  databases?: any;
}

/**
 * Salva um snapshot completo dos arquivos dos bots no MongoDB
 */
export async function backupBotFilesToMongo(
  bots: any[],
  trigger: 'manual' | 'daily' | 'weekly' | 'hourly' = 'manual',
  labelCustom?: string,
  selectedBotIds: string[] = [],
  includeDatabases: boolean = true,
  appDatabase?: any
): Promise<{ success: boolean; backupId?: string; error?: string; stats?: any }> {
  try {
    const database = await getMongoDb();
    if (!database) {
      return { success: false, error: connectionError || 'MongoDB não está conectado.' };
    }

    const col = database.collection('bot_files_backups');

    const targetBots = (selectedBotIds && selectedBotIds.length > 0)
      ? bots.filter(b => selectedBotIds.includes(b.id))
      : bots;

    let totalFiles = 0;
    let totalBytes = 0;

    const backupBotsData = targetBots.map(b => {
      const safeFiles = (b.files || []).map((f: any) => {
        const contentStr = typeof f.content === 'string' ? f.content : '';
        const size = Buffer.byteLength(contentStr, 'utf8');
        totalFiles++;
        totalBytes += size;
        return {
          name: f.name || f.path || 'unnamed',
          path: f.path || f.name || '',
          size,
          content: contentStr
        };
      });

      return {
        id: b.id,
        name: b.name || 'Bot Sem Nome',
        status: b.status || 'offline',
        files: safeFiles
      };
    });

    const nowIso = new Date().toISOString();
    const backupId = `bkp_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const triggerLabels: Record<string, string> = {
      manual: 'Backup Manual dos Arquivos',
      daily: 'Backup Automático Diário',
      weekly: 'Backup Automático Semanal',
      hourly: 'Backup Automático Periódico'
    };

    const doc: BotBackupDocument = {
      id: backupId,
      createdAt: nowIso,
      trigger,
      label: labelCustom || `${triggerLabels[trigger] || 'Backup'} (${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })})`,
      totalBots: targetBots.length,
      totalFiles,
      totalBytes,
      bots: backupBotsData,
      databases: includeDatabases && appDatabase ? {
        users_mm: appDatabase.users_mm,
        pix_database: appDatabase.pix_database,
        proofs_global: appDatabase.proofs_global,
        taxas_diarias: appDatabase.taxas_diarias
      } : undefined
    };

    await col.insertOne(doc as any);
    console.log(`💾 [BACKUP MONGODB] Salvo com sucesso! ID: ${backupId} (${totalFiles} arquivos, ${(totalBytes / 1024).toFixed(1)} KB)`);

    // Clean old backups according to retention
    try {
      const allBackups = await col.find({}, { projection: { id: 1, createdAt: 1 } }).sort({ createdAt: -1 }).toArray();
      const maxRetention = 20;
      if (allBackups.length > maxRetention) {
        const toDelete = allBackups.slice(maxRetention).map(b => b._id);
        await col.deleteMany({ _id: { $in: toDelete } });
      }
    } catch (e) {}

    return {
      success: true,
      backupId,
      stats: {
        totalBots: targetBots.length,
        totalFiles,
        totalBytes,
        sizeKb: Number((totalBytes / 1024).toFixed(1))
      }
    };
  } catch (err: any) {
    console.error('❌ [BACKUP MONGODB ERRO]', err);
    return { success: false, error: err?.message || 'Falha ao salvar backup no MongoDB' };
  }
}

/**
 * Lista os backups de arquivos armazenados no MongoDB
 */
export async function listMongoBotBackups(limit: number = 20): Promise<any[]> {
  try {
    const database = await getMongoDb();
    if (!database) return [];

    const col = database.collection('bot_files_backups');
    const items = await col
      .find({}, {
        projection: {
          id: 1,
          createdAt: 1,
          trigger: 1,
          label: 1,
          totalBots: 1,
          totalFiles: 1,
          totalBytes: 1,
          'bots.id': 1,
          'bots.name': 1
        }
      })
      .sort({ createdAt: -1 })
      .limit(limit)
      .toArray();

    return items.map(item => ({
      id: item.id || String(item._id),
      createdAt: item.createdAt,
      trigger: item.trigger || 'manual',
      label: item.label,
      totalBots: item.totalBots || (item.bots ? item.bots.length : 0),
      totalFiles: item.totalFiles || 0,
      totalBytes: item.totalBytes || 0,
      sizeKb: Number(((item.totalBytes || 0) / 1024).toFixed(1)),
      botNames: (item.bots || []).map((b: any) => b.name)
    }));
  } catch (err) {
    console.error('❌ [LISTAR BACKUPS MONGODB ERRO]', err);
    return [];
  }
}

/**
 * Recupera um backup completo para restauração
 */
export async function getMongoBotBackupById(backupId: string): Promise<BotBackupDocument | null> {
  try {
    const database = await getMongoDb();
    if (!database) return null;

    const col = database.collection('bot_files_backups');
    let doc = await col.findOne({ id: backupId });
    if (!doc && ObjectId.isValid(backupId)) {
      doc = await col.findOne({ _id: new ObjectId(backupId) });
    }
    return doc as any || null;
  } catch (err) {
    console.error('❌ [OBTER BACKUP MONGODB ERRO]', err);
    return null;
  }
}

/**
 * Exclui um backup específico no MongoDB
 */
export async function deleteMongoBotBackup(backupId: string): Promise<boolean> {
  try {
    const database = await getMongoDb();
    if (!database) return false;

    const col = database.collection('bot_files_backups');
    const res = await col.deleteOne({ id: backupId });
    if (res.deletedCount === 0 && ObjectId.isValid(backupId)) {
      await col.deleteOne({ _id: new ObjectId(backupId) });
    }
    return true;
  } catch (err) {
    console.error('❌ [EXCLUIR BACKUP MONGODB ERRO]', err);
    return false;
  }
}
