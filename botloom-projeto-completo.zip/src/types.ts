export type BotStatus = 'online' | 'offline' | 'starting' | 'error' | 'installing';

export interface BotFile {
  name: string;
  path: string;
  content: string;
  isFolder?: boolean;
}

export interface BotLog {
  id: string;
  timestamp: string;
  type: 'stdout' | 'stderr' | 'system' | 'discord' | 'error';
  message: string;
}

export interface BotStats {
  cpuUsage: number; // percentage, e.g., 2.4
  memoryUsage: number; // in MB, e.g., 48.5
  maxMemory: number; // in MB, e.g., 512
  uptimeSeconds: number;
}

export interface DiscordComponent {
  type: 'button' | 'select' | 'input';
  customId: string;
  label: string;
  style?: 'primary' | 'secondary' | 'success' | 'danger' | 'link';
  placeholder?: string;
  options?: { label: string; value: string; description?: string }[];
}

export interface DiscordEmbed {
  title?: string;
  description?: string;
  color?: string;
  author?: { name: string; iconUrl?: string };
  fields?: { name: string; value: string; inline?: boolean }[];
  footer?: { text: string; iconUrl?: string };
  imageUrl?: string;
  thumbnailUrl?: string;
  timestamp?: boolean;
}

export interface DiscordMessage {
  id: string;
  author: {
    username: string;
    bot: boolean;
    avatar: string;
  };
  content?: string;
  embeds?: DiscordEmbed[];
  components?: DiscordComponent[];
  attachments?: (string | { url: string; attachment?: string })[];
  canvasBannerUrl?: string;
  timestamp: string;
}

export interface Bot {
  id: string;
  botId: string; // Discord Client ID
  name: string;
  status: BotStatus;
  token?: string;
  prefix: string;
  description: string;
  icon: string; // Emoji or image URL
  createdAt: string;
  lastRunAt: string | null;
  files: BotFile[];
  dependencies: Record<string, string>;
  stats: BotStats;
  logs: BotLog[];
  autoRestart: boolean;
  version: string;
}

export interface BotTemplate {
  id: string;
  name: string;
  description: string;
  icon: string;
  files: BotFile[];
  dependencies: Record<string, string>;
}
