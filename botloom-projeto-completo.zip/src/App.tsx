import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Bot, BotFile } from './types';
import {
  fetchBots,
  createBot,
  updateBot,
  deleteBot,
  startBot,
  stopBot,
  restartBot,
  clearBotLogs,
  interactWithBot
} from './services/api';
import { useStorageSync } from './services/storageSync';
import { Header } from './components/Header';
import { BotCard } from './components/BotCard';
import { AddBotModal } from './components/AddBotModal';
import { CodeEditorModal } from './components/CodeEditorModal';
import { LogsConsoleModal } from './components/LogsConsoleModal';
import { DiscordSimulatorModal } from './components/DiscordSimulatorModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { DatabaseModal } from './components/DatabaseModal';
import { CardConfiguratorModal } from './components/CardConfiguratorModal';
import { UptimeRobotModal } from './components/UptimeRobotModal';
import { TokenConfigModal } from './components/TokenConfigModal';
import { MongoAutoBackupModal } from './components/MongoAutoBackupModal';
import { ExportNetlifyModal } from './components/ExportNetlifyModal';
import {
  ShieldCheck,
  HardDrive,
  Sparkles,
  Bot as BotIcon,
  Layers,
  Plus
} from 'lucide-react';

export default function App() {
  const {
    bots,
    setBots,
    isHydrated,
    syncNow,
    syncStats
  } = useStorageSync();
  const [loading, setLoading] = useState<boolean>(() => bots.length === 0);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [isDatabaseModalOpen, setIsDatabaseModalOpen] = useState<boolean>(false);
  const [isMongoBackupModalOpen, setIsMongoBackupModalOpen] = useState<boolean>(false);
  const [isCardConfiguratorOpen, setIsCardConfiguratorOpen] = useState<boolean>(false);
  const [isUptimeModalOpen, setIsUptimeModalOpen] = useState<boolean>(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [activeCodeBotId, setActiveCodeBotId] = useState<string | null>(null);
  const [activeTokenBotId, setActiveTokenBotId] = useState<string | null>(null);
  const [activeLogsBotId, setActiveLogsBotId] = useState<string | null>(null);
  const [activeSimulateBotId, setActiveSimulateBotId] = useState<string | null>(null);
  const [activeDeleteBotId, setActiveDeleteBotId] = useState<string | null>(null);

  const [actionLoadingMap, setActionLoadingMap] = useState<Record<string, boolean>>({});

  // Active bot references derived from state
  const activeCodeBot = useMemo(() => bots.find(b => b.id === activeCodeBotId) || null, [bots, activeCodeBotId]);
  const activeTokenBot = useMemo(() => bots.find(b => b.id === activeTokenBotId) || null, [bots, activeTokenBotId]);
  const activeLogsBot = useMemo(() => bots.find(b => b.id === activeLogsBotId) || null, [bots, activeLogsBotId]);
  const activeSimulateBot = useMemo(() => bots.find(b => b.id === activeSimulateBotId) || null, [bots, activeSimulateBotId]);
  const activeDeleteBot = useMemo(() => bots.find(b => b.id === activeDeleteBotId) || null, [bots, activeDeleteBotId]);

  // Fetch bots on mount and periodically with smart visibility check & localStorage sync
  const loadBotsData = useCallback(async (showLoading = false) => {
    try {
      if (showLoading) {
        setIsRefreshing(true);
        await syncNow();
      }
      const data = await fetchBots();
      if (Array.isArray(data) && data.length > 0) {
        setBots(data);
      }
    } catch (err) {
      // Ignora falhas temporárias na sondagem mantendo os dados do localStorage
    } finally {
      setLoading(false);
      setIsRefreshing(false);
    }
  }, [setBots, syncNow]);

  useEffect(() => {
    if (isHydrated || bots.length > 0) {
      setLoading(false);
    }
    const safetyTimer = setTimeout(() => {
      setLoading(false);
    }, 2000);
    return () => clearTimeout(safetyTimer);
  }, [isHydrated, bots.length]);

  // 📡 Conexão Streaming SSE Persistente 24/7 (Server-Sent Events)
  // Mantém uma conexão HTTP ativa e ininterrupta com o servidor para o Cloud Run nunca congelar a CPU nem derrubar a aplicação
  useEffect(() => {
    let eventSource: EventSource | null = null;
    let sseRetryTimer: NodeJS.Timeout | null = null;

    const connectSSE = () => {
      try {
        eventSource = new EventSource('/api/stream');
        eventSource.onerror = () => {
          if (eventSource) {
            eventSource.close();
            eventSource = null;
          }
          if (sseRetryTimer) clearTimeout(sseRetryTimer);
          sseRetryTimer = setTimeout(connectSSE, 5000);
        };
      } catch (e) {
        if (sseRetryTimer) clearTimeout(sseRetryTimer);
        sseRetryTimer = setTimeout(connectSSE, 5000);
      }
    };

    connectSSE();

    return () => {
      if (eventSource) eventSource.close();
      if (sseRetryTimer) clearTimeout(sseRetryTimer);
    };
  }, []);

  useEffect(() => {
    loadBotsData();

    // Polling regular quando o usuário está com o painel aberto
    const interval = setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      loadBotsData(false);
    }, 5000);

    // Heartbeat 24/7 incondicional: mantém a conexão ativa mesmo em abas de segundo plano
    const heartbeatInterval = setInterval(() => {
      fetch('/api/ping', { cache: 'no-store' }).catch(() => {});
    }, 15000);

    // Ao voltar para a aba, atualiza os dados instantaneamente
    const handleVisibility = () => {
      if (typeof document !== 'undefined' && !document.hidden) {
        loadBotsData(false);
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);

    return () => {
      clearInterval(interval);
      clearInterval(heartbeatInterval);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [loadBotsData]);

  // Filtered bots list
  const filteredBots = useMemo(() => {
    const term = searchTerm.toLowerCase();
    return bots.filter(bot =>
      bot.name.toLowerCase().includes(term) ||
      bot.botId.includes(term)
    );
  }, [bots, searchTerm]);

  const onlineBotsCount = useMemo(() => bots.filter(b => b.status === 'online').length, [bots]);
  const totalMemoryMB = useMemo(() => bots.reduce((sum, b) => sum + (b.status === 'online' ? b.stats.memoryUsage : 0), 0), [bots]);

  // Handlers with stable callbacks to prevent child re-renders
  const handleStartBot = useCallback(async (botId: string) => {
    try {
      setActionLoadingMap(prev => ({ ...prev, [botId]: true }));
      setBots(prev => prev.map(b => (b.id === botId ? { ...b, status: 'starting' } : b)));
      const updated = await startBot(botId);
      setBots(prev => prev.map(b => (b.id === botId ? updated : b)));
    } catch (err: any) {
      alert(err.message || 'Erro ao ligar o bot.');
      loadBotsData(false);
    } finally {
      setActionLoadingMap(prev => ({ ...prev, [botId]: false }));
    }
  }, [loadBotsData]);

  const handleStopBot = useCallback(async (botId: string) => {
    try {
      setActionLoadingMap(prev => ({ ...prev, [botId]: true }));
      setBots(prev => prev.map(b => (b.id === botId ? { ...b, status: 'offline' } : b)));
      const updated = await stopBot(botId);
      setBots(prev => prev.map(b => (b.id === botId ? updated : b)));
    } catch (err: any) {
      alert(err.message || 'Erro ao desligar o bot.');
      loadBotsData(false);
    } finally {
      setActionLoadingMap(prev => ({ ...prev, [botId]: false }));
    }
  }, [loadBotsData]);

  const handleRestartBot = useCallback(async (botId: string) => {
    try {
      setActionLoadingMap(prev => ({ ...prev, [botId]: true }));
      setBots(prev => prev.map(b => (b.id === botId ? { ...b, status: 'starting' } : b)));
      const updated = await restartBot(botId);
      setBots(prev => prev.map(b => (b.id === botId ? updated : b)));
    } catch (err: any) {
      alert(err.message || 'Erro ao reiniciar o bot.');
      loadBotsData(false);
    } finally {
      setActionLoadingMap(prev => ({ ...prev, [botId]: false }));
    }
  }, [loadBotsData]);

  const handleEditCode = useCallback((botToEdit: Bot) => {
    setActiveCodeBotId(botToEdit.id);
  }, []);

  const handleEditToken = useCallback((botToToken: Bot) => {
    setActiveTokenBotId(botToToken.id);
  }, []);

  const handleViewLogs = useCallback((botToLog: Bot) => {
    setActiveLogsBotId(botToLog.id);
  }, []);

  const handleSimulate = useCallback((botToSim: Bot) => {
    setActiveSimulateBotId(botToSim.id);
  }, []);

  const handleDelete = useCallback((botToDelete: Bot) => {
    setActiveDeleteBotId(botToDelete.id);
  }, []);

  const handleAddBot = useCallback(async (data: {
    name: string;
    botId: string;
    token?: string;
    prefix?: string;
    description?: string;
    files: BotFile[];
    codeOption: 'file' | 'code';
  }) => {
    const newBot = await createBot(data);
    setBots(prev => [newBot, ...prev]);
  }, []);

  const handleSaveFiles = useCallback(async (botId: string, files: BotFile[]) => {
    const updated = await updateBot(botId, { files });
    setBots(prev => prev.map(b => (b.id === botId ? updated : b)));
  }, []);

  const handleSaveToken = useCallback(async (botId: string, newToken: string) => {
    const updated = await updateBot(botId, { token: newToken });
    setBots(prev => prev.map(b => (b.id === botId ? updated : b)));
  }, []);

  const handleClearLogs = useCallback(async (botId: string) => {
    const updated = await clearBotLogs(botId);
    setBots(prev => prev.map(b => (b.id === botId ? updated : b)));
  }, []);

  const handleDeleteBotConfirm = useCallback(async (botId: string) => {
    try {
      await deleteBot(botId);
      setBots(prev => prev.filter(b => b.id !== botId));
      setActiveDeleteBotId(null);
    } catch (err: any) {
      alert(err.message || 'Erro ao excluir o bot.');
    }
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased selection:bg-indigo-500 selection:text-white pb-12">
      
      {/* Header Bar */}
      <Header
        totalBots={bots.length}
        onlineBots={onlineBotsCount}
        onAddBotClick={() => setIsAddModalOpen(true)}
        onOpenDatabaseClick={() => setIsDatabaseModalOpen(true)}
        onOpenAutoBackupClick={() => setIsMongoBackupModalOpen(true)}
        onOpenCardConfiguratorClick={() => setIsCardConfiguratorOpen(true)}
        onOpenUptimeRobotClick={() => setIsUptimeModalOpen(true)}
        onOpenExportClick={() => setIsExportModalOpen(true)}
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        onRefresh={() => loadBotsData(true)}
        isRefreshing={isRefreshing}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        
        {/* Banner Section / Dashboard Stats */}
        <div className="mb-8 grid grid-cols-1 md:grid-cols-4 gap-4">
          
          {/* Card 1: Status de Hospedagem 24/7 */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex items-center space-x-3.5 shadow-lg">
            <div className="w-11 h-11 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center flex-shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Status do Servidor</p>
              <h4 className="text-sm font-bold text-white flex items-center space-x-1.5 mt-0.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Hospedagem 24/7 Ativa</span>
              </h4>
            </div>
          </div>

          {/* Card 2: Total de Bots */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex items-center space-x-3.5 shadow-lg">
            <div className="w-11 h-11 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center flex-shrink-0">
              <BotIcon className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Instâncias Cadastradas</p>
              <h4 className="text-base font-black text-white mt-0.5 font-mono">
                {bots.length} <span className="text-xs font-normal text-slate-400">({onlineBotsCount} Online)</span>
              </h4>
            </div>
          </div>

          {/* Card 3: RAM Total Alocada */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex items-center space-x-3.5 shadow-lg">
            <div className="w-11 h-11 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center flex-shrink-0">
              <HardDrive className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Consumo de Memória</p>
              <h4 className="text-base font-black text-white mt-0.5 font-mono">
                {totalMemoryMB.toFixed(1)} MB <span className="text-xs font-normal text-slate-400">/ Node Pool</span>
              </h4>
            </div>
          </div>

          {/* Card 4: Suporte Completo Discord.js */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex items-center space-x-3.5 shadow-lg">
            <div className="w-11 h-11 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Ambiente Discord.js</p>
              <h4 className="text-xs font-bold text-slate-200 mt-0.5">
                v14 • Slash, Modals & Canvas
              </h4>
            </div>
          </div>

        </div>

        {/* Section Title */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2">
              <Layers className="w-5 h-5 text-indigo-400" />
              <span>Painel de Gerenciamento de Bots</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Controle o estado, edite o código e monitore os logs de todos os seus bots em um único lugar.
            </p>
          </div>

          <button
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2.5 rounded-xl text-xs font-bold transition-all shadow-lg shadow-indigo-600/30 active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Adicionar Bot</span>
          </button>
        </div>

        {/* Loading Spinner */}
        {loading && (
          <div className="py-20 text-center">
            <div className="w-10 h-10 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
            <p className="text-xs text-slate-400 font-mono">Carregando instâncias de bots...</p>
          </div>
        )}

        {/* Empty State */}
        {!loading && filteredBots.length === 0 && (
          <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-12 text-center max-w-lg mx-auto my-8">
            <div className="w-16 h-16 rounded-2xl bg-indigo-600/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center mx-auto mb-4">
              <BotIcon className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-white mb-2">Nenhum bot encontrado</h3>
            <p className="text-xs text-slate-400 leading-relaxed mb-6">
              {searchTerm
                ? 'Nenhum bot corresponde ao termo pesquisado. Tente buscar por outro nome ou ID.'
                : 'Você ainda não cadastrou nenhum bot do Discord. Clique no botão abaixo para adicionar seu primeiro bot.'}
            </p>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="inline-flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-2.5 rounded-xl text-xs font-bold transition-all shadow-lg shadow-indigo-600/30"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Primeiro Bot</span>
            </button>
          </div>
        )}

        {/* Bot Cards Grid */}
        {!loading && filteredBots.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredBots.map(bot => (
              <BotCard
                key={bot.id}
                bot={bot}
                onStart={handleStartBot}
                onStop={handleStopBot}
                onRestart={handleRestartBot}
                onEditCode={handleEditCode}
                onEditToken={handleEditToken}
                onViewLogs={handleViewLogs}
                onSimulate={handleSimulate}
                onDelete={handleDelete}
                isActionLoading={!!actionLoadingMap[bot.id]}
              />
            ))}
          </div>
        )}

      </main>

      {/* Modals */}
      <AddBotModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onSubmit={handleAddBot}
      />

      <CodeEditorModal
        bot={activeCodeBot}
        isOpen={!!activeCodeBot}
        onClose={() => setActiveCodeBotId(null)}
        onSaveFiles={handleSaveFiles}
      />

      <TokenConfigModal
        bot={activeTokenBot}
        isOpen={!!activeTokenBot}
        onClose={() => setActiveTokenBotId(null)}
        onSaveToken={handleSaveToken}
      />

      <LogsConsoleModal
        bot={activeLogsBot}
        isOpen={!!activeLogsBot}
        onClose={() => setActiveLogsBotId(null)}
        onClearLogs={handleClearLogs}
      />

      <DiscordSimulatorModal
        bot={activeSimulateBot}
        isOpen={!!activeSimulateBot}
        onClose={() => setActiveSimulateBotId(null)}
        onStartBot={handleStartBot}
        onInteract={(payload) => interactWithBot(activeSimulateBot!.id, payload)}
      />

      <DeleteConfirmModal
        bot={activeDeleteBot}
        isOpen={!!activeDeleteBot}
        onClose={() => setActiveDeleteBotId(null)}
        onConfirmDelete={handleDeleteBotConfirm}
        isDeleting={false}
      />

      <DatabaseModal
        isOpen={isDatabaseModalOpen}
        onClose={() => setIsDatabaseModalOpen(false)}
        onOpenAutoBackupModal={() => setIsMongoBackupModalOpen(true)}
      />

      <CardConfiguratorModal
        isOpen={isCardConfiguratorOpen}
        onClose={() => setIsCardConfiguratorOpen(false)}
        bots={bots}
        selectedBotId={activeCodeBotId}
        onBotsUpdated={() => loadBotsData(false)}
      />

      <UptimeRobotModal
        isOpen={isUptimeModalOpen}
        onClose={() => setIsUptimeModalOpen(false)}
      />

      <MongoAutoBackupModal
        isOpen={isMongoBackupModalOpen}
        onClose={() => setIsMongoBackupModalOpen(false)}
        bots={bots}
        onOpenDatabaseModal={() => setIsDatabaseModalOpen(true)}
      />

      <ExportNetlifyModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
      />

    </div>
  );
}
