import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { installStorageSyncMiddleware } from './services/storageSync';

installStorageSyncMiddleware();

createRoot(document.getElementById('root')!).render(
  <App />
);


