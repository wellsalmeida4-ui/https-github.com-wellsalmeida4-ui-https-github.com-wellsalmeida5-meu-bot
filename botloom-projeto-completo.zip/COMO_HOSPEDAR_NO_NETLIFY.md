# 🚀 Como Hospedar seu Site no Netlify

Existem duas formas simples e gratuitas de colocar este site no ar no Netlify:

---

### Opção 1: Método Ultra Rápido (Arrastar e Soltar - Netlify Drop)
1. Extraia o arquivo **botloom-netlify-dist.zip** (você terá a pasta `dist`).
2. Acesse sua conta no Netlify: https://app.netlify.com/drop
3. Arraste a pasta `dist` (ou o próprio arquivo zip se suportado) diretamente para o retângulo de upload.
4. Pronto! Em 5 segundos o Netlify vai gerar um link público grátis com certificado SSL HTTPS (ex: `https://meu-painel.netlify.app`).

> **Nota Técnica**: O arquivo `_redirects` já está incluso dentro da pasta `dist` com a regra (`/* /index.html 200`), evitando erros 404 ao atualizar a página no navegador.

---

### Opção 2: Conectar com seu GitHub (Deploy Automático Contínuo)
1. Descompacte o arquivo completo do projeto.
2. Crie um repositório no seu GitHub e suba os arquivos:
   ```bash
   git init
   git add .
   git commit -m "Meu painel BotLoom"
   git branch -M main
   git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
   git push -u origin main
   ```
3. No painel do Netlify, clique em **"Add new site" > "Import an existing project"** e escolha o repositório do GitHub.
4. O Netlify lerá automaticamente o arquivo `netlify.toml` já configurado:
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
5. Clique em **Deploy site**.

---

### ⚠️ Como Funcionam os Bots do Discord vs Netlify:
- O **Netlify** é uma infraestrutura feita exclusivamente para hospedar **sites estáticos e frontends (React, HTML, CSS, JavaScript)**.
- Os **Bots do Discord** precisam de uma conexão aberta 24/7 (via WebSocket/Node.js). O Netlify não mantém servidores Node.js ligados continuamente.
- Por isso, seus bots podem continuar rodando 24 horas por dia aqui na nuvem do **BotLoom Cloud** (com UptimeRobot ativo), ou em uma VPS (Oracle, DigitalOcean, Hetzner), no Railway ou no Render, enquanto o painel do site fica hospedado no Netlify!
