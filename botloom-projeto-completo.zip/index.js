const fs = require("fs");
const { SlashCommandBuilder, ApplicationCommandOptionType,
    Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder,
    ModalBuilder, TextInputBuilder, TextInputStyle, ChannelType, PermissionsBitField,
    PermissionFlagsBits, ButtonBuilder, ButtonStyle, MessageFlags,
    ContainerBuilder, TextDisplayBuilder, MediaGalleryBuilder, MediaGalleryItemBuilder
} = require("discord.js");

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.DirectMessages
    ]
});

let pixConfig = {};
try {
    pixConfig = JSON.parse(fs.readFileSync("config.json", "utf8"));
} catch (e) {
    console.log("config.json não encontrado ou inválido, usando configurações padrão.");
}

const STAFF_ROLE_ID = "1434006673055289486";
const CATEGORY_ID = "1556024912404152453"; // Categoria dos Tickets
const AUCTION_CATEGORY_ID = "1507168410373718017"; // ID da Categoria onde os leilões serão criados
const MM_CHANNEL_URL = "https://discord.com/channels/1417672403382960130/1508936157596090459";
const MM_CANAL_ID_TEXTO = "1539463840318624024";
const SERVIDOR_ID_TEXTO = "1393608809246756914";
const COR_PADRAO = "#FF0000";

const dadosCriacao = new Map();
const dadosLeilao = new Map();
const lancesAtuais = new Map();

// Tabela de MM reduzido: aplica a maior faixa atingida pelo valor da transação.
function calcularTaxaMM(valor) {
    const total = Number(valor) || 0;
    if (total > 700) return total * 0.01;
    if (total > 400) return 6.50;
    if (total > 200) return 4.00;
    if (total > 100) return 2.00;
    if (total > 8) return 0.25;
    return 0;
}

function formatarBRL(valor) {
    return Number(valor).toFixed(2).replace('.', ',');
}

client.once('ready', async (c) => {
    console.log(`Bot online: ${c.user.tag}`);

    const pixLeilaoCommand = new SlashCommandBuilder()
        .setName('pixleilao')
        .setDescription('Configura a chave Pix para leilões.')
        .addStringOption(option =>
            option.setName('chave')
                .setDescription('A chave Pix (ex: email, telefone, CPF, CNPJ)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('nome')
                .setDescription('O nome do recebedor Pix')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('id_atendente')
                .setDescription('O ID do atendente responsável (opcional)')
                .setRequired(false));

    await client.application.commands.create(pixLeilaoCommand);
    console.log('Comando /pixleilao registrado globalmente.');
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (message.channel.parentId === CATEGORY_ID) {
        await processarAnexosTicket(message);
    }

    if (message.channel.isThread()) {
        const leilao = lancesAtuais.get(message.channel.id);
        if (leilao && leilao.permitirLancesTexto) {
            await processarLanceViaTexto(message, leilao, message.channel.id);
        }
    }

    if (message.content === '!setup' && message.member.roles.cache.has(STAFF_ROLE_ID)) {
        await enviarPainelInicial(message);
    }
});

client.on('interactionCreate', async (interaction) => {
    await gerenciarInteracoes(interaction);
});

async function gerenciarInteracoes(interaction) {
    try {
        const customId = interaction.customId;
        const userId = interaction.user.id;

        if (customId === 'confirmar_fluxo') return await iniciarFluxoCriacao(interaction);
        if (customId === 'escolher_tipo') return await exibirTiposLeilao(interaction);
        if (customId === 'modal_unitario') return await abrirModalDados(interaction);
        if (customId === 'modal_base') return await abrirModalDados(interaction);

        if (interaction.isModalSubmit() && customId === 'modal_leilao') {
            await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
            const dados = {
                user: interaction.user,
                desc: interaction.fields.getTextInputValue('desc'),
                valor: interaction.fields.getTextInputValue('valor'),
                min: interaction.fields.getTextInputValue('min'),
                max: interaction.fields.getTextInputValue('max') || "150.00",
                imagens: [],
                discussaoAtiva: false,
                permitirLancesTexto: false
            };
            dadosCriacao.set(userId, dados);
            return await exibirEtapa1(interaction, dados);
        }

        if (customId === 'ativar_disc' || customId === 'pular_disc') {
            const dados = dadosCriacao.get(userId);
            if (!dados) return interaction.reply({ content: "Sessão expirada.", flags: [MessageFlags.Ephemeral] });
            dados.discussaoAtiva = (customId === 'ativar_disc');
            return await exibirEtapa2(interaction, dados);
        }

        if (customId === 'permitir_lances_txt' || customId === 'apenas_botoes') {
            const dados = dadosCriacao.get(userId);
            if (!dados) return interaction.reply({ content: "Sessão expirada.", flags: [MessageFlags.Ephemeral] });
            dados.permitirLancesTexto = (customId === 'permitir_lances_txt');
            return await criarTicketFinal(interaction, dados);
        }
if (customId === 'select_cat' || (interaction.isStringSelectMenu() && customId === 'select_cat')) return await processarSelecaoCategoria(interaction);
        if (customId === 'copy_pix') return await copiarCodigoPix(interaction);
        if (customId === 'aprovar_final') return await publicarLeilaoOficial(interaction);
        if (interaction.isCommand() && interaction.commandName === 'pixleilao') return await handlePixLeilaoCommand(interaction);
        if (customId === 'fechar_ticket') return await interaction.channel.delete().catch(() => { });
        if (customId === 'reivindicar_pagamento') return await reivindicarPagamento(interaction);

        const leilao = lancesAtuais.get(interaction.channel.id);
        if (leilao) {
            const isOwner = userId === leilao.leiloeiroId;
            const isStaff = interaction.member.roles.cache.has(STAFF_ROLE_ID);

            if (customId === 'btn_configuracoes' && !isOwner && !isStaff) {
                return interaction.reply({ content: "❌ Só o leiloeiro ou a staff autorizada pode abrir as configurações.", flags: [MessageFlags.Ephemeral] });
            }
            if (customId === 'btn_editar_lances' && !isOwner && !isStaff) {
                return interaction.reply({ content: "❌ Só o leiloeiro pode editar lances.", flags: [MessageFlags.Ephemeral] });
            }
            if (customId === 'btn_dar_dole' && !isOwner && !isStaff) {
                return interaction.reply({ content: "❌ Só o leiloeiro ou a staff autorizada pode encerrar o leilão.", flags: [MessageFlags.Ephemeral] });
            }
        }

        if (customId === 'btn_dar_lance') return await abrirModalLance(interaction);
        if (customId === 'btn_historico') return await exibirHistoricoLances(interaction);
        if (customId === 'btn_editar_lances') return await abrirModalEditarLances(interaction);
        if (customId === 'btn_configuracoes') return await abrirConfiguracoesAdmin(interaction);
        if (customId === 'btn_dar_dole') return await finalizarLeilaoAdmin(interaction);
        if (customId === 'confirmar_encerramento_final') return await finalizarLeilaoAdmin(interaction);
        if (customId === 'cancelar_encerramento') return await interaction.update({ content: "Encerramento cancelado.", components: [], embeds: [] });
        if (interaction.isModalSubmit() && customId === 'modal_efetuar_lance') return await registrarLanceModal(interaction);

        if (interaction.isStringSelectMenu() && customId === 'remover_lance_select') return await executarRemocaoLance(interaction);
        if (interaction.isStringSelectMenu() && customId === 'admin_select_tudo') return await processarSelecaoAdminTudo(interaction);

    } catch (e) {
        console.error("Erro na interação:", e);
    }
}

async function enviarPainelInicial(message) {
    const embed = new EmbedBuilder()
        .setColor("#FF0000")
        .setAuthor({ name: '| Sistema de Leilão', iconURL: client.user.displayAvatarURL() })
        .setDescription('# | Sistema de Leilão\n\nCrie e gerencie seus leilões de forma rápida e segura com o nosso sistema de leilão automatizado.\n\nTaxa de publicação\n' +
            '\n- Abaixo de 500M -> R$ 1,00\n- Acima de 500M -> R$ 1,00\n- Acima de 800M -> R$ 1,00\n- Acima de 1B -> R$ 1,00\n- Acima de 2B -> R$ 1,00 + excedente\n\n' +
            'Pets raros / OG -> valor a combinar');
    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('confirmar_fluxo').setLabel('Criar Leilão').setEmoji('💰').setStyle(ButtonStyle.Danger)
    );
    await message.channel.send({ embeds: [embed], components: [row] });
}

async function iniciarFluxoCriacao(interaction) {
    const embed = new EmbedBuilder()
        .setColor("#FF0000")
        .setDescription('# <:emoji_168:1499988099696951326> Confirmar criação\n\nVocê está prestes a iniciar o fluxo de criação de um novo leilão.\n\n> Um ticket privado será aberto para coletar as informações do seu leilão.\n> Você pode cancelar a qualquer momento.');
    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('escolher_tipo').setLabel('Confirmar').setStyle(ButtonStyle.Secondary).setEmoji('✅'),
        new ButtonBuilder().setCustomId('cancelar').setLabel('Cancelar').setStyle(ButtonStyle.Secondary).setEmoji('❌')
    );
    await interaction.reply({ embeds: [embed], components: [row], flags: [MessageFlags.Ephemeral] });
}

async function exibirTiposLeilao(interaction) {
    const embed = new EmbedBuilder()
        .setColor("#FF0000")
        .setDescription('# <:emoji_168:1499988099696951326> Tipo do Leilão\n\nEscolha o formato que melhor representa seu anúncio.\n\nUnitário — um item ou lote único.\nBase (Múltiplos) — vários itens em um mesmo leilão.');
    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('modal_unitario').setLabel('Unitário').setStyle(ButtonStyle.Secondary).setEmoji('🎁'),
        new ButtonBuilder().setCustomId('modal_base').setLabel('Base (Múltiplos)').setStyle(ButtonStyle.Secondary).setEmoji('🏠')
    );
    await interaction.update({ embeds: [embed], components: [row] });
}

async function abrirModalDados(interaction) {
    const modal = new ModalBuilder().setCustomId('modal_leilao').setTitle('Dados do Leilão');
    modal.addComponents(
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('desc').setLabel("Descrição dos itens").setStyle(TextInputStyle.Paragraph).setRequired(true)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('valor').setLabel("Valor total do pet (ex: 100M)").setStyle(TextInputStyle.Short).setRequired(true)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('min').setLabel("Lance mínimo inicial (R$)").setStyle(TextInputStyle.Short).setRequired(true)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('max').setLabel("Lance máximo (opcional)").setStyle(TextInputStyle.Short).setRequired(false))
    );
    await interaction.showModal(modal);
}

async function exibirEtapa1(interaction, dados) {
    const embed = new EmbedBuilder()
        .setColor("#FF0000")
        .setDescription(`# Etapa 1 — Discussão\n\nLeilão \`${Math.random().toString(16).slice(2)}\`\nUnitário · Aguardando taxa\n\n**Item:** ${dados.desc}\n💎 **Valor in-game:** ${dados.valor}\n💸 **Lance inicial:** R$ ${dados.min}\n\n**Ação necessária:** defina se o anúncio terá discussão pública.\n\n-# Esta escolha organiza comentários e dúvidas antes dos lances.`);
    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('ativar_disc').setLabel('Ativar discussão').setEmoji('💬').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('pular_disc').setLabel('Não ativar discussão').setEmoji('🔔').setStyle(ButtonStyle.Secondary)
    );
    if (interaction.deferred || interaction.replied) {
        await interaction.editReply({ embeds: [embed], components: [row] });
    } else {
        await interaction.update({ embeds: [embed], components: [row] });
    }
}

async function exibirEtapa2(interaction, dados) {
    const embed = new EmbedBuilder()
        .setColor("#FF0000")
        .setDescription(`# Etapa 2 — Lances na discussão\n\nLeilão \`${Math.random().toString(16).slice(2)}\`\nUnitário · Aguardando taxa\n\n**Item:** ${dados.desc}\n\n**Ação necessária:** escolha se números enviados na discussão podem virar lance.\n\nDesative se preferir aceitar lances apenas pelos botões.\n\n-# ${dados.discussaoAtiva ? 'Discussão: Ativada' : 'Discussão: Desativada'}`);
    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('permitir_lances_txt').setLabel('Permitir lances na discussão').setEmoji('💰').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('apenas_botoes').setLabel('Só conversa na discussão').setEmoji('💬').setStyle(ButtonStyle.Primary)
    );
    await interaction.update({ embeds: [embed], components: [row] });
}

async function criarTicketFinal(interaction, dados) {
    await interaction.update({ content: '⌛ Criando seu ticket privado...', embeds: [], components: [] });
    const canal = await interaction.guild.channels.create({
        name: `ticket-${interaction.user.username}`,
        type: ChannelType.GuildText,
        parent: CATEGORY_ID,
        permissionOverwrites: [
            { id: interaction.guild.id, deny: [PermissionsBitField.Flags.ViewChannel] },
            { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] },
            { id: STAFF_ROLE_ID, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] }
        ],
    });
    dadosLeilao.set(canal.id, dados);
    dadosCriacao.delete(interaction.user.id);
    const embedWelcome = new EmbedBuilder()
        .setColor("#FF0000")
        .setDescription(`# 👋 @${interaction.user.username} seu ticket foi aberto com sucesso!\n\n**Usuário:** ${dados.user.tag}\n**Opção:** Leilão\n\n# 📸 ATENÇÃO\nEnvie agora todas as imagens do seu pet aqui no chat antes de prosseguir!`)
        .setThumbnail(dados.user.displayAvatarURL());
    const menu = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId('select_cat').setPlaceholder('Selecione a categoria').addOptions([
            { label: '-500M', value: '1.00_-500M' },
            { label: '+500M', value: '1.00_+500M' },
            { label: '+1B', value: '1.00_+1B' },
            { label: '+2B', value: '1.00_+2B' },
            { label: 'OG', value: '1.00_OG' }
        ])
    );
    await canal.send({ content: `<@${dados.user.id}>`, embeds: [embedWelcome], components: [menu] });
    await interaction.editReply({ content: `✅ Ticket criado: ${canal}` });
}

async function processarSelecaoCategoria(interaction) {
    try {
        // Responder imediatamente para evitar o erro de timeout (3s)
        await interaction.deferUpdate();

        const [preco, cat] = interaction.values[0].split('_');
        const info = dadosLeilao.get(interaction.channel.id);
        if (!info) return;

        info.catNome = cat;
        const pix = getPixQR();
        info.pixCode = pix.code;

        const embedPix = new EmbedBuilder()
            .setColor(0xFF0000)
            .setDescription(`# Pagamento da Taxa\n\nValor: R$ 1,00\nCopie o código pix abaixo.\n\nTotal de fotos enviadas: ${info.imagens.length}`);

        if (pix.link) {
            embedPix.setImage(pix.link);
        } else {
            embedPix.addFields({ name: '⚠️ Atenção', value: 'Chave Pix não configurada. Use `/pixleilao` para configurar.' });
        }

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('copy_pix').setLabel('Copiar Pix').setStyle(ButtonStyle.Secondary).setEmoji('📋'),
            new ButtonBuilder().setCustomId('aprovar_final').setLabel('Postar Leilão').setStyle(ButtonStyle.Success).setEmoji('✅'),
            new ButtonBuilder().setCustomId('reivindicar_pagamento').setLabel('Reivindicar Pagamento').setStyle(ButtonStyle.Primary).setEmoji('🙋'),
            new ButtonBuilder().setCustomId('fechar_ticket').setLabel('Fechar Ticket').setStyle(ButtonStyle.Danger)
        );

        await interaction.editReply({ embeds: [embedPix], components: [row] });
    } catch (error) {
        console.error("Erro na seleção de categoria:", error);
    }
}
async function publicarLeilaoOficial(interaction) {
    if (!interaction.member.roles.cache.has(STAFF_ROLE_ID)) return interaction.reply({ content: "❌ Staff apenas.", flags: [MessageFlags.Ephemeral] });
    const dados = dadosLeilao.get(interaction.channel.id);
    if (!dados) return;
    await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

    const canalPost = await interaction.guild.channels.create({
        name: `💰・${formatarNomeCanal(dados.desc)}`,
        type: ChannelType.GuildText,
        parent: AUCTION_CATEGORY_ID,
        permissionOverwrites: [
            { id: interaction.guild.roles.everyone.id, allow: [PermissionsBitField.Flags.ViewChannel], deny: [PermissionsBitField.Flags.SendMessages] },
            { id: dados.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.AttachFiles] },
            { id: STAFF_ROLE_ID, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] }
        ],
    });

    const minVal = parseFloat(dados.min.replace(/[R$\s]/g, '').replace(',', '.')) || 50.00;
    const maxVal = parseFloat(dados.max.replace(/[R$\s]/g, '').replace(',', '.')) || 150.00;
    const leilaoId = Math.random().toString(16).slice(2, 12);

    const infoLeilao = {
        id: leilaoId,
        leiloeiroId: dados.user.id,
        titulo: dados.desc,
        valorPet: dados.valor,
        lanceMinimo: minVal,
        lanceMaximo: maxVal,
        imagens: dados.imagens,
        discussaoAtiva: dados.discussaoAtiva,
        permitirLancesTexto: dados.permitirLancesTexto,
        historico: [],
        doles: [],
        painelMsgId: null,
        threadId: null
    };

    lancesAtuais.set(canalPost.id, infoLeilao);
    const msgPainel = await atualizarPainelLeilao(canalPost, infoLeilao);

    if (msgPainel && dados.discussaoAtiva) {
        const thread = await msgPainel.startThread({
            name: `Discussão`,
            autoArchiveDuration: 1440
        }).catch(console.error);

        if (thread) {
            infoLeilao.threadId = thread.id;
            lancesAtuais.set(thread.id, infoLeilao);
            await thread.send(`🚀 **O leilão começou!**\n\n- O preço inicial é **R$ ${minVal.toFixed(2)}**.\n- O incremento mínimo é **R$ 1.00**.\n\nFaça seus lances usando o botão na mensagem principal ou enviando o valor aqui no chat!`);
        }
    }

    await interaction.editReply({ content: `✅ Leilão postado no canal: ${canalPost}` });
}

async function processarAnexosTicket(message) {
    const info = dadosLeilao.get(message.channel.id);
    if (info) {
        // Se for staff, apenas reagimos com ✅ se houver anexo (comprovante), mas não adicionamos às fotos do pet
        if (message.member.roles.cache.has(STAFF_ROLE_ID)) {
            if (message.attachments.size > 0 || message.content.startsWith('http')) {
                await message.react('✅').catch(() => { });
            }
            return;
        }

        let added = false;
        if (message.attachments.size > 0) {
            message.attachments.forEach(a => {
                if (info.imagens.length < 50) {
                    info.imagens.push(a.url);
                    added = true;
                }
            });
        } else if (message.content.startsWith('http')) {
            if (info.imagens.length < 50) {
                info.imagens.push(message.content);
                added = true;
            }
        }
        if (added) await message.react('✅').catch(() => { });
    }
}

async function processarLanceViaTexto(message, info, threadId) {
    const input = message.content.replace(/[R$\s]/g, '').replace(',', '.');
    const valorLance = parseFloat(input);
    if (!isNaN(valorLance) && /^\d/.test(message.content)) {
        if (message.author.id === info.leiloeiroId) return;
        const lanceAnterior = info.historico.length > 0 ? info.historico[0].valor : info.lanceMinimo;
        if (valorLance >= lanceAnterior + 1.0) {
            info.historico.unshift({ userId: message.author.id, valor: valorLance, timestamp: Math.floor(Date.now() / 1000) });
            const thread = message.channel;
            const canalPai = thread.parent;
            if (canalPai) await atualizarPainelLeilao(canalPai, info);
            await message.reply(`✅ **Novo lance!** <@${message.author.id}> deu **R$ ${valorLance.toFixed(2)}**!`).catch(() => {});
        }
    }
}

async function registrarLanceModal(interaction) {
    const leilao = lancesAtuais.get(interaction.channel.id);
    if (!leilao) return interaction.reply({ content: "Leilão não encontrado.", flags: [MessageFlags.Ephemeral] });
    if (interaction.user.id === leilao.leiloeiroId) return interaction.reply({ content: "❌ O leiloeiro não pode dar lance no próprio leilão.", flags: [MessageFlags.Ephemeral] });
const valorInput = parseFloat(interaction.fields.getTextInputValue('valor_lance_input').replace(',', '.'));
    if (isNaN(valorInput)) return interaction.reply({ content: "Valor inválido.", flags: [MessageFlags.Ephemeral] });
    const lanceAnterior = leilao.historico.length > 0 ? leilao.historico[0].valor : leilao.lanceMinimo;
    if (valorInput < lanceAnterior + 1.0) return interaction.reply({ content: `Mínimo: R$ ${(lanceAnterior + 1.0).toFixed(2)}`, flags: [MessageFlags.Ephemeral] });

    leilao.historico.unshift({ userId: interaction.user.id, valor: valorInput, timestamp: Math.floor(Date.now() / 1000) });
    let canalPrincipal, thread;
    if (interaction.channel.isThread()) {
        thread = interaction.channel;
        canalPrincipal = thread.parent;
    } else {
        canalPrincipal = interaction.channel;
        thread = await interaction.guild.channels.fetch(leilao.threadId).catch(() => null);
    }

    if (canalPrincipal) await atualizarPainelLeilao(canalPrincipal, leilao);
    await interaction.reply({ content: "✅ Lance registrado!", flags: [MessageFlags.Ephemeral] });
    if (thread) await thread.send(`✅ **Novo lance!** <@${interaction.user.id}> deu **R$ ${valorInput.toFixed(2)}**!`);
}

async function abrirModalLance(interaction) {
    const leilao = lancesAtuais.get(interaction.channel.id);
    if (leilao && interaction.user.id === leilao.leiloeiroId) return interaction.reply({ content: "❌ O leiloeiro não pode dar lance no próprio leilão.", flags: [MessageFlags.Ephemeral] });
    const modal = new ModalBuilder().setCustomId('modal_efetuar_lance').setTitle('Dar um Lance');
    modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('valor_lance_input').setLabel('Valor do Lance (R$)').setStyle(TextInputStyle.Short).setRequired(true)));
    await interaction.showModal(modal);
}

async function atualizarPainelLeilao(canal, info) {
    const temLances = info.historico.length > 0;
    const ultimoLance = temLances ? info.historico[0].valor : info.lanceMinimo;
    const liderId = temLances ? info.historico[0].userId : "Ninguém";
    const totalLances = info.historico.length;
    const taxaMM = formatarBRL(calcularTaxaMM(ultimoLance));
    const proximoMinimo = ultimoLance + 1.0;
    const timestampFim = Math.floor(Date.now() / 1000) + 86400;
    const dataAbertura = Math.floor(Date.now() / 1000);
    const components = [];

    const containerUnico = new ContainerBuilder().setAccentColor(0x2ecc71);

    // Galeria de imagens no topo absoluto
    if (info.imagens.length > 0) {
        const gallery = new MediaGalleryBuilder();
        info.imagens.slice(0, 10).forEach(url => gallery.addItems(new MediaGalleryItemBuilder({ media: { url } })));
        containerUnico.addMediaGalleryComponents(gallery);
    }

    // Título e informações logo abaixo das imagens
    let content = `## Fileira linda mais não tão linda\n` +
        `-# LEILÃO \`${info.id}\` · leiloado por <@${info.leiloeiroId}> · valor \`${info.valorPet}\` · total ~${info.valorPet.replace(/[^0-9]/g, '')}M\n` +
        `Encerra <t:${timestampFim}:F> (<t:${timestampFim}:R>)\n` +
        `**Lance mais alto:** R$ ${ultimoLance.toFixed(2)} — <@${liderId}>\n` +
        `**Taxa de MM reduzido:** R$ ${taxaMM}.\n` +
        `-# Faixas: R$ 0,25 acima de R$ 8 · R$ 2,00 acima de R$ 100 · R$ 4,00 acima de R$ 200 · R$ 6,50 acima de R$ 400 · 1% acima de R$ 700.\n` +
        `-# ${totalLances} lances · **próximo mínimo:** R$ ${proximoMinimo.toFixed(2)} · **teto (faixa):** R$ ${info.lanceMaximo.toFixed(2)}\n` +
        `-# Pet **acima de 1B** — teto relativo ao lance de referência: **+ R$ 300**.`;

    containerUnico.addTextDisplayComponents(new TextDisplayBuilder().setContent(content));

    containerUnico.addActionRowComponents(new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('btn_dar_lance').setLabel('Dar lance').setStyle(ButtonStyle.Success).setEmoji('💸'),
        new ButtonBuilder().setCustomId('btn_dar_dole').setLabel('Dar dole').setStyle(ButtonStyle.Danger).setEmoji('🔥'),
        new ButtonBuilder().setCustomId('btn_configuracoes').setLabel('Configurações').setStyle(ButtonStyle.Secondary).setEmoji('⚙️')
    ));
containerUnico.addActionRowComponents(new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('btn_historico').setLabel('Histórico').setStyle(ButtonStyle.Secondary).setEmoji('📜'),
        new ButtonBuilder().setCustomId('btn_editar_lances').setLabel('Editar lances').setStyle(ButtonStyle.Secondary).setEmoji('🛠️')
    ));

    components.push(containerUnico);

    const payload = { components, flags: [MessageFlags.IsComponentsV2] };

    if (!info.painelMsgId) {
        await canal.send({ content: "<@&1485352938145845433>" }).catch(() => {});
        const msg = await canal.send(payload);
        info.painelMsgId = msg.id;
        return msg;
    } else {
        const msg = await canal.messages.fetch(info.painelMsgId).catch(() => null);
        if (msg) await msg.edit(payload);
        return msg;
    }
}

async function finalizarLeilaoAdmin(interaction) {
    const leilao = lancesAtuais.get(interaction.channel.id);
    if (!leilao) return;
    const vencedorId = leilao.historico.length > 0 ? leilao.historico[0].userId : "Ninguém";
    const valorFinal = leilao.historico.length > 0 ? leilao.historico[0].valor : 0;
    const taxaMMFinal = formatarBRL(calcularTaxaMM(valorFinal));
    const dataFim = Math.floor(Date.now() / 1000);
    const textoDM = `## Leilão encerrado — intermediário\n-# Leilão \`${leilao.id}\` · Perfil: **Vendedor**\n**Abra um intermediário com a outra parte** no canal do servidor abaixo. As instruções completas foram combinadas com a equipe.\n### Dados do leilão\n**ID do leilão:** \`${leilao.id}\`\n**Vendedor:** <@${leilao.leiloeiroId}>\n**Ganhador:** ${vencedorId.startsWith('<') ? vencedorId : `<@${vencedorId}>`}\n**Descrição:** ${leilao.titulo}\n**Valor total do pet:** \`${leilao.valorPet}\`\n**Lance vencedor:** R$ ${valorFinal.toFixed(2)}\n**Taxa de MM reduzido:** R$ ${taxaMMFinal}\n**Encerrado em:** <t:${dataFim}:F>\n### Solicitar MM reduzido\n**Taxa sobre transação via PIX:**\n- R$ 0,25 acima de R$ 8,00\n- R$ 2,00 acima de R$ 100,00\n- R$ 4,00 acima de R$ 200,00\n- R$ 6,50 acima de R$ 400,00\n- 1% acima de R$ 700,00\n\n-# Servidor: \`${SERVIDOR_ID_TEXTO}\` · Canal MM: ${MM_CHANNEL_URL}\n(\`${MM_CANAL_ID_TEXTO}\`)\n\n-# Use o botão **Abrir MM reduzido** para abrir o canal correto.`;
    const embedDM = new EmbedBuilder().setColor("#FF0000").setDescription(textoDM);
    const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setLabel('Abrir MM reduzido').setStyle(ButtonStyle.Link).setURL(MM_CHANNEL_URL));
    const leiloeiro = await client.users.fetch(leilao.leiloeiroId).catch(() => null);
    if (leiloeiro) await leiloeiro.send({ embeds: [embedDM], components: [row] }).catch(() => { });
    if (vencedorId !== "Ninguém") {
        const vencedor = await client.users.fetch(vencedorId).catch(() => null);
        if (vencedor) {
            const textoVencedor = textoDM.replace('Perfil: **Vendedor**', 'Perfil: **Comprador**');
            const embedVencedor = new EmbedBuilder().setColor("#FF0000").setDescription(textoVencedor);
            await vencedor.send({ embeds: [embedVencedor], components: [row] }).catch(() => { });
        }
    }
    await interaction.channel.delete("Leilão finalizado pelo dono/staff").catch(() => { });
}

async function handlePixLeilaoCommand(interaction) {
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) return interaction.reply({ content: 'Você não tem permissão para usar este comando.', ephemeral: true });
    const chave = interaction.options.getString('chave');
    const nome = interaction.options.getString('nome');
    const idAtendente = interaction.options.getString('id_atendente');
    pixConfig = { chave, nome, idAtendente };
    fs.writeFileSync('config.json', JSON.stringify(pixConfig, null, 2));
    await interaction.reply({ content: 'Configurações do Pix para leilão salvas com sucesso!', ephemeral: true });
}
async function reivindicarPagamento(interaction) {
    if (!interaction.member.roles.cache.has(STAFF_ROLE_ID)) return interaction.reply({ content: '❌ Apenas a staff pode reivindicar pagamentos.', flags: [MessageFlags.Ephemeral] });
    const originalEmbed = interaction.message.embeds[0];
    const newEmbed = EmbedBuilder.from(originalEmbed).setDescription(originalEmbed.description + `\n\n**Reivindicado por:** <@${interaction.user.id}>`);
    const updatedComponents = interaction.message.components.map(row => {
        return new ActionRowBuilder().addComponents(row.components.map(component => {
            if (component.customId === 'reivindicar_pagamento') return ButtonBuilder.from(component).setDisabled(true).setLabel('Atendido por Staff').setStyle(ButtonStyle.Secondary);
            return component;
        }));
    });
    await interaction.update({ embeds: [newEmbed], components: updatedComponents });
    await interaction.followUp({ content: `✅ Pagamento reivindicado por <@${interaction.user.id}>.`, flags: [MessageFlags.Ephemeral] });
}

async function copiarCodigoPix(interaction) {
    const info = dadosLeilao.get(interaction.channel.id);
    if (!info) return interaction.reply({ content: "Dados não encontrados.", flags: [MessageFlags.Ephemeral] });
    await interaction.reply({ content: `${info.pixCode}`, flags: [MessageFlags.Ephemeral] });
}

function formatarNomeCanal(texto) {
    return texto.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9\s-]/g, "").trim().replace(/\s+/g, "-").substring(0, 25);
}

function getPixQR() {
    if (!pixConfig.chave || !pixConfig.nome) return { link: "", code: "" };
    // Payload fixo para R$ 1,00 (041.00)
    const payload = `00020126580014BR.GOV.BCB.PIX01${pixConfig.chave.length.toString().padStart(2, '0')}${pixConfig.chave}52040000530398654041.005802BR59${pixConfig.nome.length.toString().padStart(2, '0')}${pixConfig.nome}6009SAO PAULO62070503***6304`;
    return { link: `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(payload)}`, code: payload };
}

async function exibirHistoricoLances(interaction) {
    const leilao = lancesAtuais.get(interaction.channel.id);
    if (!leilao) return interaction.reply({ content: "Leilão não encontrado.", flags: [MessageFlags.Ephemeral] });

    const lancesTexto = leilao.historico.length > 0
        ? leilao.historico.slice(0, 10).map((l, i) => `${i + 1}. <@${l.userId}> — R$ ${l.valor.toFixed(2)} · <t:${l.timestamp}:R>`).join('\n')
        : "Nenhum lance registrado.";

    const dolesTexto = (leilao.doles && leilao.doles.length > 0)
        ? leilao.doles.slice(0, 10).map((d, i) => `${i + 1}. <@${d.userId}> — R$ ${d.valor.toFixed(2)} · <t:${d.timestamp}:R>`).join('\n')
        : "Nenhum dole registrado.";

    const container = new ContainerBuilder()
        .setAccentColor(0xFF0000)
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# Histórico administrativo (${leilao.id})\n` +
                `**Histórico completo**\n\n` +
                `**Lances recentes:**\n` +
                `${lancesTexto}\n\n` +
                `**Doles recentes:**\n` +
                `${dolesTexto}`
            )
        )
        .addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('admin_select_tudo')
                    .setPlaceholder('Tudo')
                    .addOptions([
                        { label: 'Remover lance', value: 'remover_lance', emoji: '🗑️' },
                        { label: 'Encerrar', value: 'encerrar_leilao', emoji: '🔒' },
                        { label: 'Dar dole', value: 'dar_dole', emoji: '🔥' }
                    ])
            )
        );

    await interaction.reply({
        components: [container],
        flags: [MessageFlags.Ephemeral, MessageFlags.IsComponentsV2]
    });
}

async function processarSelecaoAdminTudo(interaction) {
    const value = interaction.values[0];
    if (value === 'remover_lance') return await abrirModalEditarLances(interaction);
    if (value === 'encerrar_leilao') return await abrirConfiguracoesAdmin(interaction);
    if (value === 'dar_dole') return await finalizarLeilaoAdmin(interaction);
}

async function abrirModalEditarLances(interaction) {
    const leilao = lancesAtuais.get(interaction.channel.id);
    if (leilao.historico.length === 0) return interaction.reply({ content: "Sem lances.", flags: [MessageFlags.Ephemeral] });
    const options = leilao.historico.slice(0, 25).map((l, i) => ({ label: `Lance #${leilao.historico.length - i}: R$ ${l.valor.toFixed(2)}`, value: i.toString() }));
    const menu = new StringSelectMenuBuilder().setCustomId('remover_lance_select').setPlaceholder('Remover lance').addOptions(options);
    await interaction.reply({ content: "Selecione para remover:", components: [new ActionRowBuilder().addComponents(menu)], flags: [MessageFlags.Ephemeral] });
}

async function executarRemocaoLance(interaction) {
    await interaction.deferUpdate();
    const leilao = lancesAtuais.get(interaction.channel.id);
    const index = parseInt(interaction.values[0]);
    if (leilao && index >= 0 && index < leilao.historico.length) {
        leilao.historico.splice(index, 1);
        await atualizarPainelLeilao(interaction.channel, leilao);
        await interaction.editReply({ content: "Removido.", components: [] });
    }
}

async function abrirConfiguracoesAdmin(interaction) {
    const leilao = lancesAtuais.get(interaction.channel.id);
    if (!leilao) return interaction.reply({ content: "Leilão não encontrado.", flags: [MessageFlags.Ephemeral] });
    const vencedorId = leilao.historico.length > 0 ? leilao.historico[0].userId : null;
    const valorTopo = leilao.historico.length > 0 ? leilao.historico[0].valor : leilao.lanceMinimo;
    const embed = new EmbedBuilder().setColor("#2b2d31").setDescription(`Confirma encerrar o leilão\n\`${leilao.id}\` com o lance\natual no topo?\n\n**Vencedor atual:** ${vencedorId ? `<@${vencedorId}>` : "Ninguém"}\n**Valor do topo:** R$ ${valorTopo.toFixed(2)}\n-# Ao confirmar, seguirá o mesmo fluxo normal de fim do leilão (DMs e logs).`);
    const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('confirmar_encerramento_final').setLabel('Confirmar e encerrar').setStyle(ButtonStyle.Danger), new ButtonBuilder().setCustomId('cancelar_encerramento').setLabel('Cancelar').setStyle(ButtonStyle.Secondary));
    await interaction.reply({ embeds: [embed], components: [row], flags: [MessageFlags.Ephemeral] });
}

process.on('unhandledRejection', (reason) => console.error(reason));
process.on("uncaughtException", (err) => console.error(err));

client.login ('MTQzODM1MzgyMzIzNTA1MTY0Mg.GZTaeL.zIjR2RasRolvFvU9n1asQJs9M62mzgxn8ewgn4');