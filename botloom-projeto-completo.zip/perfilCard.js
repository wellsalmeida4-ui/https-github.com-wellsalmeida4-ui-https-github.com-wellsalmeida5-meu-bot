const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");
const fs = require("fs");
const path = require("path");

/* ───────────── Fontes (Inter = fonte da imagem) ───────────── */
(function registerFonts() {
    const dirs = [
        path.join(__dirname, "fonts"),
        path.join(process.cwd(), "fonts"),
        path.join(__dirname, "..", "fonts")
    ];
    const done = new Set();
    for (const dir of dirs) {
        if (!fs.existsSync(dir)) continue;
        for (const file of fs.readdirSync(dir)) {
            if (done.has(file)) continue;
            const l = file.toLowerCase();
            if (!(l.endsWith(".ttf") || l.endsWith(".otf"))) continue;
            try {
                if (l.startsWith("inter")) GlobalFonts.registerFromPath(path.join(dir, file), "Inter");
                else if (l.startsWith("montserrat")) GlobalFonts.registerFromPath(path.join(dir, file), "Montserrat");
                else if (l.startsWith("poppins")) GlobalFonts.registerFromPath(path.join(dir, file), "Poppins");
                else if (l.includes("noto") || l.includes("cjk")) GlobalFonts.registerFromPath(path.join(dir, file), "NotoCJK");
                else continue;
                done.add(file);
            } catch (e) {}
        }
    }
})();

console.log("[perfilCard] versão nova carregada (layout profissional)");

const FONT = "'Inter', 'Montserrat', 'Poppins', 'NotoCJK', 'DejaVu Sans', 'Noto Sans', Arial, sans-serif";

/* ───────────── Cargos (a cor do card segue o cargo) ───────────── */
const TIERS = [
    { name: "Cliente",  color: "#7f95b8", min: 0 },
    { name: "Bronze",   color: "#d98a3d", min: 2500 },
    { name: "Prata",   color: "#d1d5db", min: 10000 },
    { name: "Ouro",     color: "#e0ad1f", min: 22000 },
    { name: "Diamante", color: "#3ab0d4", min: 50000 },
    { name: "Emerald",  color: "#22c55e", min: 100000 },
    { name: "Rubi",     color: "#f43f5e", min: 250000 },
    { name: "Ametista", color: "#8b5cf6", min: 500000 }
];

/* Nomes dos cargos (iguais ao canal #cargos). Aceita os nomes antigos do bot e troca pelos novos. */
const NOMES_CARGOS = {
    "cliente iniciante": "Cliente",
    "cliente nobre": "Cliente Premium",
    "cliente imperial": "Cliente Platina",
    "cliente celestial": "Cliente Esmeralda",
    "cliente sagrado": "Cliente Eterno",
    "cliente lendário": "Cliente Galático",
    "cliente lendario": "Cliente Galático",
    "cliente divino": "Cliente Imperador",
    "100k": "Cliente Nebula",
    "200k": "Cliente Master"
};
function nomeCargo(n) {
    const bruto = String(n === undefined || n === null ? "" : n).trim();
    return NOMES_CARGOS[bruto.toLowerCase()] || bruto;
}

/* ───────────── Helpers ───────────── */
const pick = (...v) => v.find(x => x !== undefined && x !== null);
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));

function hexToRgba(hex, a) {
    const h = hex.replace("#", "");
    const n = parseInt(h.length === 3 ? h.split("").map(c => c + c).join("") : h, 16);
    return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}
function lighten(hex, amt) {
    const h = hex.replace("#", "");
    const n = parseInt(h, 16);
    const f = c => Math.round(c + (255 - c) * amt);
    return `rgb(${f((n >> 16) & 255)},${f((n >> 8) & 255)},${f(n & 255)})`;
}
function cleanText(s) {
    if (s === undefined || s === null) return "";
    return String(s).replace(/[\u0000-\u001F\u007F-\u009F]/g, "").trim();
}
function fmtBRL(v) {
    v = typeof v === "number" ? v : parseFloat(String(v).replace(/[^0-9.\-]/g, "")) || 0;
    const neg = v < 0;
    const [inteiro, cent] = Math.abs(v).toFixed(2).split(".");
    return (neg ? "-" : "") + "R$ " + inteiro.replace(/\B(?=(\d{3})+(?!\d))/g, ".") + "," + cent;
}
function rr(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
}
function truncate(ctx, text, maxW) {
    if (ctx.measureText(text).width <= maxW) return text;
    let t = text;
    while (t.length > 1 && ctx.measureText(t + "…").width > maxW) t = t.slice(0, -1);
    return t + "…";
}
function fitFont(ctx, text, weight, size, maxW) {
    do {
        ctx.font = `${weight} ${size}px ${FONT}`;
        size -= 2;
    } while (ctx.measureText(text).width > maxW && size > 20);
}
/* texto com espaçamento entre letras */
function spaced(ctx, text, x, y, sp, align) {
    const chars = [...String(text)];
    ctx.textAlign = "left";
    const w = chars.reduce((a, c) => a + ctx.measureText(c).width + sp, 0) - sp;
    let cx = align === "right" ? x - w : align === "center" ? x - w / 2 : x;
    for (const c of chars) {
        ctx.fillText(c, cx, y);
        cx += ctx.measureText(c).width + sp;
    }
    return w;
}
function spacedWidth(ctx, text, sp) {
    const chars = [...String(text)];
    return chars.reduce((a, c) => a + ctx.measureText(c).width + sp, 0) - sp;
}

/* ───────────── Ícones vetoriais ───────────── */
function poly(ctx, cx, cy, s, pts) {
    ctx.beginPath();
    pts.forEach(([px, py], i) => (i ? ctx.lineTo(cx + px * s, cy + py * s) : ctx.moveTo(cx + px * s, cy + py * s)));
    ctx.closePath();
    ctx.fill();
}
function starPath(ctx, cx, cy, spikes, outer, inner) {
    let rot = (Math.PI / 2) * 3;
    const step = Math.PI / spikes;
    ctx.beginPath();
    ctx.moveTo(cx, cy - outer);
    for (let i = 0; i < spikes; i++) {
        ctx.lineTo(cx + Math.cos(rot) * outer, cy + Math.sin(rot) * outer);
        rot += step;
        ctx.lineTo(cx + Math.cos(rot) * inner, cy + Math.sin(rot) * inner);
        rot += step;
    }
    ctx.closePath();
}
const GLYPHS = {
    bars(ctx, cx, cy, s) {
        poly(ctx, cx, cy, s, [[-0.35, -0.8], [0.35, -0.8], [0.6, -0.05], [-0.6, -0.05]]);
        poly(ctx, cx, cy, s, [[-1.0, 0.1], [-0.05, 0.1], [-0.2, 0.85], [-1.2, 0.85]]);
        poly(ctx, cx, cy, s, [[0.05, 0.1], [1.0, 0.1], [1.2, 0.85], [0.2, 0.85]]);
    },
    bolt(ctx, cx, cy, s) {
        poly(ctx, cx, cy, s, [[0.2, -1], [-0.6, 0.15], [-0.05, 0.15], [-0.25, 1], [0.6, -0.2], [0.05, -0.2]]);
    },
    star(ctx, cx, cy, s) {
        starPath(ctx, cx, cy, 5, s, s * 0.45);
        ctx.fill();
    },
    heart(ctx, cx, cy, s) {
        ctx.beginPath();
        ctx.moveTo(cx, cy + s * 0.85);
        ctx.bezierCurveTo(cx - s * 1.4, cy - s * 0.1, cx - s * 0.6, cy - s * 1.0, cx, cy - s * 0.35);
        ctx.bezierCurveTo(cx + s * 0.6, cy - s * 1.0, cx + s * 1.4, cy - s * 0.1, cx, cy + s * 0.85);
        ctx.fill();
    },
    flame(ctx, cx, cy, s) {
        ctx.beginPath();
        ctx.moveTo(cx, cy + s * 0.9);
        ctx.quadraticCurveTo(cx - s, cy + s * 0.1, cx - s * 0.4, cy - s * 0.45);
        ctx.quadraticCurveTo(cx - s * 0.1, cy - s * 1.1, cx + s * 0.7, cy - s * 0.75);
        ctx.quadraticCurveTo(cx + s * 0.75, cy - s * 0.2, cx + s * 0.5, cy + s * 0.5);
        ctx.quadraticCurveTo(cx + s * 0.3, cy + s * 0.9, cx, cy + s * 0.9);
        ctx.fill();
    },
    group(ctx, cx, cy, s) {
        [[-0.5, 0], [0.5, 0]].forEach(([ox]) => {
            ctx.beginPath();
            ctx.arc(cx + ox * s, cy - s * 0.4, s * 0.38, 0, Math.PI * 2);
            ctx.fill();
            ctx.beginPath();
            ctx.ellipse(cx + ox * s, cy + s * 0.75, s * 0.62, s * 0.6, 0, Math.PI, 0);
            ctx.fill();
        });
    },
    crown(ctx, cx, cy, s) {
        poly(ctx, cx, cy, s, [[-1, 0.65], [-1, -0.55], [-0.45, 0.0], [0, -0.75], [0.45, 0.0], [1, -0.55], [1, 0.65]]);
    },
    bug(ctx, cx, cy, s, bg, fg) {
        ctx.beginPath();
        ctx.ellipse(cx, cy + s * 0.15, s * 0.5, s * 0.7, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(cx, cy - s * 0.65, s * 0.3, 0, Math.PI * 2);
        ctx.fill();
        ctx.lineWidth = Math.max(1.5, s * 0.14);
        ctx.strokeStyle = fg || "#000000";
        ctx.lineCap = "round";
        [-0.3, 0.1, 0.5].forEach(y => {
            ctx.beginPath();
            ctx.moveTo(cx - s * 0.45, cy + y * s);
            ctx.lineTo(cx - s * 0.95, cy + (y - 0.2) * s);
            ctx.moveTo(cx + s * 0.45, cy + y * s);
            ctx.lineTo(cx + s * 0.95, cy + (y - 0.2) * s);
            ctx.stroke();
        });
    },
    fire(ctx, cx, cy, s) {
        GLYPHS.flame(ctx, cx, cy, s);
    },
    cash(ctx, cx, cy, s, bg) {
        rr(ctx, cx - s * 1.05, cy - s * 0.65, s * 2.1, s * 1.3, s * 0.2);
        ctx.fill();
        ctx.fillStyle = bg;
        ctx.beginPath();
        ctx.arc(cx, cy, s * 0.32, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(cx - s * 0.75, cy, s * 0.1, 0, Math.PI * 2);
        ctx.arc(cx + s * 0.75, cy, s * 0.1, 0, Math.PI * 2);
        ctx.fill();
    }
};

/* ───────────── Badges (20) ───────────── */
const BADGES = [
    { id: "d10",    kind: "circle", text: "10",    color: "#5cf08a", fg: "#0c3a1c", test: s => s.deals >= 10 },
    { id: "d25",    kind: "circle", text: "25",    color: "#3a9e55", fg: "#0c2a16", test: s => s.deals >= 25 },
    { id: "v1k",    kind: "shield", text: "$1K",   color: "#5b6cf5", test: s => s.volume >= 1000 },
    { id: "v5k",    kind: "shield", text: "$5K",   color: "#8b5cf6", test: s => s.volume >= 5000 },
    { id: "cash",   kind: "circle", glyph: "cash", color: "#22c55e", fg: "#ffffff", test: s => s.biggest >= 1000 },
    { id: "d100",   kind: "circle", text: "100",   color: "#e2e8f0", fg: "#111", test: s => s.deals >= 100 },
    { id: "d500",   kind: "circle", text: "500",   color: "#fbbf24", fg: "#111", test: s => s.deals >= 500 },
    { id: "d1k",    kind: "circle", text: "1K",    color: "#f472b6", fg: "#111", big: true, test: s => s.deals >= 1000 },
    { id: "v25k",   kind: "shield", text: "$25K",  color: "#06b6d4", test: s => s.volume >= 25000 },
    { id: "v100k",  kind: "shield", text: "$100K", color: "#f59e0b", test: s => s.volume >= 100000 },
    { id: "v250k",  kind: "shield", text: "$250K", color: "#ef4444", test: s => s.volume >= 250000 },
    { id: "bars",   kind: "circle", glyph: "bars",  color: "#fbbf24", fg: "#2a1b00", test: s => s.volume >= 50000 },
    { id: "bolt",   kind: "circle", glyph: "bolt",  color: "#facc15", fg: "#2a2300", test: s => s.deals >= 150 },
    { id: "star",   kind: "circle", glyph: "star",  color: "#fde047", fg: "#2a2300", test: s => s.repCount >= 50 },
    { id: "heart",  kind: "circle", glyph: "heart", color: "#fb7185", fg: "#2d0710", test: s => s.tipped >= 100 },
    { id: "flame",  kind: "circle", glyph: "flame", color: "#fb923c", fg: "#2d1204", test: s => s.swapped >= 10000 },
    { id: "group",  kind: "circle", glyph: "group", color: "#60a5fa", fg: "#06162d", test: s => s.invited >= 1 },
    { id: "crown",  kind: "circle", glyph: "crown", color: "#fbbf24", fg: "#2a1b00", test: s => s.tierIdx >= 3 },
    { id: "bug",    kind: "circle", glyph: "bug",   color: "#4ade80", fg: "#06240f", test: s => s.early },
    { id: "fire",   kind: "circle", glyph: "fire",  color: "#f97316", fg: "#2d1204", test: s => s.deals >= 250 }
];

function shieldPath(ctx, cx, cy, r) {
    ctx.beginPath();
    ctx.moveTo(cx, cy - r);
    ctx.lineTo(cx + r * 0.88, cy - r * 0.5);
    ctx.lineTo(cx + r * 0.88, cy + r * 0.4);
    ctx.lineTo(cx, cy + r);
    ctx.lineTo(cx - r * 0.88, cy + r * 0.4);
    ctx.lineTo(cx - r * 0.88, cy - r * 0.5);
    ctx.closePath();
}

function drawBadge(ctx, d, cx, cy, unlocked) {
    ctx.save();
    const r = unlocked ? 28 : 20;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    if (d.kind === "shield") {
        shieldPath(ctx, cx, cy, r);
        if (unlocked) {
            ctx.fillStyle = lighten(d.color, 0.1);
            ctx.shadowColor = hexToRgba(d.color, 0.7);
            ctx.shadowBlur = 12;
            ctx.fill();
            ctx.shadowBlur = 0;
            ctx.strokeStyle = "rgba(255,255,255,0.35)";
            ctx.lineWidth = 1.5;
            ctx.stroke();
        } else {
            ctx.fillStyle = "rgba(255,255,255,0.05)";
            ctx.fill();
            ctx.strokeStyle = "rgba(255,255,255,0.10)";
            ctx.lineWidth = 1.5;
            ctx.stroke();
        }
        ctx.fillStyle = unlocked ? "#ffffff" : "rgba(255,255,255,0.32)";
        const fs = unlocked ? Math.round(r * 0.62) : d.text.length > 4 ? 10 : 12;
        ctx.font = `800 ${fs}px ${FONT}`;
        ctx.fillText(d.text, cx, cy + 1);
    } else {
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        if (unlocked) {
            ctx.fillStyle = d.color;
            ctx.shadowColor = hexToRgba(d.color, 0.6);
            ctx.shadowBlur = 12;
            ctx.fill();
            ctx.shadowBlur = 0;
        } else {
            ctx.fillStyle = "rgba(255,255,255,0.05)";
            ctx.fill();
            ctx.strokeStyle = "rgba(255,255,255,0.10)";
            ctx.lineWidth = 1.5;
            ctx.stroke();
        }
        const fg = unlocked ? d.fg : "rgba(255,255,255,0.30)";
        ctx.fillStyle = fg;
        if (d.text) {
            const fs = unlocked ? Math.round(r * 0.85) : d.big ? 24 : 15;
            ctx.font = `800 ${fs}px ${FONT}`;
            ctx.fillText(d.text, cx, cy + 1);
        } else if (d.glyph) {
            const gs = unlocked ? r * 0.55 : 10;
            GLYPHS[d.glyph](ctx, cx, cy, gs, unlocked ? d.color : "#1a1b1f", fg);
        }
    }
    ctx.restore();
}

/* ───────────── Gerador principal ───────────── */
async function gerarCartaoPerfilInterno(opts) {
    opts = opts || {};

    /* dados (aceita os nomes antigos também) */
    const username = cleanText(opts.username) || "Cliente";
    const volume = Number(pick(opts.volume, opts.totalMovimentado, opts.total, opts.totalValor, 0)) || 0;
    const deals = Number(pick(opts.deals, opts.intermediacoes, opts.trocas, opts.totalTrocas, 0)) || 0;
    const biggest = Number(pick(opts.biggestDeal, opts.maiorTransacao, opts.maiorTrend, opts.maiorTroca, 0)) || 0;
    const tipped = Number(pick(opts.totalTipped, opts.tipped, 0)) || 0;
    const feesSaved = Number(pick(opts.feesSaved, 0)) || 0;
    const swapped = Number(pick(opts.swapped, 0)) || 0;
    const repCount = Number(pick(opts.reputationCount, opts.reputacaoQtd, 0)) || 0;
    const invited = Number(pick(opts.invited, opts.convidados, 0)) || 0;
    const rankPos = pick(opts.rank, opts.rankPosicao, null);

    /* cargo → cor */
    let tiers;
    if (Array.isArray(opts.todosCargos) && opts.todosCargos.length >= 2) {
        // usa exatamente os cargos do bot (nome, limite e cor de cada um)
        tiers = opts.todosCargos.map(c => ({ name: nomeCargo(c.nome), color: c.corHex || "#9B30FF", min: Number(c.limite) || 0, custom: true }));
    } else {
        tiers = TIERS.map((t, i) => ({ ...t, min: pick(opts.tierThresholds && opts.tierThresholds[i], t.min) }));
    }
    let tierIdx = opts.tierIndex;
    if (tierIdx === undefined || tierIdx === null) {
        const nm = nomeCargo(cleanText(pick(opts.cargo, opts.rankNome, ""))).toLowerCase();
        tierIdx = nm ? tiers.findIndex(t => t.name.toLowerCase() === nm) : -1;
        if (tierIdx < 0 && nm) tierIdx = tiers.findIndex(t => nm.includes(t.name.toLowerCase()));
        if (tierIdx < 0) {
            tierIdx = 0;
            tiers.forEach((t, i) => { if (volume >= t.min) tierIdx = i; });
        }
    }
    tierIdx = clamp(tierIdx, 0, tiers.length - 1);
    const tier = tiers[tierIdx];
    const next = tiers[tierIdx + 1];
    const accent = opts.rankCorHex || tier.color;
    const tierTitle = tier.custom ? tier.name.toUpperCase() : tier.name === "Cliente" ? "CLIENTE" : `CLIENTE ${tier.name.toUpperCase()}`;

    const falta = next ? pick(opts.proximoRank && opts.proximoRank.faltam, Math.max(0, next.min - volume)) : 0;
    const progress = next
        ? clamp(pick(opts.progresso, (volume - tier.min) / (next.min - tier.min)), 0, 1)
        : 1;

    /* canvas */
    const W = 1800, H = 1056;
    const scale = opts.scale || 1;
    const canvas = createCanvas(Math.round(W * scale), Math.round(H * scale));
    const ctx = canvas.getContext("2d");
    ctx.scale(scale, scale);

    /* 1. Fundo (opts.transparent = true deixa o PNG transparente) */
    if (!opts.transparent) {
        ctx.fillStyle = "#16171b";
        ctx.fillRect(0, 0, W, H);

        /* brilho suave na cor do cargo (sem gradiente: círculos translúcidos) */
        ctx.fillStyle = hexToRgba(accent, 0.012);
        for (let k = 0; k < 16; k++) {
            ctx.beginPath();
            ctx.arc(180, 180, 760 - k * 45, 0, Math.PI * 2);
            ctx.fill();
        }

        for (let i = 0; i < 180; i++) {
            ctx.globalAlpha = 0.04 + (i % 4) * 0.02;
            ctx.fillStyle = "#ffffff";
            ctx.fillRect((i * 193 + 71) % W, (i * 127 + 53) % H, 2, 2);
        }
        ctx.globalAlpha = 1;
    }

    /* 2. Avatar com anel de progresso + decágono */
    const acx = 176, acy = 180;
    ctx.save();
    ctx.strokeStyle = "rgba(255,255,255,0.22)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
        const a = (Math.PI * 2 * i) / 10 - Math.PI / 2;
        const px = acx + Math.cos(a) * 124, py = acy + Math.sin(a) * 124;
        i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
    }
    ctx.closePath();
    ctx.stroke();
    ctx.restore();

    ctx.save();
    ctx.lineWidth = 9;
    ctx.lineCap = "round";
    ctx.strokeStyle = "rgba(255,255,255,0.15)";
    ctx.beginPath();
    ctx.arc(acx, acy, 105, 0, Math.PI * 2);
    ctx.stroke();
    if (progress > 0) {
        ctx.strokeStyle = lighten(accent, 0.35);
        ctx.shadowColor = hexToRgba(accent, 0.55);
        ctx.shadowBlur = 14;
        ctx.beginPath();
        ctx.arc(acx, acy, 105, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * progress);
        ctx.stroke();
    }
    ctx.restore();

    const avR = 94;
    try {
        if (!opts.avatarURL || !String(opts.avatarURL).startsWith("http")) throw new Error("no avatar");
        const img = await loadImage(opts.avatarURL);
        ctx.save();
        ctx.beginPath();
        ctx.arc(acx, acy, avR, 0, Math.PI * 2);
        ctx.clip();
        ctx.drawImage(img, acx - avR, acy - avR, avR * 2, avR * 2);
        ctx.restore();
    } catch (e) {
        ctx.save();
        ctx.fillStyle = "#050506";
        ctx.beginPath();
        ctx.arc(acx, acy, avR, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "rgba(255,255,255,0.55)";
        ctx.font = `800 ${avR}px ${FONT}`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText((username[0] || "U").toUpperCase(), acx, acy + 4);
        ctx.restore();
    }

    /* 3. Nome + tag + cargo */
    ctx.save();
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "#ffffff";
    ctx.font = `800 64px ${FONT}`;
    const nameStr = truncate(ctx, username, 310);
    ctx.fillText(nameStr, 328, 170);
    const nameW = ctx.measureText(nameStr).width;

    const tag = opts.patron === false ? "" : cleanText(pick(opts.tag, "PATRONO"));
    if (tag) {
        ctx.font = `700 22px ${FONT}`;
        const tw = spacedWidth(ctx, tag, 3);
        const pw = tw + 46, ph = 50;
        const px = 328 + nameW + 29, py = 123;
        rr(ctx, px, py, pw, ph, 25);
        ctx.fillStyle = "rgba(79,91,255,0.18)";
        ctx.fill();
        ctx.strokeStyle = "rgba(79,91,255,0.55)";
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.fillStyle = "#5b66ff";
        spaced(ctx, tag, px + 23, py + 33, 3, "left");
    }

    ctx.font = `800 52px ${FONT}`;
    ctx.fillStyle = accent;
    ctx.shadowColor = hexToRgba(accent, 0.35);
    ctx.shadowBlur = 14;
    spaced(ctx, tierTitle, 328, 239, 5, "left");
    ctx.restore();

    /* helper de card translúcido */
    function glass(x, y, w, h, r) {
        ctx.save();
        rr(ctx, x, y, w, h, r);
        ctx.fillStyle = "rgba(255,255,255,0.045)";
        ctx.fill();
        ctx.strokeStyle = "rgba(255,255,255,0.11)";
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.restore();
    }
    const labelStyle = (size) => {
        ctx.font = `700 ${size}px ${FONT}`;
        ctx.fillStyle = "#a1a5ad";
        ctx.textAlign = "left";
        ctx.textBaseline = "alphabetic";
    };

    /* 4. Card principal – Total Volume */
    glass(80, 345, 743, 320, 40);
    ctx.save();
    labelStyle(22);
    spaced(ctx, "TOTAL MOVIMENTADO", 132, 413, 2.5, "left");
    ctx.fillStyle = "#ffffff";
    fitFont(ctx, fmtBRL(volume), "800", 120, 645);
    ctx.fillText(fmtBRL(volume), 130, 528);
    ctx.strokeStyle = "rgba(255,255,255,0.12)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(132, 540);
    ctx.lineTo(773, 540);
    ctx.stroke();

    labelStyle(21);
    spaced(ctx, "INTERMEDIAÇÕES", 132, 584, 2.5, "left");
    spaced(ctx, "MAIOR TRANSAÇÃO", 416, 584, 2.5, "left");
    ctx.fillStyle = "#ffffff";
    ctx.font = `800 54px ${FONT}`;
    ctx.fillText(String(deals), 132, 638);
    ctx.fillText(fmtBRL(biggest), 416, 638);
    ctx.restore();

    /* 5. Cards pequenos (2 linhas x 3) */
    const repLevel = cleanText(pick(opts.reputation, opts.reputacao, repCount < 20 ? "Baixa" : repCount < 100 ? "Média" : "Alta"));
    const repColor = /alta|high/i.test(repLevel) ? "#22c55e" : /m[eé]d/i.test(repLevel) ? "#facc15" : "rgba(255,255,255,0.32)";
    const small = [
        { label: "GORJETAS", value: fmtBRL(tipped), color: "#fbd10b", row: 0, col: 0 },
        { label: "TAXAS POUPADAS", value: fmtBRL(feesSaved), color: "#2fe07a", row: 0, col: 1 },
        { label: "TROCADO", value: fmtBRL(swapped), color: "#4cc2f5", row: 0, col: 2 },
        { label: `REPUTAÇÃO (${repCount})`, value: repLevel, color: repColor, row: 1, col: 0 },
        { label: "RANKING", value: rankPos ? `#${rankPos}` : "—", color: "#ffffff", row: 1, col: 1 },
        { label: "CONVIDADOS", value: String(invited), color: invited > 0 ? "#ffffff" : "rgba(255,255,255,0.32)", row: 1, col: 2 }
    ];
    small.forEach(c => {
        const x = 850 + c.col * 299;
        const y = c.row === 0 ? 345 : 518;
        const h = c.row === 0 ? 146 : 148;
        glass(x, y, 272, h, 32);
        ctx.save();
        labelStyle(19);
        spaced(ctx, c.label, x + 28, y + 48, 2.2, "left");
        ctx.fillStyle = c.color;
        fitFont(ctx, c.value, "800", 46, 218);
        ctx.fillText(c.value, x + 28, y + 108);
        ctx.restore();
    });

    /* 6. Badges */
    const sctx = { deals, volume, biggest, tipped, swapped, invited, repCount, tierIdx, early: !!opts.earlyAdopter };
    const ids = Array.isArray(opts.badges) ? new Set(opts.badges) : null;
    const states = BADGES.map(b => ({ b, on: ids ? ids.has(b.id) : !!b.test(sctx) }));
    const unlocked = states.filter(s => s.on);
    const locked = states.filter(s => !s.on);

    ctx.save();
    labelStyle(21);
    spaced(ctx, "CONQUISTAS", 80, 706, 2.5, "left");
    ctx.textAlign = "right";
    ctx.fillStyle = "#e5e7eb";
    ctx.font = `700 21px ${FONT}`;
    ctx.fillText(`${unlocked.length} de ${BADGES.length}`, 1720, 706);
    ctx.restore();

    let bx = 110;
    unlocked.forEach(s => {
        drawBadge(ctx, s.b, bx, 750, true);
        bx += 74;
    });
    let lx = 80 + 23;
    if (unlocked.length) {
        const divX = bx - 74 + 52;
        ctx.strokeStyle = "rgba(255,255,255,0.18)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(divX, 728);
        ctx.lineTo(divX, 772);
        ctx.stroke();
        lx = divX + 45;
    }
    locked.forEach(s => {
        drawBadge(ctx, s.b, lx, 750, false);
        lx += 54;
    });

    /* 7. Tier progress */
    ctx.save();
    labelStyle(21);
    spaced(ctx, "PROGRESSO DE NÍVEL", 80, 838, 2.5, "left");
    ctx.textAlign = "right";
    ctx.fillStyle = "#e5e7eb";
    ctx.font = `700 23px ${FONT}`;
    ctx.fillText(next ? `Faltam ${fmtBRL(falta).replace(/,00$/, "")} para ${next.name}` : "Nível máximo atingido", 1720, 838);
    ctx.restore();

    const ty = 874, tx0 = 124, tx1 = 1676;
    const step = (tx1 - tx0) / (tiers.length - 1);
    ctx.save();
    ctx.lineCap = "round";
    ctx.lineWidth = 6;
    ctx.strokeStyle = "rgba(255,255,255,0.08)";
    ctx.beginPath();
    ctx.moveTo(tx0, ty);
    ctx.lineTo(tx1, ty);
    ctx.stroke();
    for (let i = 0; i < tierIdx; i++) {
        ctx.strokeStyle = tiers[i + 1].color;
        ctx.beginPath();
        ctx.moveTo(tx0 + step * i, ty);
        ctx.lineTo(tx0 + step * (i + 1), ty);
        ctx.stroke();
    }
    ctx.restore();

    tiers.forEach((t, i) => {
        const x = tx0 + step * i;
        ctx.save();
        if (i === tierIdx) {
            ctx.shadowColor = hexToRgba(accent, 0.8);
            ctx.shadowBlur = 22;
            ctx.fillStyle = lighten(accent, 0.55);
            ctx.beginPath();
            for (let k = 0; k < 6; k++) {
                const a = (Math.PI / 3) * k - Math.PI / 2;
                const px = x + Math.cos(a) * 24, py = ty + Math.sin(a) * 24;
                k ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
            }
            ctx.closePath();
            ctx.fill();
            ctx.shadowBlur = 0;
            ctx.fillStyle = "#15161a";
            ctx.beginPath();
            ctx.arc(x, ty, 8, 0, Math.PI * 2);
            ctx.fill();
        } else if (i < tierIdx) {
            ctx.fillStyle = hexToRgba(t.color, 0.55);
            ctx.strokeStyle = t.color;
            ctx.lineWidth = 4;
            ctx.beginPath();
            ctx.arc(x, ty, 14, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();
        } else {
            ctx.fillStyle = "#17181c";
            ctx.strokeStyle = hexToRgba(t.color, 0.55);
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.arc(x, ty, 11, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();
            ctx.fillStyle = hexToRgba(t.color, 0.25);
            ctx.beginPath();
            ctx.arc(x, ty, 5, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.restore();

        ctx.save();
        ctx.textAlign = "center";
        ctx.textBaseline = "alphabetic";
        if (i === tierIdx) {
            ctx.font = `800 ${tiers.length > 8 ? 20 : 24}px ${FONT}`;
            ctx.fillStyle = "#ffffff";
            ctx.fillText(t.name, x, 926);
        } else {
            ctx.font = `500 ${tiers.length > 8 ? 17 : 22}px ${FONT}`;
            ctx.fillStyle = i < tierIdx ? t.color : hexToRgba(t.color, 0.55);
            ctx.fillText(t.name, x, 927);
        }
        ctx.restore();
    });

    /* 8. Rodapé */
    ctx.save();
    ctx.textAlign = "center";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "#f87171";
    ctx.font = `700 24px ${FONT}`;
    ctx.fillText(cleanText(pick(opts.warning, "Reputação alta não significa confiança. Sempre use um middleman.")), W / 2, 999);
    ctx.fillStyle = "#9ca3af";
    ctx.font = `500 20px ${FONT}`;
    ctx.fillText(
        cleanText(pick(opts.brandFooter, opts.perfilBrandFooter, "NEUX MEDIAÇÃO")),
        W / 2,
        1035
    );
    ctx.restore();

    /* 9. Linha na borda esquerda, na cor do cargo */
    /* Forte no topo e vai enfraquecendo para baixo (a cor continua aparecendo).
       Feito em faixas finas, sem gradiente, para funcionar no seu servidor. */
    const FAIXAS = 96;
    const altFaixa = H / FAIXAS;
    for (let i = 0; i < FAIXAS; i++) {
        const t = i / (FAIXAS - 1);
        const y = Math.floor(i * altFaixa);
        ctx.fillStyle = hexToRgba(accent, 1 - t * 0.78);
        ctx.fillRect(0, y, 12, Math.ceil(altFaixa) + 1);
        ctx.fillStyle = `rgba(255,255,255,${(0.2 - t * 0.17).toFixed(3)})`;
        ctx.fillRect(0, y, 3, Math.ceil(altFaixa) + 1);
    }

    return canvas.toBuffer("image/png");
}

/* Se der qualquer erro, devolve uma imagem com o erro escrito (aparece direto no Discord) */
async function gerarCartaoPerfil(opts) {
    try {
        console.log("[perfilCard] gerando cartão para:", opts && opts.username);
        const buf = await gerarCartaoPerfilInterno(opts);
        console.log("[perfilCard] cartão gerado, bytes:", buf && buf.length);
        return buf;
    } catch (e) {
        console.error("[perfilCard] ERRO:", e);
        const canvas = createCanvas(1400, 500);
        const ctx = canvas.getContext("2d");
        ctx.fillStyle = "#111215";
        ctx.fillRect(0, 0, 1400, 500);
        ctx.fillStyle = "#f87171";
        ctx.font = "bold 36px sans-serif";
        ctx.fillText("ERRO AO GERAR O PERFIL", 40, 70);
        ctx.fillStyle = "#e5e7eb";
        ctx.font = "24px sans-serif";
        const texto = String((e && e.stack) || e).split("\n").slice(0, 9);
        texto.forEach((linha, i) => ctx.fillText(linha.slice(0, 95), 40, 130 + i * 38));
        return canvas.toBuffer("image/png");
    }
}

module.exports = { gerarCartaoPerfil };
module.exports.default = { gerarCartaoPerfil };
