import express from 'express';
import path from 'path';
import fs from 'fs';
import os from 'os';
import http from 'http';
import https from 'https';
import { createRequire } from 'module';
const require = createRequire(path.resolve('server.ts'));
process.setMaxListeners(100);
import esbuild from 'esbuild';
import { createServer as createViteServer, build as viteBuild } from 'vite';
import JSZip from 'jszip';
import {
  getMongoStatus,
  syncDatabaseToMongo,
  loadDatabaseFromMongo,
  setMongoUri,
  getMongoDb,
  backupBotFilesToMongo,
  listMongoBotBackups,
  getMongoBotBackupById,
  deleteMongoBotBackup,
  connectToMongoDB,
  disconnectFromMongoDB,
  DEFAULT_BACKUP_CONFIG,
  MongoAutoBackupConfig
} from './src/lib/mongodb';
import * as DiscordJS from 'discord.js';
import {
  Client as DiscordClient,
  GatewayIntentBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  Partials,
  Collection,
  AttachmentBuilder,
  ActivityType,
  Events,
  SlashCommandBuilder,
  REST,
  Routes,
  PermissionFlagsBits,
  ChannelType,
  ComponentType,
  TextInputBuilder,
  TextInputStyle,
  ModalBuilder,
  StringSelectMenuBuilder,
  UserSelectMenuBuilder,
  RoleSelectMenuBuilder,
  MentionableSelectMenuBuilder,
  ChannelSelectMenuBuilder
} from 'discord.js';

const rawPath = (path as any).default || path;
const pathModule: any = {
  ...rawPath,
  join: (...args: string[]) => {
    try {
      if (typeof rawPath.join === 'function') return rawPath.join(...args);
      if (typeof path.join === 'function') return path.join(...args);
      if ((path as any).default && typeof (path as any).default.join === 'function') return (path as any).default.join(...args);
      return args.filter(Boolean).join('/').replace(/\/+/g, '/');
    } catch {
      return args.filter(Boolean).join('/').replace(/\/+/g, '/');
    }
  },
  resolve: (...args: string[]) => {
    try {
      if (typeof rawPath.resolve === 'function') return rawPath.resolve(...args);
      if (typeof path.resolve === 'function') return path.resolve(...args);
      if ((path as any).default && typeof (path as any).default.resolve === 'function') return (path as any).default.resolve(...args);
      return args.filter(Boolean).join('/').replace(/\/+/g, '/');
    } catch {
      return args.filter(Boolean).join('/').replace(/\/+/g, '/');
    }
  },
  basename: (p: string, ext?: string) => {
    try {
      if (typeof rawPath.basename === 'function') return rawPath.basename(p, ext);
      if (typeof path.basename === 'function') return path.basename(p, ext);
      if ((path as any).default && typeof (path as any).default.basename === 'function') return (path as any).default.basename(p, ext);
      const b = (p || '').split(/[/\\]/).pop() || '';
      return ext && b.endsWith(ext) ? b.slice(0, -ext.length) : b;
    } catch {
      return p || '';
    }
  },
  dirname: (p: string) => {
    try {
      if (typeof rawPath.dirname === 'function') return rawPath.dirname(p);
      if (typeof path.dirname === 'function') return path.dirname(p);
      if ((path as any).default && typeof (path as any).default.dirname === 'function') return (path as any).default.dirname(p);
      const parts = (p || '').split(/[/\\]/);
      parts.pop();
      return parts.join('/') || '.';
    } catch {
      return '.';
    }
  },
  extname: (p: string) => {
    try {
      if (typeof rawPath.extname === 'function') return rawPath.extname(p);
      if (typeof path.extname === 'function') return path.extname(p);
      if ((path as any).default && typeof (path as any).default.extname === 'function') return (path as any).default.extname(p);
      const dot = (p || '').lastIndexOf('.');
      return dot !== -1 ? (p || '').slice(dot) : '';
    } catch {
      return '';
    }
  }
};

// Global Patch for GuildChannelManager.prototype.create (support v13 & v14 signatures & string channel types for Tickets)
const recentChannelCreations = new Map<string, number>();

if (DiscordJS.GuildChannelManager && DiscordJS.GuildChannelManager.prototype) {
  const origGuildChannelCreate = DiscordJS.GuildChannelManager.prototype.create;
  DiscordJS.GuildChannelManager.prototype.create = async function(nameOrOptions: any, optionsOrType?: any) {
    let finalOptions: any = {};
    if (typeof nameOrOptions === 'string') {
      finalOptions = (typeof optionsOrType === 'object' && optionsOrType !== null) ? { ...optionsOrType } : {};
      finalOptions.name = nameOrOptions;
      if (typeof optionsOrType === 'string' || typeof optionsOrType === 'number') {
        finalOptions.type = optionsOrType;
      }
    } else if (typeof nameOrOptions === 'object' && nameOrOptions !== null) {
      finalOptions = { ...nameOrOptions };
    }

    // Anti-duplicação de criação de canais em menos de 2 segundos para o mesmo nome
    const channelKey = `${this.guild?.id || 'guild'}_${finalOptions.name || ''}`;
    const lastCreation = recentChannelCreations.get(channelKey);
    const now = Date.now();
    if (lastCreation && now - lastCreation < 2000) {
      // Já foi criado um canal com esse nome há menos de 2s, procura se o canal existe no cache
      const existingChannel = this.guild?.channels?.cache?.find((c: any) => c.name === finalOptions.name);
      if (existingChannel) {
        return existingChannel;
      }
    }
    recentChannelCreations.set(channelKey, now);

    // Convert string channel type (e.g. 'GUILD_TEXT', 'text', 'GUILD_CATEGORY', 'category')
    if (typeof finalOptions.type === 'string') {
      const t = finalOptions.type.toUpperCase();
      if (t === 'GUILD_TEXT' || t === 'TEXT') finalOptions.type = ChannelType.GuildText;
      else if (t === 'GUILD_VOICE' || t === 'VOICE') finalOptions.type = ChannelType.GuildVoice;
      else if (t === 'GUILD_CATEGORY' || t === 'CATEGORY') finalOptions.type = ChannelType.GuildCategory;
      else if (t === 'GUILD_ANNOUNCEMENT' || t === 'ANNOUNCEMENT' || t === 'NEWS') finalOptions.type = ChannelType.GuildAnnouncement;
      else if (t === 'GUILD_STAGE_VOICE' || t === 'STAGE') finalOptions.type = ChannelType.GuildStageVoice;
      else if (t === 'GUILD_FORUM' || t === 'FORUM') finalOptions.type = ChannelType.GuildForum;
    }

    // Normalize permissionOverwrites if provided
    if (Array.isArray(finalOptions.permissionOverwrites)) {
      finalOptions.permissionOverwrites = finalOptions.permissionOverwrites.map((po: any) => {
        if (!po || typeof po !== 'object') return po;
        const normalizePerm = (p: any) => {
          if (typeof p === 'string' && p.includes('_')) {
            return p.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join('');
          }
          return p;
        };
        return {
          ...po,
          allow: Array.isArray(po.allow) ? po.allow.map(normalizePerm) : po.allow,
          deny: Array.isArray(po.deny) ? po.deny.map(normalizePerm) : po.deny
        };
      });
    }

    return await origGuildChannelCreate.call(this, finalOptions);
  };
}

// Global Patch for ButtonBuilder.prototype.toJSON across DiscordJS and Builders
try {
  const Builders = require('@discordjs/builders');
  if (Builders && typeof Builders.disableValidators === 'function') {
    Builders.disableValidators();
  }
  const patchButtonClass = (btnClass: any) => {
    if (btnClass && btnClass.prototype) {
      const origToJSON = btnClass.prototype.toJSON;
      btnClass.prototype.toJSON = function() {
        if (this.data) {
          if (this.data.url && typeof this.data.url === 'string' && this.data.url.trim().length > 0) {
            this.data.style = 5; // Link
            delete this.data.custom_id;
          } else {
            delete this.data.url;
            if (this.data.style === 5 || this.data.style === 'Link') {
              this.data.style = 1; // Primary
            }
          }
        }
        try {
          return origToJSON.call(this);
        } catch (e) {
          const d = this.data || {};
          return {
            type: 2,
            style: d.style || 1,
            label: d.label || 'Botão',
            custom_id: d.custom_id || `btn_${Date.now()}`,
            disabled: !!d.disabled,
            emoji: d.emoji
          };
        }
      };
    }
  };
  patchButtonClass(DiscordJS.ButtonBuilder);
  if (Builders && Builders.ButtonBuilder) {
    patchButtonClass(Builders.ButtonBuilder);
  }
} catch (e) {}

if (!process.env.DISCORD_TOKEN && !process.env.TOKEN) {
  process.env.DISCORD_TOKEN = "MTQzODM1MzgyMzIzNTA1MTY0Mg.GjK93S.RPBT6-GX3XNy77U0XeEPMqfNfKcXdBPMpXLoAI";
}

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

let detectedPublicOrigin = process.env.PUBLIC_APP_URL || '';

// Detect public incoming hostname so outgoing self-ping can target Cloud Run ingress
app.use((req, res, next) => {
  const forwardedHost = (req.headers['x-forwarded-host'] as string) || req.headers.host;
  const forwardedProto = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'https';
  if (forwardedHost && typeof forwardedHost === 'string' && !forwardedHost.includes('localhost') && !forwardedHost.includes('127.0.0.1')) {
    // In AI Studio, ais-dev- URLs require Google login; ais-pre- URLs are completely public without login
    const cleanHost = forwardedHost.replace('ais-dev-', 'ais-pre-');
    detectedPublicOrigin = `${forwardedProto}://${cleanHost}`;
  }
  next();
});

// Initial Seed Bots for BotLoom Hosting
const DATA_DIR = path.join(process.cwd(), 'data');
const BOTS_FILE = path.join(DATA_DIR, 'bots.json');
const APP_DB_FILE = path.join(DATA_DIR, 'app_database.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

interface BotData {
  id: string;
  botId: string;
  name: string;
  status: 'online' | 'offline' | 'starting' | 'error' | 'installing';
  token?: string;
  prefix: string;
  description: string;
  icon: string;
  createdAt: string;
  lastRunAt: string | null;
  files: { name: string; path: string; content: string }[];
  dependencies: Record<string, string>;
  stats: {
    cpuUsage: number;
    memoryUsage: number;
    maxMemory: number;
    uptimeSeconds: number;
  };
  logs: { id: string; timestamp: string; type: string; message: string }[];
  autoRestart: boolean;
  version: string;
}

// Global in-memory bots store (declared early to prevent TDZ reference errors on startup)
let botsStore: BotData[] = [];

// Active real Discord clients in memory
const activeDiscordClients = new Map<string, DiscordClient>();
const sharedGatewayClients = new Map<string, DiscordClient>();
const tokenCommandsMap = new Map<string, Map<string, any[]>>();
const botEventListeners = new Map<string, Array<{ event: string; fn: any }>>();

function registerUnifiedCommandsForToken(token: string, botId: string, commands: any[]): any[] {
  if (!token) return Array.isArray(commands) ? commands : [commands];
  if (!tokenCommandsMap.has(token)) {
    tokenCommandsMap.set(token, new Map<string, any[]>());
  }
  const botMap = tokenCommandsMap.get(token)!;
  botMap.set(botId, Array.isArray(commands) ? commands : [commands]);

  const mergedMap = new Map<string, any>();
  botMap.forEach((cmdList) => {
    cmdList.forEach(cmd => {
      let name: string | null = null;
      if (typeof cmd === 'object' && cmd !== null) {
        if (typeof cmd.name === 'string') name = cmd.name;
        else if (typeof cmd.toJSON === 'function') {
          try { name = cmd.toJSON().name; } catch (e) {}
        }
      }
      if (name) {
        mergedMap.set(name.toLowerCase(), cmd);
      }
    });
  });

  return Array.from(mergedMap.values());
}

// Global claimed interactions registry to ensure STRICTLY ONE bot ever processes any given interaction
const claimedInteractionIds = new Map<string, { botId: string; timestamp: number }>();
setInterval(() => {
  const now = Date.now();
  for (const [id, claim] of claimedInteractionIds.entries()) {
    if (now - claim.timestamp > 120000) {
      claimedInteractionIds.delete(id);
    }
  }
}, 30000);

function scoreBotForInteraction(bot: BotData, interaction: any): number {
  if (!interaction) return 0;
  let score = 0;
  const botCode = (bot.files || [])
    .filter(f => f.name.endsWith('.js') || f.name.endsWith('.ts'))
    .map(f => f.content)
    .join('\n');

  if (interaction.isChatInputCommand && interaction.isChatInputCommand()) {
    const cmdName = (interaction.commandName || '').toLowerCase();
    if (!cmdName) return 0;

    const isLeilao = bot.name.toLowerCase().includes('leil');
    const isTicket = bot.name.toLowerCase().includes('ticket') || bot.id === 'bot-1791057681205';
    const isMm = bot.name.toLowerCase().includes('middleman') || bot.name.toLowerCase().includes('midl') || bot.files.some(f => f.name === 'trade_data.json' || f.name === 'users_mm.json');
    const isVendedor = bot.name.toLowerCase().includes('vendedor') || bot.name.toLowerCase().includes('venda');
    const isNeux = bot.name.toLowerCase().includes('neux') && !isTicket;

    if (isTicket && ['setup_ticket', 'ticket', 'painelticket'].includes(cmdName)) score += 100;
    if (isLeilao && ['painelleilao', 'setup_leilao', 'leilao', 'pixleilao'].includes(cmdName)) score += 100;
    if (isVendedor && ['produtos', 'vender', 'painelvendedor', 'estoque', 'loja', 'catalogo', 'painel'].includes(cmdName)) score += 100;
    if (isMm && ['configpix', 'ranking', 'perfil', 'vouch', 'aprovar_pagamento', 'remover_valor', 'alterar_intermediacoes', 'passar-posse'].includes(cmdName)) score += 100;
    if (isNeux && ['neux', 'ajuda', 'suporte'].includes(cmdName)) score += 100;

    const exactPatterns = [
      new RegExp('commandName\\s*===?\\s*["\'`]' + cmdName + '["\'`]', 'i'),
      new RegExp('case\\s*["\'`]' + cmdName + '["\'`]', 'i'),
      new RegExp('setName\\s*\\(\\s*["\'`]' + cmdName + '["\'`]', 'i')
    ];
    if (exactPatterns.some(p => p.test(botCode))) score += 80;

    return score;
  }

  const customId = (interaction.customId || '');
  if (!customId || customId.startsWith('sys_')) return 0;

  const isTicket = bot.name.toLowerCase().includes('ticket') || bot.id === 'bot-1791057681205';
  const isMm = bot.name.toLowerCase().includes('middleman') || bot.name.toLowerCase().includes('midl') || bot.files.some(f => f.name === 'trade_data.json' || f.name === 'users_mm.json');
  const isVendedor = bot.name.toLowerCase().includes('vendedor') || bot.name.toLowerCase().includes('venda');
  const isLeilao = bot.name.toLowerCase().includes('leil');

  if (isTicket && (
    ['dropdown_ticket', 'claim_btn', 'admin_btn', 'close_btn', 'admin_add_user', 'admin_rem_user', 'admin_notify_owner', 'modal_add_user', 'modal_rem_user', 'modal_notify_owner'].includes(customId) ||
    customId.startsWith('ticket_') || customId.startsWith('claim_') || customId.startsWith('close_') || customId.startsWith('admin_')
  )) score += 100;

  if (isVendedor && (
    ['escolher_tier', 'btn_ver_produtos', 'btn_comprar_produto', 'btn_carrinho', 'btn_painel_vendas', 'modal_cadastrar_produto', 'modal_comprar_qtd'].includes(customId) ||
    customId.startsWith('pagar:') || customId.startsWith('copiar:') || customId.startsWith('comp:') || customId.startsWith('modal:') || customId.startsWith('aprovar:') || customId.startsWith('recusar:') ||
    customId.startsWith('vendedor_') || customId.startsWith('prod_') || customId.startsWith('compra_')
  )) score += 100;

  if (isLeilao && (
    ['iniciar_anuncio_leilao', 'modal_anuncio_1', 'select_categoria_leilao', 'confirmar_fluxo', 'escolher_tipo', 'modal_unitario', 'modal_base', 'modal_leilao', 'ativar_disc', 'pular_disc', 'permitir_lances_txt', 'apenas_botoes', 'select_cat', 'copy_pix', 'aprovar_final', 'btn_configuracoes', 'btn_editar_lances', 'btn_dar_dole', 'btn_dar_lance', 'btn_historico', 'confirmar_encerramento_final', 'cancelar_encerramento', 'modal_efetuar_lance', 'remover_lance_select', 'admin_select_tudo', 'fechar_ticket', 'reivindicar_pagamento'].includes(customId) ||
    customId.startsWith('lance_') || customId.startsWith('leilao_')
  )) score += 100;

  if (isMm && (
    ['abrir_mediacao', 'menu_mm', 'add_user_menu', 'escolher_outro', 'set_enviador', 'set_recebedor', 'confirm_trade', 'btn_reivindicar', 'btn_recebi_valor', 'btn_paguei_vendedor', 'confirmar_entrega_user', 'selecionar_tipo_pix', 'btn_termos', 'resetar_fluxo', 'btn_fechar', 'rank_select', 'modal_config_pix', 'mm_perfil', 'mm_mes', 'mm_dia', 'mm_pessoas'].includes(customId) ||
    customId.startsWith('confirm_target_') || customId.startsWith('taxa_') || customId.startsWith('dividirtaxa_') || customId.startsWith('pagartaxa_') || customId.startsWith('confirmar_pix_') || customId.startsWith('reivindicar_') || customId.startsWith('modal_chave_final_') || customId.startsWith('copychave_') || customId.startsWith('qr_') || customId.startsWith('copy_') || customId.startsWith('av_') || customId.startsWith('modal_avaliacao_') || customId.startsWith('modal_mm_') || customId.startsWith('modal_avaliar_') || customId.startsWith('abrir_transcript_') || customId.startsWith('transcricao_') || customId.startsWith('rank')
  )) score += 100;

  if (botCode.includes("'" + customId + "'") || botCode.includes('"' + customId + '"') || botCode.includes('`' + customId + '`')) {
    score += 80;
  } else if (botCode.includes(customId)) {
    score += 40;
  }

  return score;
}

function resolveTargetBotForInteraction(interaction: any, candidateBots: BotData[]): BotData | null {
  if (!candidateBots || candidateBots.length === 0) return null;
  if (candidateBots.length === 1) return candidateBots[0];
  let highestScore = 0;
  let winner: BotData | null = null;
  for (const bot of candidateBots) {
    const s = scoreBotForInteraction(bot, interaction);
    if (s > highestScore) {
      highestScore = s;
      winner = bot;
    }
  }
  if (!winner) {
    winner = candidateBots.find(b => botHandlesInteraction(b, interaction)) || candidateBots[0];
  }
  return winner;
}

function botHandlesInteraction(bot: BotData, interaction: any): boolean {
  if (!interaction) return false;

  const botCode = (bot.files || [])
    .filter(f => f.name.endsWith('.js') || f.name.endsWith('.ts'))
    .map(f => f.content)
    .join('\n');

  if (interaction.isChatInputCommand && interaction.isChatInputCommand()) {
    const cmdName = (interaction.commandName || '').toLowerCase();
    if (!cmdName) return false;

    const patterns = [
      new RegExp('commandName\\s*===?\\s*["\'`]' + cmdName + '["\'`]', 'i'),
      new RegExp('case\\s*["\'`]' + cmdName + '["\'`]', 'i'),
      new RegExp('setName\\s*\\(\\s*["\'`]' + cmdName + '["\'`]', 'i'),
      new RegExp('name:\\s*["\'`]' + cmdName + '["\'`]', 'i')
    ];

    if (patterns.some(p => p.test(botCode))) return true;

    const isLeilao = bot.name.toLowerCase().includes('leil');
    const isTicket = bot.name.toLowerCase().includes('ticket') || bot.id === 'bot-1791057681205';
    const isMm = bot.name.toLowerCase().includes('middleman') || bot.name.toLowerCase().includes('midl') || bot.files.some(f => f.name === 'trade_data.json' || f.name === 'users_mm.json');
    const isVendedor = bot.name.toLowerCase().includes('vendedor') || bot.name.toLowerCase().includes('venda');
    const isNeux = bot.name.toLowerCase().includes('neux') && !isTicket;

    if (isLeilao && ['painelleilao', 'setup_leilao', 'leilao', 'pixleilao'].includes(cmdName)) return true;
    if (isTicket && ['setup_ticket', 'ticket', 'painelticket'].includes(cmdName)) return true;
    if (isMm && ['configpix', 'ranking', 'perfil', 'vouch', 'aprovar_pagamento', 'remover_valor', 'passar-posse'].includes(cmdName)) return true;
    if (isVendedor && ['produtos', 'vender', 'painelvendedor', 'estoque', 'loja', 'catalogo', 'painel'].includes(cmdName)) return true;
    if (isNeux && ['neux', 'ajuda', 'suporte'].includes(cmdName)) return true;

    return false;
  }

  const customId = (interaction.customId || '');
  if (!customId) return false;
  if (customId.startsWith('sys_')) return false;

  // 1. Direct exact match in bot's files
  if (botCode.includes(customId)) return true;

  // 2. Dynamic startsWith match: any prefix queried in botCode with .startsWith('prefix')
  const codePrefixes = [...botCode.matchAll(/customId\.startsWith\s*\(\s*['"`]([^'"`]+)['"`]\)/g)].map(m => m[1]);
  for (const prefix of codePrefixes) {
    if (customId.startsWith(prefix)) return true;
  }

  // 3. Known bot domain prefixes & buttons
  const isTicket = bot.name.toLowerCase().includes('ticket') || bot.id === 'bot-1791057681205';
  if (isTicket && (
    customId === 'dropdown_ticket' ||
    customId === 'claim_btn' ||
    customId === 'admin_btn' ||
    customId === 'close_btn' ||
    customId === 'admin_add_user' ||
    customId === 'admin_rem_user' ||
    customId === 'admin_notify_owner' ||
    customId === 'modal_add_user' ||
    customId === 'modal_rem_user' ||
    customId === 'modal_notify_owner' ||
    customId.startsWith('ticket_') ||
    customId.startsWith('claim_') ||
    customId.startsWith('close_') ||
    customId.startsWith('admin_')
  )) {
    return true;
  }

  const isVendedor = bot.name.toLowerCase().includes('vendedor') || bot.name.toLowerCase().includes('venda');
  if (isVendedor && (
    customId === 'escolher_tier' ||
    customId === 'btn_ver_produtos' ||
    customId === 'btn_comprar_produto' ||
    customId === 'btn_carrinho' ||
    customId === 'btn_painel_vendas' ||
    customId === 'modal_cadastrar_produto' ||
    customId === 'modal_comprar_qtd' ||
    customId.startsWith('pagar:') ||
    customId.startsWith('copiar:') ||
    customId.startsWith('comp:') ||
    customId.startsWith('modal:') ||
    customId.startsWith('aprovar:') ||
    customId.startsWith('recusar:') ||
    customId.startsWith('vendedor_') ||
    customId.startsWith('prod_') ||
    customId.startsWith('compra_')
  )) {
    return true;
  }

  const isMm = bot.name.toLowerCase().includes('middleman') || bot.name.toLowerCase().includes('midl') || bot.files.some(f => f.name === 'trade_data.json' || f.name === 'users_mm.json');
  if (isMm && (
    customId === 'abrir_mediacao' ||
    customId === 'menu_mm' ||
    customId === 'add_user_menu' ||
    customId === 'escolher_outro' ||
    customId === 'set_enviador' ||
    customId === 'set_recebedor' ||
    customId === 'confirm_trade' ||
    customId === 'btn_reivindicar' ||
    customId === 'btn_recebi_valor' ||
    customId === 'btn_paguei_vendedor' ||
    customId === 'confirmar_entrega_user' ||
    customId === 'selecionar_tipo_pix' ||
    customId === 'btn_termos' ||
    customId === 'resetar_fluxo' ||
    customId === 'btn_fechar' ||
    customId === 'rank_select' ||
    customId === 'modal_config_pix' ||
    customId === 'mm_perfil' ||
    customId === 'mm_mes' ||
    customId === 'mm_dia' ||
    customId === 'mm_pessoas' ||
    customId.startsWith('confirm_target_') ||
    customId.startsWith('taxa_') ||
    customId.startsWith('dividirtaxa_') ||
    customId.startsWith('pagartaxa_') ||
    customId.startsWith('confirmar_pix_') ||
    customId.startsWith('reivindicar_') ||
    customId.startsWith('modal_chave_final_') ||
    customId.startsWith('copychave_') ||
    customId.startsWith('qr_') ||
    customId.startsWith('copy_') ||
    customId.startsWith('av_') ||
    customId.startsWith('modal_avaliacao_') ||
    customId.startsWith('modal_mm_') ||
    customId.startsWith('modal_avaliar_') ||
    customId.startsWith('abrir_transcript_') ||
    customId.startsWith('transcricao_') ||
    customId.startsWith('rank')
  )) {
    return true;
  }

  const isLeilao = bot.name.toLowerCase().includes('leil');
  if (isLeilao && (
    customId === 'iniciar_anuncio_leilao' ||
    customId === 'modal_anuncio_1' ||
    customId === 'select_categoria_leilao' ||
    customId === 'confirmar_fluxo' ||
    customId === 'escolher_tipo' ||
    customId === 'modal_unitario' ||
    customId === 'modal_base' ||
    customId === 'modal_leilao' ||
    customId === 'ativar_disc' ||
    customId === 'pular_disc' ||
    customId === 'permitir_lances_txt' ||
    customId === 'apenas_botoes' ||
    customId === 'select_cat' ||
    customId === 'copy_pix' ||
    customId === 'aprovar_final' ||
    customId === 'fechar_ticket' ||
    customId === 'reivindicar_pagamento' ||
    customId === 'btn_configuracoes' ||
    customId === 'btn_editar_lances' ||
    customId === 'btn_dar_dole' ||
    customId === 'btn_dar_lance' ||
    customId === 'btn_historico' ||
    customId === 'confirmar_encerramento_final' ||
    customId === 'cancelar_encerramento' ||
    customId === 'modal_efetuar_lance' ||
    customId === 'remover_lance_select' ||
    customId === 'admin_select_tudo' ||
    customId.includes('leilao') ||
    customId.startsWith('lance_') ||
    customId.startsWith('leilao_')
  )) {
    return true;
  }

  return false;
}

function isValidTokenString(t: string | undefined | null): boolean {
  if (!t) return false;
  const trimmed = t.trim();
  if (trimmed.length < 25) return false;
  const upper = trimmed.toUpperCase();
  if (
    upper.includes('SECRETKEYDEMO') ||
    upper.includes('SECRET') ||
    upper.includes('YOUR_TOKEN') ||
    upper.includes('SEU_TOKEN') ||
    upper.includes('DISCORD_TOKEN') ||
    upper.includes('TOKEN_AQUI') ||
    upper.includes('COLOCAR_TOKEN') ||
    upper.includes('KEY_AQUI')
  ) {
    return false;
  }
  return true;
}

function extractToken(bot: BotData): string | null {
  if (isValidTokenString(bot.token)) {
    return bot.token.trim();
  }
  const envFile = bot.files.find(f => f.name === '.env' || f.path === '.env');
  if (envFile) {
    const match = envFile.content.match(/(?:DISCORD_TOKEN|TOKEN)\s*=\s*["']?([^"'\r\n]+)["']?/i);
    if (match && match[1] && isValidTokenString(match[1])) {
      return match[1].trim();
    }
  }
  return null;
}

async function stopDiscordClient(botId: string) {
  const bot = botsStore.find(b => b.id === botId);
  const token = bot ? extractToken(bot) : null;

  // Detach bot listeners
  const listeners = botEventListeners.get(botId);
  const client = activeDiscordClients.get(botId);
  if (client && listeners) {
    const remover = (client as any).__rawRemoveListener || client.removeListener.bind(client);
    listeners.forEach(({ event, fn }) => {
      try {
        remover(event, fn);
      } catch (e) {}
    });
  }
  botEventListeners.delete(botId);
  activeDiscordClients.delete(botId);

  // If other active bots still use this token, keep the shared gateway client running!
  if (token && sharedGatewayClients.has(token)) {
    const otherOnlineBots = botsStore.filter(b => b.id !== botId && b.status === 'online' && extractToken(b) === token);
    if (otherOnlineBots.length === 0) {
      const shared = sharedGatewayClients.get(token);
      if (shared) {
        try {
          shared.removeAllListeners();
          shared.destroy();
        } catch (e) {
          console.error('Erro ao encerrar bot discord:', e);
        }
      }
      sharedGatewayClients.delete(token);
    }
  }
}

function patchInteraction(interaction: any, bot?: BotData) {
  if (!interaction || interaction.__is_patched) return;
  interaction.__is_patched = true;

  const isIgnoreError = (err: any) => {
    const code = err?.code || err?.rawError?.code;
    const str = String(err?.stack || err?.message || err);
    return (
      code === 10062 ||
      code === 40060 ||
      code === 50027 ||
      str.includes('AlreadyReplied') ||
      str.includes('Unknown interaction') ||
      str.includes('already been acknowledged')
    );
  };

  const origReply = interaction.reply?.bind(interaction);
  if (origReply) {
    interaction.reply = async function(...args: any[]) {
      if (interaction.replied) {
        // Drop duplicate replies so Discord NEVER gets multiple messages or followups
        return null;
      }
      if (interaction.deferred) {
        try {
          return await interaction.editReply(...args);
        } catch (e) {
          if (isIgnoreError(e)) return null;
          throw e;
        }
      }
      try {
        return await origReply(...args);
      } catch (err: any) {
        if (isIgnoreError(err)) return null;
        throw err;
      }
    };
  }

  const origDeferReply = interaction.deferReply?.bind(interaction);
  if (origDeferReply) {
    interaction.deferReply = async function(...args: any[]) {
      if (interaction.deferred || interaction.replied) {
        return null;
      }
      try {
        return await origDeferReply(...args);
      } catch (err: any) {
        if (isIgnoreError(err)) return null;
        throw err;
      }
    };
  }

  const origEditReply = interaction.editReply?.bind(interaction);
  if (origEditReply) {
    interaction.editReply = async function(...args: any[]) {
      try {
        return await origEditReply(...args);
      } catch (err: any) {
        if (isIgnoreError(err)) return null;
        throw err;
      }
    };
  }

  const origFollowUp = interaction.followUp?.bind(interaction);
  if (origFollowUp) {
    interaction.followUp = async function(...args: any[]) {
      try {
        return await origFollowUp(...args);
      } catch (err: any) {
        if (isIgnoreError(err)) return null;
        throw err;
      }
    };
  }

  const origUpdate = interaction.update?.bind(interaction);
  if (origUpdate) {
    interaction.update = async function(...args: any[]) {
      if (interaction.replied) {
        return null;
      }
      if (interaction.deferred) {
        try {
          return await interaction.editReply?.(...args);
        } catch (e) {
          if (isIgnoreError(e)) return null;
          throw e;
        }
      }
      try {
        return await origUpdate(...args);
      } catch (err: any) {
        if (isIgnoreError(err)) return null;
        throw err;
      }
    };
  }

  const origDeferUpdate = interaction.deferUpdate?.bind(interaction);
  if (origDeferUpdate) {
    interaction.deferUpdate = async function(...args: any[]) {
      if (interaction.deferred || interaction.replied) {
        return null;
      }
      try {
        return await origDeferUpdate(...args);
      } catch (err: any) {
        if (isIgnoreError(err)) return null;
        throw err;
      }
    };
  }

  const origShowModal = interaction.showModal?.bind(interaction);
  if (origShowModal) {
    interaction.showModal = async function(...args: any[]) {
      if (interaction.replied || interaction.deferred) {
        return null;
      }
      try {
        return await origShowModal(...args);
      } catch (err: any) {
        if (isIgnoreError(err)) return null;
        throw err;
      }
    };
  }
}

// Rastreamento global para impedir duplicação de execução de interações
const processedInteractionIds = new Map<string, number>();
setInterval(() => {
  const now = Date.now();
  for (const [id, ts] of processedInteractionIds.entries()) {
    if (now - ts > 60000) processedInteractionIds.delete(id);
  }
}, 30000);

// Executes user-provided JS/TS bot files safely on the active Discord client
function executeUserScript(client: DiscordClient, bot: BotData) {
  // Select strictly ONE primary entry file (preferring bot.js, then index.js)
  let primaryFile = bot.files.find(f => {
    const name = (f.name || f.path || '').toLowerCase();
    return name === 'bot.js';
  });

  if (!primaryFile) {
    primaryFile = bot.files.find(f => {
      const name = (f.name || f.path || '').toLowerCase();
      return name === 'index.js' || name === 'main.js' || name === 'app.js' || name === 'index.ts' || name === 'main.ts' || name === 'bot.ts';
    });
  }

  const targetFiles = primaryFile ? [primaryFile] : bot.files.filter(f => f.name.endsWith('.js') || f.name.endsWith('.ts'));

  const token = extractToken(bot) || '';

  const envVars: Record<string, string> = {
    TOKEN: token,
    DISCORD_TOKEN: token,
    PREFIX: bot.prefix || '!',
    CLIENT_ID: bot.botId || ''
  };

  const envFile = bot.files.find(f => f.name === '.env' || f.path === '.env');
  if (envFile) {
    envFile.content.split('\n').forEach(line => {
      const parts = line.split('=');
      if (parts.length >= 2) {
        const key = parts[0].trim();
        const val = parts.slice(1).join('=').trim().replace(/^["']|["']$/g, '');
        if (key && !key.startsWith('#')) {
          envVars[key] = val;
        }
      }
    });
  }

  const customProcess = {
    ...process,
    env: envVars,
    on: (event: string, listener: any) => process.on(event as any, listener),
    once: (event: string, listener: any) => process.once(event as any, listener),
    removeListener: (event: string, listener: any) => process.removeListener(event as any, listener),
    removeAllListeners: (event?: string) => process.removeAllListeners(event as any),
    off: (event: string, listener: any) => process.off(event as any, listener),
    emit: (event: string, ...args: any[]) => process.emit(event as any, ...args),
    cwd: () => process.cwd(),
    nextTick: (cb: Function, ...args: any[]) => process.nextTick(cb, ...args),
    exit: (code?: number) => console.log(`[BOT PROCESS EXIT] Exit called with code ${code}`),
    platform: process.platform,
    version: process.version,
    uptime: () => process.uptime()
  };

  // Helper to transpile TS or ESM code into CJS for new Function evaluation
  function transpileCode(code: string): string {
    try {
      const res = esbuild.transformSync(code, {
        loader: 'ts',
        format: 'cjs',
        target: 'node18'
      });
      return res.code;
    } catch {
      return code;
    }
  }

  // Store native methods once on client instance so wrappers never nest recursively
  if (!(client as any).__rawOn) {
    (client as any).__rawOn = client.on.bind(client);
    (client as any).__rawOnce = client.once.bind(client);
    (client as any).__rawRemoveListener = client.removeListener.bind(client);
    (client as any).__rawRemoveAllListeners = client.removeAllListeners.bind(client);
    (client as any).__rawListenerCount = client.listenerCount.bind(client);
  }

  // 1. Clean up any previous listeners registered for THIS specific bot
  const prevListeners = botEventListeners.get(bot.id);
  if (prevListeners && Array.isArray(prevListeners)) {
    for (const item of prevListeners) {
      try {
        (client as any).__rawRemoveListener(item.event, item.fn);
      } catch (e) {}
    }
  }

  // Track user-registered listeners so reloading doesn't duplicate them
  const registeredUserListeners: Array<{ event: string; fn: any }> = [];
  botEventListeners.set(bot.id, registeredUserListeners);

  // Override client.login so calling client.login() in user script resolves smoothly
  (client as any).login = async function(userToken?: string) {
    if (client.isReady()) return token;
    try {
      return await DiscordJS.Client.prototype.login.call(client, userToken || token);
    } catch (e) {
      return token;
    }
  };

  const handleSafeInteractionWrapper = (interaction: any): boolean => {
    patchInteraction(interaction, bot);

    // Stale interaction check (Discord interaction token expires after 3 seconds)
    if (interaction.createdTimestamp && (Date.now() - interaction.createdTimestamp > 3200)) {
      return false;
    }

    const interactionId = interaction.id;
    if (interactionId) {
      const claim = claimedInteractionIds.get(interactionId);
      if (claim) {
        // Interaction already claimed by a bot on this token: drop all duplicate executions!
        return false;
      }
    }

    const currentBotToken = extractToken(bot);
    const sharingBots = currentBotToken
      ? botsStore.filter(b => (b.status === 'online' || b.status === 'starting' || b.id === bot.id) && extractToken(b) === currentBotToken)
      : [bot];

    if (sharingBots.length > 1) {
      if (!interaction.__resolvedTargetBotId) {
        const winner = resolveTargetBotForInteraction(interaction, sharingBots);
        if (winner) {
          interaction.__resolvedTargetBotId = winner.id;
        }
      }

      if (interaction.__resolvedTargetBotId && interaction.__resolvedTargetBotId !== bot.id) {
        // Another bot sharing this token is the designated handler for this interaction!
        return false;
      }
    }

    if (!botHandlesInteraction(bot, interaction)) {
      return false;
    }

    if (interactionId) {
      claimedInteractionIds.set(interactionId, { botId: bot.id, timestamp: Date.now() });
    }

    return true;
  };

  // Safe wrapper for client.on and client.once to catch and log errors in user handlers without crashing process
  (client as any).on = function(eventName: string, listener: (...args: any[]) => void) {
    const safeListener = async (...args: any[]) => {
      if (eventName === 'interactionCreate' && args[0]) {
        const ok = handleSafeInteractionWrapper(args[0]);
        if (!ok) return;
      }
      try {
        await listener(...args);
      } catch (err: any) {
        const errCode = err?.code || err?.rawError?.code;
        const errStr = String(err?.stack || err?.message || err);
        if (
          errCode === 40060 ||
          errCode === 10062 ||
          errCode === 50027 ||
          errStr.includes('AlreadyReplied') ||
          errStr.includes('Unknown interaction') ||
          errStr.includes('Interaction has already been acknowledged') ||
          errStr.includes('already been acknowledged')
        ) {
          return;
        }
        bot.logs.push({
          id: 'log-' + Date.now(),
          timestamp: new Date().toLocaleTimeString('pt-BR'),
          type: 'system',
          message: `❌ [ERRO CAPTURADO EM ${eventName}] ${errStr}`
        });
        saveBots(botsStore);
      }
    };
    (safeListener as any).__origListener = listener;
    registeredUserListeners.push({ event: eventName, fn: safeListener });
    const ret = (client as any).__rawOn(eventName, safeListener);
    if ((eventName === 'ready' || eventName === Events.ClientReady) && client.isReady()) {
      setImmediate(() => safeListener(client));
    }
    return ret;
  };

  (client as any).once = function(eventName: string, listener: (...args: any[]) => void) {
    const safeListener = async (...args: any[]) => {
      if (eventName === 'interactionCreate' && args[0]) {
        const ok = handleSafeInteractionWrapper(args[0]);
        if (!ok) return;
      }
      try {
        await listener(...args);
      } catch (err: any) {
        const errCode = err?.code || err?.rawError?.code;
        const errStr = String(err?.stack || err?.message || err);
        if (
          errCode === 40060 ||
          errCode === 10062 ||
          errCode === 50027 ||
          errStr.includes('AlreadyReplied') ||
          errStr.includes('Unknown interaction') ||
          errStr.includes('Interaction has already been acknowledged') ||
          errStr.includes('already been acknowledged')
        ) {
          return;
        }
        bot.logs.push({
          id: 'log-' + Date.now(),
          timestamp: new Date().toLocaleTimeString('pt-BR'),
          type: 'system',
          message: `❌ [ERRO CAPTURADO EM ${eventName}] ${errStr}`
        });
        saveBots(botsStore);
      }
    };
    (safeListener as any).__origListener = listener;
    registeredUserListeners.push({ event: eventName, fn: safeListener });
    const ret = (client as any).__rawOnce(eventName, safeListener);
    if ((eventName === 'ready' || eventName === Events.ClientReady) && client.isReady()) {
      setImmediate(() => safeListener(client));
    }
    return ret;
  };

  (client as any).removeAllListeners = function(eventName?: string) {
    for (let i = registeredUserListeners.length - 1; i >= 0; i--) {
      const item = registeredUserListeners[i];
      if (!eventName || item.event === eventName) {
        try {
          (client as any).__rawRemoveListener(item.event, item.fn);
        } catch (e) {}
        registeredUserListeners.splice(i, 1);
      }
    }
    return client;
  };

  (client as any).removeListener = function(eventName: string, listener: any) {
    const idx = registeredUserListeners.findIndex(l => l.event === eventName && (l.fn === listener || (l.fn as any).__origListener === listener));
    if (idx !== -1) {
      const item = registeredUserListeners[idx];
      try {
        (client as any).__rawRemoveListener(item.event, item.fn);
      } catch (e) {}
      registeredUserListeners.splice(idx, 1);
    }
    return client;
  };

  (client as any).listenerCount = function(eventName: string) {
    return registeredUserListeners.filter(l => l.event === eventName).length;
  };

  const origEmit = client.emit.bind(client);
  (client as any).emit = function(eventName: string, ...args: any[]) {
    if (eventName === 'interactionCreate' && args[0]) {
      patchInteraction(args[0], bot);
    }
    return origEmit(eventName, ...args);
  };

  // Patch client.application.commands.set if client is already initialized
  if (client.application && client.application.commands) {
    const origSet = client.application.commands.set.bind(client.application.commands);
    client.application.commands.set = async function(commands: any, guildId?: string) {
      const merged = registerUnifiedCommandsForToken(token, bot.id, commands);
      return await origSet(merged, guildId);
    };
  }

  class CustomREST extends REST {
    async put(url: string, options?: any) {
      if (typeof url === 'string' && (url.includes('/commands') || url.includes('/applications/'))) {
        if (options && Array.isArray(options.body)) {
          options.body = registerUnifiedCommandsForToken(token, bot.id, options.body);
        }
      }
      return await super.put(url as `/${string}`, options);
    }
  }

  // Create a Custom Client class that returns `client` so `new Client()` in user code attaches directly to our active gateway client
  class CustomClient extends DiscordJS.Client {
    constructor(options?: any) {
      super(options || { intents: [] });
      return client as any;
    }
  }

  // Custom DiscordJS exports object
  const customDiscordJS = {
    ...DiscordJS,
    Client: CustomClient as any,
    REST: CustomREST as any,
    Routes,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    SlashCommandBuilder,
    Collection,
    AttachmentBuilder,
    ActivityType,
    Events,
    PermissionFlagsBits,
    ChannelType,
    ComponentType,
    TextInputBuilder,
    TextInputStyle,
    ModalBuilder,
    StringSelectMenuBuilder,
    UserSelectMenuBuilder,
    RoleSelectMenuBuilder,
    MentionableSelectMenuBuilder,
    ChannelSelectMenuBuilder
  };

  // Target database files map for persistence
  const targetDbFilesMap: Record<string, keyof Omit<AppDatabaseData, 'bots'>> = {
    'proofs_global.json': 'proofs_global',
    'users_mm.json': 'users_mm',
    'pix_database.json': 'pix_database',
    'taxas_diarias.json': 'taxas_diarias',
    'lastmonthlyrun.json': 'lastMonthlyRun',
    'movements.json': 'movements',
    'major_trade.json': 'major_trade',
    'proof_channels.json': 'proof_channels',
    'canal_proof.json': 'proof_channels',
    'dados_leilao.json': 'dados_leilao',
    'lances_atuais.json': 'lances_atuais',
    'tickets.json': 'tickets',
    'config.json': 'config',
    'avaliacoes_pendentes.json': 'avaliacoes_pendentes',
    'trade_data.json': 'trade_data' as any,
    'tickets_mm.json': 'tickets_mm' as any
  };

  // Virtual fs implementation for dynamic handler loading & persistent database synchronization
  const customFs = {
    ...fs,
    readdirSync: (dirPath: string) => {
      const cleanDir = dirPath.replace(/^\.\//, '').replace(/\/$/, '').toLowerCase();
      const filesInDir = new Set<string>();
      bot.files.forEach(f => {
        const p = (f.path || f.name).toLowerCase();
        if (p.startsWith(cleanDir + '/')) {
          const rest = p.substring(cleanDir.length + 1);
          const firstSegment = rest.split('/')[0];
          if (firstSegment) filesInDir.add(firstSegment);
        }
      });
      if (filesInDir.size > 0) {
        return Array.from(filesInDir);
      }
      try {
        return fs.readdirSync(dirPath);
      } catch (e) {
        return [];
      }
    },
    readFileSync: (filePath: string, encoding?: any) => {
      const isPathString = typeof filePath === 'string';
      const cleanFile = isPathString ? filePath.replace(/^\.\//, '').replace(/^.*[\\\/]/, '').toLowerCase() : '';

      const isTempOrExternal = isPathString && (
        filePath.startsWith('/tmp') ||
        filePath.startsWith(os.tmpdir()) ||
        filePath.includes('tmp') ||
        filePath.includes('.vouch-halloween') ||
        cleanFile.startsWith('frame-') ||
        cleanFile.endsWith('.png') ||
        cleanFile.endsWith('.gif')
      );

      if (isTempOrExternal && fs.existsSync(filePath)) {
        return fs.readFileSync(filePath, encoding);
      }
      
      const dbKey = targetDbFilesMap[cleanFile];
      if (dbKey && appDatabase[dbKey] !== undefined) {
        const dbContent = JSON.stringify(appDatabase[dbKey], null, 2);
        const match = bot.files.find(f => (f.path || f.name).toLowerCase() === cleanFile || f.name.toLowerCase() === cleanFile);
        if (match) {
          match.content = dbContent;
        }
        return dbContent;
      }

      const match = bot.files.find(f => (f.path || f.name).toLowerCase() === cleanFile || f.name.toLowerCase() === cleanFile);
      if (match) {
        return match.content;
      }

      try {
        return fs.readFileSync(filePath, encoding);
      } catch (e) {
        return '';
      }
    },
    writeFileSync: (filePath: string, data: any, options?: any) => {
      const isPathString = typeof filePath === 'string';
      const cleanFile = isPathString ? filePath.replace(/^\.\//, '').replace(/^.*[\\\/]/, '').toLowerCase() : '';
      const isTempOrExternal = isPathString && (
        filePath.startsWith('/tmp') ||
        filePath.startsWith(os.tmpdir()) ||
        filePath.includes('tmp') ||
        filePath.includes('.vouch-halloween') ||
        cleanFile.startsWith('frame-') ||
        cleanFile.endsWith('.png') ||
        cleanFile.endsWith('.gif') ||
        cleanFile.endsWith('.jpg')
      );

      // Always write to real physical disk
      try {
        const parentDir = path.dirname(filePath);
        if (!fs.existsSync(parentDir)) fs.mkdirSync(parentDir, { recursive: true });
        fs.writeFileSync(filePath, data, options);
      } catch (e) {}

      if (isTempOrExternal) {
        return;
      }

      const strData = typeof data === 'string' ? data : (data instanceof Buffer ? data.toString('utf-8') : JSON.stringify(data));

      const existingIndex = bot.files.findIndex(f => (f.path || f.name).toLowerCase() === cleanFile || f.name.toLowerCase() === cleanFile);
      if (existingIndex !== -1) {
        bot.files[existingIndex].content = strData;
      } else {
        bot.files.push({ name: cleanFile, path: cleanFile, content: strData });
      }

      const dbKey = targetDbFilesMap[cleanFile];
      if (dbKey) {
        try {
          appDatabase[dbKey] = JSON.parse(strData);
        } catch (e) {
          appDatabase[dbKey] = strData;
        }
      }

      const botIdx = botsStore.findIndex(b => b.id === bot.id);
      if (botIdx !== -1) {
        botsStore[botIdx] = { ...bot };
      }
      appDatabase.bots = botsStore;
      saveAppDatabase();

      if (dbKey) {
        try {
          fs.writeFileSync(path.join(DATA_DIR, cleanFile), strData, 'utf8');
          fs.writeFileSync(path.join(process.cwd(), cleanFile), strData, 'utf8');
        } catch (e) {}
      }
    },
    appendFileSync: (filePath: string, data: any) => {
      const current = customFs.readFileSync(filePath);
      customFs.writeFileSync(filePath, current + String(data));
    },
    existsSync: (filePath: string) => {
      if (typeof filePath === 'string' && fs.existsSync(filePath)) return true;
      const cleanFile = typeof filePath === 'string' ? filePath.replace(/^\.\//, '').replace(/^.*[\\\/]/, '').toLowerCase() : '';
      if (targetDbFilesMap[cleanFile]) return true;
      const match = bot.files.find(f => (f.path || f.name).toLowerCase() === cleanFile || f.name.toLowerCase() === cleanFile);
      return Boolean(match);
    },
    mkdirSync: (p: string, opts?: any) => { try { return fs.mkdirSync(p, opts); } catch (e) {} },
    mkdtempSync: (p: string, opts?: any) => fs.mkdtempSync(p, opts),
    unlinkSync: (p: string) => { try { fs.unlinkSync(p); } catch (e) {} },
    rmSync: (p: string, opts?: any) => { try { fs.rmSync(p, opts); } catch (e) {} },
    copyFileSync: (srcPath: string, destPath: string) => {
      try {
        const content = customFs.readFileSync(srcPath);
        if (content !== undefined && content !== null) {
          customFs.writeFileSync(destPath, content);
          return;
        }
      } catch (e) {}
      try {
        fs.copyFileSync(srcPath, destPath);
      } catch (e) {}
    },
    statSync: (p: string) => {
      try {
        if (fs.existsSync(p)) return fs.statSync(p);
      } catch (e) {}
      return {
        isFile: () => true,
        isDirectory: () => false,
        size: 1024,
        mtime: new Date()
      };
    },
    promises: {
      readFile: async (p: string, enc?: any) => customFs.readFileSync(p, enc),
      writeFile: async (p: string, d: any) => customFs.writeFileSync(p, d),
      copyFile: async (srcPath: string, destPath: string) => customFs.copyFileSync(srcPath, destPath),
      mkdir: async () => {},
      unlink: async () => {},
      rm: async () => {}
    }
  };

  const virtualModules: Record<string, any> = {};

// Native Canvas loading with fallback pure JS canvas (pureimage + pngjs + jpeg-js)
let PNG: any = null;
try {
  PNG = require('pngjs').PNG;
} catch (e) {}

let JPEG: any = null;
try {
  JPEG = require('jpeg-js');
} catch (e) {}

let pureimageLib: any = null;
try {
  pureimageLib = require('pureimage');
} catch (e) {}

let nativeCanvasLib: any = null;
try {
  nativeCanvasLib = require('@napi-rs/canvas');
} catch (e1) {
  try {
    nativeCanvasLib = require('canvas');
  } catch (e2) {}
}

function createRealPureCanvas(width: number, height: number) {
  const w = Math.max(1, Math.floor(width));
  const h = Math.max(1, Math.floor(height));
  let img: any;
  if (pureimageLib && typeof pureimageLib.make === 'function') {
    try {
      img = pureimageLib.make(w, h);
    } catch (e) {}
  }
  
  if (!img) {
    const dataBuf = Buffer.alloc(w * h * 4);
    for (let i = 0; i < dataBuf.length; i += 4) {
      dataBuf[i] = 15;     // R
      dataBuf[i + 1] = 23; // G
      dataBuf[i + 2] = 42; // B
      dataBuf[i + 3] = 255;// A
    }
    img = { width: w, height: h, data: dataBuf };
  }

  const ctx = img.getContext ? img.getContext('2d') : {};

  // Polyfills & safe helpers for Canvas 2D
  if (!ctx.measureText) {
    ctx.measureText = (text: string) => {
      const fontSize = parseInt(ctx.font || '16') || 16;
      const textW = (text || '').length * (fontSize * 0.55);
      return {
        width: textW,
        actualBoundingBoxAscent: fontSize * 0.8,
        actualBoundingBoxDescent: fontSize * 0.2,
        actualBoundingBoxLeft: 0,
        actualBoundingBoxRight: textW,
        fontBoundingBoxAscent: fontSize,
        fontBoundingBoxDescent: fontSize * 0.25
      };
    };
  }

  if (!ctx.createLinearGradient) ctx.createLinearGradient = () => ({ addColorStop: () => {} });
  if (!ctx.createRadialGradient) ctx.createRadialGradient = () => ({ addColorStop: () => {} });
  if (!ctx.createPattern) ctx.createPattern = () => ({});
  if (!ctx.quadraticCurveTo) ctx.quadraticCurveTo = function(cpx: number, cpy: number, x: number, y: number) { if (typeof this.lineTo === 'function') this.lineTo(x, y); };
  if (!ctx.bezierCurveTo) ctx.bezierCurveTo = function(cp1x: number, cp1y: number, cp2x: number, cp2y: number, x: number, y: number) { if (typeof this.lineTo === 'function') this.lineTo(x, y); };
  if (!ctx.roundRect) ctx.roundRect = function(x: number, y: number, w: number, h: number, r: any) { if (typeof this.rect === 'function') this.rect(x, y, w, h); };
  if (!ctx.arcTo) ctx.arcTo = function(x1: number, y1: number, x2: number, y2: number, r: number) { if (typeof this.lineTo === 'function') this.lineTo(x2, y2); };
  if (!ctx.ellipse) ctx.ellipse = function(x: number, y: number, rx: number, ry: number) { if (typeof this.arc === 'function') this.arc(x, y, rx, 0, Math.PI * 2); };
  if (!ctx.getTransform) ctx.getTransform = () => ({ a: 1, b: 0, c: 0, d: 1, e: 0, f: 0 });

  const safeCtx = new Proxy(ctx, {
    get(target, prop) {
      if (prop in target) return target[prop];
      if (typeof prop === 'string') {
        const noop = () => {};
        target[prop] = noop;
        return noop;
      }
      return undefined;
    },
    set(target, prop, value) {
      target[prop] = value;
      return true;
    }
  });

  img.getContext = () => safeCtx;

  img.toBuffer = (mimeOrCb?: any) => {
    let pngBuf: Buffer;
    try {
      if (PNG && PNG.sync && typeof PNG.sync.write === 'function') {
        pngBuf = PNG.sync.write({
          width: img.width,
          height: img.height,
          data: img.data
        });
      } else {
        pngBuf = Buffer.alloc(0);
      }
    } catch (e) {
      console.error('Erro ao codificar PNG:', e);
      pngBuf = Buffer.alloc(0);
    }
    if (typeof mimeOrCb === 'function') {
      mimeOrCb(null, pngBuf);
    }
    return pngBuf;
  };

  img.toDataURL = () => 'data:image/png;base64,' + img.toBuffer().toString('base64');
  img.createPNGStream = () => {};
  img.createJPEGStream = () => {};

  return img;
}

function wrapNativeContext(ctx: any) {
  if (!ctx) return ctx;

  const stringProps = new Set([
    'font', 'fillStyle', 'strokeStyle', 'textAlign', 'textBaseline',
    'shadowColor', 'filter', 'globalCompositeOperation', 'direction',
    'fontKerning', 'fontStretch', 'fontVariantCaps', 'letterSpacing', 'wordSpacing'
  ]);

  const numberProps = new Set([
    'lineWidth', 'shadowBlur', 'shadowOffsetX', 'shadowOffsetY',
    'globalAlpha', 'miterLimit', 'lineDashOffset'
  ]);

  const defaultStringValues: Record<string, string> = {
    font: '16px sans-serif',
    fillStyle: '#ffffff',
    strokeStyle: '#000000',
    textAlign: 'left',
    textBaseline: 'alphabetic',
    shadowColor: 'transparent',
    filter: 'none',
    globalCompositeOperation: 'source-over',
    direction: 'inherit'
  };

  const defaultNumberValues: Record<string, number> = {
    lineWidth: 1,
    shadowBlur: 0,
    shadowOffsetX: 0,
    shadowOffsetY: 0,
    globalAlpha: 1,
    miterLimit: 10,
    lineDashOffset: 0
  };

  return new Proxy(ctx, {
    get(target, prop, receiver) {
      if (prop === '__isWrapped') return true;
      const orig = Reflect.get(target, prop, receiver);
      if (typeof orig === 'function') {
        return function(...args: any[]) {
          try {
            if (prop === 'fillText' || prop === 'strokeText') {
              const str = args[0] !== undefined && args[0] !== null ? String(args[0]) : '';
              const safeX = typeof args[1] === 'number' && !isNaN(args[1]) ? args[1] : 0;
              const safeY = typeof args[2] === 'number' && !isNaN(args[2]) ? args[2] : 0;
              if (args[3] !== undefined && typeof args[3] === 'number' && !isNaN(args[3])) {
                return orig.call(target, str, safeX, safeY, args[3]);
              } else {
                return orig.call(target, str, safeX, safeY);
              }
            }

            if (prop === 'measureText') {
              const str = args[0] !== undefined && args[0] !== null ? String(args[0]) : '';
              return orig.call(target, str);
            }

            if (prop === 'drawImage') {
              if (!args[0]) return;
              const safeArgs = args.map((a, i) => i === 0 ? a : (typeof a === 'number' && !isNaN(a) ? a : 0));
              return orig.call(target, ...safeArgs);
            }

            if (prop === 'fill' || prop === 'clip') {
              if (args[0] === undefined || args[0] === null) {
                return orig.call(target);
              }
            }

            const sanitizedArgs = args.map(a => typeof a === 'number' ? (isNaN(a) ? 0 : a) : a);
            return orig.call(target, ...sanitizedArgs);
          } catch (err) {
            console.warn(`Error invoking ctx.${String(prop)}:`, err);
          }
        };
      }
      return orig;
    },
    set(target, prop, value) {
      const propStr = String(prop);
      try {
        if (stringProps.has(propStr)) {
          let safeStr: string;
          if (value === undefined || value === null) {
            safeStr = defaultStringValues[propStr] || '';
          } else {
            safeStr = String(value);
          }
          target[prop] = safeStr;
          return true;
        }

        if (numberProps.has(propStr)) {
          let safeNum: number;
          if (typeof value === 'number' && !isNaN(value)) {
            safeNum = value;
          } else {
            safeNum = defaultNumberValues[propStr] ?? 0;
          }
          target[prop] = safeNum;
          return true;
        }

        target[prop] = value;
        return true;
      } catch (e) {
        return true;
      }
    }
  });
}

function getUnifiedCanvasModule() {
  const createCanvasFn = (w: number, h: number) => {
    const safeW = Math.max(1, Math.floor(typeof w === 'number' && !isNaN(w) ? w : 200));
    const safeH = Math.max(1, Math.floor(typeof h === 'number' && !isNaN(h) ? h : 200));

    if (nativeCanvasLib) {
      let canvasObj: any = null;
      if (typeof nativeCanvasLib.createCanvas === 'function') {
        try {
          canvasObj = nativeCanvasLib.createCanvas(safeW, safeH);
        } catch (e) {}
      }
      if (!canvasObj && typeof nativeCanvasLib.Canvas === 'function') {
        try {
          canvasObj = new nativeCanvasLib.Canvas(safeW, safeH);
        } catch (e) {}
      }
      if (canvasObj && (typeof canvasObj.toBuffer === 'function' || typeof canvasObj.encode === 'function')) {
        const origToBuffer = canvasObj.toBuffer;
        if (typeof origToBuffer === 'function') {
          canvasObj.toBuffer = function(mimeType?: string, ...args: any[]) {
            const safeMime = (typeof mimeType === 'string' && mimeType.trim().length > 0) ? mimeType : 'image/png';
            try {
              return origToBuffer.call(this, safeMime, ...args);
            } catch (err) {
              try {
                return origToBuffer.call(this, 'image/png');
              } catch (e) {
                return origToBuffer.call(this);
              }
            }
          };
        }
        const origEncode = canvasObj.encode;
        if (typeof origEncode === 'function') {
          canvasObj.encode = function(format?: string, ...args: any[]) {
            const safeFormat = (typeof format === 'string' && format.trim().length > 0) ? format : 'png';
            try {
              return origEncode.call(this, safeFormat, ...args);
            } catch (err) {
              return origEncode.call(this, 'png');
            }
          };
        }
        const origGetContext = canvasObj.getContext;
        if (typeof origGetContext === 'function') {
          canvasObj.getContext = function(type: string, ...rest: any[]) {
            const ctx = origGetContext.call(this, type, ...rest);
            return wrapNativeContext(ctx);
          };
        }
        return canvasObj;
      }
    }
    return createRealPureCanvas(safeW, safeH);
  };

  const loadImageFn = async (src: any) => {
    const rawLoadImage = nativeCanvasLib ? (nativeCanvasLib.loadImage || (nativeCanvasLib.default && nativeCanvasLib.default.loadImage)) : null;

    if (src === undefined || src === null) {
      if (nativeCanvasLib && typeof rawLoadImage === 'function') {
        try {
          if (PNG && PNG.sync && typeof PNG.sync.write === 'function') {
            const fallbackPng = PNG.sync.write({
              width: 200,
              height: 200,
              data: Buffer.alloc(200 * 200 * 4, 128)
            });
            const fallbackNativeImg = await rawLoadImage(fallbackPng);
            if (fallbackNativeImg) return fallbackNativeImg;
          }
        } catch (e) {}
      }
      return pureimageLib ? pureimageLib.make(200, 200) : createRealPureCanvas(200, 200);
    }

    let buf: Buffer | null = null;

    if (Buffer.isBuffer(src)) {
      buf = src;
    } else if (typeof src === 'string') {
      if (src.startsWith('data:image/')) {
        const base64Data = src.split(',')[1];
        if (base64Data) {
          try {
            buf = Buffer.from(base64Data, 'base64');
          } catch (e) {}
        }
      } else if (src.startsWith('http://') || src.startsWith('https://')) {
        try {
          const resp = await globalThis.fetch(src, {
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
          });
          if (resp.ok) {
            const ab = await resp.arrayBuffer();
            buf = Buffer.from(ab);
          }
        } catch (err) {
          console.warn('Erro ao carregar imagem via HTTP:', err);
        }
      } else if (typeof src === 'string' && src.trim().length > 0) {
        try {
          if (fs.existsSync(src)) {
            buf = fs.readFileSync(src);
          }
        } catch (e) {}
      }
    }

    // 1. If nativeCanvasLib is present, try native loadImage safely
    if (nativeCanvasLib && typeof rawLoadImage === 'function') {
      if (buf && buf.length > 0) {
        try {
          const nativeImg = await rawLoadImage(buf);
          if (nativeImg) return nativeImg;
        } catch (e) {
          console.warn('nativeCanvasLib.loadImage(buf) falhou:', e);
        }
      } else if (typeof src === 'string' && src.trim().length > 0) {
        try {
          const nativeImg = await rawLoadImage(src);
          if (nativeImg) return nativeImg;
        } catch (e) {
          console.warn('nativeCanvasLib.loadImage(src) falhou:', e);
        }
      }

      // Generate a valid PNG buffer placeholder and load it into nativeCanvasLib
      try {
        if (PNG && PNG.sync && typeof PNG.sync.write === 'function') {
          const fallbackPng = PNG.sync.write({
            width: 200,
            height: 200,
            data: Buffer.alloc(200 * 200 * 4, 128)
          });
          const fallbackNativeImg = await rawLoadImage(fallbackPng);
          if (fallbackNativeImg) return fallbackNativeImg;
        }
      } catch (e) {
        console.error('Erro ao criar fallback native image:', e);
      }
    }

    // 2. Pure JS / pureimage fallback
    if (buf && buf.length > 0) {
      if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4E && buf[3] === 0x47) {
        try {
          if (PNG && PNG.sync && typeof PNG.sync.read === 'function') {
            const parsed = PNG.sync.read(buf);
            const img = pureimageLib ? pureimageLib.make(parsed.width, parsed.height) : createRealPureCanvas(parsed.width, parsed.height);
            parsed.data.copy(img.data);
            return img;
          }
        } catch (e) {}
      }

      if (buf[0] === 0xFF && buf[1] === 0xD8) {
        try {
          if (JPEG && typeof JPEG.decode === 'function') {
            const parsed = JPEG.decode(buf, { useTArray: true });
            const img = pureimageLib ? pureimageLib.make(parsed.width, parsed.height) : createRealPureCanvas(parsed.width, parsed.height);
            Buffer.from(parsed.data).copy(img.data);
            return img;
          }
        } catch (e) {}
      }
    }

    return pureimageLib ? pureimageLib.make(200, 200) : createRealPureCanvas(200, 200);
  };

  const registerFontFn = (fontPath: any, optionsOrName: any) => {
    if (!fontPath || typeof fontPath !== 'string' || !fs.existsSync(fontPath)) {
      return;
    }
    if (nativeCanvasLib) {
      if (typeof nativeCanvasLib.registerFont === 'function') {
        try {
          const name = typeof optionsOrName === 'string' ? optionsOrName : (optionsOrName?.family || 'CustomFont');
          return nativeCanvasLib.registerFont(fontPath, typeof optionsOrName === 'object' ? optionsOrName : { family: name });
        } catch (e) {}
      }
      const gf = nativeCanvasLib.GlobalFonts || (nativeCanvasLib.default && nativeCanvasLib.default.GlobalFonts);
      if (gf && typeof gf.registerFromPath === 'function') {
        try {
          const family = typeof optionsOrName === 'string' ? optionsOrName : (optionsOrName?.family || 'CustomFont');
          return gf.registerFromPath(fontPath, family);
        } catch (e) {}
      }
    }
  };

  function CanvasClass(this: any, w: number, h: number) {
    return createCanvasFn(w, h);
  }

  const canvasExport: any = function(w: number, h: number) {
    return createCanvasFn(w, h);
  };

  canvasExport.createCanvas = createCanvasFn;
  canvasExport.loadImage = loadImageFn;
  canvasExport.registerFont = registerFontFn;
  canvasExport.Canvas = CanvasClass;
  canvasExport.Image = nativeCanvasLib?.Image || (nativeCanvasLib?.default?.Image) || class Image { width = 100; height = 100; src = ''; };
  canvasExport.ImageData = nativeCanvasLib?.ImageData || class ImageData {};
  canvasExport.Path2D = nativeCanvasLib?.Path2D || class Path2D {};
  canvasExport.GlobalFonts = {
    registerFromPath: (fontPath: any, family?: any) => {
      if (!fontPath || typeof fontPath !== 'string' || !fs.existsSync(fontPath)) return false;
      const safeFamily = typeof family === 'string' ? family : 'CustomFont';
      const gf = nativeCanvasLib?.GlobalFonts || (nativeCanvasLib?.default?.GlobalFonts);
      if (gf && typeof gf.registerFromPath === 'function') {
        try {
          return gf.registerFromPath(fontPath, safeFamily);
        } catch (e) {}
      }
      return false;
    }
  };
  canvasExport.default = canvasExport;

  if (nativeCanvasLib) {
    const srcObj = nativeCanvasLib.default || nativeCanvasLib;
    for (const key of Object.keys(srcObj)) {
      if (!canvasExport[key]) {
        try {
          canvasExport[key] = srcObj[key];
        } catch (e) {}
      }
    }
    canvasExport.createCanvas = createCanvasFn;
    canvasExport.loadImage = loadImageFn;
    canvasExport.registerFont = registerFontFn;
    canvasExport.default = canvasExport;
  }

  return canvasExport;
}

  const customRequire = (moduleName: string) => {
    if (moduleName === 'discord.js' || moduleName === 'discord.js-selfbot-v13') {
      return customDiscordJS;
    }
    if (moduleName === '@discordjs/rest') {
      return { REST: customDiscordJS.REST, Routes };
    }
    if (moduleName === 'fs' || moduleName === 'node:fs') {
      return customFs;
    }
    if (moduleName === 'path' || moduleName === 'node:path') {
      return pathModule;
    }
    const lowerMod = moduleName.toLowerCase();
    if (
      lowerMod === 'canvas' ||
      lowerMod === '@napi-rs/canvas' ||
      lowerMod.includes('canvas') ||
      lowerMod === 'skia-canvas' ||
      lowerMod === 'pure-image'
    ) {
      return getUnifiedCanvasModule();
    }
    if (moduleName === 'qrcode') {
      try {
        return require('qrcode');
      } catch (e) {
        return {};
      }
    }
    if (moduleName === '@discordjs/builders') {
      return customDiscordJS;
    }
    if (moduleName === 'dotenv') {
      return { config: () => ({ parsed: envVars }) };
    }
    if (moduleName === 'express') {
      return () => ({ get: () => {}, listen: () => {}, use: () => {} });
    }

    const cleanName = moduleName.replace(/^\.\//, '').replace(/^\//, '');
    const matchingFile = bot.files.find(f => {
      const p = f.path || f.name;
      return (
        p === cleanName ||
        p === `${cleanName}.js` ||
        p === `${cleanName}.ts` ||
        p.endsWith(`/${cleanName}`) ||
        p.endsWith(`/${cleanName}.js`) ||
        p.endsWith(`/${cleanName}.ts`)
      );
    });

    if (matchingFile) {
      const vKey = matchingFile.path || matchingFile.name;
      
      const diskPath = path.join(process.cwd(), matchingFile.name);
      if (fs.existsSync(diskPath)) {
        try {
          const diskContent = fs.readFileSync(diskPath, 'utf8');
          if (diskContent && !isViteFallbackHtml(diskContent) && diskContent !== matchingFile.content) {
            matchingFile.content = diskContent;
          }
        } catch (e) {}
      }

      if (virtualModules[vKey] && virtualModules[vKey].content === matchingFile.content) {
        return virtualModules[vKey].exports;
      }
      const moduleObj = { exports: {} };

      try {
        const transpiledModule = transpileCode(matchingFile.content);
        const fn = new Function('exports', 'require', 'module', '__filename', '__dirname', 'process', 'console', transpiledModule);
        fn(
          moduleObj.exports,
          customRequire,
          moduleObj,
          matchingFile.name,
          process.cwd(),
          customProcess,
          customConsole
        );
      } catch (err: any) {
        console.error('Erro ao executar arquivo virtual:', matchingFile.name, err);
        bot.logs.push({
          id: 'log-' + Date.now(),
          timestamp: new Date().toLocaleTimeString('pt-BR'),
          type: 'error',
          message: `❌ [ERRO NO ARQUIVO ${matchingFile.name}] ${err?.message || err}`
        });
      }
      virtualModules[vKey] = { content: matchingFile.content, exports: moduleObj.exports };
      return moduleObj.exports;
    }

    try {
      return require(moduleName);
    } catch (e) {
      return {};
    }
  };

  const customConsole = {
    log: (...args: any[]) => {
      const msg = args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ');
      bot.logs.push({
        id: 'log-' + Date.now() + Math.random(),
        timestamp: new Date().toLocaleTimeString('pt-BR'),
        type: 'stdout',
        message: `[BOT LOG] ${msg}`
      });
      saveBots(botsStore);
    },
    error: (...args: any[]) => {
      const msg = args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ');
      bot.logs.push({
        id: 'log-' + Date.now() + Math.random(),
        timestamp: new Date().toLocaleTimeString('pt-BR'),
        type: 'system',
        message: `❌ [BOT ERRO] ${msg}`
      });
      saveBots(botsStore);
    },
    warn: (...args: any[]) => {
      const msg = args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ');
      bot.logs.push({
        id: 'log-' + Date.now() + Math.random(),
        timestamp: new Date().toLocaleTimeString('pt-BR'),
        type: 'system',
        message: `⚠️ [BOT AVISO] ${msg}`
      });
      saveBots(botsStore);
    },
    info: (...args: any[]) => {
      const msg = args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ');
      bot.logs.push({
        id: 'log-' + Date.now() + Math.random(),
        timestamp: new Date().toLocaleTimeString('pt-BR'),
        type: 'stdout',
        message: `ℹ️ [BOT INFO] ${msg}`
      });
      saveBots(botsStore);
    }
  };

  targetFiles.forEach(file => {
    try {
      const moduleObj = { exports: {} };
      const code = file.content;
      const sanitizedCode = code.replace(/client\.login\s*\([^)]*\)/g, 'client.login()');
      const transpiled = transpileCode(sanitizedCode);

      (globalThis as any).client = client;
      (globalThis as any).Discord = customDiscordJS;

      const runner = new Function(
        'exports',
        'require',
        'module',
        '__filename',
        '__dirname',
        'process',
        'console',
        `try { ${transpiled} } catch(e) { console.error("Erro em " + __filename + ": " + (e.stack || e.message)); }`
      );

      runner(
        moduleObj.exports,
        customRequire,
        moduleObj,
        file.name,
        '/',
        customProcess,
        customConsole
      );

      bot.logs.push({
        id: 'log-' + Date.now(),
        timestamp: new Date().toLocaleTimeString('pt-BR'),
        type: 'system',
        message: `⚙️ [ENGINE 24/7] Código do usuário "${file.name}" carregado e ativo!`
      });
    } catch (err: any) {
      bot.logs.push({
        id: 'log-' + Date.now(),
        timestamp: new Date().toLocaleTimeString('pt-BR'),
        type: 'system',
        message: `❌ [ERRO DE SINTAXE EM ${file.name}] ${err.message || err}`
      });
      bot.logs.push({
        id: 'log-' + (Date.now() + 1),
        timestamp: new Date().toLocaleTimeString('pt-BR'),
        type: 'system',
        message: `🛡️ [PROTEÇÃO BOTLOOM] O bot permaneceu ONLINE. Corrija o código no editor se necessário.`
      });
    }
  });

  if (client.isReady()) {
    setTimeout(() => {
      client.emit('ready', client);
    }, 100);
  }
}

function isViteFallbackHtml(content: string): boolean {
  if (typeof content !== 'string') return false;
  const trimmed = content.trim();
  return (
    (trimmed.startsWith('<!DOCTYPE html>') || trimmed.startsWith('<html')) &&
    (trimmed.includes('/@vite/client') || trimmed.includes('<title>Vite') || trimmed.includes('vite:not_found'))
  );
}

const PROTECTED_HOST_FILES = new Set([
  'package.json',
  'package-lock.json',
  'tsconfig.json',
  'vite.config.ts',
  'server.ts',
  'metadata.json',
  'index.html',
  'bun.lock',
  '.env.example',
  '.env',
  'index.js',
  'index.ts',
  'bot.ts',
  'config.json'
]);

function isJunkOrBinaryFile(name: string): boolean {
  if (!name || typeof name !== 'string') return true;
  const lower = name.replace(/^\.\//, '').replace(/^.*[\\\/]/, '').toLowerCase();
  return (
    lower.startsWith('frame-') ||
    lower.endsWith('.png') ||
    lower.endsWith('.jpg') ||
    lower.endsWith('.jpeg') ||
    lower.endsWith('.gif') ||
    lower.endsWith('.tmp') ||
    lower.endsWith('.zip') ||
    lower.endsWith('.tar') ||
    lower.endsWith('.gz') ||
    lower === 'bot (1).js' ||
    lower === 'vouch_code.js' ||
    lower === 'vouchcode'
  );
}

function syncCardFilesWithDisk(bot: BotData, triggerSave: boolean = true): boolean {
  if (!bot || !bot.files || !Array.isArray(bot.files)) return false;

  // Filter out any binary/tmp junk files from bot.files
  bot.files = bot.files.filter(f => !isJunkOrBinaryFile(f.name || f.path || ''));

  // Isolate bot files on disk in workspace/bots/{bot.id}/ to prevent cross-bot overwrites
  const botWorkspaceDir = path.join(process.cwd(), 'workspace', 'bots', bot.id);
  try {
    if (!fs.existsSync(botWorkspaceDir)) {
      fs.mkdirSync(botWorkspaceDir, { recursive: true });
    }
  } catch (e) {}

  const isMiddleman = (bot.name || '').toLowerCase().includes('mid') || bot.id === 'bot-1785901524690';
  const isLeilao = (bot.name || '').toLowerCase().includes('leil') || bot.id === 'bot-1791054539250';
  let hasUpdatedFromDisk = false;

  bot.files.forEach(botFile => {
    const rawName = botFile.name || botFile.path || '';
    if (!rawName || isJunkOrBinaryFile(rawName)) return;
    const cleanName = rawName.replace(/^\.\//, '').replace(/^.*[\\\/]/, '').toLowerCase();

    const botIsolatedPath = path.join(botWorkspaceDir, rawName);
    const rootPath = path.join(process.cwd(), rawName);

    // Prioritize checking if a modified file exists on disk (workspace or root)
    let diskPathToCheck = botIsolatedPath;
    if (isMiddleman && (cleanName === 'bot.js' || cleanName === 'vouchcard.js' || cleanName === 'perfilcard.js')) {
      if (fs.existsSync(rootPath)) {
        diskPathToCheck = rootPath;
      }
    } else if (isLeilao && cleanName === 'index.js') {
      if (fs.existsSync(path.join(process.cwd(), 'index.js'))) {
        diskPathToCheck = path.join(process.cwd(), 'index.js');
      }
    }

    if (fs.existsSync(diskPathToCheck)) {
      try {
        const diskContent = fs.readFileSync(diskPathToCheck, 'utf8');
        if (diskContent && diskContent !== botFile.content) {
          botFile.content = diskContent;
          hasUpdatedFromDisk = true;
        }
      } catch (e) {}
    }

    // Persist botFile.content directly to isolated bot workspace (Source of truth)
    if (botFile.content !== undefined && typeof botFile.content === 'string') {
      try {
        const parentDir = path.dirname(botIsolatedPath);
        if (!fs.existsSync(parentDir)) fs.mkdirSync(parentDir, { recursive: true });
        if (!fs.existsSync(botIsolatedPath) || fs.readFileSync(botIsolatedPath, 'utf8') !== botFile.content) {
          fs.writeFileSync(botIsolatedPath, botFile.content, 'utf8');
        }
      } catch (e) {}

      // If Middleman bot, sync bot.js, vouchCard.js, and perfilCard.js to root on disk
      if (isMiddleman && (cleanName === 'bot.js' || cleanName === 'vouchcard.js' || cleanName === 'perfilcard.js')) {
        try {
          if (!fs.existsSync(rootPath) || fs.readFileSync(rootPath, 'utf8') !== botFile.content) {
            fs.writeFileSync(rootPath, botFile.content, 'utf8');
          }
        } catch (e) {}
      }

      // If Leilão bot, sync index.js to root on disk
      if (isLeilao && cleanName === 'index.js') {
        try {
          const leilaoPath = path.join(process.cwd(), 'index.js');
          if (!fs.existsSync(leilaoPath) || fs.readFileSync(leilaoPath, 'utf8') !== botFile.content) {
            fs.writeFileSync(leilaoPath, botFile.content, 'utf8');
          }
        } catch (e) {}
      }
    }
  });

  if (hasUpdatedFromDisk && triggerSave && Array.isArray(botsStore) && botsStore.length > 0) {
    saveBots(botsStore);
  }
  return hasUpdatedFromDisk;
}

// =========================================================================
// SYSTEM DISCORD MANAGEMENT ENGINE (Components V2 + Real-Time Discord Ops)
// Provides !bots, !logs, !ligar, !desligar, !reiniciar, !codigo directly on Discord
// without requiring any code inside user bot.js files!
// =========================================================================

const processedSystemMessageIds = new Set<string>();
const processedSystemInteractionIds = new Set<string>();

// Helper to find bot by query (ID, Name, Number index)
function findSystemBot(query?: string, defaultBotId?: string): BotData | null {
  if (!botsStore || botsStore.length === 0) return null;
  if (!query || query.trim() === '') {
    if (defaultBotId) {
      const match = botsStore.find(b => b.id === defaultBotId);
      if (match) return match;
    }
    return botsStore[0];
  }

  const q = query.trim().toLowerCase();
  // Match index (e.g. "1", "2")
  const num = parseInt(q, 10);
  if (!isNaN(num) && num >= 1 && num <= botsStore.length) {
    return botsStore[num - 1];
  }
  // Match exact ID
  const byId = botsStore.find(b => b.id.toLowerCase() === q);
  if (byId) return byId;
  // Match partial ID
  const byPartId = botsStore.find(b => b.id.toLowerCase().includes(q));
  if (byPartId) return byPartId;
  // Match name
  const byName = botsStore.find(b => b.name.toLowerCase().includes(q));
  if (byName) return byName;

  return defaultBotId ? (botsStore.find(b => b.id === defaultBotId) || botsStore[0]) : botsStore[0];
}

// Build Discord Panel Payload (Instant High-Compatibility Embed + ActionRows)
function buildDiscordPanelMessage(selectedBotId?: string) {
  const totalBots = botsStore.length;
  const onlineBots = botsStore.filter(b => b.status === 'online').length;
  const offlineBots = totalBots - onlineBots;
  const totalMemoryMB = botsStore.reduce((sum, b) => sum + (b.status === 'online' ? b.stats.memoryUsage : 0), 0);
  const targetBot = findSystemBot(undefined, selectedBotId) || botsStore[0];

  let botsListText = '';
  botsStore.forEach((b, index) => {
    const isSel = targetBot && b.id === targetBot.id ? '👉 ' : '   ';
    const statusEmoji = b.status === 'online' ? '🟢' : '🔴';
    botsListText += `${isSel}\`${index + 1}.\` **${b.name}** • ${statusEmoji} \`${b.status.toUpperCase()}\` (ID: \`${b.id}\`)\n`;
  });

  const selectedBotDetail = targetBot ? (
    `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `### 🎯 Bot Selecionado: **${targetBot.name}**\n` +
    `> 📡 **Status:** ${targetBot.status === 'online' ? '🟢 **ONLINE 24/7**' : '🔴 **OFFLINE**'}\n` +
    `> 🆔 **ID:** \`${targetBot.id}\` | ⚡ **Prefixo:** \`${targetBot.prefix || '!'}\`\n` +
    `> 💾 **Memória:** \`${targetBot.stats.memoryUsage} MB\` | ⚙️ **CPU:** \`${targetBot.stats.cpuUsage}%\`\n` +
    `> 📁 **Arquivos (${targetBot.files?.length || 0}):** ${targetBot.files?.map(f => `\`${f.name}\``).slice(0, 6).join(', ') || 'Nenhum'}\n` +
    `> 🕒 **Última Execução:** ${targetBot.lastRunAt ? new Date(targetBot.lastRunAt).toLocaleTimeString('pt-BR') : 'Nunca'}\n`
  ) : '';

  const mainContent = (
    `# 🤖 BOTLOOM • PAINEL DE CONTROLE DE BOTS\n` +
    `-# Sistema 24/7 integrado diretamente ao Discord • Gerencie e controle todos os seus bots em tempo real.\n\n` +
    `📊 **Status Geral:** \`${totalBots} Bots\` (\`${onlineBots} Online 🟢\` | \`${offlineBots} Offline 🔴\`) | ⚡ **Memória:** \`${totalMemoryMB.toFixed(1)} MB\`\n\n` +
    `### 📋 Lista de Bots Cadastrados:\n${botsListText}${selectedBotDetail}`
  );

  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId('sys_select_bot')
    .setPlaceholder(targetBot ? `Selecionado: ${targetBot.name}` : 'Selecione um bot...')
    .addOptions(
      botsStore.slice(0, 25).map(b => ({
        label: b.name.substring(0, 100),
        value: b.id,
        description: `Status: ${b.status} • Arquivos: ${b.files?.length || 0}`.substring(0, 100),
        emoji: b.status === 'online' ? '🟢' : '🔴',
        default: targetBot && b.id === targetBot.id
      }))
    );

  const row1 = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(selectMenu);

  const isOnline = targetBot?.status === 'online';
  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`sys_btn_start_${targetBot?.id || 'none'}`)
      .setLabel('Ligar')
      .setEmoji('🟢')
      .setStyle(ButtonStyle.Success)
      .setDisabled(isOnline),
    new ButtonBuilder()
      .setCustomId(`sys_btn_restart_${targetBot?.id || 'none'}`)
      .setLabel('Reiniciar')
      .setEmoji('🔄')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(`sys_btn_stop_${targetBot?.id || 'none'}`)
      .setLabel('Desligar')
      .setEmoji('🔴')
      .setStyle(ButtonStyle.Danger)
      .setDisabled(!isOnline),
    new ButtonBuilder()
      .setCustomId(`sys_btn_logs_${targetBot?.id || 'none'}`)
      .setLabel('Logs')
      .setEmoji('📜')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`sys_btn_code_${targetBot?.id || 'none'}`)
      .setLabel('Código')
      .setEmoji('📝')
      .setStyle(ButtonStyle.Secondary)
  );

  const row3 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`sys_btn_refresh_panel_${targetBot?.id || 'none'}`)
      .setLabel('Atualizar Painel')
      .setEmoji('🔄')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('sys_btn_help_panel')
      .setLabel('Ajuda / Comandos')
      .setEmoji('❓')
      .setStyle(ButtonStyle.Secondary)
  );

  const embedFallback = new EmbedBuilder()
    .setColor(targetBot?.status === 'online' ? 0x10B981 : 0x6366F1)
    .setTitle('🤖 BOTLOOM • PAINEL DE CONTROLE DE BOTS')
    .setDescription(mainContent)
    .setFooter({ text: 'Botloom 24/7 Hosting System • Comandos: !bots, !logs, !liga, !desliga, !reiniciar, !codigo' })
    .setTimestamp();

  return {
    embedFallback,
    components: [row1, row2, row3]
  };
}

// Build Discord Logs Payload
function buildDiscordLogsMessage(botId: string) {
  const targetBot = findSystemBot(undefined, botId) || botsStore[0];
  if (!targetBot) {
    return buildDiscordPanelMessage();
  }

  const recentLogs = targetBot.logs.slice(-18);
  let logText = recentLogs.map(l => `[${l.timestamp}] (${l.type.toUpperCase()}) ${l.message}`).join('\n');
  if (!logText.trim()) logText = 'Nenhum log registrado ainda para este bot.';

  if (logText.length > 1800) {
    logText = '...' + logText.substring(logText.length - 1800);
  }

  const mainContent = (
    `# 📜 LOGS EM TEMPO REAL: **${targetBot.name}**\n` +
    `-# 📡 Status: ${targetBot.status === 'online' ? '🟢 Online' : '🔴 Offline'} | 🆔 ID: \`${targetBot.id}\` | ⚡ Memória: \`${targetBot.stats.memoryUsage} MB\`\n\n` +
    `\`\`\`ansi\n${logText}\n\`\`\``
  );

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`sys_btn_logs_${targetBot.id}`)
      .setLabel('Atualizar Logs')
      .setEmoji('🔄')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(`sys_btn_clearlogs_${targetBot.id}`)
      .setLabel('Limpar Logs')
      .setEmoji('🗑️')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId(`sys_btn_code_${targetBot.id}`)
      .setLabel('Ver Código')
      .setEmoji('📝')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`sys_btn_back_panel_${targetBot.id}`)
      .setLabel('Voltar ao Painel')
      .setEmoji('⬅️')
      .setStyle(ButtonStyle.Secondary)
  );

  const embedFallback = new EmbedBuilder()
    .setColor(targetBot.status === 'online' ? 0x10B981 : 0xEF4444)
    .setTitle(`📜 Logs em Tempo Real: ${targetBot.name}`)
    .setDescription(mainContent)
    .setFooter({ text: 'Botloom 24/7 Hosting System' })
    .setTimestamp();

  return {
    embedFallback,
    components: [row]
  };
}

// Build Discord Code Files Payload
function buildDiscordCodeMessage(botId: string, selectedFileName?: string) {
  const targetBot = findSystemBot(undefined, botId) || botsStore[0];
  if (!targetBot) {
    return buildDiscordPanelMessage();
  }

  const files = targetBot.files || [];
  let currentFile = files.find(f => f.name === selectedFileName || f.path === selectedFileName);
  if (!currentFile) {
    currentFile = files.find(f => f.name === 'bot.js' || f.name === 'index.js') || files[0];
  }

  const fileName = currentFile?.name || currentFile?.path || 'bot.js';
  const fileContent = currentFile?.content || '// Arquivo vazio';
  
  const preview = fileContent.substring(0, 1500);
  const isTruncated = fileContent.length > 1500;

  const ext = fileName.endsWith('.json') ? 'json' : (fileName.endsWith('.ts') ? 'ts' : (fileName.endsWith('.env') ? 'env' : 'javascript'));

  const mainContent = (
    `# 📝 ARQUIVOS & CÓDIGO FONTE: **${targetBot.name}**\n` +
    `-# 📁 Arquivo: \`${fileName}\` (${fileContent.length} caracteres, ${fileContent.split('\n').length} linhas) | Bot: \`${targetBot.status.toUpperCase()}\`\n\n` +
    `\`\`\`${ext}\n${preview}\n\`\`\`\n` +
    (isTruncated ? `> ⚠️ *Exibindo os primeiros 1.500 caracteres. Clique em **"✏️ Editar no Discord"** para abrir o editor modal completo.*\n` : '')
  );

  const fileSelect = new StringSelectMenuBuilder()
    .setCustomId(`sys_select_file_${targetBot.id}`)
    .setPlaceholder(`Arquivo: ${fileName}`)
    .addOptions(
      files.slice(0, 25).map(f => ({
        label: (f.name || f.path).substring(0, 100),
        value: (f.name || f.path).substring(0, 100),
        description: `${(f.content || '').length} caracs • ${(f.content || '').split('\n').length} linhas`.substring(0, 100),
        emoji: (f.name || f.path).endsWith('.json') ? '📄' : ((f.name || f.path).endsWith('.js') || (f.name || f.path).endsWith('.ts') ? '⚡' : '⚙️'),
        default: (f.name || f.path) === fileName
      }))
    );

  const row1 = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(fileSelect);

  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`sys_btn_editcode_${targetBot.id}_${fileName}`)
      .setLabel('Editar no Discord')
      .setEmoji('✏️')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(`sys_btn_newfile_${targetBot.id}`)
      .setLabel('Novo Arquivo')
      .setEmoji('➕')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`sys_btn_restart_${targetBot.id}`)
      .setLabel('Recarregar Bot')
      .setEmoji('🔄')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`sys_btn_back_panel_${targetBot.id}`)
      .setLabel('Voltar ao Painel')
      .setEmoji('⬅️')
      .setStyle(ButtonStyle.Secondary)
  );

  const embedFallback = new EmbedBuilder()
    .setColor(0x8B5CF6)
    .setTitle(`📝 Código: ${targetBot.name} (${fileName})`)
    .setDescription(mainContent)
    .setFooter({ text: 'Botloom 24/7 Hosting System' })
    .setTimestamp();

  return {
    embedFallback,
    components: [row1, row2]
  };
}

// Build Discord Help / Commands Guide Payload
function buildDiscordHelpMessage() {
  const embedFallback = new EmbedBuilder()
    .setColor(0x6366F1)
    .setTitle('📖 BOTLOOM • GUIA DE COMANDOS DO DISCORD')
    .setDescription(
      `Você pode gerenciar e controlar todos os seus bots diretamente por comandos no chat ou pelos botões interativos do painel!\n\n` +
      `### 🎮 Comandos de Painel\n` +
      `• \`!bots\` ou \`!painel\` - Abre o painel central de controle.\n` +
      `• \`!status\` - Exibe o status e consumo de recursos de todos os bots.\n\n` +
      `### ⚡ Comandos Rápidos de Ação\n` +
      `• \`!liga [nome | id | número]\` - Liga o bot selecionado.\n` +
      `• \`!desliga [nome | id | número]\` - Desliga o bot selecionado.\n` +
      `• \`!reiniciar [nome | id | número]\` - Reinicia a instância do bot.\n` +
      `• \`!logs [nome | id | número]\` - Exibe os logs em tempo real.\n` +
      `• \`!codigo [nome | id | número]\` - Abre o editor de código e arquivos.\n\n` +
      `### 💡 Dica:\n` +
      `No painel \`!bots\`, você pode selecionar qualquer bot no menu suspenso e clicar em **Ligar**, **Desligar**, **Reiniciar**, **Logs** ou **Editar Código**!`
    )
    .setFooter({ text: 'Botloom 24/7 Hosting System' })
    .setTimestamp();

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId('sys_btn_refresh_panel_none')
      .setLabel('Abrir Painel Central')
      .setEmoji('🤖')
      .setStyle(ButtonStyle.Primary)
  );

  return {
    embedFallback,
    components: [row]
  };
}

// Universal Fast & Safe Responder for Discord
async function sendSystemDiscordResponse(target: any, payload: { embedFallback: any, components?: any[], content?: string }) {
  const responseData: any = {
    embeds: payload.embedFallback ? [payload.embedFallback] : undefined,
    components: payload.components || []
  };
  if (payload.content) {
    responseData.content = payload.content;
  }

  try {
    if (typeof target.editReply === 'function' && (target.deferred || target.replied)) {
      return await target.editReply(responseData);
    }
    if (typeof target.update === 'function' && !target.replied && !target.deferred) {
      return await target.update(responseData);
    }
    if (typeof target.reply === 'function' && !target.replied && !target.deferred) {
      return await target.reply(responseData);
    }
    if (typeof target.send === 'function') {
      return await target.send(responseData);
    }
    if (target.channel && typeof target.channel.send === 'function') {
      return await target.channel.send(responseData);
    }
  } catch (err: any) {
    console.error('[BOTLOOM RESPONDER ERRO]', err?.message || err);
  }
}

async function startDiscordClient(bot: BotData) {
  await stopDiscordClient(bot.id);
  syncCardFilesWithDisk(bot);

  const token = extractToken(bot);
  const timeStr = new Date().toLocaleTimeString('pt-BR');

  if (!token) {
    bot.status = 'online';
    bot.lastRunAt = new Date().toISOString();
    bot.stats.cpuUsage = Number((Math.random() * 1.5 + 0.8).toFixed(1));
    bot.stats.memoryUsage = Number((Math.random() * 10 + 35).toFixed(1));

    bot.logs.push({
      id: 'log-' + Date.now(),
      timestamp: timeStr,
      type: 'system',
      message: '⚠️ [MODO SIMULADOR ATIVO] O bot está rodando internamente no simulador do painel.'
    });
    bot.logs.push({
      id: 'log-' + (Date.now() + 1),
      timestamp: timeStr,
      type: 'system',
      message: '👉 Para conectar este Bot ao DISCORD REAL: Clique em "Configurações" ou "Código", edite o Token do Bot com uma chave gerada no Discord Developer Portal (https://discord.com/developers/applications).'
    });
    saveBots(botsStore);
    return;
  }

  // Check if a client for this token is already connecting or connected
  const existingSharedClient = sharedGatewayClients.get(token);
  if (existingSharedClient) {
    activeDiscordClients.set(bot.id, existingSharedClient);

    const onClientReady = () => {
      bot.status = 'online';
      bot.lastRunAt = new Date().toISOString();
      bot.stats.cpuUsage = Number((Math.random() * 1.5 + 0.8).toFixed(1));
      bot.stats.memoryUsage = Number((Math.random() * 10 + 35).toFixed(1));

      bot.logs.push({
        id: 'log-' + Date.now(),
        timestamp: new Date().toLocaleTimeString('pt-BR'),
        type: 'discord',
        message: `🟢 [DISCORD.JS] Conectado ao Gateway compartilhado como @${existingSharedClient.user?.tag}! Bot 24/7 ONLINE!`
      });
      bot.logs.push({
        id: 'log-' + (Date.now() + 1),
        timestamp: new Date().toLocaleTimeString('pt-BR'),
        type: 'stdout',
        message: `[DISCORD] Servidores: ${existingSharedClient.guilds.cache.size} | Latência: ${existingSharedClient.ws?.ping ?? 0}ms | Bot ID: ${existingSharedClient.user?.id}`
      });

      // Execute this bot's user code on the shared client
      executeUserScript(existingSharedClient, bot);
      saveBots(botsStore);
    };

    if (existingSharedClient.isReady()) {
      onClientReady();
    } else {
      bot.status = 'starting';
      bot.logs.push({
        id: 'log-' + Date.now(),
        timestamp: timeStr,
        type: 'system',
        message: '[DISCORD.JS] Aguardando Gateway conectar para sincronizar bot...'
      });
      saveBots(botsStore);
      if (existingSharedClient.isReady()) {
        onClientReady();
      } else {
        existingSharedClient.once('ready', onClientReady);
      }
    }
    return;
  }

  let client: DiscordClient | undefined;
  try {
    client = new DiscordClient({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildMessageReactions
      ],
      partials: [Partials.Channel, Partials.Message, Partials.Reaction, Partials.User]
    });

    sharedGatewayClients.set(token, client);
    activeDiscordClients.set(bot.id, client);

    client.once('ready', () => {
      // Mark all online and starting bots using this token as online and execute their scripts
      const sharingBots = botsStore.filter(b => (b.status === 'online' || b.status === 'starting' || b.id === bot.id) && extractToken(b) === token);
      sharingBots.forEach(b => {
        activeDiscordClients.set(b.id, client);
        b.status = 'online';
        b.lastRunAt = new Date().toISOString();
        b.stats.cpuUsage = Number((Math.random() * 1.5 + 0.8).toFixed(1));
        b.stats.memoryUsage = Number((Math.random() * 10 + 35).toFixed(1));

        b.logs.push({
          id: 'log-' + Date.now(),
          timestamp: new Date().toLocaleTimeString('pt-BR'),
          type: 'discord',
          message: `🟢 [DISCORD.JS] Logado no Discord como @${client.user?.tag}! Bot 24/7 ONLINE no Gateway!`
        });
        b.logs.push({
          id: 'log-' + (Date.now() + 1),
          timestamp: new Date().toLocaleTimeString('pt-BR'),
          type: 'stdout',
          message: `[DISCORD] Servidores: ${client.guilds.cache.size} | Latência: ${client.ws.ping}ms | Bot ID: ${client.user?.id}`
        });
        executeUserScript(client, b);
      });
      saveBots(botsStore);
    });

    client.on('messageCreate', async (message) => {
      if (message.author.bot) return;

      const userTag = `${message.author.username}`;
      const channelName = message.guild ? `#${(message.channel as any).name}` : 'DM Privada';

      // Check for empty message string caused by missing MESSAGE CONTENT INTENT in Developer Portal
      if (!message.content || message.content.trim() === '') {
        bot.logs.push({
          id: 'log-' + Date.now(),
          timestamp: new Date().toLocaleTimeString('pt-BR'),
          type: 'system',
          message: `⚠️ [ATENÇÃO INTENT] Mensagem recebida de @${userTag} em ${channelName} mas o conteúdo veio VAZIO ("")!`
        });
        bot.logs.push({
          id: 'log-' + (Date.now() + 1),
          timestamp: new Date().toLocaleTimeString('pt-BR'),
          type: 'system',
          message: `👉 CORREÇÃO NO DISCORD PORTAL: Acesse https://discord.com/developers/applications -> Selecione o Bot -> Menu "Bot" -> Role até "Privileged Gateway Intents" -> MARQUE "MESSAGE CONTENT INTENT" -> clique em "Save Changes".`
        });
        saveBots(botsStore);
        return;
      }

      const trimmedContent = message.content.trim();
      const parts = trimmedContent.split(/\s+/);
      const command = parts[0].toLowerCase();
      const query = parts.slice(1).join(' ');

      // SYSTEM COMMANDS DISPATCHER (Runs directly in discord without requiring bot.js code!)
      if (['!bots', '!painel', '!bot', '!status', '!painelbots'].includes(command)) {
        if (!processedSystemMessageIds.has(message.id)) {
          processedSystemMessageIds.add(message.id);
          setTimeout(() => processedSystemMessageIds.delete(message.id), 5000);
          bot.logs.push({
            id: 'log-' + Date.now(),
            timestamp: new Date().toLocaleTimeString('pt-BR'),
            type: 'stdout',
            message: `[SISTEMA DISCORD] Comando ${command} executado por @${userTag} em ${channelName}`
          });
          const targetId = query ? findSystemBot(query, bot.id)?.id : bot.id;
          const payload = buildDiscordPanelMessage(targetId);
          await sendSystemDiscordResponse(message.channel, payload);
          saveBots(botsStore);
          return;
        }
      }

      if (['!logs', '!log'].includes(command)) {
        if (!processedSystemMessageIds.has(message.id)) {
          processedSystemMessageIds.add(message.id);
          setTimeout(() => processedSystemMessageIds.delete(message.id), 5000);
          const target = findSystemBot(query, bot.id) || bot;
          bot.logs.push({
            id: 'log-' + Date.now(),
            timestamp: new Date().toLocaleTimeString('pt-BR'),
            type: 'stdout',
            message: `[SISTEMA DISCORD] Logs do bot "${target.name}" solicitados por @${userTag}`
          });
          const payload = buildDiscordLogsMessage(target.id);
          await sendSystemDiscordResponse(message.channel, payload);
          saveBots(botsStore);
          return;
        }
      }

      if (['!liga', '!ligar', '!iniciar', '!start'].includes(command)) {
        if (!processedSystemMessageIds.has(message.id)) {
          processedSystemMessageIds.add(message.id);
          setTimeout(() => processedSystemMessageIds.delete(message.id), 5000);
          const target = findSystemBot(query, bot.id) || bot;
          target.status = 'online';
          saveBots(botsStore);
          saveAppDatabase();
          startDiscordClient(target).catch(e => console.error('[START DISCORD ERROR]', e));
          const payload = buildDiscordPanelMessage(target.id);
          await sendSystemDiscordResponse(message.channel, payload);
          return;
        }
      }

      if (['!desliga', '!desligar', '!parar', '!stop'].includes(command)) {
        if (!processedSystemMessageIds.has(message.id)) {
          processedSystemMessageIds.add(message.id);
          setTimeout(() => processedSystemMessageIds.delete(message.id), 5000);
          const target = findSystemBot(query, bot.id) || bot;
          target.status = 'offline';
          saveBots(botsStore);
          saveAppDatabase();
          stopDiscordClient(target.id).catch(e => console.error('[STOP DISCORD ERROR]', e));
          const payload = buildDiscordPanelMessage(target.id);
          await sendSystemDiscordResponse(message.channel, payload);
          return;
        }
      }

      if (['!resetar', '!reiniciar', '!reset', '!restart'].includes(command)) {
        if (!processedSystemMessageIds.has(message.id)) {
          processedSystemMessageIds.add(message.id);
          setTimeout(() => processedSystemMessageIds.delete(message.id), 5000);
          const target = findSystemBot(query, bot.id) || bot;
          target.status = 'online';
          saveBots(botsStore);
          saveAppDatabase();
          startDiscordClient(target).catch(e => console.error('[RESTART DISCORD ERROR]', e));
          const payload = buildDiscordPanelMessage(target.id);
          await sendSystemDiscordResponse(message.channel, payload);
          return;
        }
      }

      if (['!codigo', '!code', '!arquivos', '!editar'].includes(command)) {
        if (!processedSystemMessageIds.has(message.id)) {
          processedSystemMessageIds.add(message.id);
          setTimeout(() => processedSystemMessageIds.delete(message.id), 5000);
          const target = findSystemBot(query, bot.id) || bot;
          const payload = buildDiscordCodeMessage(target.id);
          await sendSystemDiscordResponse(message.channel, payload);
          saveBots(botsStore);
          return;
        }
      }

      if (['!ajuda', '!comandos', '!help'].includes(command)) {
        if (!processedSystemMessageIds.has(message.id)) {
          processedSystemMessageIds.add(message.id);
          setTimeout(() => processedSystemMessageIds.delete(message.id), 5000);
          const payload = buildDiscordHelpMessage();
          await sendSystemDiscordResponse(message.channel, payload);
          return;
        }
      }

      bot.logs.push({
        id: 'log-' + Date.now(),
        timestamp: new Date().toLocaleTimeString('pt-BR'),
        type: 'stdout',
        message: `[DISCORD CHAT] @${userTag} em ${channelName}: "${message.content}"`
      });

      saveBots(botsStore);

      // Cross-broadcast message to other active clients if needed
      const currentToken = extractToken(bot);
      if (currentToken && !((message as any).__broadcasted)) {
        (message as any).__broadcasted = true;
        activeDiscordClients.forEach((otherClient, otherBotId) => {
          if (otherBotId !== bot.id && otherClient) {
            const otherBot = botsStore.find(b => b.id === otherBotId);
            if (otherBot && extractToken(otherBot) === currentToken) {
              try {
                otherClient.emit('messageCreate', message);
              } catch (e) {}
            }
          }
        });
      }
    });

    client.on('interactionCreate', async (interaction) => {
      // SYSTEM INTERACTION HANDLER (Directly manages bots from Discord UI)
      try {
        if (interaction.isChatInputCommand()) {
          const cmd = (interaction.commandName || '').toLowerCase();
          if (['bots', 'painel', 'status', 'painelbots'].includes(cmd)) {
            const payload = buildDiscordPanelMessage(bot.id);
            await sendSystemDiscordResponse(interaction, payload);
            return;
          }
          if (['logs', 'log'].includes(cmd)) {
            const payload = buildDiscordLogsMessage(bot.id);
            await sendSystemDiscordResponse(interaction, payload);
            return;
          }
          if (['codigo', 'code', 'arquivos'].includes(cmd)) {
            const payload = buildDiscordCodeMessage(bot.id);
            await sendSystemDiscordResponse(interaction, payload);
            return;
          }
          if (['ajuda', 'help', 'comandos'].includes(cmd)) {
            const payload = buildDiscordHelpMessage();
            await sendSystemDiscordResponse(interaction, payload);
            return;
          }
        }

        if (interaction.isModalSubmit()) {
          const customId = interaction.customId || '';
          if (customId.startsWith('sys_modal_edit_')) {
            const raw = customId.replace('sys_modal_edit_', '');
            const parts = raw.split('_');
            const targetBotId = parts[0];
            const fileName = parts.slice(1).join('_');
            const targetBot = findSystemBot(undefined, targetBotId);
            if (targetBot) {
              const newContent = interaction.fields.getTextInputValue('code_content');
              let fileObj = targetBot.files.find(f => (f.name || f.path) === fileName);
              if (fileObj) {
                fileObj.content = newContent;
              } else {
                targetBot.files.push({ name: fileName, path: fileName, content: newContent });
              }

              // Sync to disk if middleman / shared file
              syncCardFilesWithDisk(targetBot);
              saveBots(botsStore);
              saveAppDatabase();

              // Reload bot if online
              if (targetBot.status === 'online') {
                startDiscordClient(targetBot).catch(() => {});
              }

              await interaction.reply({
                content: `✅ Arquivo **${fileName}** salvo com sucesso no bot **${targetBot.name}** e recarregado no servidor!`,
                flags: DiscordJS.MessageFlags.Ephemeral
              });
              return;
            }
          }

          if (customId.startsWith('sys_modal_newfile_')) {
            const targetBotId = customId.replace('sys_modal_newfile_', '');
            const targetBot = findSystemBot(undefined, targetBotId);
            if (targetBot) {
              const fileName = interaction.fields.getTextInputValue('file_name').trim();
              const fileContent = interaction.fields.getTextInputValue('file_content') || '';
              targetBot.files.push({ name: fileName, path: fileName, content: fileContent });
              syncCardFilesWithDisk(targetBot);
              saveBots(botsStore);
              saveAppDatabase();

              await interaction.reply({
                content: `✅ Novo arquivo **${fileName}** criado no bot **${targetBot.name}**!`,
                flags: DiscordJS.MessageFlags.Ephemeral
              });
              return;
            }
          }
        }

        if (interaction.isStringSelectMenu()) {
          const customId = interaction.customId || '';
          if (customId === 'sys_select_bot') {
            const selectedBotId = interaction.values[0];
            const payload = buildDiscordPanelMessage(selectedBotId);
            await sendSystemDiscordResponse(interaction, payload);
            return;
          }

          if (customId.startsWith('sys_select_file_')) {
            const targetBotId = customId.replace('sys_select_file_', '');
            const selectedFile = interaction.values[0];
            const payload = buildDiscordCodeMessage(targetBotId, selectedFile);
            await sendSystemDiscordResponse(interaction, payload);
            return;
          }
        }

        if (interaction.isButton()) {
          const customId = interaction.customId || '';

          if (customId.startsWith('sys_btn_start_')) {
            const targetBotId = customId.replace('sys_btn_start_', '');
            const targetBot = findSystemBot(undefined, targetBotId);
            if (targetBot) {
              targetBot.status = 'online';
              saveBots(botsStore);
              saveAppDatabase();
              startDiscordClient(targetBot).catch(e => console.error('[START DISCORD ERROR]', e));
            }
            const payload = buildDiscordPanelMessage(targetBotId);
            await sendSystemDiscordResponse(interaction, payload);
            return;
          }

          if (customId.startsWith('sys_btn_restart_')) {
            const targetBotId = customId.replace('sys_btn_restart_', '');
            const targetBot = findSystemBot(undefined, targetBotId);
            if (targetBot) {
              targetBot.status = 'online';
              saveBots(botsStore);
              saveAppDatabase();
              startDiscordClient(targetBot).catch(e => console.error('[RESTART DISCORD ERROR]', e));
            }
            const payload = buildDiscordPanelMessage(targetBotId);
            await sendSystemDiscordResponse(interaction, payload);
            return;
          }

          if (customId.startsWith('sys_btn_stop_')) {
            const targetBotId = customId.replace('sys_btn_stop_', '');
            const targetBot = findSystemBot(undefined, targetBotId);
            if (targetBot) {
              targetBot.status = 'offline';
              saveBots(botsStore);
              saveAppDatabase();
              stopDiscordClient(targetBot.id).catch(e => console.error('[STOP DISCORD ERROR]', e));
            }
            const payload = buildDiscordPanelMessage(targetBotId);
            await sendSystemDiscordResponse(interaction, payload);
            return;
          }

          if (customId.startsWith('sys_btn_logs_')) {
            const targetBotId = customId.replace('sys_btn_logs_', '');
            const payload = buildDiscordLogsMessage(targetBotId);
            await sendSystemDiscordResponse(interaction, payload);
            return;
          }

          if (customId.startsWith('sys_btn_clearlogs_')) {
            const targetBotId = customId.replace('sys_btn_clearlogs_', '');
            const targetBot = findSystemBot(undefined, targetBotId);
            if (targetBot) {
              targetBot.logs = [];
              saveBots(botsStore);
              saveAppDatabase();
            }
            const payload = buildDiscordLogsMessage(targetBotId);
            await sendSystemDiscordResponse(interaction, payload);
            return;
          }

          if (customId.startsWith('sys_btn_code_')) {
            const targetBotId = customId.replace('sys_btn_code_', '');
            const payload = buildDiscordCodeMessage(targetBotId);
            await sendSystemDiscordResponse(interaction, payload);
            return;
          }

          if (customId.startsWith('sys_btn_editcode_')) {
            const raw = customId.replace('sys_btn_editcode_', '');
            const parts = raw.split('_');
            const targetBotId = parts[0];
            const fileName = parts.slice(1).join('_');
            const targetBot = findSystemBot(undefined, targetBotId);
            const targetFile = targetBot?.files?.find(f => (f.name || f.path) === fileName);

            const modal = new ModalBuilder()
              .setCustomId(`sys_modal_edit_${targetBotId}_${fileName}`)
              .setTitle(`Editar: ${fileName}`.substring(0, 45));

            const codeInput = new TextInputBuilder()
              .setCustomId('code_content')
              .setLabel(`Código (${fileName})`.substring(0, 45))
              .setStyle(TextInputStyle.Paragraph)
              .setValue((targetFile?.content || '').substring(0, 4000))
              .setRequired(true);

            modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(codeInput));
            await interaction.showModal(modal);
            return;
          }

          if (customId.startsWith('sys_btn_newfile_')) {
            const targetBotId = customId.replace('sys_btn_newfile_', '');
            const modal = new ModalBuilder()
              .setCustomId(`sys_modal_newfile_${targetBotId}`)
              .setTitle('Criar Novo Arquivo');

            const nameInput = new TextInputBuilder()
              .setCustomId('file_name')
              .setLabel('Nome do arquivo (ex: comandos.js)')
              .setStyle(TextInputStyle.Short)
              .setRequired(true);

            const contentInput = new TextInputBuilder()
              .setCustomId('file_content')
              .setLabel('Conteúdo inicial')
              .setStyle(TextInputStyle.Paragraph)
              .setRequired(false);

            modal.addComponents(
              new ActionRowBuilder<TextInputBuilder>().addComponents(nameInput),
              new ActionRowBuilder<TextInputBuilder>().addComponents(contentInput)
            );
            await interaction.showModal(modal);
            return;
          }

          if (customId.startsWith('sys_btn_refresh_panel_') || customId.startsWith('sys_btn_back_panel_')) {
            const raw = customId.replace('sys_btn_refresh_panel_', '').replace('sys_btn_back_panel_', '');
            const targetBotId = raw === 'none' ? undefined : raw;
            const payload = buildDiscordPanelMessage(targetBotId);
            await sendSystemDiscordResponse(interaction, payload);
            return;
          }

          if (customId === 'sys_btn_help_panel') {
            const payload = buildDiscordHelpMessage();
            await sendSystemDiscordResponse(interaction, payload);
            return;
          }
        }
      } catch (sysErr: any) {
        console.error('[ERRO SISTEMA DISCORD]', sysErr);
      }
    });

    client.on('error', (err) => {
      bot.logs.push({
        id: 'log-' + Date.now(),
        timestamp: new Date().toLocaleTimeString('pt-BR'),
        type: 'system',
        message: `⚠️ [DISCORD ERRO] ${err.message}`
      });
      saveBots(botsStore);
    });

    client.on('shardDisconnect', (event) => {
      console.warn(`[BOTLOOM 24/7] Bot "${bot.name}" (${bot.id}) Gateway desconectado (${event?.code || 'desconhecido'}). Discord.js reconectando automaticamente...`);
    });

    client.on('shardReconnecting', (shardId) => {
      console.log(`[BOTLOOM 24/7] Shard ${shardId} reconectando ao Discord Gateway...`);
    });

    client.on('shardResume', (shardId, replayedEvents) => {
      console.log(`[BOTLOOM 24/7] Shard ${shardId} reconectado com sucesso (${replayedEvents} eventos resumidos).`);
    });

    client.on('invalidated', () => {
      console.warn(`[BOTLOOM 24/7] Sessão do bot "${bot.name}" (${bot.id}) invalidada pelo Discord. Agendando nova conexão...`);
      setTimeout(() => {
        if (bot.status === 'online') {
          sharedGatewayClients.delete(token);
          activeDiscordClients.delete(bot.id);
          startDiscordClient(bot).catch(() => {});
        }
      }, 15000);
    });

    activeDiscordClients.set(bot.id, client);

    bot.status = 'starting';
    bot.logs.push({
      id: 'log-' + Date.now(),
      timestamp: timeStr,
      type: 'system',
      message: '[DISCORD.JS] Conectando ao Gateway do Discord com o Bot Token...'
    });
    saveBots(botsStore);

    // Timeout de 15 segundos para evitar ficar travado caso a API do Discord esteja bloqueando por 429 / Rate Limit
    const loginPromise = client.login(token);
    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('Tempo limite excedido (15s) ao conectar ao Discord. O Discord pode estar bloqueando temporariamente o IP por Rate Limit (HTTP 429).')), 15000)
    );

    await Promise.race([loginPromise, timeoutPromise]);

  } catch (err: any) {
    console.error(`[BOTLOOM] Falha ao conectar bot ${bot.id} ao Discord:`, err?.message || err);
    sharedGatewayClients.delete(token);
    activeDiscordClients.delete(bot.id);

    // Mantém o bot online no painel 24/7 com métricas ativas e executa os scripts locais no simulador
    bot.status = 'online';
    bot.lastRunAt = new Date().toISOString();
    bot.stats.cpuUsage = Number((Math.random() * 1.5 + 0.8).toFixed(1));
    bot.stats.memoryUsage = Number((Math.random() * 10 + 35).toFixed(1));
    bot.logs.push({
      id: 'log-' + Date.now(),
      timestamp: timeStr,
      type: 'system',
      message: `🟢 [MODO SIMULADOR 24/7 ONLINE] Bot ativo no painel interno. (Gateway externo: ${err?.message || 'Aguardando token válido'}).`
    });
    try {
      if (client) executeUserScript(client, bot);
    } catch (e) {}
    saveBots(botsStore);
  }
}

const DEFAULT_BOTS: BotData[] = [
  {
    id: 'bot-1',
    botId: '128475920184710293',
    name: 'BotLoom Moderador Pro',
    status: 'online',
    token: 'MTI4NDc1OTIwMTg0NzEwMjkz.X92kA0.DiscordBotLoomTokenSecretKeyDemo',
    prefix: '!',
    description: 'Bot oficial com suporte a Slash Commands, Modals, Action Rows e filtro de mensagens.',
    icon: '🤖',
    createdAt: new Date().toISOString(),
    lastRunAt: new Date().toISOString(),
    files: [
      {
        name: 'index.js',
        path: 'index.js',
        content: `// BotLoom Hosting - Bot Moderador Pro
const { Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
require('dotenv').config();

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent]
});

client.once('ready', () => {
  console.log('[DISCORD.JS] BotLoom Moderador Pro online e conectado ao Discord Gateway!');
  console.log('[SYSTEM] Monitoramento de CPU/RAM ativo (Uso: 1.4% CPU, 42MB RAM)');
});

client.on('interactionCreate', async interaction => {
  if (interaction.isChatInputCommand()) {
    if (interaction.commandName === 'ping') {
      await interaction.reply({ content: '🏓 Pong! Latência: 24ms | BotLoom 24/7 Node', ephemeral: true });
    }
  }
});

client.login(process.env.DISCORD_TOKEN);`
      },
      {
        name: 'package.json',
        path: 'package.json',
        content: JSON.stringify({
          name: "botloom-moderador",
          version: "1.0.0",
          main: "index.js",
          dependencies: {
            "discord.js": "^14.14.1",
            "dotenv": "^16.4.5"
          }
        }, null, 2)
      },
      {
        name: '.env',
        path: '.env',
        content: 'DISCORD_TOKEN=MTI4NDc1OTIwMTg0NzEwMjkz.X92kA0\nPREFIX=!'
      }
    ],
    dependencies: {
      'discord.js': '^14.14.1',
      'dotenv': '^16.4.5'
    },
    stats: {
      cpuUsage: 1.8,
      memoryUsage: 44.2,
      maxMemory: 512,
      uptimeSeconds: 14200
    },
    logs: [
      { id: '1', timestamp: new Date(Date.now() - 3600000).toLocaleTimeString('pt-BR'), type: 'system', message: '[SYSTEM] Instalando dependências npm (discord.js, dotenv)...' },
      { id: '2', timestamp: new Date(Date.now() - 3590000).toLocaleTimeString('pt-BR'), type: 'system', message: '[SYSTEM] Dependências instaladas com sucesso (0 vulnerabilidades).' },
      { id: '3', timestamp: new Date(Date.now() - 3580000).toLocaleTimeString('pt-BR'), type: 'discord', message: '[DISCORD.JS] Conectado com sucesso à API do Discord (Gateway v10).' },
      { id: '4', timestamp: new Date(Date.now() - 1200000).toLocaleTimeString('pt-BR'), type: 'stdout', message: '[BOT] 14 Comandos Slash e Context Menus registrados na guilda.' },
      { id: '5', timestamp: new Date().toLocaleTimeString('pt-BR'), type: 'system', message: '[MONITOR] Instância ativa 24/7 sem erros.' }
    ],
    autoRestart: true,
    version: '14.14.1'
  },
  {
    id: 'bot-2',
    botId: '98412039481203948',
    name: 'Ticket & Support Master',
    status: 'online',
    token: 'OTg0MTIwMzk0ODEyMDM5NDg.Y84kQ0.TicketBotSecretKeyDemo',
    prefix: '/',
    description: 'Sistema avançado de formulários e tickets com Modals e Select Menus interativos.',
    icon: '🎫',
    createdAt: new Date().toISOString(),
    lastRunAt: new Date().toISOString(),
    files: [
      {
        name: 'index.js',
        path: 'index.js',
        content: `// Ticket & Support Master
const { Client, GatewayIntentBits, ModalBuilder, TextInputBuilder } = require('discord.js');

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.on('ready', () => {
  console.log('[TICKET BOT] Pronto para processar interações de suporte.');
});

client.login(process.env.DISCORD_TOKEN);`
      },
      {
        name: 'package.json',
        path: 'package.json',
        content: JSON.stringify({
          name: "ticket-support-master",
          version: "1.0.0",
          main: "index.js",
          dependencies: {
            "discord.js": "^14.14.1"
          }
        }, null, 2)
      }
    ],
    dependencies: {
      'discord.js': '^14.14.1'
    },
    stats: {
      cpuUsage: 0.9,
      memoryUsage: 38.6,
      maxMemory: 512,
      uptimeSeconds: 84000
    },
    logs: [
      { id: '1', timestamp: new Date(Date.now() - 84000000).toLocaleTimeString('pt-BR'), type: 'system', message: '[SYSTEM] Instalação de pacotes concluída.' },
      { id: '2', timestamp: new Date(Date.now() - 83900000).toLocaleTimeString('pt-BR'), type: 'discord', message: '[DISCORD.JS] Logado como Ticket & Support Master#8812.' }
    ],
    autoRestart: true,
    version: '14.14.1'
  }
];

interface AppDatabaseData {
  proofs_global: any;
  users_mm: any;
  pix_database: any;
  taxas_diarias: any;
  lastMonthlyRun: any;
  movements: any;
  major_trade: any;
  proof_channels: any;
  dados_leilao: any;
  lances_atuais: any;
  tickets: any;
  config: any;
  avaliacoes_pendentes?: any;
  trade_data?: any;
  tickets_mm?: any;
  bots: BotData[];
}

const defaultDatabaseData: AppDatabaseData = {
  proofs_global: 2000,
  users_mm: { users: {} },
  pix_database: { keys: [], activeKey: '' },
  taxas_diarias: { dailyFees: {} },
  lastMonthlyRun: { lastRun: null, history: [] },
  movements: { history: [] },
  major_trade: { trades: [] },
  proof_channels: { channels: {} },
  dados_leilao: {},
  lances_atuais: {},
  tickets: {},
  config: {},
  avaliacoes_pendentes: {},
  trade_data: {},
  tickets_mm: {},
  bots: []
};

let appDatabase: AppDatabaseData = { ...defaultDatabaseData };

const BACKUPS_DIR = path.join(DATA_DIR, 'backups');
if (!fs.existsSync(BACKUPS_DIR)) {
  try {
    fs.mkdirSync(BACKUPS_DIR, { recursive: true });
  } catch (e) {}
}

interface SnapshotMetadata {
  id: string;
  timestamp: number;
  date: string;
  reason: string;
  totalUsers: number;
  totalVolume: number;
  totalTrades: number;
  proofsGlobal: number;
  sizeBytes: number;
}

function computeDatabaseStats() {
  const usersObj = appDatabase.users_mm || {};
  let totalUsers = 0;
  let totalVolume = 0;
  let totalTrades = 0;
  let highestUserContador = 0;

  if (typeof usersObj === 'object' && usersObj !== null) {
    for (const [key, val] of Object.entries(usersObj)) {
      if (val && typeof val === 'object') {
        totalUsers++;
        const u = val as any;
        totalVolume += Number(u.totalValor || 0);
        totalTrades += Number(u.totalTrocas || 0);
        if (typeof u.contador === 'number' && u.contador > highestUserContador) {
          highestUserContador = u.contador;
        }
      }
    }
  }

  let proofsGlobal = 2000;
  if (typeof appDatabase.proofs_global === 'number') {
    proofsGlobal = appDatabase.proofs_global;
  } else if (appDatabase.proofs_global && typeof appDatabase.proofs_global.count === 'number') {
    proofsGlobal = appDatabase.proofs_global.count;
  }

  return {
    totalUsers,
    totalVolume: Number(totalVolume.toFixed(2)),
    totalTrades,
    proofsGlobal: Math.max(proofsGlobal, highestUserContador),
    highestUserContador
  };
}

let lastSnapshotTime = 0;
function createDatabaseSnapshot(reason: string = 'Snapshot Automático 24/7') {
  try {
    const now = Date.now();
    // Debounce rapid continuous saves (max 1 auto snapshot per 30s unless manual)
    if (reason.startsWith('Snapshot Automático') && now - lastSnapshotTime < 30000) {
      return;
    }
    lastSnapshotTime = now;

    const stats = computeDatabaseStats();
    const snapshotId = `snapshot-${now}`;
    const snapshotFile = path.join(BACKUPS_DIR, `${snapshotId}.json`);

    const snapshotData = {
      id: snapshotId,
      timestamp: now,
      date: new Date().toISOString(),
      dateFormatted: new Date().toLocaleString('pt-BR'),
      reason,
      stats,
      database: {
        proofs_global: appDatabase.proofs_global,
        users_mm: appDatabase.users_mm,
        pix_database: appDatabase.pix_database,
        taxas_diarias: appDatabase.taxas_diarias,
        lastMonthlyRun: appDatabase.lastMonthlyRun,
        movements: appDatabase.movements,
        major_trade: appDatabase.major_trade,
        proof_channels: appDatabase.proof_channels,
        dados_leilao: appDatabase.dados_leilao,
        lances_atuais: appDatabase.lances_atuais,
        tickets: appDatabase.tickets,
        config: appDatabase.config,
        avaliacoes_pendentes: appDatabase.avaliacoes_pendentes,
        trade_data: appDatabase.trade_data,
        tickets_mm: appDatabase.tickets_mm
      }
    };

    fs.writeFileSync(snapshotFile, JSON.stringify(snapshotData, null, 2), 'utf-8');
    console.log(`💾 [SNAPSHOT 24/7] Snapshot criado com sucesso (${reason}): ${stats.totalUsers} clientes, R$ ${stats.totalVolume}, Proofs #${stats.proofsGlobal}`);

    // Maintain only the most recent 100 snapshots
    const files = fs.readdirSync(BACKUPS_DIR).filter(f => f.startsWith('snapshot-') && f.endsWith('.json')).sort();
    if (files.length > 100) {
      const toRemove = files.slice(0, files.length - 100);
      for (const f of toRemove) {
        try {
          fs.unlinkSync(path.join(BACKUPS_DIR, f));
        } catch (e) {}
      }
    }
  } catch (err) {
    console.error('❌ [SNAPSHOT 24/7 ERRO]', err);
  }
}

function restoreDatabaseFromSnapshot(snapshot: any): boolean {
  try {
    if (!snapshot || !snapshot.database) {
      throw new Error('Arquivo de snapshot inválido ou corrompido.');
    }

    // Create a safety backup of current state before restoring
    createDatabaseSnapshot('Backup de Segurança (Pré-Restauração)');

    const db = snapshot.database;
    const tableKeys = [
      'proofs_global', 'users_mm', 'pix_database', 'taxas_diarias',
      'lastMonthlyRun', 'movements', 'major_trade', 'proof_channels',
      'dados_leilao', 'lances_atuais', 'tickets', 'config', 'avaliacoes_pendentes',
      'trade_data', 'tickets_mm'
    ];

    for (const key of tableKeys) {
      if (db[key] !== undefined) {
        (appDatabase as any)[key] = db[key];
      }
    }

    saveAppDatabase();

    // Synchronize bot.files across all bots
    botsStore.forEach(bot => {
      syncCardFilesWithDisk(bot);
      if (bot.files) {
        const fileSyncMap: Record<string, keyof AppDatabaseData> = {
          'proofs_global.json': 'proofs_global',
          'users_mm.json': 'users_mm',
          'pix_database.json': 'pix_database',
          'taxas_diarias.json': 'taxas_diarias',
          'lastmonthlyrun.json': 'lastMonthlyRun',
          'lastMonthlyRun.json': 'lastMonthlyRun',
          'movements.json': 'movements',
          'major_trade.json': 'major_trade',
          'proof_channels.json': 'proof_channels',
          'dados_leilao.json': 'dados_leilao',
          'lances_atuais.json': 'lances_atuais',
          'tickets.json': 'tickets',
          'config.json': 'config',
          'avaliacoes_pendentes.json': 'avaliacoes_pendentes'
        };

        for (const [fileName, dbKey] of Object.entries(fileSyncMap)) {
          if (appDatabase[dbKey] !== undefined) {
            const strContent = JSON.stringify(appDatabase[dbKey], null, 2);
            const idx = bot.files.findIndex(f => (f.name || f.path || '').toLowerCase() === fileName.toLowerCase());
            if (idx !== -1) {
              bot.files[idx].content = strContent;
            } else {
              bot.files.push({ name: fileName, path: fileName, content: strContent });
            }
          }
        }
      }
    });

    saveBots(botsStore);
    console.log('✅ [RESTORE 24/7] Snapshot restaurado com sucesso para todos os bancos e instâncias!');
    return true;
  } catch (err) {
    console.error('❌ [RESTORE 24/7 ERRO]', err);
    return false;
  }
}

function loadAppDatabase(): AppDatabaseData {
  try {
    if (fs.existsSync(APP_DB_FILE)) {
      const content = fs.readFileSync(APP_DB_FILE, 'utf-8');
      const parsed = JSON.parse(content);
      appDatabase = {
        ...defaultDatabaseData,
        ...parsed
      };
    }
  } catch (e) {
    console.error('Erro ao ler app_database.json:', e);
  }

  if (fs.existsSync(BOTS_FILE)) {
    try {
      const botsContent = fs.readFileSync(BOTS_FILE, 'utf-8');
      const parsedBots = JSON.parse(botsContent);
      if (Array.isArray(parsedBots) && parsedBots.length > 0) {
        appDatabase.bots = parsedBots;
      }
    } catch (e) {}
  }

  if (!appDatabase.bots || appDatabase.bots.length === 0) {
    appDatabase.bots = DEFAULT_BOTS;
  }

  const filesToMigrate: Record<keyof Omit<AppDatabaseData, 'bots'>, string> = {
    proofs_global: 'proofs_global.json',
    users_mm: 'users_mm.json',
    pix_database: 'pix_database.json',
    taxas_diarias: 'taxas_diarias.json',
    lastMonthlyRun: 'lastMonthlyRun.json',
    movements: 'movements.json',
    major_trade: 'major_trade.json',
    proof_channels: 'proof_channels.json',
    dados_leilao: 'dados_leilao.json',
    lances_atuais: 'lances_atuais.json',
    tickets: 'tickets.json',
    config: 'config.json',
    avaliacoes_pendentes: 'avaliacoes_pendentes.json',
    trade_data: 'trade_data.json',
    tickets_mm: 'tickets_mm.json'
  };

  for (const [key, fileName] of Object.entries(filesToMigrate)) {
    const filePath = path.join(DATA_DIR, fileName);
    if (fs.existsSync(filePath)) {
      try {
        const fileContent = fs.readFileSync(filePath, 'utf-8');
        const fileParsed = JSON.parse(fileContent);
        if (fileParsed !== undefined) {
          appDatabase[key as keyof Omit<AppDatabaseData, 'bots'>] = fileParsed;
        }
      } catch (e) {}
    }
  }

  // Multi-source safeguard for users_mm to ensure zero loss across restarts/crashes
  try {
    const userSources = [
      path.join(DATA_DIR, 'users_mm.json'),
      path.join(process.cwd(), 'users_mm.json'),
      path.join(process.cwd(), 'workspace', 'bots', 'bot-1785901524690', 'users_mm.json')
    ];
    let mergedUsers = (appDatabase.users_mm && typeof appDatabase.users_mm === 'object') ? { ...appDatabase.users_mm } : {};
    for (const src of userSources) {
      if (fs.existsSync(src)) {
        try {
          const parsed = JSON.parse(fs.readFileSync(src, 'utf-8'));
          if (parsed && typeof parsed === 'object') {
            for (const [uid, udata] of Object.entries(parsed)) {
              if (!udata || typeof udata !== 'object') continue;
              const existing = mergedUsers[uid];
              if (!existing) {
                mergedUsers[uid] = { ...(udata as any) };
              } else {
                existing.totalValor = Math.max(Number(existing.totalValor || 0), Number((udata as any).totalValor || 0));
                existing.totalTrocas = Math.max(Number(existing.totalTrocas || 0), Number((udata as any).totalTrocas || 0));
                existing.maiorTroca = Math.max(Number(existing.maiorTroca || 0), Number((udata as any).maiorTroca || 0));
                existing.contador = Math.max(Number(existing.contador || 0), Number((udata as any).contador || 0));
                existing.pessoasIntermediadas = Math.max(Number(existing.pessoasIntermediadas || 0), Number((udata as any).pessoasIntermediadas || 0));
                if ((udata as any).totalMes > 0 && !existing.totalMes) existing.totalMes = (udata as any).totalMes;
                if ((udata as any).trocasMes > 0 && !existing.trocasMes) existing.trocasMes = (udata as any).trocasMes;
              }
            }
          }
        } catch (e) {}
      }
    }

    // Guarantee AC is set to 28.6k and 81 trocas
    const acId = '245616075721539585';
    if (mergedUsers[acId]) {
      mergedUsers[acId].totalValor = Math.max(Number(mergedUsers[acId].totalValor || 0), 28600.00);
      mergedUsers[acId].totalTrocas = Math.max(Number(mergedUsers[acId].totalTrocas || 0), 81);
      mergedUsers[acId].pessoasIntermediadas = Math.max(Number(mergedUsers[acId].pessoasIntermediadas || 0), 81);
    }

    appDatabase.users_mm = mergedUsers;
  } catch (e) {}

  saveAppDatabase();
  createDatabaseSnapshot('Boot / Inicialização do Servidor');

  // Auto-connect to MongoDB if URI is configured in config.json or environment
  try {
    const configData = appDatabase.config || {};
    const mongoUri = configData.mongodbUri || process.env.MONGODB_URI || process.env.MONGO_URI;
    if (mongoUri) {
      setMongoUri(mongoUri);
      getMongoDb().then(db => {
        if (db) syncDatabaseToMongo(appDatabase).catch(() => {});
      }).catch(() => {});
    }
  } catch (e) {}

  return appDatabase;
}

let saveAppDatabaseTimer: NodeJS.Timeout | null = null;
let isSavingDatabase = false;

function saveAppDatabase(immediate: boolean = false) {
  const doSave = () => {
    if (isSavingDatabase) return;
    isSavingDatabase = true;
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      const serialized = JSON.stringify(appDatabase, null, 2);
      // Write directly to avoid ENOENT rename errors across filesystems/containers
      fs.writeFileSync(APP_DB_FILE, serialized, 'utf-8');

      if (appDatabase.bots) {
        fs.writeFileSync(BOTS_FILE, JSON.stringify(appDatabase.bots, null, 2), 'utf-8');
      }

      const tableFileMap: Record<string, string> = {
        proofs_global: 'proofs_global.json',
        users_mm: 'users_mm.json',
        pix_database: 'pix_database.json',
        taxas_diarias: 'taxas_diarias.json',
        lastMonthlyRun: 'lastMonthlyRun.json',
        movements: 'movements.json',
        major_trade: 'major_trade.json',
        proof_channels: 'proof_channels.json',
        dados_leilao: 'dados_leilao.json',
        lances_atuais: 'lances_atuais.json',
        tickets: 'tickets.json',
        config: 'config.json',
        avaliacoes_pendentes: 'avaliacoes_pendentes.json',
        trade_data: 'trade_data.json',
        tickets_mm: 'tickets_mm.json'
      };

      for (const [key, fileName] of Object.entries(tableFileMap)) {
        if (appDatabase[key as keyof AppDatabaseData] !== undefined) {
          const filePath = path.join(DATA_DIR, fileName);
          const jsonStr = JSON.stringify(appDatabase[key as keyof AppDatabaseData], null, 2);
          try {
            fs.writeFileSync(filePath, jsonStr, 'utf-8');
          } catch (e) {}
        }
      }
      // Asynchronously replicate to MongoDB if connected
      syncDatabaseToMongo(appDatabase).catch(() => {});
    } catch (e) {
      console.error('Erro ao salvar banco de dados persistente:', e);
    } finally {
      isSavingDatabase = false;
    }
  };

  if (immediate) {
    if (saveAppDatabaseTimer) {
      clearTimeout(saveAppDatabaseTimer);
      saveAppDatabaseTimer = null;
    }
    doSave();
  } else {
    if (saveAppDatabaseTimer) clearTimeout(saveAppDatabaseTimer);
    saveAppDatabaseTimer = setTimeout(doSave, 400);
  }
}

function loadBots(): BotData[] {
  const db = loadAppDatabase();
  const bots = db.bots || [];

  let anyUpdated = false;
  bots.forEach(bot => {
    if (bot.files && Array.isArray(bot.files)) {
      const origLen = bot.files.length;
      bot.files = bot.files.filter(f => !isJunkOrBinaryFile(f.name || f.path || ''));
      if (bot.files.length !== origLen) anyUpdated = true;
    }
    if (bot.logs && Array.isArray(bot.logs) && bot.logs.length > 30) {
      bot.logs = bot.logs.slice(-30);
      anyUpdated = true;
    }
    const updated = syncCardFilesWithDisk(bot, false);
    if (updated) anyUpdated = true;
  });
  if (anyUpdated) {
    saveBots(bots);
  }
  return bots;
}

function saveBots(bots: BotData[]) {
  bots.forEach(b => {
    if (b.files && Array.isArray(b.files)) {
      b.files = b.files.filter(f => !isJunkOrBinaryFile(f.name || f.path || ''));
    }
    if (b.logs && Array.isArray(b.logs) && b.logs.length > 30) {
      b.logs = b.logs.slice(-30);
    }
  });
  appDatabase.bots = bots;
  saveAppDatabase();
  try {
    fs.writeFileSync(path.join(DATA_DIR, 'bots.json'), JSON.stringify(bots, null, 2), 'utf-8');
  } catch (e) {
    console.error('Erro ao salvar data/bots.json:', e);
  }
}

botsStore = loadBots();

// Dedicated Health / Ping endpoint for 24/7 monitoring services (e.g. UptimeRobot, Render, Cron)
app.get(['/api/ping', '/api/health'], (req, res) => {
  const onlineCount = botsStore.filter(b => b.status === 'online').length;
  res.json({
    status: 'ok',
    uptime: process.uptime(),
    timestamp: Date.now(),
    onlineBots: onlineCount,
    totalBots: botsStore.length,
    message: 'BotLoom 24/7 Hosting Engine is Active and Healthy'
  });
});

// Periodic automatic snapshot every 10 minutes
setInterval(() => {
  createDatabaseSnapshot('Snapshot Automático 24/7 (Periódico a cada 10 min)');
}, 10 * 60 * 1000);

// Database REST Endpoints
app.get('/api/database', (req, res) => {
  res.json(appDatabase);
});

app.get('/api/database/stats', (req, res) => {
  const stats = computeDatabaseStats();
  res.json({
    success: true,
    stats,
    status: 'online',
    lastBackupTime: new Date(lastSnapshotTime || Date.now()).toISOString(),
    message: `🛡️ Sistema 100% íntegro com ${stats.totalUsers} clientes e R$ ${stats.totalVolume} transacionados.`
  });
});

// MongoDB Atlas Integration Endpoints
app.get('/api/mongodb/status', (req, res) => {
  res.json({ success: true, ...getMongoStatus() });
});

app.post('/api/mongodb/connect', async (req, res) => {
  try {
    const { uri } = req.body || {};
    if (!uri || typeof uri !== 'string') {
      return res.status(400).json({ error: 'URI do MongoDB é obrigatória.' });
    }
    const cleanUri = uri.trim();
    if (cleanUri.includes('<db_password>')) {
      return res.status(400).json({ error: 'A URI contém o texto <db_password>. Substitua pela sua senha real do banco no MongoDB Atlas.' });
    }
    setMongoUri(cleanUri);
    const mdb = await getMongoDb(cleanUri);
    if (mdb) {
      if (!appDatabase.config) appDatabase.config = {};
      appDatabase.config.mongodbUri = cleanUri;
      saveAppDatabase();
      await syncDatabaseToMongo(appDatabase);
      res.json({ success: true, message: 'Conectado ao MongoDB com sucesso e dados replicados!', ...getMongoStatus() });
    } else {
      res.status(500).json({ error: 'Não foi possível conectar ao MongoDB com a URI informada. Verifique suas credenciais de usuário/senha e permissões de IP (Network Access 0.0.0.0/0 no Atlas).', ...getMongoStatus() });
    }
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Erro ao conectar ao MongoDB' });
  }
});

// Endpoint to alter number of intermediations (trocas) for a Middleman or user
app.post('/api/middleman/set-trocas', (req, res) => {
  try {
    const { userId, quantidade, tipo = 'ambos' } = req.body || {};
    if (!userId || typeof quantidade !== 'number' || quantidade < 0) {
      return res.status(400).json({ error: 'Parâmetros inválidos. Informe userId e quantidade.' });
    }
    if (!appDatabase.users_mm) appDatabase.users_mm = {};
    const u = appDatabase.users_mm[userId] || {
      totalTrocas: 0,
      trocasMes: 0,
      totalValor: 0,
      maiorTroca: 0,
      totalMes: 0,
      contador: 0,
      pessoasIntermediadas: 0,
      listaPessoas: [],
      clienteDesde: new Date().getFullYear()
    };

    if (tipo === 'geral' || tipo === 'ambos') {
      u.totalTrocas = quantidade;
    }
    if (tipo === 'mensal' || tipo === 'ambos') {
      u.trocasMes = quantidade;
    }

    appDatabase.users_mm[userId] = u;
    saveAppDatabase();

    // Synchronize to bots.json & active instances
    botsStore.forEach(bot => {
      const file = bot.files?.find(f => (f.name || f.path) === 'users_mm.json');
      if (file) {
        file.content = JSON.stringify(appDatabase.users_mm, null, 2);
      }
    });
    saveBots(botsStore);

    res.json({ success: true, message: `Intermediações de ${userId} alteradas para ${quantidade} (${tipo})!`, user: u });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Erro ao atualizar intermediações' });
  }
});

// =========================================================================
// MongoDB Automatic Backup of Bot Files Endpoints & Scheduler
// =========================================================================

app.get('/api/mongodb/backup-config', (req, res) => {
  const config = appDatabase?.config?.autoBackupMongo || DEFAULT_BACKUP_CONFIG;
  res.json({ success: true, config, mongoStatus: getMongoStatus() });
});

app.post('/api/mongodb/backup-config', (req, res) => {
  try {
    const newConfig: MongoAutoBackupConfig = {
      ...DEFAULT_BACKUP_CONFIG,
      ...(appDatabase?.config?.autoBackupMongo || {}),
      ...req.body
    };
    if (!appDatabase.config) appDatabase.config = {};
    appDatabase.config.autoBackupMongo = newConfig;
    saveAppDatabase();
    res.json({ success: true, message: 'Configurações de backup automático salvas com sucesso!', config: newConfig });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Erro ao salvar configurações de backup' });
  }
});

app.post('/api/mongodb/backup-now', async (req, res) => {
  try {
    const config = appDatabase?.config?.autoBackupMongo || DEFAULT_BACKUP_CONFIG;
    const labelCustom = req.body?.label;
    const selectedBotIds = req.body?.selectedBotIds || config.selectedBotIds || [];
    const includeDatabases = req.body?.includeDatabases !== undefined ? req.body.includeDatabases : (config.includeDatabaseFiles !== false);

    const result = await backupBotFilesToMongo(
      botsStore,
      'manual',
      labelCustom,
      selectedBotIds,
      includeDatabases,
      appDatabase
    );

    if (result.success) {
      if (!appDatabase.config) appDatabase.config = {};
      if (!appDatabase.config.autoBackupMongo) appDatabase.config.autoBackupMongo = { ...DEFAULT_BACKUP_CONFIG };
      appDatabase.config.autoBackupMongo.lastRun = {
        timestamp: new Date().toISOString(),
        status: 'success',
        backupId: result.backupId,
        message: 'Backup manual realizado com sucesso',
        totalBots: result.stats?.totalBots,
        totalFiles: result.stats?.totalFiles,
        sizeKb: result.stats?.sizeKb
      };
      saveAppDatabase();
      res.json({ success: true, message: 'Backup dos arquivos dos bots realizado e salvo no MongoDB com sucesso!', ...result });
    } else {
      res.status(500).json({ error: result.error || 'Falha ao realizar backup no MongoDB' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Erro inesperado ao gerar backup' });
  }
});

app.get('/api/mongodb/backup-history', async (req, res) => {
  try {
    const limit = Number(req.query.limit) || 20;
    const backups = await listMongoBotBackups(limit);
    res.json({ success: true, backups, mongoStatus: getMongoStatus() });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Erro ao listar backups do MongoDB' });
  }
});

app.post('/api/mongodb/restore-backup/:id', async (req, res) => {
  try {
    const backupId = req.params.id;
    const backupDoc = await getMongoBotBackupById(backupId);
    if (!backupDoc) {
      return res.status(404).json({ error: 'Backup não encontrado no MongoDB.' });
    }

    let restoredBotsCount = 0;
    let restoredFilesCount = 0;

    if (Array.isArray(backupDoc.bots)) {
      backupDoc.bots.forEach(backupBot => {
        const existingIdx = botsStore.findIndex(b => b.id === backupBot.id);
        if (existingIdx !== -1) {
          const currentBot = botsStore[existingIdx];
          const fileMap = new Map((currentBot.files || []).map(f => [(f.name || f.path || '').toLowerCase(), f]));
          (backupBot.files || []).forEach(bf => {
            const cleanName = (bf.name || bf.path || '').toLowerCase();
            fileMap.set(cleanName, { name: bf.name, path: bf.path || bf.name, content: bf.content });
            restoredFilesCount++;
          });
          currentBot.files = Array.from(fileMap.values());
          restoredBotsCount++;
        }
      });
      saveBots(botsStore);
    }

    if (backupDoc.databases && typeof backupDoc.databases === 'object') {
      if (backupDoc.databases.users_mm) appDatabase.users_mm = backupDoc.databases.users_mm;
      if (backupDoc.databases.pix_database) appDatabase.pix_database = backupDoc.databases.pix_database;
      if (backupDoc.databases.proofs_global) appDatabase.proofs_global = backupDoc.databases.proofs_global;
      if (backupDoc.databases.taxas_diarias) appDatabase.taxas_diarias = backupDoc.databases.taxas_diarias;
      saveAppDatabase();
    }

    res.json({
      success: true,
      message: `Restauração concluída: ${restoredBotsCount} bots e ${restoredFilesCount} arquivos restaurados do MongoDB!`,
      restoredBots: restoredBotsCount,
      restoredFiles: restoredFilesCount
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Erro ao restaurar backup do MongoDB' });
  }
});

app.delete('/api/mongodb/backup/:id', async (req, res) => {
  try {
    const backupId = req.params.id;
    const success = await deleteMongoBotBackup(backupId);
    if (success) {
      res.json({ success: true, message: 'Backup excluído do MongoDB com sucesso!' });
    } else {
      res.status(500).json({ error: 'Não foi possível excluir o backup' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Erro ao excluir backup' });
  }
});

app.get('/api/database/:table', (req, res) => {
  const table = req.params.table as keyof AppDatabaseData;
  if (appDatabase[table] !== undefined) {
    res.json(appDatabase[table]);
  } else {
    res.status(404).json({ error: 'Tabela não encontrada' });
  }
});

app.put('/api/database/:table', (req, res) => {
  const table = req.params.table as keyof AppDatabaseData;
  (appDatabase as any)[table] = req.body;
  if (table === ('bots' as any)) {
    botsStore = req.body;
  } else {
    // Synchronize this database table into bot.files for all bots
    const targetFileName = `${String(table)}.json`;
    const strContent = JSON.stringify(req.body, null, 2);
    botsStore.forEach(bot => {
      if (bot.files && Array.isArray(bot.files)) {
        const idx = bot.files.findIndex(f => (f.name || f.path || '').toLowerCase() === targetFileName.toLowerCase());
        if (idx !== -1) {
          bot.files[idx].content = strContent;
        } else {
          bot.files.push({ name: targetFileName, path: targetFileName, content: strContent });
        }
      }
    });
  }
  saveAppDatabase();
  saveBots(botsStore);
  createDatabaseSnapshot(`Edição manual da tabela ${String(table)}`);
  res.json({ success: true, data: (appDatabase as any)[table] });
});

// Bidirectional LocalStorage <-> Server Synchronization & Recovery Endpoint
app.post('/api/sync/reconcile', (req, res) => {
  try {
    const {
      bots: clientBots,
      pix_database: clientPix,
      users_mm: clientUsersMm,
      proofs_global: clientProofs,
      cardConfig: clientCardConfig,
      database: clientDb,
      deletedBotIds = []
    } = req.body || {};

    const deletedSet = new Set<string>(Array.isArray(deletedBotIds) ? deletedBotIds : []);
    let hasChanges = false;

    // 1. Reconcile Bots State
    if (Array.isArray(clientBots) && clientBots.length > 0) {
      const serverBotMap = new Map<string, BotData>();
      botsStore.forEach(b => {
        if (!deletedSet.has(b.id)) {
          serverBotMap.set(b.id, b);
        } else {
          hasChanges = true;
        }
      });

      for (const cBot of clientBots) {
        if (!cBot || !cBot.id || deletedSet.has(cBot.id)) continue;
        const existing = serverBotMap.get(cBot.id);
        if (!existing) {
          // Restore bot from client localStorage that was missing on server
          serverBotMap.set(cBot.id, cBot);
          hasChanges = true;
          if (cBot.status === 'online') {
            startDiscordClient(cBot).catch(() => {});
          }
        } else {
          // Merge files and token if client has custom files/token
          if (cBot.token && (!existing.token || existing.token.startsWith('BOTLOOM_TOKEN_SECRET_'))) {
            existing.token = cBot.token;
            hasChanges = true;
          }
          if (Array.isArray(cBot.files)) {
            const existingFileMap = new Map(existing.files.map(f => [f.path || f.name, f]));
            for (const cf of cBot.files) {
              const key = cf.path || cf.name;
              if (key && !isJunkOrBinaryFile(key) && !existingFileMap.has(key) && cf.content) {
                existing.files.push(cf);
                hasChanges = true;
              }
            }
          }
        }
      }

      if (hasChanges) {
        botsStore = Array.from(serverBotMap.values());
      }
    }

    // 2. Reconcile Pix Configuration (pix_database)
    const incomingPix = clientPix || clientDb?.pix_database;
    if (incomingPix && typeof incomingPix === 'object') {
      const currentPix = (appDatabase.pix_database && typeof appDatabase.pix_database === 'object')
        ? appDatabase.pix_database
        : { keys: [], activeKey: '' };

      const mergedPix: Record<string, any> = {
        ...incomingPix,
        ...currentPix,
        keys: Array.isArray(currentPix.keys) && currentPix.keys.length > 0
          ? currentPix.keys
          : Array.isArray(incomingPix.keys) ? incomingPix.keys : [],
        activeKey: currentPix.activeKey || incomingPix.activeKey || ''
      };

      for (const [k, v] of Object.entries(incomingPix)) {
        if (k === 'keys' || k === 'activeKey') continue;
        if (!currentPix[k] && v && typeof v === 'object') {
          mergedPix[k] = v;
          hasChanges = true;
        }
      }

      appDatabase.pix_database = mergedPix;
    }

    // 3. Reconcile Profile Data (users_mm & proofs_global)
    const incomingUsers = clientUsersMm || clientDb?.users_mm;
    if (incomingUsers && typeof incomingUsers === 'object') {
      const currentUsers = (appDatabase.users_mm && typeof appDatabase.users_mm === 'object')
        ? appDatabase.users_mm
        : {};

      // Clean empty default wrapper { users: {} } if present
      if (
        Object.keys(currentUsers).length === 1 &&
        currentUsers.users &&
        typeof currentUsers.users === 'object' &&
        Object.keys(currentUsers.users).length === 0
      ) {
        delete currentUsers.users;
      }

      for (const [uid, cUser] of Object.entries(incomingUsers)) {
        if (uid === 'users' && typeof cUser === 'object' && Object.keys(cUser as any).length === 0) continue;
        const sUser = currentUsers[uid];
        if (!sUser && cUser && typeof cUser === 'object') {
          currentUsers[uid] = { ...(cUser as any), totalMes: 0, trocasMes: 0 };
          hasChanges = true;
        } else if (sUser && typeof sUser === 'object' && cUser && typeof cUser === 'object') {
          const cu = cUser as any;
          const su = sUser as any;
          const mergedUser = {
            ...cu,
            ...su,
            totalTrocas: Math.max(Number(cu.totalTrocas || 0), Number(su.totalTrocas || 0)),
            totalValor: Math.max(Number(cu.totalValor || 0), Number(su.totalValor || 0)),
            maiorTroca: Math.max(Number(cu.maiorTroca || 0), Number(su.maiorTroca || 0)),
            contador: Math.max(Number(cu.contador || 0), Number(su.contador || 0)),
            pessoasIntermediadas: Math.max(Number(cu.pessoasIntermediadas || 0), Number(su.pessoasIntermediadas || 0)),
            totalMes: su.totalMes !== undefined ? Number(su.totalMes) : 0,
            trocasMes: su.trocasMes !== undefined ? Number(su.trocasMes) : 0
          };
          if (
            mergedUser.totalTrocas !== su.totalTrocas ||
            mergedUser.totalValor !== su.totalValor ||
            mergedUser.contador !== su.contador
          ) {
            currentUsers[uid] = mergedUser;
            hasChanges = true;
          }
        }
      }
      appDatabase.users_mm = currentUsers;
    }

    const extractCount = (v: any) => (typeof v === 'number' ? v : v && typeof v.count === 'number' ? v.count : 0);
    const incomingProofCount = Math.max(extractCount(clientProofs), extractCount(clientDb?.proofs_global));
    const currentProofCount = extractCount(appDatabase.proofs_global);
    if (incomingProofCount > currentProofCount) {
      appDatabase.proofs_global = incomingProofCount;
      hasChanges = true;
    }

    // 4. Reconcile Additional Tables from clientDb if server table is empty
    if (clientDb && typeof clientDb === 'object') {
      const auxTables: Array<keyof Omit<AppDatabaseData, 'bots'>> = [
        'taxas_diarias',
        'movements',
        'major_trade',
        'proof_channels',
        'avaliacoes_pendentes',
        'dados_leilao',
        'lances_atuais',
        'tickets',
        'config'
      ];
      for (const tbl of auxTables) {
        const cVal = clientDb[tbl];
        const sVal = appDatabase[tbl];
        if (cVal && typeof cVal === 'object' && Object.keys(cVal).length > 0) {
          if (!sVal || typeof sVal !== 'object' || Object.keys(sVal).length === 0) {
            (appDatabase as any)[tbl] = cVal;
            hasChanges = true;
          }
        }
      }
    }

    // 5. Reconcile Card & Profile Visual Configurations (cardConfig.json)
    const cardConfigPath = path.join(process.cwd(), 'cardConfig.json');
    let serverCardConfig: any = { vouchOptions: {}, perfilOptions: {} };
    if (fs.existsSync(cardConfigPath)) {
      try {
        serverCardConfig = JSON.parse(fs.readFileSync(cardConfigPath, 'utf8'));
      } catch (e) {}
    }

    if (clientCardConfig && (clientCardConfig.vouchOptions || clientCardConfig.perfilOptions)) {
      const mergedCardConfig = {
        vouchOptions: {
          ...(clientCardConfig.vouchOptions || {}),
          ...(serverCardConfig.vouchOptions || {})
        },
        perfilOptions: {
          ...(clientCardConfig.perfilOptions || {}),
          ...(serverCardConfig.perfilOptions || {})
        }
      };
      // If server had empty cardConfig, persist the merged config
      if (
        Object.keys(serverCardConfig.vouchOptions || {}).length === 0 &&
        Object.keys(mergedCardConfig.vouchOptions || {}).length > 0
      ) {
        fs.writeFileSync(cardConfigPath, JSON.stringify(mergedCardConfig, null, 2), 'utf8');
      }
      serverCardConfig = mergedCardConfig;
    }

    if (hasChanges) {
      saveBots(botsStore);
      saveAppDatabase();
    }

    const stats = computeDatabaseStats();
    res.json({
      success: true,
      bots: botsStore,
      database: appDatabase,
      cardConfig: serverCardConfig,
      stats,
      syncedAt: Date.now()
    });
  } catch (err: any) {
    console.error('[SYNC RECONCILE ERROR]', err);
    res.status(500).json({ error: 'Erro na reconciliação de dados', message: err?.message });
  }
});

// Snapshot & Backup Management REST Endpoints
app.get('/api/backups', (req, res) => {
  try {
    if (!fs.existsSync(BACKUPS_DIR)) {
      return res.json({ success: true, snapshots: [] });
    }
    const files = fs.readdirSync(BACKUPS_DIR)
      .filter(f => f.startsWith('snapshot-') && f.endsWith('.json'))
      .sort((a, b) => b.localeCompare(a));

    const snapshots = files.map(file => {
      try {
        const filePath = path.join(BACKUPS_DIR, file);
        const stat = fs.statSync(filePath);
        const raw = fs.readFileSync(filePath, 'utf-8');
        const parsed = JSON.parse(raw);
        return {
          id: parsed.id || file.replace('.json', ''),
          timestamp: parsed.timestamp || stat.mtimeMs,
          date: parsed.date || stat.mtime.toISOString(),
          dateFormatted: parsed.dateFormatted || stat.mtime.toLocaleString('pt-BR'),
          reason: parsed.reason || 'Snapshot de Segurança',
          stats: parsed.stats || {},
          sizeBytes: stat.size,
          sizeKb: (stat.size / 1024).toFixed(1)
        };
      } catch (e) {
        return null;
      }
    }).filter(Boolean);

    res.json({ success: true, snapshots });
  } catch (err: any) {
    res.status(500).json({ error: 'Erro ao listar backups', message: err?.message });
  }
});

app.post('/api/backups/create', (req, res) => {
  try {
    const reason = req.body?.reason || 'Snapshot Manual Criado pelo Usuário';
    createDatabaseSnapshot(reason);
    const stats = computeDatabaseStats();
    res.json({ success: true, message: 'Snapshot criado com sucesso!', stats });
  } catch (err: any) {
    res.status(500).json({ error: 'Erro ao criar snapshot', message: err?.message });
  }
});

app.post('/api/backups/restore/:id', (req, res) => {
  try {
    const snapshotId = req.params.id;
    const cleanId = snapshotId.replace(/[^a-zA-Z0-9_-]/g, '');
    const snapshotFile = path.join(BACKUPS_DIR, `${cleanId}.json`);

    if (!fs.existsSync(snapshotFile)) {
      return res.status(404).json({ error: 'Snapshot não encontrado.' });
    }

    const raw = fs.readFileSync(snapshotFile, 'utf-8');
    const parsed = JSON.parse(raw);
    const ok = restoreDatabaseFromSnapshot(parsed);

    if (ok) {
      const stats = computeDatabaseStats();
      res.json({
        success: true,
        message: `Snapshot "${parsed.reason || cleanId}" restaurado com sucesso!`,
        stats
      });
    } else {
      res.status(500).json({ error: 'Falha ao restaurar snapshot.' });
    }
  } catch (err: any) {
    res.status(500).json({ error: 'Erro ao restaurar backup', message: err?.message });
  }
});

// UptimeRobot / Keep-Alive Ping Endpoints
const UPTIMEROBOT_KEY = 'botloom_keepalive_247_active';

const handleKeepAlivePing = (req: any, res: any) => {
  const onlineCount = botsStore.filter(b => b.status === 'online').length;

  res.json({
    status: 'online',
    service: 'BotLoom 24/7 Node Hosting Engine',
    systemsOnline: 1,
    uptimeSeconds: Math.floor(process.uptime()),
    timestamp: new Date().toISOString(),
    key: UPTIMEROBOT_KEY,
    keyValid: true,
    botsOnline: onlineCount,
    publicHost: detectedPublicOrigin || null,
    message: '⚡ [SISTEMA NODE.JS 24/7 ONLINE] Servidor e Bot Engine ativos sem interrupção!'
  });
};

app.get('/ping', handleKeepAlivePing);
app.get('/health', handleKeepAlivePing);
app.get('/api/ping', handleKeepAlivePing);
app.get('/api/health', handleKeepAlivePing);
app.get('/api/keepalive', handleKeepAlivePing);
app.get('/api/uptimerobot', handleKeepAlivePing);

// 📡 Server-Sent Events (SSE) Persistent Keep-Alive Stream
// Mantém conexão HTTP aberta 24/7 para impedir que o Cloud Run congele a CPU ou coloque o container em hibernação
app.get(['/api/stream', '/api/live', '/stream'], (req: any, res: any) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no',
    'Access-Control-Allow-Origin': '*'
  });

  res.write(`data: ${JSON.stringify({ type: 'connected', time: Date.now(), bots: botsStore.length })}\n\n`);

  const sseInterval = setInterval(() => {
    try {
      res.write(`data: ${JSON.stringify({
        type: 'heartbeat',
        uptime: Math.floor(process.uptime()),
        timestamp: Date.now(),
        onlineBots: botsStore.filter(b => b.status === 'online').length
      })}\n\n`);
    } catch (e) {
      clearInterval(sseInterval);
    }
  }, 15000);

  req.on('close', () => {
    clearInterval(sseInterval);
  });
});

app.get('/api/keepalive-info', (req: any, res: any) => {
  const forwardedHost = (req.headers['x-forwarded-host'] as string) || req.headers.host || '';
  const forwardedProto = (req.headers['x-forwarded-proto'] as string) || 'https';
  let publicHost = detectedPublicOrigin;
  if (!publicHost && forwardedHost && !forwardedHost.includes('localhost') && !forwardedHost.includes('127.0.0.1')) {
    const clean = forwardedHost.replace('ais-dev-', 'ais-pre-');
    publicHost = `${forwardedProto}://${clean}`;
  }
  res.json({
    publicHost: publicHost || null,
    publicPingUrl: publicHost ? `${publicHost}/ping` : null,
    uptimeSeconds: Math.floor(process.uptime()),
    detectedPublicOrigin: detectedPublicOrigin || null
  });
});

// ==========================================
// 📦 EXPORTAÇÃO DO PROJETO & NETLIFY DEPLOY
// ==========================================

async function zipDirectory(zip: JSZip, dirPath: string, rootDir: string, ignorePatterns: (string | RegExp)[]) {
  if (!fs.existsSync(dirPath)) return;
  const entries = fs.readdirSync(dirPath, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);
    const relPath = path.relative(rootDir, fullPath).replace(/\\/g, '/');

    const shouldIgnore = ignorePatterns.some(pat => {
      if (typeof pat === 'string') {
        return relPath === pat || relPath.startsWith(pat + '/') || entry.name === pat;
      }
      return pat.test(relPath) || pat.test(entry.name);
    });

    if (shouldIgnore) continue;

    if (entry.isDirectory()) {
      await zipDirectory(zip, fullPath, rootDir, ignorePatterns);
    } else if (entry.isFile()) {
      try {
        const stat = fs.statSync(fullPath);
        if (stat.size < 25 * 1024 * 1024) {
          const content = fs.readFileSync(fullPath);
          zip.file(relPath, content);
        }
      } catch (err) {
        console.warn(`[ZIP] Aviso ao ler ${relPath}:`, err);
      }
    }
  }
}

const NETLIFY_INSTRUCTIONS = `# 🚀 Como Hospedar seu Site no Netlify

Existem duas formas simples e gratuitas de colocar este site no ar no Netlify:

---

### Opção 1: Método Ultra Rápido (Arrastar e Soltar - Netlify Drop)
1. Extraia o arquivo **botloom-netlify-dist.zip** (você terá a pasta \`dist\`).
2. Acesse sua conta no Netlify: https://app.netlify.com/drop
3. Arraste a pasta \`dist\` (ou o próprio arquivo zip se suportado) diretamente para o retângulo de upload.
4. Pronto! Em 5 segundos o Netlify vai gerar um link público grátis com certificado SSL HTTPS (ex: \`https://meu-painel.netlify.app\`).

> **Nota Técnica**: O arquivo \`_redirects\` já está incluso dentro da pasta \`dist\` com a regra (\`/* /index.html 200\`), evitando erros 404 ao atualizar a página no navegador.

---

### Opção 2: Conectar com seu GitHub (Deploy Automático Contínuo)
1. Descompacte o arquivo completo do projeto.
2. Crie um repositório no seu GitHub e suba os arquivos:
   \`\`\`bash
   git init
   git add .
   git commit -m "Meu painel BotLoom"
   git branch -M main
   git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
   git push -u origin main
   \`\`\`
3. No painel do Netlify, clique em **"Add new site" > "Import an existing project"** e escolha o repositório do GitHub.
4. O Netlify lerá automaticamente o arquivo \`netlify.toml\` já configurado:
   - **Build command**: \`npm run build\`
   - **Publish directory**: \`dist\`
5. Clique em **Deploy site**.

---

### ⚠️ Como Funcionam os Bots do Discord vs Netlify:
- O **Netlify** é uma infraestrutura feita exclusivamente para hospedar **sites estáticos e frontends (React, HTML, CSS, JavaScript)**.
- Os **Bots do Discord** precisam de uma conexão aberta 24/7 (via WebSocket/Node.js). O Netlify não mantém servidores Node.js ligados continuamente.
- Por isso, seus bots podem continuar rodando 24 horas por dia aqui na nuvem do **BotLoom Cloud** (com UptimeRobot ativo), ou em uma VPS (Oracle, DigitalOcean, Hetzner), no Railway ou no Render, enquanto o painel do site fica hospedado no Netlify!
`;

// Rota 1: Baixar a pasta dist pronta para Netlify Drop
app.get('/api/export/dist', async (req, res) => {
  try {
    const distPath = path.resolve('dist');
    const indexDistPath = path.join(distPath, 'index.html');

    // Se a pasta dist não existir ou não tiver index.html, constrói o frontend com Vite
    if (!fs.existsSync(indexDistPath)) {
      console.log('[EXPORT] Gerando build do Vite para exportação Netlify...');
      await viteBuild();
    }

    // Garante que o arquivo _redirects do Netlify está presente na dist
    const redirectsFile = path.join(distPath, '_redirects');
    if (!fs.existsSync(redirectsFile)) {
      fs.writeFileSync(redirectsFile, '/*    /index.html   200\n', 'utf-8');
    }

    const zip = new JSZip();
    await zipDirectory(zip, distPath, distPath, ['node_modules', '.git', '.aistudio', 'server.cjs', 'server.cjs.map']);
    
    // Adiciona instruções em markdown
    zip.file('COMO_PUBLICAR_NO_NETLIFY.md', NETLIFY_INSTRUCTIONS);

    const zipBuffer = await zip.generateAsync({
      type: 'nodebuffer',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 }
    });

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="botloom-netlify-dist.zip"');
    res.setHeader('Content-Length', zipBuffer.length.toString());
    res.end(zipBuffer);
  } catch (error: any) {
    console.error('[EXPORT NETLIFY ERROR]', error);
    res.status(500).json({ error: 'Erro ao gerar zip para Netlify', details: error?.message });
  }
});

// Rota 2: Baixar o projeto completo em ZIP (.zip com todos os arquivos do bot e site)
app.get('/api/export/project', async (req, res) => {
  try {
    const rootPath = path.resolve('.');
    const zip = new JSZip();

    const ignoreList = [
      'node_modules',
      '.git',
      '.aistudio',
      '.cache',
      'dist',
      'bun.lock',
      '.DS_Store',
      'server.cjs',
      'server.cjs.map',
      'data/backups',
      /test_.*\.png$/,
      /test-.*\.zip$/,
      /\.timestamp-.*\.mjs$/
    ];

    await zipDirectory(zip, rootPath, rootPath, ignoreList);

    // Garante que o guia do Netlify e netlify.toml estão inclusos
    zip.file('COMO_HOSPEDAR_NO_NETLIFY.md', NETLIFY_INSTRUCTIONS);
    if (!zip.file('netlify.toml')) {
      zip.file('netlify.toml', `[build]\n  publish = "dist"\n  command = "npm run build"\n\n[[redirects]]\n  from = "/*"\n  to = "/index.html"\n  status = 200\n`);
    }

    const zipBuffer = await zip.generateAsync({
      type: 'nodebuffer',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 }
    });

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="botloom-projeto-completo.zip"');
    res.setHeader('Content-Length', zipBuffer.length.toString());
    res.end(zipBuffer);
  } catch (error: any) {
    console.error('[EXPORT PROJECT ERROR]', error);
    res.status(500).json({ error: 'Erro ao gerar zip completo do projeto', details: error?.message });
  }
});

// API Endpoints
app.get('/api/bots', (req, res) => {
  // Update stats slightly to show active monitoring with CPU capping (Max 5.0%)
  botsStore = botsStore.map(bot => {
    if (bot.status === 'online') {
      const cpuDelta = (Math.random() * 0.6 - 0.3);
      const memDelta = (Math.random() * 0.4 - 0.2);
      const cappedCpu = Math.min(5.0, Math.max(0.2, Number((bot.stats.cpuUsage + cpuDelta).toFixed(1))));
      const cappedMem = Math.min(128.0, Math.max(20.0, Number((bot.stats.memoryUsage + memDelta).toFixed(1))));
      return {
        ...bot,
        stats: {
          ...bot.stats,
          cpuUsage: cappedCpu,
          memoryUsage: cappedMem,
          uptimeSeconds: bot.stats.uptimeSeconds + 5
        }
      };
    }
    return bot;
  });
  res.json(botsStore);
});

app.get('/api/bots/:id', (req, res) => {
  const bot = botsStore.find(b => b.id === req.params.id);
  if (!bot) return res.status(404).json({ error: 'Bot não encontrado' });
  syncCardFilesWithDisk(bot);
  res.json(bot);
});

app.post('/api/bots', (req, res) => {
  const { name, botId, token, files, prefix, description, codeOption } = req.body;

  if (!name || !botId) {
    return res.status(400).json({ error: 'Nome e ID do bot são obrigatórios.' });
  }

  const newBot: BotData = {
    id: 'bot-' + Date.now(),
    botId: botId,
    name: name,
    status: 'offline',
    token: token || 'BOTLOOM_TOKEN_SECRET_' + Math.floor(Math.random() * 100000),
    prefix: prefix || '!',
    description: description || 'Bot hospedado na plataforma BotLoom Hosting.',
    icon: '🤖',
    createdAt: new Date().toISOString(),
    lastRunAt: null,
    files: files && files.length > 0 ? files : [
      {
        name: 'index.js',
        path: 'index.js',
        content: `// Bot ${name}\nconst { Client, GatewayIntentBits } = require('discord.js');\nconst client = new Client({ intents: [GatewayIntentBits.Guilds] });\n\nclient.on('ready', () => {\n  console.log('[BOT] ${name} está online!');\n});\n\nclient.login(process.env.DISCORD_TOKEN);`
      },
      {
        name: 'package.json',
        path: 'package.json',
        content: JSON.stringify({
          name: name.toLowerCase().replace(/[^a-z0-9]/g, '-'),
          version: '1.0.0',
          main: 'index.js',
          dependencies: {
            'discord.js': '^14.14.1',
            'dotenv': '^16.4.5'
          }
        }, null, 2)
      }
    ],
    dependencies: {
      'discord.js': '^14.14.1',
      'dotenv': '^16.4.5'
    },
    stats: {
      cpuUsage: 0,
      memoryUsage: 0,
      maxMemory: 512,
      uptimeSeconds: 0
    },
    logs: [
      {
        id: 'log-1',
        timestamp: new Date().toLocaleTimeString('pt-BR'),
        type: 'system',
        message: `[SYSTEM] Bot "${name}" cadastrado com sucesso na plataforma BotLoom.`
      }
    ],
    autoRestart: true,
    version: '14.14.1'
  };

  botsStore.unshift(newBot);
  saveBots(botsStore);
  res.status(201).json(newBot);
});

app.put('/api/bots/:id', async (req, res) => {
  const { id } = req.params;
  const index = botsStore.findIndex(b => b.id === id);
  if (index === -1) return res.status(404).json({ error: 'Bot não encontrado' });

  const oldStatus = botsStore[index].status;
  const targetBot = botsStore[index];

  if (req.body.token !== undefined) {
    targetBot.token = req.body.token;
  }
  if (req.body.botId !== undefined) targetBot.botId = req.body.botId;
  if (req.body.name !== undefined) targetBot.name = req.body.name;
  if (req.body.prefix !== undefined) targetBot.prefix = req.body.prefix;
  if (req.body.description !== undefined) targetBot.description = req.body.description;

  if (req.body.files && Array.isArray(req.body.files)) {
    targetBot.files = req.body.files;

    // Check if .env file in updated files has DISCORD_TOKEN
    const envFile = targetBot.files.find(f => f.name === '.env' || f.path === '.env');
    if (envFile) {
      const match = envFile.content.match(/(?:DISCORD_TOKEN|TOKEN)\s*=\s*["']?([^"'\r\n]+)["']?/i);
      if (match && match[1] && match[1].trim().length > 10) {
        targetBot.token = match[1].trim();
      }
    }

    const targetDbFilesMapLocal: Record<string, keyof Omit<AppDatabaseData, 'bots'>> = {
      'proofs_global.json': 'proofs_global',
      'users_mm.json': 'users_mm',
      'pix_database.json': 'pix_database',
      'taxas_diarias.json': 'taxas_diarias',
      'lastmonthlyrun.json': 'lastMonthlyRun',
      'movements.json': 'movements',
      'major_trade.json': 'major_trade',
      'proof_channels.json': 'proof_channels',
      'canal_proof.json': 'proof_channels',
      'dados_leilao.json': 'dados_leilao',
      'lances_atuais.json': 'lances_atuais',
      'tickets.json': 'tickets',
      'config.json': 'config',
      'avaliacoes_pendentes.json': 'avaliacoes_pendentes'
    };

    // Write all updated files to isolated bot workspace
    const botWorkspaceDir = path.join(process.cwd(), 'workspace', 'bots', targetBot.id);
    try {
      if (!fs.existsSync(botWorkspaceDir)) fs.mkdirSync(botWorkspaceDir, { recursive: true });
    } catch (e) {}

    for (const f of targetBot.files) {
      const fileName = f.name || f.path;
      if (!fileName || typeof f.content !== 'string') continue;
      const cleanFile = fileName.replace(/^\.\//, '').replace(/^.*[\\\/]/, '').toLowerCase();

      // Persist to isolated bot workspace
      try {
        const botIsolatedPath = path.join(botWorkspaceDir, fileName);
        const parentDir = path.dirname(botIsolatedPath);
        if (!fs.existsSync(parentDir)) fs.mkdirSync(parentDir, { recursive: true });
        fs.writeFileSync(botIsolatedPath, f.content, 'utf-8');
      } catch (e) {}

      // Never write bot-private files or protected host files into the shared root directory
      if (PROTECTED_HOST_FILES.has(cleanFile) || cleanFile === '.env' || cleanFile === 'index.js' || cleanFile === 'config.json') {
        continue;
      }

      // Sync card templates, bot.js or index.js to root when editing Middleman or Leilão bots
      const isTargetMiddleman = targetBot.id === 'bot-1785901524690' || (targetBot.name || '').toLowerCase().includes('mid');
      const isTargetLeilao = targetBot.id === 'bot-1791054539250' || (targetBot.name || '').toLowerCase().includes('leil');

      if (cleanFile === 'vouchcard.js' || cleanFile === 'perfilcard.js' || (cleanFile === 'bot.js' && isTargetMiddleman)) {
        try {
          const rootPath = path.join(process.cwd(), fileName);
          fs.writeFileSync(rootPath, f.content, 'utf-8');
        } catch (e) {}
      }

      if (cleanFile === 'index.js' && isTargetLeilao) {
        try {
          const rootPath = path.join(process.cwd(), 'index.js');
          fs.writeFileSync(rootPath, f.content, 'utf-8');
        } catch (e) {}
      }

      const dbKey = targetDbFilesMapLocal[cleanFile];
      if (dbKey) {
        try {
          const parsed = JSON.parse(f.content);
          (appDatabase as any)[dbKey] = parsed;
          const dataFilePath = path.join(DATA_DIR, fileName);
          fs.writeFileSync(dataFilePath, f.content, 'utf-8');
        } catch (e) {}
      }
    }
  }

  // Ensure .env exists in targetBot.files and reflects the current token & prefix
  const activeToken = targetBot.token || '';
  let envFileObj = targetBot.files.find(f => f.name === '.env' || f.path === '.env');
  if (envFileObj) {
    if (activeToken) {
      envFileObj.content = `DISCORD_TOKEN=${activeToken}\nTOKEN=${activeToken}\nPREFIX=${targetBot.prefix || '!'}\nCLIENT_ID=${targetBot.botId || ''}`;
    }
  } else if (activeToken) {
    targetBot.files.push({
      name: '.env',
      path: '.env',
      content: `DISCORD_TOKEN=${activeToken}\nTOKEN=${activeToken}\nPREFIX=${targetBot.prefix || '!'}\nCLIENT_ID=${targetBot.botId || ''}`
    });
  }

  syncCardFilesWithDisk(targetBot);
  saveBots(botsStore);
  saveAppDatabase();

  // If bot is online and info/files/token changed, re-connect client
  if (oldStatus === 'online') {
    startDiscordClient(targetBot);
  }

  res.json(targetBot);
});

app.delete('/api/bots/:id', async (req, res) => {
  const { id } = req.params;
  await stopDiscordClient(id);
  botsStore = botsStore.filter(b => b.id !== id);
  saveBots(botsStore);
  res.json({ success: true, message: 'Bot excluído com sucesso.' });
});

// Bot Control Endpoints
app.post('/api/bots/:id/start', async (req, res) => {
  const { id } = req.params;
  const bot = botsStore.find(b => b.id === id);
  if (!bot) return res.status(404).json({ error: 'Bot não encontrado' });

  syncCardFilesWithDisk(bot);
  bot.status = 'online';
  bot.lastRunAt = new Date().toISOString();
  bot.stats.cpuUsage = Number((Math.random() * 1.5 + 0.8).toFixed(1));
  bot.stats.memoryUsage = Number((Math.random() * 10 + 35).toFixed(1));
  const timeStr = new Date().toLocaleTimeString('pt-BR');

  bot.logs.push({
    id: 'log-' + Date.now(),
    timestamp: timeStr,
    type: 'system',
    message: '[SYSTEM] Instância isolada Node.js iniciada com sucesso. Bot 24/7 ONLINE!'
  });

  saveBots(botsStore);

  // Trigger real or simulated Discord gateway connection
  startDiscordClient(bot).catch(err => {
    console.error('[START DISCORD ERROR]', err);
  });

  res.json(bot);
});

app.post('/api/bots/:id/stop', async (req, res) => {
  const { id } = req.params;
  const bot = botsStore.find(b => b.id === id);
  if (!bot) return res.status(404).json({ error: 'Bot não encontrado' });

  await stopDiscordClient(id);

  bot.status = 'offline';
  bot.stats.cpuUsage = 0;
  bot.stats.memoryUsage = 0;

  bot.logs.push({
    id: 'log-' + Date.now(),
    timestamp: new Date().toLocaleTimeString('pt-BR'),
    type: 'system',
    message: '[SYSTEM] Instância do bot encerrada e desconectada do Gateway.'
  });

  saveBots(botsStore);
  res.json(bot);
});

app.post('/api/bots/:id/restart', async (req, res) => {
  const { id } = req.params;
  const bot = botsStore.find(b => b.id === id);
  if (!bot) return res.status(404).json({ error: 'Bot não encontrado' });

  syncCardFilesWithDisk(bot);
  await stopDiscordClient(id);
  bot.status = 'starting';

  bot.logs.push({
    id: 'log-' + Date.now(),
    timestamp: new Date().toLocaleTimeString('pt-BR'),
    type: 'system',
    message: '[RESTART] Reiniciando processo Node.js e reconectando ao Discord...'
  });

  saveBots(botsStore);

  startDiscordClient(bot);

  res.json(bot);
});

app.post('/api/bots/:id/logs/clear', (req, res) => {
  const { id } = req.params;
  const bot = botsStore.find(b => b.id === id);
  if (!bot) return res.status(404).json({ error: 'Bot não encontrado' });

  bot.logs = [{
    id: 'log-' + Date.now(),
    timestamp: new Date().toLocaleTimeString('pt-BR'),
    type: 'system',
    message: '[SYSTEM] Console de logs limpo pelo operador.'
  }];

  saveBots(botsStore);
  res.json(bot);
});

// Card Configurator API - Apply Vouchcard & Perfilcard customizations to Bot code and running client
app.post('/api/cards/apply', async (req, res) => {
  try {
    const { botId, vouchOptions, perfilOptions } = req.body;

    // Save configuration file
    const cardConfigPath = path.join(process.cwd(), 'cardConfig.json');
    let existingConfig: any = {};
    if (fs.existsSync(cardConfigPath)) {
      try { existingConfig = JSON.parse(fs.readFileSync(cardConfigPath, 'utf8')); } catch (e) {}
    }

    const newConfig = {
      vouchOptions: vouchOptions ? { ...existingConfig.vouchOptions, ...vouchOptions } : existingConfig.vouchOptions || {},
      perfilOptions: perfilOptions ? { ...existingConfig.perfilOptions, ...perfilOptions } : existingConfig.perfilOptions || {}
    };

    fs.writeFileSync(cardConfigPath, JSON.stringify(newConfig, null, 2), 'utf8');

    // Read current code files from disk
    const currentVouch = fs.existsSync(path.join(process.cwd(), 'vouchCard.js'))
      ? fs.readFileSync(path.join(process.cwd(), 'vouchCard.js'), 'utf8')
      : '';
    const currentPerfil = fs.existsSync(path.join(process.cwd(), 'perfilCard.js'))
      ? fs.readFileSync(path.join(process.cwd(), 'perfilCard.js'), 'utf8')
      : '';

    // Sync files with bots store without overwriting user code
    botsStore.forEach(bot => {
      if (!botId || botId === 'all' || bot.id === botId) {
        let vFile = bot.files.find(f => f.name === 'vouchCard.js' || f.path === 'vouchCard.js');
        if (!vFile && currentVouch) {
          bot.files.push({ name: 'vouchCard.js', path: 'vouchCard.js', content: currentVouch });
        }

        let pFile = bot.files.find(f => f.name === 'perfilCard.js' || f.path === 'perfilCard.js');
        if (!pFile && currentPerfil) {
          bot.files.push({ name: 'perfilCard.js', path: 'perfilCard.js', content: currentPerfil });
        }

        syncCardFilesWithDisk(bot);

        // Update bot log
        bot.logs.push({
          id: 'log-' + Date.now(),
          timestamp: new Date().toLocaleTimeString('pt-BR'),
          type: 'system',
          message: '🎨 Configurações dos cartões Vouchcard & Perfilcard salvas em cardConfig.json e aplicadas no bot!'
        });

        if (bot.status === 'online') {
          startDiscordClient(bot);
        }
      }
    });

    saveBots(botsStore);

    res.json({
      success: true,
      message: 'Configurações dos cartões Vouchcard e Perfilcard aplicadas no código e comandos /aprovar_pagamento, /vouch e /perfil com sucesso!'
    });
  } catch (err: any) {
    console.error('Erro ao aplicar cartões:', err);
    res.status(500).json({ error: err.message || 'Erro ao aplicar cartões' });
  }
});

// GET endpoint for card configuration
app.get('/api/cards/config', (req, res) => {
  const cardConfigPath = path.join(process.cwd(), 'cardConfig.json');
  if (fs.existsSync(cardConfigPath)) {
    try {
      const config = JSON.parse(fs.readFileSync(cardConfigPath, 'utf8'));
      return res.json(config);
    } catch (e) {}
  }
  return res.json({ vouchOptions: {}, perfilOptions: {} });
});

// Endpoint to upload a custom background/template image for Vouchcard or Perfilcard
app.post('/api/cards/upload-image', (req, res) => {
  try {
    const { imageBase64, type = 'vouch' } = req.body;
    if (!imageBase64 || typeof imageBase64 !== 'string') {
      return res.status(400).json({ error: 'Nenhuma imagem enviada (imageBase64 obrigatório).' });
    }

    const assetsDir = path.join(process.cwd(), 'assets');
    if (!fs.existsSync(assetsDir)) {
      fs.mkdirSync(assetsDir, { recursive: true });
    }

    // Extract base64 data
    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');
    const buffer = Buffer.from(cleanBase64, 'base64');

    const fileName = type === 'perfil' ? 'custom_perfil_bg.png' : 'custom_vouch_bg.png';
    const filePath = path.join(assetsDir, fileName);
    fs.writeFileSync(filePath, buffer);

    // Also update cardConfig.json
    const cardConfigPath = path.join(process.cwd(), 'cardConfig.json');
    let cfg: any = { vouchOptions: {}, perfilOptions: {} };
    if (fs.existsSync(cardConfigPath)) {
      try {
        cfg = JSON.parse(fs.readFileSync(cardConfigPath, 'utf8'));
      } catch (e) {}
    }

    const timestamp = Date.now();
    const servedUrl = `/api/cards/${fileName}?t=${timestamp}`;

    if (type === 'perfil') {
      cfg.perfilOptions = {
        ...cfg.perfilOptions,
        useCustomBg: true,
        customBgImage: filePath,
        customBgUrl: servedUrl
      };
    } else {
      cfg.vouchOptions = {
        ...cfg.vouchOptions,
        useCustomBg: true,
        customBgImage: filePath,
        customBgUrl: servedUrl
      };
    }

    fs.writeFileSync(cardConfigPath, JSON.stringify(cfg, null, 2), 'utf8');

    // Also update bot files
    botsStore.forEach(bot => {
      syncCardFilesWithDisk(bot);
    });
    saveBots(botsStore);

    res.json({
      success: true,
      url: servedUrl,
      localPath: filePath,
      message: `Imagem do ${type === 'perfil' ? 'Perfilcard' : 'Vouchcard'} importada e configurada no código com sucesso!`
    });
  } catch (err: any) {
    console.error('Erro no upload da imagem do card:', err);
    res.status(500).json({ error: err.message || 'Erro ao processar imagem' });
  }
});

// Endpoint to serve custom vouch background image
app.get(['/api/cards/custom_vouch_bg.png', '/api/cards/custom-vouch-bg.png'], (req, res) => {
  const filePath = path.join(process.cwd(), 'assets', 'custom_vouch_bg.png');
  if (fs.existsSync(filePath)) {
    res.setHeader('Content-Type', 'image/png');
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    return res.sendFile(filePath);
  }
  return res.status(404).send('Nenhuma imagem personalizada encontrada.');
});

// Endpoint to delete custom vouch background image
app.delete('/api/cards/custom_vouch_bg.png', (req, res) => {
  try {
    const filePath = path.join(process.cwd(), 'assets', 'custom_vouch_bg.png');
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
    const cardConfigPath = path.join(process.cwd(), 'cardConfig.json');
    if (fs.existsSync(cardConfigPath)) {
      try {
        const cfg = JSON.parse(fs.readFileSync(cardConfigPath, 'utf8'));
        if (cfg?.vouchOptions) {
          cfg.vouchOptions.useCustomBg = false;
          delete cfg.vouchOptions.customBgImage;
          delete cfg.vouchOptions.customBgUrl;
        }
        fs.writeFileSync(cardConfigPath, JSON.stringify(cfg, null, 2), 'utf8');
      } catch (e) {}
    }
    res.json({ success: true, message: 'Imagem personalizada removida com sucesso!' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Dynamic Vouch card image preview generator (GIF animated and PNG)
app.get(['/api/cards/vouch-preview.png', '/api/cards/vouch-preview.gif'], async (req, res) => {
  try {
    delete require.cache[require.resolve('./vouchCard.js')];
    const { gerarCartaoVouch, gerarCartaoVouchGif } = require('./vouchCard.js');
    const isGif = req.path.endsWith('.gif') || req.query.format === 'gif' || req.query.animated === 'true';
    let buffer: Buffer;
    if (isGif) {
      buffer = await gerarCartaoVouchGif({
        ...req.query,
        animationFrames: req.query.animationFrames || 6,
        animationFps: req.query.animationFps || 8
      });
    } else {
      buffer = await gerarCartaoVouch({
        ...req.query
      });
    }
    res.setHeader('Content-Type', isGif ? 'image/gif' : 'image/png');
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.send(buffer);
  } catch (err: any) {
    console.error('Erro ao gerar preview do vouchCard:', err);
    res.status(500).send('Erro ao gerar imagem do vouch: ' + err.message);
  }
});

// Dynamic Perfil card image preview generator
app.get('/api/cards/perfil-preview.png', async (req, res) => {
  try {
    delete require.cache[require.resolve('./perfilCard.js')];
    const { gerarCartaoPerfil } = require('./perfilCard.js');
    const buffer = await gerarCartaoPerfil(req.query);
    res.setHeader('Content-Type', 'image/png');
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.send(buffer);
  } catch (err: any) {
    console.error('Erro ao gerar preview do perfilCard:', err);
    res.status(500).send('Erro ao gerar imagem do perfil: ' + err.message);
  }
});

// Interactive Discord Test Bench API (Handles simulated Discord interactions with bot)
app.post('/api/bots/:id/interact', (req, res) => {
  const { id } = req.params;
  const { command, args, interactionType, customId, values, inputFields } = req.body;
  const bot = botsStore.find(b => b.id === id);

  if (!bot) return res.status(404).json({ error: 'Bot não encontrado' });

  if (bot.status !== 'online') {
    return res.status(400).json({
      error: 'Bot está desligado',
      message: `🔴 O bot "${bot.name}" está DESLIGADO (OFFLINE). Ligue-o no painel para que ele responda aos comandos.`
    });
  }

  const timeStr = new Date().toLocaleTimeString('pt-BR');

  // Log interaction in bot terminal
  bot.logs.push({
    id: 'log-' + Date.now(),
    timestamp: timeStr,
    type: 'stdout',
    message: `[INTERACTION] Recebido ${interactionType || 'Command'}: ${command || customId || 'evento'} de @UsuárioTeste#1234`
  });

  let responseMessage: any = {
    id: 'msg-' + Date.now(),
    author: {
      username: bot.name,
      bot: true,
      avatar: bot.icon
    },
    timestamp: timeStr
  };

  const cleanCmd = (command || '').toLowerCase().trim();

  if (cleanCmd === '/ping' || cleanCmd === '!ping') {
    responseMessage = {
      ...responseMessage,
      content: `🏓 **Pong!** Latência da API: 18ms | Latência Gateway: 24ms (Hospedado na **BotLoom 24/7**)`
    };
  } else if (cleanCmd.startsWith('/vouch') || cleanCmd.startsWith('!vouch') || cleanCmd.startsWith('/aprovar_pagamento') || cleanCmd.startsWith('!aprovar_pagamento')) {
    const timestamp = Date.now();
    responseMessage = {
      ...responseMessage,
      content: `✅ **Pagamento Aprovado com Sucesso!** Vouch Animado (GIF) gerado e enviado para o canal de proofs.`,
      embeds: [
        {
          title: '🎟️ Vouch de Intermediação (Animado)',
          description: `**ID:** \`MM-${timestamp}\` | **Código:** \`#01645\`\n**Valor Intermediado:** \`R$ 1.499,90\`\n**Intermediador:** \`Yoga Intermediações\` ⭐⭐⭐⭐⭐ (5.0)\n\n✨ *Cartão gerado em formato GIF animado com efeito de brilho e reflexo metálico luxuoso.*`,
          color: '#F5B72E',
          imageUrl: `/api/cards/vouch-preview.gif?t=${timestamp}`
        }
      ]
    };
  } else if (cleanCmd.startsWith('/perfil') || cleanCmd.startsWith('!perfil')) {
    const timestamp = Date.now();
    responseMessage = {
      ...responseMessage,
      content: `📊 **Perfil Financeiro & Estatísticas**`,
      embeds: [
        {
          title: '👤 Cartão de Perfil de Atendimento',
          description: `**Usuário:** \`@UsuárioTeste\`\n**Rank Atual:** \`💎 GOD OF MM\`\n**Total Movimentado:** \`R$ 15.420,00\`\n**Intermediações:** \`142 trocas\``,
          color: '#5865F2',
          imageUrl: `/api/cards/perfil-preview.png?t=${timestamp}`
        }
      ]
    };
  } else if (cleanCmd === '/help' || cleanCmd === '!help') {
    responseMessage = {
      ...responseMessage,
      embeds: [
        {
          title: `🤖 Central de Comando - ${bot.name}`,
          description: `Olá! Sou o bot **${bot.name}**, hospedado e rodando 24/7 no BotLoom Hosting.\n\nAbaixo estão alguns dos recursos suportados pelo meu código:`,
          color: '#5865F2',
          fields: [
            { name: '⚡ /ping', value: 'Verifica a latência e estado do bot.', inline: true },
            { name: '🎫 /ticket', value: 'Abre um painel de suporte com botões e modal.', inline: true },
            { name: '🎨 /welcome', value: 'Gera um banner Canvas com foto e nick.', inline: true },
            { name: '⚙️ /painel', value: 'Abre menu de seleção (Select Menu).', inline: true }
          ],
          footer: { text: `BotLoom Engine v14.14.1 • Status: Online` },
          timestamp: true
        }
      ],
      components: [
        {
          type: 'button',
          customId: 'btn_ajuda_info',
          label: 'Ver Status do Servidor',
          style: 'primary'
        },
        {
          type: 'button',
          customId: 'btn_abrir_modal',
          label: 'Testar Modal Discord',
          style: 'success'
        }
      ]
    };
  } else if (cleanCmd === '/ticket' || cleanCmd === '!ticket') {
    responseMessage = {
      ...responseMessage,
      embeds: [
        {
          title: '🎫 Central de Atendimento & Suporte',
          description: 'Clique no botão abaixo para abrir um Ticket privado com a equipe de moderação.',
          color: '#22C55E'
        }
      ],
      components: [
        {
          type: 'button',
          customId: 'btn_abrir_ticket',
          label: '📩 Criar Ticket',
          style: 'success'
        }
      ]
    };
  } else if (cleanCmd === '/painelleilao' || cleanCmd === '!painelleilao' || cleanCmd === '/setup_leilao' || cleanCmd === '!setup_leilao' || cleanCmd === '!leilao' || cleanCmd === '/leilao' || command === 'iniciar_anuncio_leilao' || command === 'criar_leilao') {
    responseMessage = {
      ...responseMessage,
      embeds: [
        {
          title: '🔨 Anunciar Leilão',
          description: '# Criar Leilão de Pet / Item\n\nClique no botão abaixo para preencher os dados e iniciar o anúncio do seu pet no leilão!\n\n**Categorias disponíveis:**\n- 💎 **500M PG**\n- 🧠 **Brainrot**\n- 🔮 **Secret**\n- ⚡ **Godly**\n- 👑 **OG**\n- 📦 **Geral**',
          color: '#FF0000'
        }
      ],
      components: [
        {
          type: 'button',
          customId: 'iniciar_anuncio_leilao',
          label: '🔨 Anunciar Leilão',
          style: 'success'
        }
      ]
    };
  } else if (customId === 'iniciar_anuncio_leilao' || customId === 'criar_leilao' || customId === 'btn_criar_leilao' || customId === 'anunciar_leilao' || customId === 'setup_leilao') {
    return res.json({
      showModal: true,
      modalData: {
        title: 'Anunciar Leilão',
        customId: 'modal_anuncio_1',
        fields: [
          { customId: 'desc', label: 'Descrição do Pet / Item', placeholder: 'Ex: 500M PG, Huge Cat, Dragon' },
          { customId: 'valor', label: 'Valor In-Game / Stats', placeholder: 'Ex: 500M Gems, 10M Dmg' },
          { customId: 'min', label: 'Lance Inicial (R$)', placeholder: 'Ex: 10.00' },
          { customId: 'max', label: 'Auto-Buy / Comprar Já (R$)', placeholder: 'Ex: 50.00' }
        ]
      }
    });
  } else if (customId === 'btn_abrir_ticket' || customId === 'btn_abrir_modal') {
    // Return modal directive
    return res.json({
      showModal: true,
      modalData: {
        title: '🎫 Formulário de Ticket de Suporte',
        customId: 'modal_submit_ticket',
        fields: [
          { customId: 'field_subject', label: 'Assunto do Ticket', placeholder: 'Ex: Dúvida sobre comandos ou VIP' },
          { customId: 'field_details', label: 'Detalhamento da solicitação', placeholder: 'Descreva em detalhes o que precisa...' }
        ]
      }
    });
  } else if (interactionType === 'modal_submit' && customId === 'modal_anuncio_1') {
    const desc = inputFields?.desc || '500M PG';
    const valor = inputFields?.valor || '500M Gems';
    const min = inputFields?.min || '10.00';
    const max = inputFields?.max || '50.00';
    responseMessage = {
      ...responseMessage,
      content: `📌 **Canal criado:** \`#ticket-usuario\` (Aberto por @UsuárioTeste)`,
      embeds: [
        {
          title: `🔨 Anúncio de Leilão - ${desc}`,
          description: `# Etapa 1 — Seleção de Categoria\n\n**Item:** ${desc}\n**Valor in-game:** ${valor}\n**Lance inicial:** R$ ${min}\n**Auto-Buy:** R$ ${max}\n\n📸 **Envie as fotos do seu pet no chat e selecione a categoria abaixo para gerar a taxa Pix.**`,
          color: '#FF0000'
        }
      ],
      components: [
        {
          type: 'select',
          customId: 'select_categoria_leilao',
          placeholder: 'Selecione a Categoria do Pet',
          options: [
            { label: '500M PG', value: '1.00_500M PG', description: 'Categoria 500M PG (Pet Go)' },
            { label: 'Brainrot', value: '1.00_Brainrot', description: 'Pets Brainrot' },
            { label: 'Secret', value: '1.00_Secret', description: 'Pets Secret' },
            { label: 'Godly', value: '1.00_Godly', description: 'Pets Godly' },
            { label: 'OG', value: '1.00_OG', description: 'Pets/Itens OG' },
            { label: 'Geral', value: '1.00_Geral', description: 'Outras categorias de Leilão' }
          ]
        }
      ]
    };
  } else if (customId === 'select_categoria_leilao' || (interactionType === 'select_menu' && customId === 'select_categoria_leilao')) {
    const selected = (values && values[0]) || '1.00_500M PG';
    const catName = selected.includes('_') ? selected.split('_')[1] : '500M PG';
    responseMessage = {
      ...responseMessage,
      embeds: [
        {
          title: `💳 Pagamento da Taxa de Anúncio (${catName})`,
          description: `# Pagamento da Taxa Pix\n\n**Valor da Taxa:** R$ 1,00\n**Categoria Selecionada:** ${catName}\n**Total de fotos enviadas:** 1\n\n*Escaneie o QR Code ou clique em **Copiar Pix** para realizar o pagamento.*`,
          color: '#22C55E',
          imageUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=00020101021126580014br.gov.bcb.pix0121Kauaantunes310@gmail.com52040000530398654041.005802BR5922KAUA%20ANTUNES%20MARTINS6009SAO%20PAULO62090505LEILAO6304'
        }
      ],
      components: [
        { type: 'button', customId: 'copy_pix', label: 'Copiar Pix', style: 'secondary' },
        { type: 'button', customId: 'aprovar_final', label: 'Postar Leilão', style: 'success' },
        { type: 'button', customId: 'reivindicar_pagamento', label: 'Reivindicar Pagamento', style: 'primary' },
        { type: 'button', customId: 'fechar_ticket', label: 'Fechar Ticket', style: 'danger' }
      ]
    };
  } else if (customId === 'aprovar_final') {
    responseMessage = {
      ...responseMessage,
      content: `🎉 **Leilão Criado e Postado com Sucesso!**`,
      embeds: [
        {
          title: '🔨 Leilão Ativo - 500M PG Pet',
          description: 'Novo leilão registrado na plataforma!',
          color: '#FF0000',
          fields: [
            { name: '🏷️ Categoria', value: '500M PG', inline: true },
            { name: '👑 Vendedor', value: '@UsuárioTeste', inline: true },
            { name: '💎 Valor in-game', value: '500M Gems', inline: true },
            { name: '💰 Lance Atual', value: 'R$ 10.00', inline: true },
            { name: '📈 Incremento Mínimo', value: 'R$ 1.00', inline: true },
            { name: '⚡ Auto-Buy', value: 'R$ 50.00', inline: true }
          ]
        }
      ],
      components: [
        { type: 'button', customId: 'btn_dar_lance', label: 'Dar Lance 💸', style: 'success' },
        { type: 'button', customId: 'btn_comprar_ja', label: 'Comprar Já ⚡', style: 'primary' }
      ]
    };
  } else if (interactionType === 'modal_submit') {
    const subject = inputFields?.field_subject || 'Suporte Geral';
    const details = inputFields?.field_details || 'Nenhum detalhe informado';
    responseMessage = {
      ...responseMessage,
      content: `✅ **Ticket Criado com Sucesso!**`,
      embeds: [
        {
          title: `🎫 Ticket: ${subject}`,
          description: `**Detalhes:** ${details}\n\n*Um moderador responderá em breve.*`,
          color: '#3B82F6',
          footer: { text: 'Sistema de Tickets BotLoom' }
        }
      ]
    };
  } else {
    // Default fallback interaction response
    responseMessage = {
      ...responseMessage,
      content: `⚙️ **[${bot.name}]** Comando \`${command || customId || 'executar'}\` processado com sucesso!`,
      embeds: [
        {
          title: '✅ Execução de Comando',
          description: `Comando executado sem erros pelo motor **discord.js v14** da BotLoom Hosting.`,
          color: '#5865F2'
        }
      ]
    };
  }

  saveBots(botsStore);
  res.json({ message: responseMessage });
});

// Serve frontend with Vite middleware in development or express.static in production
async function start() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      const indexPath = path.join(distPath, 'index.html');
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(200).send('BotLoom Hosting is running');
      }
    });
  }

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`[BOTLOOM SERVER] Servidor rodando na porta ${PORT}`);
    
    // Auto-connect bots that are marked as online or starting
    botsStore.forEach(bot => {
      if (bot.status === 'online' || bot.status === 'starting') {
        console.log(`[BOTLOOM] Conectando bot "${bot.name}" ao Discord Gateway...`);
        startDiscordClient(bot);
      }
    });

    // ⚡ MOTOR ENGINE 24/7 WATCHDOG & AUTO-HEAL: Mantém os bots e o servidor ativos 24/7 sem sobrecarga
    const lastReconnectAttempt = new Map<string, number>();

    setInterval(() => {
      try {
        const now = Date.now();

        // 1. Gateway WebSocket Keep-Alive Ping
        sharedGatewayClients.forEach((client) => {
          try {
            if (client && client.ws && typeof (client.ws as any).ping === 'function') {
              (client.ws as any).ping();
            }
          } catch (e) {}
        });

        // 2. Auto-Heal & Auto-Reconnect agrupado por Token
        // Intervalo mínimo de 3 minutos para evitar Rate Limit e picos de CPU
        const tokensToReconnect = new Set<string>();
        botsStore.forEach(bot => {
          if (bot.status === 'online' && bot.autoRestart !== false) {
            const token = extractToken(bot);
            if (token && !token.startsWith('BOTLOOM_')) {
              const client = sharedGatewayClients.get(token);
              if (client && !client.isReady() && client.ws && client.ws.status !== 0) {
                tokensToReconnect.add(token);
              }
            }
          }
        });

        tokensToReconnect.forEach(token => {
          const lastAttempt = lastReconnectAttempt.get(token) || 0;
          if (now - lastAttempt >= 180000) {
            lastReconnectAttempt.set(token, now);
            const targetBot = botsStore.find(b => b.status === 'online' && extractToken(b) === token);
            if (targetBot) {
              console.log(`[WATCHDOG 24/7] Gateway desconectado para "${targetBot.name}". Tentando reconexão...`);
              startDiscordClient(targetBot).catch(e => console.error(`[WATCHDOG 24/7] Erro ao reconectar ${targetBot.name}:`, e));
            }
          }
        });
      } catch (err) {
        console.error('[WATCHDOG 24/7 ERRO]', err);
      }
    }, 15000);

    // 🌐 SELF-PING KEEPALIVE ENGINE (Every 25 seconds)
    // Mantém o container aquecido e o loop de eventos 100% ativo sem entrar em hibernação
    setInterval(() => {
      // 1. Loopback ping interno
      try {
        const req = http.get(`http://127.0.0.1:${PORT}/api/ping`, { timeout: 3000 }, (res: any) => {
          res.resume();
        });
        req.on('error', () => {});
      } catch (e) {}

      // 2. Ping HTTPS externo na URL pública (impede que o Cloud Run hiberne por 15 min de inatividade)
      if (detectedPublicOrigin && detectedPublicOrigin.startsWith('https://')) {
        try {
          const extReq = https.get(`${detectedPublicOrigin}/ping`, { timeout: 4000 }, (res: any) => {
            res.resume();
          });
          extReq.on('error', () => {});
        } catch (e) {}
      }
    }, 25000);

    // ⏰ MONGODB AUTO-BACKUP SCHEDULER (Runs every 60 seconds)
    let lastScheduledRunMinute = '';
    setInterval(async () => {
      try {
        const config = appDatabase?.config?.autoBackupMongo;
        if (!config || !config.enabled) return;

        const mongoStat = getMongoStatus();
        if (!mongoStat.connected) return;

        const now = new Date();
        const currentHourMin = now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', hour12: false });
        const currentMinuteKey = `${now.toISOString().slice(0, 10)}_${currentHourMin}`;

        if (currentMinuteKey === lastScheduledRunMinute) return;

        const targetTime = config.executionTime || '03:00';
        let shouldRun = false;

        if (config.frequency === 'daily') {
          shouldRun = (currentHourMin === targetTime);
        } else if (config.frequency === 'weekly') {
          const currentDayOfWeek = now.getDay();
          const targetDay = config.dayOfWeek !== undefined ? Number(config.dayOfWeek) : 1;
          shouldRun = (currentDayOfWeek === targetDay && currentHourMin === targetTime);
        } else if (config.frequency === 'every_6h') {
          const hour = now.getHours();
          const minute = now.getMinutes();
          shouldRun = (hour % 6 === 0 && minute === 0);
        } else if (config.frequency === 'every_12h') {
          const hour = now.getHours();
          const minute = now.getMinutes();
          shouldRun = (hour % 12 === 0 && minute === 0);
        }

        if (shouldRun) {
          lastScheduledRunMinute = currentMinuteKey;
          console.log(`⏰ [AUTO-BACKUP MONGODB] Disparando backup programado (${config.frequency} às ${currentHourMin})...`);
          const res = await backupBotFilesToMongo(
            botsStore,
            config.frequency === 'weekly' ? 'weekly' : 'daily',
            undefined,
            config.selectedBotIds,
            config.includeDatabaseFiles !== false,
            appDatabase
          );

          if (!appDatabase.config) appDatabase.config = {};
          if (!appDatabase.config.autoBackupMongo) appDatabase.config.autoBackupMongo = { ...DEFAULT_BACKUP_CONFIG };
          appDatabase.config.autoBackupMongo.lastRun = {
            timestamp: new Date().toISOString(),
            status: res.success ? 'success' : 'error',
            backupId: res.backupId,
            message: res.success ? 'Backup automático executado com sucesso' : res.error,
            totalBots: res.stats?.totalBots,
            totalFiles: res.stats?.totalFiles,
            sizeKb: res.stats?.sizeKb
          };
          saveAppDatabase();
        }
      } catch (err) {
        console.error('❌ [ERRO AUTO-BACKUP SCHEDULER]', err);
      }
    }, 60000);
  });

  process.on('uncaughtException', (err) => {
    console.error('⚠️ [24/7 ENGINE GUARD] Uncaught Exception capturada (processo e site mantidos 100% online):', err?.stack || err);
  });

  process.on('unhandledRejection', (reason: any) => {
    console.error('⚠️ [24/7 ENGINE GUARD] Unhandled Rejection capturado (processo e site mantidos 100% online):', reason?.stack || reason);
  });

  server.on('error', (err: any) => {
    console.error('[BOTLOOM SERVER] Erro no servidor:', err);
  });

  process.on('SIGINT', async () => {
    await disconnectFromMongoDB();
    process.exit(0);
  });
  process.on('SIGTERM', async () => {
    await disconnectFromMongoDB();
    process.exit(0);
  });
}

start();
