// Production entrypoint wrapper
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

if (fs.existsSync(path.join(__dirname, 'server.cjs'))) {
  await import('./server.cjs');
} else if (fs.existsSync(path.join(__dirname, 'dist', 'server.cjs'))) {
  await import('./dist/server.cjs');
} else {
  await import('./server.ts');
}
